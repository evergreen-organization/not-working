export const ERROR_TITLE_NEW_DEVICE = 'New device detected.'
export const ERROR_MSG_NEW_DEVICE = 'Please proceed to register and create new PIN for this device.'
export const ERROR_TITLE_INVALID_PROFILE = 'Profile not found.'
export const ERROR_MSG_INVALID_PROFILE = 'Account might be removed by your parent.'
export const ERROR_TITLE_MAX_ATTEMPT = 'You have exceeded the number of login attempts.'
export const ERROR_MSG_MAX_ATTEMPT = 'Please reset your Login PIN.'
export const NEW_DEVICE_STATUS = "N"
export const INVALID_PROFILE_STATUS  = "P"
export const LOADING_TITLE_VERIFY = 'Verifying accounts'
export const LOADING_TITLE_LOGIN = 'Logging in'
export const INVALID_FIELDS_TITLE= 'Invalid fields.'
export const INVALID_FLIEDS_DESC= 'Please fill in valid value.'
export const EMPTY_FLIEDS_TITLE= 'Empty fields.'
export const EMPTY_FLIEDS_DESC= 'Please fill in all mandatory fields.'
export const TRY_AGAIN_MSG= 'Please try again later.'
export const SPECIAL_CHAR_ONLY_MSG= 'Maximum of 12 alphanumeric character only'

export const PARENT_MYKAD_LABEL = "Parent's MyKad No. / Passport No."
export const USER_MYKID_LABEL = "Child's MyKad No. / MyKid No. / Passport No."
export const JOIN_US_LABEL = "Start your financial journey with us now!"

