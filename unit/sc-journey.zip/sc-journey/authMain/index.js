import React, {
  useRef,
  useState,
  useEffect
} from 'react';
import {
  Alert,
  Dimensions,
  Keyboard,
  Platform
} from 'react-native';
import {
  useDispatch,
  useSelector
} from 'react-redux';
import demoJson from 'assets/demo.json';
import { showInfo } from '../../../components/flashMsg';
import routes from '../../../navigations/routes';
import {
  ApiException,
  checkInternet
} from '../../../services/serviceUtils';
import {
  getUser,
  requestEnquireAccount,
  requestLogin,
  storeAccount,
  storeGoal,
  storeParent,
  storeTask,
  storeUser,
  unbind,
  storeSecret
} from '../../../store';
import {
  decryptReduxKey,
  encryptReduxKey,
  isEven
} from '../../../utilities/all';
import { useDemo } from '../../../utilities/demo';
import { AuthView } from './component';
import {
  EMPTY_FLIEDS_DESC,
  EMPTY_FLIEDS_TITLE,
  ERROR_MSG_INVALID_PROFILE,
  ERROR_MSG_MAX_ATTEMPT,
  ERROR_MSG_NEW_DEVICE,
  ERROR_TITLE_INVALID_PROFILE,
  ERROR_TITLE_MAX_ATTEMPT,
  ERROR_TITLE_NEW_DEVICE,
  INVALID_FIELDS_TITLE,
  INVALID_FLIEDS_DESC,
  INVALID_PROFILE_STATUS,
  LOADING_TITLE_LOGIN,
  LOADING_TITLE_VERIFY,
  NEW_DEVICE_STATUS,
  TRY_AGAIN_MSG
} from './data';
import {
  ERROR_MSG_CONVERTED_PLUS,
  ERROR_TITLE_CONVERTED_PLUS,
  MSG_CONVERTED_TO_PLUS
} from 'constant';
import packageJson from '../../../../package.json';
import { getSystemVersion } from 'react-native-device-info';
import { useCustomKeyboard } from 'react-native-custom-keyboard';


const window = Dimensions.get('window')

const Auth = ({ navigation }) => {
  const demoHook = useDemo()
  const dispatch = useDispatch()
  const user = useSelector(getUser)
  const { hideCustomKeyboard, isVisible: isCustomKeyboardVisible } = useCustomKeyboard()

  // const [cursor] = useState(new Animated.Value(0))
  // const [recaptcha, setRecaptcha] = useState(true);
  const [mainLoading, setMainLoading] = useState(false)
  const [refreshPin, setRefreshPin] = useState(false)
  const [loadingTitle, setLoadingTitle] = useState('')
  const [parentIC, setParentIC] = useState('')//880301105132
  const [ownIC, setOwnIC] = useState('')//180210105132
  const [currentFocus, setCurrentFocus] = useState(0)
  const [attempt, setAttempt] = useState(0)

  /*
    WISE savigns acc no: 5000096730
    PLUS savings acc no: 5000096633

  */

    useEffect(() => {  
      if (!(demoHook.isDemo(parentIC, ownIC))) {
        if (user.id && !validateICUtf8(decryptReduxKey(user.id))) {
          Alert.alert(
            'Security', 
            'Security update detected. Please log in again.',
            [
              {
                text: 'OK',
                onPress: () => {
                  dispatch(unbind());
                },
              },
            ],
            { cancelable: false }  
          );
        }
    
        if (user.encryptedId) {
          dispatch(unbind());
        }
      }
    }, [user, dispatch]);


  const validateICUtf8 = (text) => {
    const regex = /^[a-zA-Z0-9]{1,12}$/;
    return regex.test(text);
  };

  const validateIC = (text) => {
    const regex = /^[a-zA-Z0-9]{1,12}$/
    return text === '' ? true : regex.test(text)
  }

  const preAccEnquiry = () => {
    if (Platform.OS === 'ios')
      Keyboard.dismiss()
    else {
      setCurrentFocus(0)
      hideCustomKeyboard()
    }

    if (parentIC !== '' && ownIC !== '') {
      if (validateIC(parentIC) && validateIC(ownIC)) {
        setLoadingTitle(LOADING_TITLE_VERIFY)
        setMainLoading(true)
        accEnquiry()
      } else {
        Alert.alert(INVALID_FIELDS_TITLE, INVALID_FLIEDS_DESC)
      }
    } else {
      Alert.alert(EMPTY_FLIEDS_TITLE, EMPTY_FLIEDS_DESC)
    }
  }

  //Acc Enquiry - Start
  const accEnquiry = async () => {
    if (demoHook.isDemo(parentIC, ownIC)) {
      setMainLoading(false)
      const { error } = await checkInternet()
      if (error === ApiException.NO_INTERNET) return Alert.alert(error.MSG, TRY_AGAIN_MSG)
      dispatch(storeUser({
        id: demoJson.childId,
        childName: encryptReduxKey(demoJson.accName),
        accNo: '',
        birthCertNo: '',

        //TODO:start
        isConverted: demoJson.isConverted
        //TODO:end

      }))
      dispatch(storeSecret({
        token: demoJson.token
      }))
      dispatch(storeParent({
        id: demoJson.parentId,
        name: encryptReduxKey(demoJson.parentName),
        mobileNo: demoJson.mobileNo
      }))
      dispatch(storeAccount({
        accNo: demoJson.voAccNo,
        balance: demoJson.accBal
      }))
      dispatch(storeGoal({
        goalList: demoJson.goalList,
      }))
      dispatch(storeTask({
        taskList: demoJson.taskList
      }))
    } else {
      const { payload } = await dispatch(requestEnquireAccount({ parentId: parentIC, childId: ownIC }))
      setMainLoading(false)
      if (payload?.accExists) return navigation.navigate(routes.INITIAL_PIN_SETUP, {
        parentId: parentIC,
        childId: ownIC
      })
    }
  }

  const login = async (pin) => {
    setLoadingTitle(LOADING_TITLE_LOGIN)
    setMainLoading(true)

    const appVersion = packageJson.version;
    const osVersion = getSystemVersion();
    const { payload, error } = await dispatch(requestLogin({ user, pin, appVersion, osVersion }))

    setMainLoading(false)
    if (error) {
      if (payload.requireErrorHandler || payload.errorType === ApiException.NO_INTERNET) return handleLoginError(payload)
      return setRefreshPin(!refreshPin)
    }
  }


  const handleLoginError = (result) => {
    const { status, data } = result
    if (status === NEW_DEVICE_STATUS) {
      showInfo([ERROR_TITLE_NEW_DEVICE, ERROR_MSG_NEW_DEVICE])
      return dispatch(unbind())
    }

    if (status === INVALID_PROFILE_STATUS) {
      showInfo([ERROR_TITLE_INVALID_PROFILE, ERROR_MSG_INVALID_PROFILE])
      return dispatch(unbind())
    }

    if (data?.Response?.converted === MSG_CONVERTED_TO_PLUS) {
      showInfo([ERROR_TITLE_CONVERTED_PLUS, ERROR_MSG_CONVERTED_PLUS])
      return dispatch(unbind())
    }

    if (data?.Response?.pinAttempt === 3) {
      showInfo([ERROR_TITLE_MAX_ATTEMPT, ERROR_MSG_MAX_ATTEMPT])
      return dispatch(unbind())
    }

    if (data?.Response) {
      setAttempt(data.Response.pinAttempt)
      return setRefreshPin(!refreshPin)
    }
    setRefreshPin(!refreshPin)
  }

  const focus = {
    1: { value: parentIC, updateState: setParentIC },
    2: { value: ownIC, updateState: setOwnIC },
  };

  const onType = (val) => {
    const currentVal = focus[currentFocus].value

    const newValue = currentVal.length < maxLength ? currentVal.padEnd(currentVal.length + 1, val) : ''

    if (newValue.length > 0) {
      updateIC(newValue);
    }
  }


  const onDelete = () => {
    const val = focus[currentFocus].value
    const newValue = val.substring(0, val.length - 1)
    updateIC(newValue)
  }

  const onDeleteAll = () => {
    updateIC('')
  }

  const updateIC = (value) => focus[currentFocus].updateState(value)

  const onUnbind = () => {
    dispatch(unbind())
  }

  const onParentIcChange = (text) => setParentIC(text)
  const onChildIcChange = (text) => setOwnIC(text)
  const dismissKeyboard = () => {
    Keyboard.dismiss()
    hideCustomKeyboard()
  }

  const props = {
    window,
    onKeyboardDismiss: dismissKeyboard,
    iOS: Platform.OS === 'ios',
    userGender: user.id && isEven(decryptReduxKey(user.id)),
    encryptId: user.encryptId,
    onLogin: login,
    refreshPin,
    attempt,
    onUnbind,
    currentFocus,
    parentIC,
    setParentIC,
    setCurrentFocus,
    validateIC,
    ownIC,
    setOwnIC,
    preAccEnquiry,
    mainLoading,
    loadingTitle,
    onType,
    onDelete,
    onDeleteAll,
    onParentIcChange,
    onChildIcChange,
    isCustomKeyboardVisible
  }

  return <AuthView {...props} />
}

export default Auth
