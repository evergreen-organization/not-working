import React from 'react';
import {
  Image,
  ImageBackground,
  KeyboardAvoidingView,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View
} from 'react-native';
import BoyIcon from 'assets/images/avatar/boy.png';
import DadIcon from 'assets/images/avatar/dad.png';
import GirlIcon from 'assets/images/avatar/girl.png';
import MomIcon from 'assets/images/avatar/mom.png';
import JourneyIcon from 'assets/images/pbJourney.png';
import PinkBg from 'assets/images/bg3.png';
import BlueBg from 'assets/images/bg2.png';
import {
  gStyles,
  Icon,
  MainLoading,
} from '../../../components';
import { Text } from '../../../components/atoms/text';
import { EnterPin } from '../../../components/enterPin';
import {
  JOIN_US_LABEL,
  PARENT_MYKAD_LABEL,
  USER_MYKID_LABEL
} from './data';
import { styles } from './styles';
import { ICInput } from 'organisms';
import { isEven } from 'utilities';

export const AuthView = (props) => {
  const {
    window,
    onKeyboardDismiss,
    iOS,
    userGender,
    encryptId,
    onLogin,
    refreshPin,
    attempt,
    onUnbind,
    currentFocus,
    parentIC,
    setCurrentFocus,
    ownIC,
    preAccEnquiry,
    mainLoading,
    loadingTitle,
    onParentIcChange,
    onChildIcChange,
    isCustomKeyboardVisible
  } = props

  return (
    <View style={gStyles.container}>
      {/* {recaptcha && <Recaptcha onSuccess={(token) => recaptchaSuccess(token)} />} */}
      <TouchableWithoutFeedback onPress={onKeyboardDismiss} accessible={false}>
        <KeyboardAvoidingView
          style={[
            { flex: 1 },
            !iOS && isCustomKeyboardVisible && {
              paddingBottom: window.height * 0.3,
            },
          ]}
          behavior={iOS ? 'padding' : 'height'}>
          <ImageBackground
            source={userGender ? PinkBg : BlueBg}
            style={{ flex: 1, justifyContent: 'center' }}>
            {encryptId ? (
              <EnterPin
                showForgotPin={true}
                submit={(pin) => onLogin(pin)}
                refresh={refreshPin}
                onSetAttempt={attempt}
                showBiometric={true}
                onUnbind={onUnbind}
              />
            ) : (
              <>
                <View style={styles.loginICcontainer}>
                  <View
                    style={[
                      styles.journeyImageContainer,
                      { marginTop: -(window.width * 0.45 * 0.5) },
                    ]}>
                    <Image
                      source={JourneyIcon}
                      style={{
                        width: window.width * 0.45,
                        height: (window.width * 0.45) / 1.5,
                      }}
                    />
                  </View>
                  {currentFocus === 0 && (
                    <View style={{ marginBottom: 30 }}>
                      <Text as={Text.type.P5} style={styles.joinUsText}>
                        {JOIN_US_LABEL}
                      </Text>
                    </View>
                  )}

                  <ICInput
                    iOS={iOS}
                    style={{ marginBottom: 20 }}
                    ICValue={parentIC}
                    label={PARENT_MYKAD_LABEL}
                    onChangeText={onParentIcChange}
                    image={isEven(parentIC.substr(parentIC.length - 1)) ? MomIcon : DadIcon}
                    currentFocus={currentFocus}
                    setCurrentFocus={setCurrentFocus}
                    focusNum={1}
                    window={window}
                  />

                  <ICInput
                    iOS={iOS}
                    style={{ marginBottom: 40 }}
                    ICValue={ownIC}
                    label={USER_MYKID_LABEL}
                    onChangeText={onChildIcChange}
                    image={isEven(ownIC.substr(ownIC.length - 1)) ? GirlIcon : BoyIcon}
                    currentFocus={currentFocus}
                    setCurrentFocus={setCurrentFocus}
                    focusNum={2}
                    window={window}
                  />

                </View>

                <TouchableOpacity
                  onPress={() => preAccEnquiry()}
                  style={styles.searchButton}>
                  <View style={styles.searchIconContainer}>
                    <Icon.FontAwesome name="search" style={styles.searchIcon} />
                  </View>
                </TouchableOpacity>
              </>
            )}
          </ImageBackground>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>

      {mainLoading && <MainLoading title={loadingTitle} />}
    </View>
  )
}
