import React from 'react';
import {
  Image,
  View
} from 'react-native';
import { Text } from 'atoms';
import { colors } from 'styles';
import { styles } from './styles';
import {
  gStyles,
  TextHelper,
  TextInput
} from 'components';
import { CustomTextInput } from 'react-native-custom-keyboard';
import { SPECIAL_CHAR_ONLY_MSG } from 'screens/auth/authMain/data';

export const ICInput = ({
  iOS,
  style,
  ICValue,
  label,
  onChangeText,
  image,
  currentFocus,
  setCurrentFocus,
  focusNum,
  window
}) => {
  const hasSpecialCharacters = /[^a-zA-Z0-9]/.test(ICValue);

  return (
    <View style={style}>
      <Text
        as={Text.type.H6}
        style={{
          color:
            ICValue === '' ? colors.textBlack : colors.textGrey,
        }}>
        {label}
      </Text>
      <View>
        {iOS ? (
          <TextInput
            bold
            keyboardType={'default'}
            maxLength={12}
            style={[gStyles.textInput, { flex: 0 }]}
            value={ICValue}
            onChangeText={onChangeText}
            onFocus={() => setCurrentFocus(focusNum)}
            onBlur={() => setCurrentFocus(0)}
          />
        ) : (
          <View>
            <CustomTextInput
              accessibilityLabel={label}
              maxLength={12}
              style={[
                styles.textInput,
                styles.androidKeyboardInput,
                { width: window.width * 0.83 },
                currentFocus === focusNum && styles.textInputOnFocus,
              ]}
              selectionColor={colors.primary}
              value={ICValue}
              onChangeText={onChangeText}
              onFocus={() => setCurrentFocus(focusNum)}
              onBlur={() => setCurrentFocus(0)}
            />
          </View>
        )}
        <View style={styles.personIconContainer}>
          {ICValue.length === 12 && (
            <Image
              source={image}
              style={styles.personIcon}
            />
          )}
        </View>
      </View>
      <TextHelper
        isValid={!hasSpecialCharacters}
        errorMsg={SPECIAL_CHAR_ONLY_MSG}
        length={ICValue.length}
        maxLength={12}
        showCount={currentFocus === focusNum}
      />
    </View>
  );
};
