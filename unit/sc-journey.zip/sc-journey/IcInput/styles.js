import { StyleSheet } from "react-native";
import { FONT_FAMILY_SEMIBOLD } from 'styles';

export const styles = StyleSheet.create({
  textInput: {
    marginTop: 15,
    paddingTop: 15,
    paddingBottom: 15,
    borderBottomColor: '#CCC',
    borderBottomWidth: 1
  },
  textInputOnFocus: {
    borderBottomColor: '#rgba(79, 155, 216, 1)',
    borderBottomWidth: 2.5
  },
  androidKeyboardInput: {
    color: '#000',
    fontFamily: FONT_FAMILY_SEMIBOLD,
    fontSize: 18,
    paddingHorizontal: 0
  },
  personIconContainer: {
    position: 'absolute', right: 0
  },
  personIcon: {
    width: 40, height: 40
  },

})
