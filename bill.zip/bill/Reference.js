import React, { useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import dayjs from 'dayjs';

import routes from 'navigations/routes';
import {
  billEnquiryInit,
  convertTrailerDropDown,
  getBillerDetailByCode,
  getBillers,
  getNewBill,
  categorizeTrailers,
  getVisibleTrailersById,
  newBillUpdated,
  updateNewBillObject,
  filterBillCountries,
} from 'stores';
import { colors } from 'configs';
import { billFieldType, BILL_FIELD_DYNAMIC_IND, rnCalendarDateFormat, validationMsg } from 'constant';
import {
  Form,
  FormButtonBottom,
  FormConditionalDisplay,
  FormDateCalendarPicker,
  FormField,
  FormPicker,
  Tag,
  Text,
} from 'components';
import { Screen, Info, SkeletonBillerReference, AvoidKeyboard } from 'atoms';
import { NavBar } from 'organisms';
import { LOADING, SUCCESS } from 'apis';
import { removeBillsRefsFromNewBill, removeDynamicBillRefs, removeEmptyBillRefs } from '../utils';
import { BottomDrawerModalMini } from 'molecules';
import { useTranslation } from 'react-i18next';
import { convertAmountByRate, utc8DateTime } from 'utils';

const LANG_PREFIX = 'screens.billReference.text.';
const currency = 'RM';

export const Reference = ({ navigation }) => {
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const billerStatus = useSelector(getBillers).status;
  const newBill = useSelector(getNewBill) || {};
  const { billerCode } = newBill;
  const { billerId, isAmountRequired } = useSelector(getBillerDetailByCode({ billerCode })) || {};
  const trailers = useSelector(getVisibleTrailersById({ billerId }));
  const { stateTrailer, countryTrailer, remainingTrailers } = categorizeTrailers(trailers);
  const [modalHelpVisible, setModalHelpVisible] = useState(false);
  const [amountByUnitPrice, setAmountByUnitPrice] = useState(null);
  const [initialValues, setInitialValues] = useState(null);

  const createSchema = trailers => {
    let schema = {};
    for (let trailer of trailers) {
      if (trailer.format === billFieldType.TEXT_BOX || trailer.format === billFieldType.TEXT_BOX_SPECIAL) {
        if (trailer.mandatory) {
          schema[`rrn${trailer.sequence}`] = Yup.string()
            .required(t(validationMsg.required))
            .label(trailer.name)
            .matches(
              new RegExp('^(' + trailer.inputFormat + ')$', 'g'),
              t(`${LANG_PREFIX}invalid`).replace('${trailerName}', trailer.name),
            );
        } else {
          schema[`rrn${trailer.sequence}`] = Yup.string()
            .label(trailer.name)
            .matches(
              new RegExp('^(' + trailer.inputFormat + ')$', 'g'),
              t(`${LANG_PREFIX}invalid`).replace('${trailerName}', trailer.name),
            );
        }
      } else {
        //Drop Down & Calendar
        if (trailer.mandatory) {
          schema[`rrn${trailer.sequence}`] = Yup.string().required(t(validationMsg.required)).label(trailer.name);
        } else {
          schema[`rrn${trailer.sequence}`] = Yup.string().label(trailer.name);
        }
      }
    }
    return schema;
  };

  const schema = createSchema(trailers);
  const validationSchema = Yup.object().shape(schema);

  useEffect(() => {
    start();
  }, []);

  const start = () => {
    const item = removeDynamicBillRefs({
      obj: newBill,
      trailers,
    });
    dispatch(updateNewBillObject({ ...item }));

    let values = {};
    for (let trailer of trailers) {
      const value = newBill[`rrn${trailer.sequence}`];
      if (trailer.dynamicInd === BILL_FIELD_DYNAMIC_IND.FIXED && value) {
        values[`rrn${trailer.sequence}`] = value;
        if (trailer.unitPrice) {
          updateAmountByUnitPrice(value, trailer.unitPrice);
        }
      } else values[`rrn${trailer.sequence}`] = '';
    }

    setInitialValues(values);
  };

  const onSubmit = item => {
    const obj = removeBillsRefsFromNewBill(newBill);
    const refs = removeEmptyBillRefs(item);
    dispatch(newBillUpdated({ ...obj, ...refs }));

    //Move logics from Amount.js, some billers do not require amount entry
    dispatch(updateNewBillObject({ currency, amount: 0, billerId }));
    dispatch(billEnquiryInit());

    if (isAmountRequired) return navigation.navigate(routes.BILL_AMOUNT);

    // If unitPrice found from trailers and user entered value in trailer,
    // to calculate total amount and dispatch to redux store
    checkUnitPrice(refs);

    navigation.navigate(routes.BILL_CONFIRMATION);
  };

  const checkUnitPrice = refs => {
    const trailer = trailers.find(a => a.unitPrice);
    if (!trailer) return;

    for (const key in refs) {
      if (trailer.sequence.toString() === key.substring(3, key.length)) {
        const amount = convertAmountByRate({ amount: refs[key], rate: trailer.unitPrice, toDivide: false });
        dispatch(updateNewBillObject({ amount }));
        break;
      }
    }
  };

  const updateAmountByUnitPrice = (unit, rate) => {
    const amount = convertAmountByRate({ amount: unit, rate, toDivide: false });
    setAmountByUnitPrice(amount);
  };

  const onInputChanged = (item, val) => {
    if (item.unitPrice) {
      updateAmountByUnitPrice(val, item.unitPrice);
    }
  };

  const renderDropDown = item => {
    if (!item.inputFormat) return;
    const data = convertTrailerDropDown(item.inputFormat);

    return (
      <FormPicker name={`rrn${item.sequence}`} label={item.name} data={data} dataLabel={'name'} dataValue={'id'} />
    );
  };

  const renderDropDownCountry = item => {
    if (!item.inputFormat) return;
    const data = convertTrailerDropDown(item.inputFormat);
    const { malaysia, remainingCountries } = filterBillCountries(data);

    return (
      <>
        <FormConditionalDisplay condition={values => values[`rrn${stateTrailer.sequence}`] === '99'}>
          <FormPicker
            name={`rrn${item.sequence}`}
            label={item.name}
            enableSearch={true}
            data={remainingCountries}
            dataLabel={'name'}
            dataValue={'id'}
          />
        </FormConditionalDisplay>

        <FormConditionalDisplay
          condition={values => {
            const val = values[`rrn${stateTrailer.sequence}`];
            return val && val !== '99';
          }}
        >
          <FormPicker
            name={`rrn${item.sequence}`}
            label={item.name}
            data={malaysia}
            dataLabel={'name'}
            dataValue={'id'}
          />
        </FormConditionalDisplay>
      </>
    );
  };

  const renderField = item => {
    if (item.format === billFieldType.DROP_DOWN) {
      return renderDropDown(item);
    } else if (item.format === billFieldType.CALENDAR) {
      const date = item.dateFormat
        ? dayjs(newBill[`rrn${item.sequence}`], item.dateFormat).format(rnCalendarDateFormat)
        : null;

      let pastScrollRange = item.pastDateMonths;
      let futureScrollRange = item.futureDateMonths;
      if (item.pastDateMonths === 0 && item.futureDateMonths === 0) {
        //API sends past and future indicator 0 to allow all date selection, set 120 months to allow 10 years past/future
        pastScrollRange = 120;
        futureScrollRange = 120;
      }

      const minDate =
        pastScrollRange || pastScrollRange === 0
          ? utc8DateTime().subtract(pastScrollRange, 'month').add(1, 'day')
          : utc8DateTime();

      const maxDate =
        futureScrollRange || futureScrollRange === 0
          ? utc8DateTime().add(futureScrollRange, 'month')
          : utc8DateTime().add(1, 'year');

      return (
        <View>
          <Text>{item.name}</Text>
          <FormDateCalendarPicker
            name={`rrn${item.sequence}`}
            date={date}
            containerStyle={{ marginBottom: 10 }}
            style={{ height: 45, marginBottom: 5 }}
            fontStyle={{ color: '#000', fontWeight: 'bold' }}
            displayFormat={item.dateFormat}
            minDate={minDate}
            maxDate={maxDate}
            pastScrollRange={pastScrollRange ?? 0}
            futureScrollRange={futureScrollRange ?? 12}
          />
        </View>
      );
    } else {
      return (
        <>
          <FormField
            name={`rrn${item.sequence}`}
            label={item.name}
            labelDesc={
              item.unitPrice && (
                <Text
                  style={{
                    fontSize: 12,
                    color: colors.medium,
                  }}
                >
                  {`${t(LANG_PREFIX + 'unitPrice')} ${currency}${item.unitPrice}`}
                </Text>
              )
            }
            autoCapitalize='none'
            style={{ marginBottom: 5 }}
            onChangeText={val => onInputChanged(item, val)}
          />
          {renderAmountByUnitPrice(item.unitPrice)}
        </>
      );
    }
  };

  const renderAmountByUnitPrice = unitPrice => {
    if (unitPrice && amountByUnitPrice) {
      return (
        <Tag
          title={`${currency}${Number(amountByUnitPrice).toFixed(2)}`}
          style={{ alignSelf: 'flex-start', marginBottom: 15, marginTop: -5 }}
          fontStyle={{ fontSize: 14 }}
        />
      );
    }
  };

  return (
    <Screen>
      {!billerId && billerStatus === SUCCESS ? (
        <>
          <NavBar title={t(LANG_PREFIX + 'emptyTitle')} back />
          <Info title={t(LANG_PREFIX + 'emptyDesc')} style={{ backgroundColor: colors.white }} />
        </>
      ) : (
        <>
          <NavBar title={t(LANG_PREFIX + 'title')} back />
          {billerStatus === LOADING ? (
            <SkeletonBillerReference />
          ) : (
            <AvoidKeyboard>
              {initialValues && (
                <Form
                  initialValues={initialValues}
                  onSubmit={onSubmit}
                  validationSchema={validationSchema}
                  button={<FormButtonBottom title={t(LANG_PREFIX + 'buttonSubmit')} />}
                >
                  <View style={styles.form}>
                    {remainingTrailers?.map((item, index) => (
                      <View key={index}>{renderField(item)}</View>
                    ))}

                    {renderDropDown(stateTrailer)}
                    {renderDropDownCountry(countryTrailer)}
                  </View>
                </Form>
              )}
            </AvoidKeyboard>
          )}
        </>
      )}

      <BottomDrawerModalMini isVisible={modalHelpVisible} closeModal={() => setModalHelpVisible(false)}>
        <View style={{ marginHorizontal: 20, marginVertical: 12 }}>
          <Text>{t(LANG_PREFIX + 'labelHelp')}</Text>
        </View>
      </BottomDrawerModalMini>
    </Screen>
  );
};

const styles = StyleSheet.create({
  form: {
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
});

export default Reference;
