import { createSelector } from '@reduxjs/toolkit';
import _ from 'lodash';

export const getNewBill = createSelector(
  state => state.bankingEntities.bill?.newBill,
  newBill => newBill,
);

export const getNewJompay = createSelector(
  state => state.bankingEntities.bill?.newJompay,
  newJompay => newJompay,
);

export const getBillers = createSelector(
  state => state.bankingEntities.bill?.biller,
  biller => biller,
);

export const getBillFavouriteList = createSelector(
  state => state.bankingEntities.bill?.favourite?.list,
  favourite => favourite,
);

export const getBillFavouriteStatus = createSelector(
  state => state.bankingEntities.bill?.favourite?.favouriteStatus,
  status => status,
);

export const addBillFavouriteStatus = createSelector(
  state => state.bankingEntities.bill?.favourite?.addStatus,
  status => status,
);

export const getBillEnquiry = createSelector(
  state => state.bankingEntities.bill?.billEnquiry,
  billEnquiry => billEnquiry,
);

export const getBillNameInquiry = createSelector(
  state => state.bankingEntities.bill?.nameInquiry,
  nameInquiry => nameInquiry,
);

export const getRecentBill = createSelector(
  state => state.bankingEntities.bill?.recent,
  recent => recent,
);

export const getReversedRecentBill = recent => [...recent].reverse();

export const getBillerDetailById = ({ billerId }) =>
  createSelector(
    state => state.bankingEntities.bill?.biller,
    biller => {
      const item = biller.list?.find(item => item.billerId === billerId);
      return item;
    },
  );

export const getBillerDetailByCode = ({ billerCode }) =>
  createSelector(
    state => state.bankingEntities.bill?.biller,
    biller => {
      const item = biller.list?.find(item => item.giroCode === billerCode);
      return item;
    },
  );

export const getTrailersById = ({ billerId }) =>
  createSelector(
    state => state.bankingEntities.bill?.biller,
    biller => {
      const newList = biller.trailerList?.filter(item => item.billerId === billerId);
      return _.sortBy(newList, 'sequence');
    },
  );

export const getVisibleTrailersById = ({ billerId }) =>
  createSelector(
    state => state.bankingEntities.bill?.biller,
    biller => {
      const newList = biller.trailerList?.filter(item => item.billerId === billerId && !item.toHide);
      return _.sortBy(newList, 'sequence');
    },
  );

export const convertTrailerDropDown = stringData => {
  const optionList = stringData.split(';')?.filter(x => x);
  const data = optionList.map((item, index) => {
    const a = item.trim().split('|');
    return { name: a[0], id: a[1] };
  });
  return data;
};

export const categorizeTrailers = list => {
  const result = list?.reduce(
    (newObj, item) => {
      if (item.isState) newObj.stateTrailer = item;
      else if (item.isCountry) newObj.countryTrailer = item;
      else newObj.remainingTrailers.push(item);
      return newObj;
    },
    {
      stateTrailer: {},
      countryTrailer: {},
      remainingTrailers: [],
    },
  ); // Initial value is required

  return result;
};

export const filterBillCountries = list => {
  const result = list?.reduce(
    (newObj, item) => {
      if (item.id === 'MYS') newObj.malaysia.push(item);
      else newObj.remainingCountries.push(item);
      return newObj;
    },
    {
      malaysia: [],
      remainingCountries: [],
    },
  ); // Initial value is required

  return result;
};
