import React, { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import { StyleSheet, TouchableOpacity, View, Image, FlatList } from 'react-native';
import { useFormikContext } from 'formik';

import { colors } from 'configs';
import { Text } from '../text';
import { Flex, Icon, TextHelper, TooltipIcon } from '../atoms';
import { BottomDrawerModalMini } from '../molecules/BottomDrawerModalMini';
import { BottomDrawerModal } from '../molecules/BottomDrawerModal';
import { TextInput } from '../organisms/TextInput';

import SearchIcon from 'assets/images/icon/search.png';
import { useTranslation } from 'react-i18next';

export const FormPicker = (
  {
    label = null,
    enableSearch = false,
    hideLabel,
    name,
    loading,
    disabled,
    data,
    dataLabel = 'label',
    dataValue = 'value',
    clearOnSelect,
    onChanged,
    style,
    fontStyle,
    t,
    resetFormValues,
    ...otherProps
  },
  ref,
) => {
  useImperativeHandle(ref, () => ({
    // methods connected to `ref`
    updateFieldValue: val => {
      handleSelect(val);
    },
  }));

  const LANG_PREFIX = 'components.formPicker.';
  const { t: translate } = useTranslation();
  const { setFieldValue, values, errors, touched, setStatus, setFieldTouched, resetForm } = useFormikContext();
  const [visible, setVisible] = useState(false);
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    if (data?.length === 1) handleSelect(data[0][dataValue]);
  }, [data?.length]);

  const handleSelect = val => {
    if (values[name] !== val && clearOnSelect) {
      // fix for ekyc employment form that require to reset and clear all the initial values of form
      if (resetFormValues) {
        resetForm({ values: resetFormValues });
      } else resetForm();
    }

    setFieldTouched(name, true);
    setStatus(name);
    setFieldValue(name, val);
    setFieldTouched(name, false);
    handleCloseModel();
    if (onChanged) onChanged(val);
  };

  const handleCloseModel = () => {
    setVisible(false);
    setSearchText(null);
  };

  const handleOpenModal = () => setVisible(true);

  const handleOnChangeSearchText = text => setSearchText(text);

  const selectedLabel = () => {
    if (!data) return;
    const selected = data.find(e => e[dataValue] === values[name]);
    if (!selected)
      return (
        <Text style={{ fontSize: 14, color: colors.medium }}>
          {translate(`${LANG_PREFIX}selectLabel`).replace('${label}', label)}
        </Text>
      );
    return (
      <Text bold style={[{ fontSize: 14 }, fontStyle]}>
        {t ? t(selected[dataLabel]) : selected[dataLabel]}
      </Text>
    );
  };

  const filteredData = () => {
    if (!data) return [];
    if (!searchText) return data;
    return data.filter(item => {
      const itemLabel = t ? t(item[dataLabel]) : item[dataLabel];
      return itemLabel.toLowerCase().includes(searchText.toLowerCase());
    });
  };

  const renderPicker = () => (
    <FlatList
      showsVerticalScrollIndicator={false}
      keyExtractor={(item, index) => index.toString()}
      data={filteredData()}
      renderItem={({ item }) => (
        <TouchableOpacity
          onPress={() => handleSelect(item[dataValue])}
          style={{
            backgroundColor: item[dataValue] === values[name] ? colors.primary : colors.white,
            paddingHorizontal: 20,
            paddingVertical: 12,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <Text style={{ fontSize: 14, color: item[dataValue] === values[name] ? colors.white : colors.black }}>
            {t ? t(item[dataLabel]) : item[dataLabel]}
          </Text>
          {item?.info && <TooltipIcon tooltipText={t ? t(item.info) : item.info} t={t} />}
        </TouchableOpacity>
      )}
    />
  );

  const renderModal = children => {
    if (enableSearch)
      return (
        <BottomDrawerModal isVisible={visible} closeModal={handleCloseModel}>
          <Flex>
            <View style={{ paddingHorizontal: 20, paddingTop: 12, paddingBottom: 5 }}>
              <Text style={{ fontSize: 13, color: colors.medium }}>{label}</Text>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <TextInput
                value={searchText}
                style={{ paddingHorizontal: 20, minHeight: 50 }}
                onChangeText={handleOnChangeSearchText}
                placeholder={translate(`${LANG_PREFIX}placeholderSearch`)}
              />
              <View pointerEvents={'none'} style={{ position: 'absolute', right: 0 }}>
                <Image
                  source={SearchIcon}
                  style={{ width: 12, height: 12, tintColor: colors.medium, marginHorizontal: 20 }}
                />
              </View>
            </View>
            {children}
          </Flex>
        </BottomDrawerModal>
      );

    return (
      <BottomDrawerModalMini isVisible={visible} closeModal={handleCloseModel}>
        <>
          <View style={{ paddingHorizontal: 20, paddingTop: 12, paddingBottom: 5 }}>
            <Text style={{ fontSize: 13, color: colors.medium }}>{label}</Text>
          </View>
          {children}
        </>
      </BottomDrawerModalMini>
    );
  };

  return (
    <View style={styles.container}>
      {!hideLabel && <Text style={{ fontSize: 14 }}>{label}</Text>}
      <TouchableOpacity onPress={handleOpenModal} disabled={disabled}>
        <View style={[styles.textInput, style, disabled && { opacity: 0.8 }]} {...otherProps}>
          <View style={{ flex: 1 }}>{selectedLabel()}</View>
          <Icon.MaterialIcons name='arrow-drop-down' style={styles.icon} />
        </View>
      </TouchableOpacity>
      {touched[name] && <TextHelper isValid={!errors[name]} errorMsg={errors[name]} showCount={false} />}
      {renderModal(renderPicker())}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 15,
  },
  textInput: {
    minHeight: 45,
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.lightgrey,
    flexDirection: 'row',
  },
  icon: {
    fontSize: 15,
    color: colors.black,
  },
});

export default forwardRef(FormPicker);
