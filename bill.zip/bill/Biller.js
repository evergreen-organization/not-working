import React, { useMemo, useState } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import routes from 'navigations/routes';
import { colors } from 'configs';
import { billInit, getBillerList, getBillers, updateNewBillObject } from 'stores';
import { useApi } from 'hooks';
import { searchFromListAllowKeys } from 'utils';
import { ListBtn, Text } from 'components';
import { ScreenFull, SkeletonBar, Space } from 'atoms';
import { ItemErrorRetry } from 'molecules';
import { AccountSearch, NavBar } from 'organisms';
import { LOADING, SUCCESS } from 'apis';
import { useTranslation } from 'react-i18next';

const LANG_PREFIX = 'screens.billSelect.text.';

export const Biller = ({ navigation }) => {
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const billers = useSelector(getBillers);
  const getBillerApi = useApi(getBillerList);
  const [searchText, setSearchText] = useState('');
  const filteredData = searchFromListAllowKeys(searchText, billers.list, ['name']);

  const renderHeader = useMemo(() => <Space height={10} />);
  const renderFooter = useMemo(() => <Space height={50} />);

  const onSelect = ({ giroCode }) => {
    dispatch(billInit());
    dispatch(updateNewBillObject({ billerCode: giroCode }));
    return navigation.navigate(routes.BILL_REFERENCE);
  };

  return (
    <ScreenFull>
      <NavBar
        title={t(LANG_PREFIX + 'titleSelectBiller')}
        back
        showShadow={true}
        bottom={<AccountSearch onChangeText={text => setSearchText(text)} value={searchText} />}
      />

      <View style={styles.alertContainer}>
        <Text bold style={styles.alertTitle}>{`${t(`${LANG_PREFIX}headerCantFindBiller`)}`}</Text>
        <Text style={styles.alertDescription}>{t(`${LANG_PREFIX}descriptionBiller`)}</Text>
      </View>

      {billers.status === SUCCESS ? (
        <FlatList
          showsVerticalScrollIndicator={false}
          keyExtractor={(item, index) => index.toString()}
          ListHeaderComponent={renderHeader}
          ListFooterComponent={renderFooter}
          data={filteredData}
          renderItem={({ item, index }) => (
            <ListBtn title={item.name} isLast={index === filteredData.length - 1} onPress={() => onSelect(item)} />
          )}
        />
      ) : (
        <View style={{ backgroundColor: colors.white, marginTop: 10 }}>
          {billers.status === LOADING ? (
            <View style={{ marginHorizontal: 20 }}>
              <SkeletonBar subtitle={true} loop={9} height={50} />
            </View>
          ) : (
            <ItemErrorRetry onRetry={() => getBillerApi.request()} />
          )}
        </View>
      )}
    </ScreenFull>
  );
};

export default Biller;

const styles = StyleSheet.create({
  alertContainer: {
    backgroundColor: '#FFF7F7',
    paddingHorizontal: 20,
    paddingVertical: 15,
    marginTop: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.border,
  },
  alertTitle: {
    color: colors.primary,
    marginBottom: 5,
  },
  alertDescription: {
    fontSize: 13,
  },
});
