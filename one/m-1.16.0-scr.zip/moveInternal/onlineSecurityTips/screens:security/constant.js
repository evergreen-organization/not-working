import { APP_SECURITY_RISK_TYPE } from 'constant';
import { DynamicConstant } from 'molecules';

const LANG_PREFIX = 'screens.securityRisk.text.';

export const SCREENREADER_RISK_DESC = {
  DANGEROUS: {
    header: `${LANG_PREFIX}riskUnknownScreenReader`,
    desc: `${LANG_PREFIX}riskUnknownScreenReaderDesc`,
    stepTitle: `${LANG_PREFIX}uninstallAcsStepTitle`,
    steps: [
      `${LANG_PREFIX}uninstallAcsStep1`,
      `${LANG_PREFIX}uninstallAcsStep2`,
      `${LANG_PREFIX}uninstallAcsStep3`,
      `${LANG_PREFIX}uninstallAcsStep4`,
      `${LANG_PREFIX}uninstallAcsStep5`,
    ],
  },
  WHITELISTED: {
    header: `${LANG_PREFIX}riskWhitelistedScreenReader`,
    desc: `${LANG_PREFIX}riskWhitelistedScreenReaderDesc`,
    stepTitle: `${LANG_PREFIX}offAcsStepTitle`,
    steps: [
      `${LANG_PREFIX}offAcsStep1`,
      `${LANG_PREFIX}offAcsStep2`,
      `${LANG_PREFIX}offAcsStep3`,
      `${LANG_PREFIX}offAcsStep4`,
      `${LANG_PREFIX}offAcsStep5`,
    ],
  },
};

export const COPY_APP_INFO_CONFIG = {
  [APP_SECURITY_RISK_TYPE.SCREEN_READER]: ({ t, data }) => ({
    title: t(
      data?.dangerousScreenreader
        ? `${LANG_PREFIX}riskUnknownScreenReader`
        : `${LANG_PREFIX}riskWhitelistedScreenReader`,
    ),
    list: data?.appInfo,
  }),

  [APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP]: ({ t, data }) => ({
    title: t(`${LANG_PREFIX}untrustedSourceApp1`),
    list: data?.untrustedApps,
  }),
};

export const getSecurityTipsData = (t, LANG_PREFIX_TIPS) => ({
  lists: [
    {
      id: 'securityTips',
      details: [
        {
          type: DynamicConstant.variants.bulletList,
          data: [
            {
              id: '1',
              label: t(`${LANG_PREFIX_TIPS}desc1`),
            },
            {
              id: '2',
              label: t(`${LANG_PREFIX_TIPS}desc2`),
            },
            {
              id: '3',
              label: t(`${LANG_PREFIX_TIPS}desc3`),
            },
            {
              id: '4',
              label: t(`${LANG_PREFIX_TIPS}desc4`),
            },
            {
              id: '5',
              label: t(`${LANG_PREFIX_TIPS}desc5`),
            },
            {
              id: '6',
              label: t(`${LANG_PREFIX_TIPS}desc6`),
            },
            {
              id: '7',
              label: t(`${LANG_PREFIX_TIPS}desc7`),
            },
            {
              id: '8',
              label: t(`${LANG_PREFIX_TIPS}desc8`),
            },
            {
              id: '9',
              label: t(`${LANG_PREFIX_TIPS}desc9`),
            },
            {
              id: '10',
              label: t(`${LANG_PREFIX_TIPS}desc10`),
            },
          ],
        },
      ],
    },
  ],
});
