import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';

import { SecurityTipsModalView } from './component';
import { getSecurityTipsData } from '../constant';

export const SecurityTipsModal = ({ isVisible, onPress }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.securityTips.text.';

  const securityTipsData = getSecurityTipsData(t, LANG_PREFIX);

  const [isScrolledToEnd, setIsScrolledToEnd] = useState(false);

  const handleScroll = ({ nativeEvent }) => {
    const { layoutMeasurement, contentOffset, contentSize } = nativeEvent;

    const isEnd = layoutMeasurement.height + contentOffset.y >= contentSize.height - 5;

    if (isEnd) {
      setIsScrolledToEnd(true);
    }
  };

  const props = {
    t,
    LANG_PREFIX,
    securityTipsData,
    isScrolledToEnd,
    isVisible,
    onPress,
    handleScroll,
  };

  return <SecurityTipsModalView {...props} />;
};
