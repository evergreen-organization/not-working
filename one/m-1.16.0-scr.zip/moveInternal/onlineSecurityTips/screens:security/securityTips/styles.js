import { StyleSheet } from 'react-native';

import { colors } from 'configs';
import { FONT_FAMILY_BOLD } from 'styles/fonts';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
  },
  modalView: {
    backgroundColor: 'white',
    overflow: 'hidden',
  },
  headerContainer: {
    width: '100%',
    backgroundColor: colors.primary,
    paddingHorizontal: 15,
    paddingVertical: 15,
    justifyContent: 'center',
  },
  headerView: {
    justifyContent: 'center',
  },
  headerImage: {
    position: 'absolute',
    zIndex: -1,
    opacity: 0.15,
  },
  headerText: {
    zIndex: 1,
    color: 'white',
    textAlign: 'center',
    fontSize: 25,
    fontFamily: FONT_FAMILY_BOLD,
  },
  triangleView: {
    alignSelf: 'center',
  },
  outerTriangle: {
    width: 0,
    height: 0,
    borderLeftWidth: 40,
    borderRightWidth: 40,
    borderTopWidth: 40,
    borderLeftColor: colors.transparent,
    borderRightColor: colors.transparent,
    borderTopColor: colors.white,
    top: -15,
  },
  innerTriangle: {
    width: 0,
    height: 0,
    borderLeftWidth: 25,
    borderRightWidth: 25,
    borderTopWidth: 25,
    borderLeftColor: colors.transparent,
    borderRightColor: colors.transparent,
    borderTopColor: colors.primary,
    position: 'absolute',
    marginTop: -1,
    right: 15,
  },
  bodyBackgroundImg: {
    flex: 1,
  },
  bodyOverlay: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.85)',
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  subtitleContainer: {
    marginBottom: 12,
  },

  subTitleText: {
    textAlign: 'center',
  },
  contentContainer: {
    flex: 1,
  },
  contentScrollView: {
    paddingHorizontal: 10,
  },
  contentLabelText: {
    fontSize: 15,
    marginBottom: 3,
  },
  buttonContainer: {
    alignItems: 'center',
    marginTop: 15,
  },
  buttonView: {
    paddingVertical: 12,
    borderRadius: 25,
    alignItems: 'center',
    width: '60%',
  },
  buttonText: {
    color: 'white',
  },
});
