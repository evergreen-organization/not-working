import React from 'react';
import { View, Modal, ImageBackground, useWindowDimensions, TouchableOpacity, Image } from 'react-native';

import { colors } from 'configs';
import { Text } from 'components';
import { DynamicConstant } from 'molecules';
import { CustomScrollView } from 'atoms';

import BulbIcon from 'assets/images/icon/bulb.png';
import ShieldLock from 'assets/images/icon/shieldLock.png';

import { styles } from './styles';

export const SecurityTipsModalView = ({
  t,
  LANG_PREFIX,
  securityTipsData,
  isScrolledToEnd,
  isVisible,
  onPress,
  handleScroll,
}) => {
  const { width, height } = useWindowDimensions();

  return (
    <Modal visible={isVisible} transparent={true} animationType='slide'>
      <View style={styles.container}>
        {/* Modal */}
        <View style={{ ...styles.modalView, width: width * 0.9, height: height * 0.75 }}>
          {/* Header section*/}
          <View style={{ ...styles.headerContainer, height: height * 0.15 }}>
            <View style={styles.headerView}>
              <Image
                source={BulbIcon}
                style={{ ...styles.headerImage, width: width * 0.3, height: height * 0.2 }}
                tintColor={colors.white}
                resizeMode='contain'
              />
              <Text style={styles.headerText}>{t(`${LANG_PREFIX}title`)}</Text>
            </View>
          </View>

          {/** Triangle section */}
          <View style={styles.triangleView}>
            {/* Outer Triangle */}
            <View style={styles.outerTriangle} />
            {/* Inner Triangle */}
            <View style={styles.innerTriangle} />
          </View>

          {/* Body */}
          <ImageBackground
            source={ShieldLock}
            style={styles.bodyBackgroundImg}
            resizeMode='contain'
            tintColor={colors.lightgrey}>
            <View style={styles.bodyOverlay}>
              <View style={styles.subtitleContainer}>
                <Text bold style={styles.subTitleText}>
                  {t(`${LANG_PREFIX}titleDesc`)}
                </Text>
              </View>
              <View style={styles.contentContainer}>
                <CustomScrollView
                  contentContainerStyle={styles.contentScrollView}
                  showsVerticalScrollIndicator={false}
                  onScrollEndDrag={handleScroll}
                  onMomentumScrollEnd={handleScroll}>
                  <DynamicConstant details={securityTipsData} labelStyle={styles.contentLabelText} />
                </CustomScrollView>
              </View>
              {/* Footer Button */}
              <View style={styles.buttonContainer}>
                <TouchableOpacity
                  style={{
                    ...styles.buttonView,
                    backgroundColor: isScrolledToEnd ? colors.primary : colors.lightgrey,
                  }}
                  onPress={onPress}
                  disabled={!isScrolledToEnd}>
                  <Text bold style={styles.buttonText}>
                    {t(`${LANG_PREFIX}buttonIUnderstand`)}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </ImageBackground>
        </View>
      </View>
    </Modal>
  );
};
