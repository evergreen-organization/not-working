import React, { useRef, useState, useCallback } from 'react';
import { StyleSheet, View, Image, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';

import { colors } from 'configs';
import { Text } from '../text';
import { TextInput } from './TextInput';

import SendIcon from 'assets/images/icon/send.png';
import LoadingWhiteIcon from 'assets/images/other/loadingWhite.gif';
import { getConditionalDisableAccessibilityProps } from 'utils';
import KeyboardIcon from 'assets/images/icon/keyboard.png';

const DEFAULT_KEYBOARD = 'default';

export const StringInput = ({
  onSubmit,
  errorTitle = '',
  maxLength = 20,
  placeholder = '',
  keyboardType = DEFAULT_KEYBOARD,
  autoCapitalize = 'sentences',
  allowSwitchKeyboard = false,
  loading = false,
}) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'organisms.stringInput.';

  const [value, setValue] = useState('');
  const [currentKeyboardType, setCurrentKeyboardType] = useState(keyboardType);
  const inputRef = useRef();

  useFocusEffect(
    useCallback(() => {
      setTimeout(() => {
        inputRef.current.focus();
      }, 500);
    }, []),
  );

  const onChange = text => setValue(text);
  const handleSubmit = () => onSubmit(value);

  const handleChangeKeyboard = () => {
    setCurrentKeyboardType(currentKeyboardType === DEFAULT_KEYBOARD ? keyboardType : DEFAULT_KEYBOARD);
  };

  return (
    <KeyboardAvoidingView style={styles.container} {...(Platform.OS === 'ios' && { behavior: 'padding' })}>
      <View style={styles.content}>
        <Text {...getConditionalDisableAccessibilityProps(errorTitle)} style={styles.errorText}>
          {errorTitle ? errorTitle : ' '}
        </Text>
        <View style={{ paddingHorizontal: 25, marginBottom: '8%' }}>
          <TextInput
            ref={inputRef}
            autoCapitalize={autoCapitalize}
            bold
            onChangeText={text => onChange(text)}
            value={value}
            maxLength={maxLength}
            style={{
              flex: 0,
              fontSize: 28,
              color: colors.black,
              minHeight: 50,
              borderBottomWidth: 0,
              textAlign: 'center',
            }}
            placeholderTextColor={colors.lightgrey}
            placeholder={placeholder}
            keyboardType={currentKeyboardType}
          />
        </View>
      </View>

      <View style={styles.btnRow}>
        {allowSwitchKeyboard && keyboardType !== DEFAULT_KEYBOARD && (
          <TouchableOpacity style={styles.keyboardBtn} onPress={handleChangeKeyboard}>
            <Image source={KeyboardIcon} style={styles.keyboardIcon} />
            <Text style={styles.keyboardText}>{t(`${LANG_PREFIX}labelChange`)}</Text>
            <Text style={styles.keyboardText}>{t(`${LANG_PREFIX}labelKeyboard`)}</Text>
          </TouchableOpacity>
        )}

        <TouchableOpacity
          style={[styles.sendBtn, { ...(loading && { backgroundColor: colors.lightgrey }) }]}
          onPress={handleSubmit}
          disabled={loading}>
          {loading ? (
            <Image source={LoadingWhiteIcon} style={{ width: 50, height: 50 }} />
          ) : (
            <>
              <Image source={SendIcon} style={styles.icon} />
              <Text bold style={styles.sendBtnText}>
                {t(`${LANG_PREFIX}labelNext`)}
              </Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  errorText: {
    fontSize: 14,
    color: colors.red,
    marginHorizontal: 25,
    textAlign: 'center',
  },
  sendBtn: {
    flex: 1,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,

    borderRadius: 10,
  },
  sendBtnText: {
    fontSize: 16,
    color: colors.white,
    marginTop: 5,
  },
  icon: {
    width: 22,
    height: 22,
    tintColor: colors.white,
  },
  btnRow: {
    flexDirection: 'row',
    marginBottom: 20,
    marginHorizontal: 20,
  },
  keyboardBtn: {
    backgroundColor: colors.white,
    marginRight: 10,
    padding: 10,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  keyboardIcon: {
    width: 23,
    height: 23,
    tintColor: colors.black,
    marginBottom: 3,
  },
  keyboardText: {
    fontSize: 10,
    textAlign: 'center',
  },
});

export default StringInput;
