import { createSelector } from '@reduxjs/toolkit';

export const getConsentList = createSelector(
  state => state.bankingEntities.autoDebit.consentList,
  consentList => consentList,
);

export const getCurrentConsent = createSelector(
  state => state.bankingEntities.autoDebit.currentConsent,
  currentConsent => currentConsent,
);

export const getConsentInquiry = createSelector(
  state => state.bankingEntities.autoDebit.consentInquiry,
  consentInquiry => consentInquiry,
);

export const getConsentTrxHistory = createSelector(
  state => state.bankingEntities.autoDebit.history,
  history => history,
);
