import { createSlice, isAnyOf } from '@reduxjs/toolkit';

import { FAIL, IDLE, LOADING, SUCCESS } from 'apis';
import {
  callAutoDebitConsentList,
  callAutoDebitConsentTrxHistory,
  consentInquiry,
  registerAutoDebit,
  rejectConsent,
  submitApproveConsent,
  submitEditConsent,
  submitTransferConsent,
  terminateConsent,
} from './thunk';

import { AUTO_DEBIT_CONSENT_STATUS } from 'screens/autoDebit/constants';

const initialState = {
  consentList: {
    pending: [],
    registered: [],
    listStatus: IDLE,
  },
  currentConsent: {
    consentId: '',
    productId: '',
    merchantName: '',
    consentDesc: '',
    effectiveDate: '',
    completionDate: '',
    reqExpiryDate: '',
    frequency: '',
    maxAmnt: '',
    consentStatus: '',
    duitNowRefNo: '',
    editable: false,
    fromAccNo: '',
    otherDetail: '',
    requestDate: '',
    registerDate: '',
  },
  history: {
    status: IDLE,
    list: [],
    historyNextKey: '',
    endOfHistory: false,
  },
  consentInquiry: {
    status: IDLE,
    consentId: '',
    productId: '',
    merchantName: '',
    consentDesc: '',
    effectiveDate: '',
    completionDate: '',
    frequency: '',
    maxAmnt: '',
    otherDetail: '',
    consentStatus: '',
    duitNowRefNo: '',
    toAcc: null,
  },
  status: IDLE,
};

const slice = createSlice({
  name: 'autoDebit',
  initialState,
  reducers: {
    autoDebitReset: _ => initialState,
    autoDebitInit: state => {
      state.currentConsent = initialState.currentConsent;
      state.consentInquiry = initialState.consentInquiry;
      state.history = initialState.history;
      state.status = initialState.status;
    },
    fromAccUpdated: (state, { payload }) => {
      state.currentConsent.fromAccNo = payload;
    },
    consentStatusUpdated: (state, { payload }) => {
      state.currentConsent.consentStatus = payload;
    },
    updateCurrentConsentObject: (state, { payload }) => {
      for (const key in payload) {
        state.currentConsent[key] = payload[key];
      }
    },
    updateConsentInquiryObject: (state, { payload }) => {
      for (const key in payload) {
        state.consentInquiry[key] = payload[key];
      }
    },
    updateRegisteredConsentById: (state, { payload }) => {
      const { consentId, ...fields } = payload;
      const index = state.consentList.registered.findIndex(item => item.consentId === consentId);
      if (index !== -1) {
        state.consentList.registered[index] = {
          ...state.consentList.registered[index],
          ...fields,
        };
      }
    },
    resetCurrentConsentObject: state => {
      state.currentConsent = initialState.currentConsent;
    },
    resetConsentListStatus: state => {
      state.consentList.listStatus = initialState.consentList.listStatus;
    },
    resetConsentHistory: state => {
      state.history = initialState.history;
    },
    resetConsentInquiry: state => {
      state.consentInquiry = initialState.consentInquiry;
    },
  },
  extraReducers: builder => {
    builder.addCase(callAutoDebitConsentList.pending, state => {
      state.consentList.listStatus = LOADING;
    });
    builder.addCase(callAutoDebitConsentList.rejected, state => {
      state.consentList.listStatus = FAIL;
    });
    builder.addCase(callAutoDebitConsentList.fulfilled, (state, { payload }) => {
      state.consentList.listStatus = SUCCESS;
      state.consentList.pending = payload?.pending;
      state.consentList.registered = payload?.registered;
    });
    builder.addCase(rejectConsent.fulfilled, (state, { meta }) => {
      const { consentId } = meta.arg || {};
      state.status = SUCCESS;
      state.consentList.pending = state.consentList.pending.filter(item => item.consentId !== consentId);
    });
    builder.addCase(rejectConsent.pending, state => {
      state.status = LOADING;
    });
    builder.addCase(rejectConsent.rejected, state => {
      state.status = FAIL;
    });
    builder.addCase(terminateConsent.fulfilled, (state, { meta }) => {
      const { consentId } = meta.arg || {};
      state.status = SUCCESS;
      const index = state.consentList.registered.findIndex(item => item.consentId === consentId);
      if (index !== -1) {
        state.consentList.registered[index] = {
          ...state.consentList.registered[index],
          consentStatus: AUTO_DEBIT_CONSENT_STATUS.CANC.key,
        };
      }
    });
    builder.addCase(terminateConsent.pending, state => {
      state.status = LOADING;
    });
    builder.addCase(terminateConsent.rejected, state => {
      state.status = FAIL;
    });
    builder.addCase(callAutoDebitConsentTrxHistory.pending, state => {
      state.history.status = LOADING;
    });
    builder.addCase(callAutoDebitConsentTrxHistory.rejected, state => {
      state.history.status = FAIL;
    });
    builder.addCase(callAutoDebitConsentTrxHistory.fulfilled, (state, { payload, meta }) => {
      state.history.status = SUCCESS;
      if (payload?.history && payload?.history.length > 0) {
        if (!meta.arg.nextKey) {
          state.history.list = payload?.history;
        } else {
          state.history.list.push(...payload.history);
        }
        state.history.historyNextKey = payload?.nextKey;
      }
      if (!payload?.nextKey) state.history.endOfHistory = true;
    });
    builder.addCase(consentInquiry.pending, state => {
      state.consentInquiry.status = LOADING;
    });
    builder.addCase(consentInquiry.rejected, state => {
      state.consentInquiry.status = FAIL;
    });
    builder.addCase(consentInquiry.fulfilled, (state, { payload, meta }) => {
      Object.keys(payload.details).forEach(key => {
        state.consentInquiry[key] = payload.details[key];
      });
      state.consentInquiry.consentId = meta.arg.consentId;
      state.consentInquiry.status = SUCCESS;
    });
    builder.addCase(registerAutoDebit.pending, state => {
      state.status = LOADING;
    });
    builder.addCase(registerAutoDebit.rejected, state => {
      state.status = FAIL;
    });
    builder.addCase(registerAutoDebit.fulfilled, state => {
      state.status = SUCCESS;
    });
    builder.addCase(submitApproveConsent.fulfilled, (state, { payload }) => {
      state.status = SUCCESS;
      if (payload?.challengeQuestion) return;
      state.currentConsent.refNo = payload.refNo;
      state.currentConsent.tranDateTime = payload.tranDateTime;
    });
    builder.addCase(submitEditConsent.fulfilled, (state, { payload, meta }) => {
      const { fromAccNo, consentId, consentStatus } = meta.arg || {};
      const newStatus = consentStatus ? AUTO_DEBIT_CONSENT_STATUS.ACTV.key : AUTO_DEBIT_CONSENT_STATUS.SUSP.key;
      state.status = SUCCESS;
      if (payload?.challengeQuestion) return;
      state.currentConsent.fromAccNo = fromAccNo;
      state.currentConsent.consentStatus = newStatus;
      const index = state.consentList.registered.findIndex(item => item.consentId === consentId);
      if (index !== -1) {
        state.consentList.registered[index] = {
          ...state.consentList.registered[index],
          fromAccNo,
          consentStatus: newStatus,
        };
      }
    });
    builder.addCase(submitTransferConsent.fulfilled, (state, { payload }) => {
      state.status = SUCCESS;
      if (payload?.challengeQuestion) return;
      state.consentInquiry.tranDateTime = payload.tranDateTime;
      state.consentInquiry.refNo = payload.refNo;
      state.consentInquiry.consentStatus = payload.consentStatus;
      state.consentInquiry.duitNowRefNo = payload.duitNowRefNo;
    });

    builder.addMatcher(
      isAnyOf(submitApproveConsent.pending, submitEditConsent.pending, submitTransferConsent.pending),
      state => {
        state.status = LOADING;
      },
    );
    builder.addMatcher(
      isAnyOf(submitApproveConsent.rejected, submitEditConsent.rejected, submitTransferConsent.rejected),
      state => {
        state.status = FAIL;
      },
    );
  },
});

export const {
  autoDebitReset,
  autoDebitInit,
  updateCurrentConsentObject,
  fromAccUpdated,
  updateConsentInquiryObject,
  updateRegisteredConsentById,
  resetCurrentConsentObject,
  resetConsentListStatus,
  resetConsentHistory,
  resetConsentInquiry,
} = slice.actions;

export default slice.reducer;
