import { createAsyncThunk } from '@reduxjs/toolkit';
import { publicClient } from 'apis/publicClient';
import { privateClient } from 'apis/privateClient';
import { apiEndpoint } from 'apis/apiUtils';
import { Demo } from 'constant';
const axiosConfig = { timeout: 30000 };

export const callAutoDebitConsentList = createAsyncThunk(
  'autoDebit/getAutoDebitConsentList',
  async (_, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.ConsentList;
    const result = await publicClient.get(`${apiEndpoint.public}/duitNowAutoDebit/getConsentList`, {}, axiosConfig);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const submitApproveConsent = createAsyncThunk(
  'autoDebit/approveNewConsent',
  async ({ isPublic, secfa, mobileSdkData, deviceTokenCookie }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.ApproveConsent;
    let result;
    if (isPublic)
      result = await publicClient.post(`${apiEndpoint.public}/duitNowAutoDebit/approveConsent`, {
        secfa,
        mobileSdkData,
        deviceTokenCookie,
      });
    else
      result = await privateClient.post(`${apiEndpoint.public}/duitNowAutoDebit/approveConsent`, {
        secfa,
        mobileSdkData,
        deviceTokenCookie,
      });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const rejectConsent = createAsyncThunk(
  'autoDebit/rejectConsent',
  async ({ consentId }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.RejectConsent;
    const result = await publicClient.post(`${apiEndpoint.public}/duitNowAutoDebit/rejectConsent`, { consentId });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const submitEditConsent = createAsyncThunk(
  'autoDebit/editConsent',
  async ({ isPublic, secfa, mobileSdkData, deviceTokenCookie }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.EditConsent;
    let result;
    if (isPublic)
      result = await publicClient.post(`${apiEndpoint.public}/duitNowAutoDebit/editConsent`, {
        secfa,
        mobileSdkData,
        deviceTokenCookie,
      });
    else
      result = await privateClient.post(`${apiEndpoint.public}/duitNowAutoDebit/editConsent`, {
        secfa,
        mobileSdkData,
        deviceTokenCookie,
      });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const callAutoDebitTerminateReason = createAsyncThunk(
  'autoDebit/getTerminateReason',
  async (id, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.TerminateReason;
    const result = await publicClient.get(`${apiEndpoint.public}/duitNowAutoDebit/getTerminateReason`);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const terminateConsent = createAsyncThunk(
  'autoDebit/terminateConsent',
  async ({ consentId, reasonId }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.TerminateConsent;
    const result = await publicClient.post(`${apiEndpoint.public}/duitNowAutoDebit/terminateConsent`, {
      consentId,
      reasonId,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const callAutoDebitConsentTrxHistory = createAsyncThunk(
  'autoDebit/getConsentTrxHistory',
  async ({ consentId, nextKey }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.PastTransaction;
    const result = await publicClient.post(`${apiEndpoint.public}/duitNowAutoDebit/getConsentHistory`, {
      consentId,
      nextKey,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
export const consentInquiry = createAsyncThunk(
  'autoDebit/consentInquiry',
  async ({ consentId }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.ConsentInquiry;
    const result = await publicClient.post(`${apiEndpoint.public}/duitNowAutoDebit/consentInquiry`, { consentId });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
export const submitTransferConsent = createAsyncThunk(
  'autoDebit/transferConsent',
  async ({ isPublic, secfa, mobileSdkData, deviceTokenCookie }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.TransferConsent;
    let result;
    if (isPublic)
      result = await publicClient.post(`${apiEndpoint.public}/duitNowAutoDebit/transferConsent`, {
        secfa,
        mobileSdkData,
        deviceTokenCookie,
      });
    else
      result = await privateClient.post(`${apiEndpoint.private}/duitNowAutoDebit/transferConsent`, {
        secfa,
        mobileSdkData,
        deviceTokenCookie,
      });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const registerAutoDebit = createAsyncThunk(
  'autoDebit/registerAutoDebit',
  async ({ n2nId }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.AutoDebit.RegisterAutoDebit;
    const result = await publicClient.post(`${apiEndpoint.public}/duitNowAutoDebit/registerAutoDebit`, { n2nId });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
