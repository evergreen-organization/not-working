import { combineReducers } from 'redux';
import casaReducer from './casa/reducer';
import cardReducer from './card/reducer';
import depositReducer from './deposit/reducer';
import loanReducer from './loan/reducer';
import investReducer from './invest/reducer';
import bankingUserReducer from './bankingUser/reducer';
import walletReducer from './portfolio/wallet/reducer';
import walletCategoryReducer from './portfolio/walletCategory/reducer';
import expenseReducer from './portfolio/expense/reducer';
import portfolioReducer from './portfolio/reducer';
import rnidReducer from './rnid/reducer';
import fundTransferReducer from './fundTransfer/reducer';
import cardPaymentReducer from './cardPayment/reducer';
import loanPaymentReducer from './loanPayment/reducer';
import billReducer from './bill/reducer';
import topUpReducer from './topUp/reducer';
import softTokenReducer from './softToken';
import qrPaymentReducer from './qrPayment/reducer';
import recurringReducer from './recurring/reducer';
import duitNowIdReducer from './duitNowId/reducer';
import flexipayReducer from './flexipay/reducer';
import cashAdvanceReducer from './cashAdvance/reducer';
import pbJourneyReducer from './pbJourney/reducer';
import cardlessWithdrawReducer from './cardlessWithdraw/reducer';
import appointmentReducer from './appointment/reducer';
import trackerReducer from './tracker/reducer';
import mailboxReducer from './mailbox/reducer';
import remittanceReducer from './remittance/reducer';
import depositPlacementReducer from './depositPlacement/reducer';
import carbonTrackerReducer from './carbonTracker/reducer';
import walletTokenizationReducer from './walletTokenization/reducer';
import goldReducer from './gold/reducer';
import insuranceReducer from './insurance/reducer';
import autoDebitReducer from './autoDebit/reducer';

export default combineReducers({
  //accounts
  casa: casaReducer,
  card: cardReducer,
  deposit: depositReducer,
  invest: investReducer,
  loan: loanReducer,
  bankingUser: bankingUserReducer,
  wallet: walletReducer,
  walletCategory: walletCategoryReducer,
  expense: expenseReducer,
  portfolio: portfolioReducer,
  rnid: rnidReducer,
  fundTransfer: fundTransferReducer,
  cardPayment: cardPaymentReducer,
  loanPayment: loanPaymentReducer,
  bill: billReducer,
  topUp: topUpReducer,
  softToken: softTokenReducer,
  qrPayment: qrPaymentReducer,
  recurring: recurringReducer,
  duitNowId: duitNowIdReducer,
  flexipay: flexipayReducer,
  cashAdvance: cashAdvanceReducer,
  pbJourney: pbJourneyReducer,
  cardlessWithdraw: cardlessWithdrawReducer,
  appointment: appointmentReducer,
  tracker: trackerReducer,
  mailbox: mailboxReducer,
  remittance: remittanceReducer,
  depositPlacement: depositPlacementReducer,
  carbonTracker: carbonTrackerReducer,
  walletTokenization: walletTokenizationReducer,
  gold: goldReducer,
  insurance: insuranceReducer,
  autoDebit: autoDebitReducer,
});
