import { createSelector } from '@reduxjs/toolkit';

export const getLanguage = createSelector(
  state => state.environmentEntities.language,
  language => language,
);

export const getLanguageCode = createSelector(
  state => state.environmentEntities.language,
  language => language?.languageCode,
);

export const getAllLanguages = createSelector(
  state => state.environmentEntities.language,
  language => language.languages,
);

export const getLanguageStatus = createSelector(
  state => state.environmentEntities.language,
  language => language?.status,
);

export const getAutoDebitTerminateReason = createSelector(
  state => state.environmentEntities.language,
  language => language.languages[language.languageCode]?.autoDebitTerminateReason,
);

export const getAutoDebitTerminateReasonStatus = createSelector(
  state => state.environmentEntities.language,
  language => language?.autoDebitTerminateReasonStatus,
);

export const getErrorList = createSelector(
  state => state.environmentEntities.language,
  language => language.languages[language.languageCode]?.errorList,
);

export const getErrorMessage = code =>
  createSelector(
    state => state.environmentEntities.language,
    language => language.languages[language.languageCode]?.errorList?.find(x => x.errorCode === code)?.errorMessage,
  );

export const getTncByTag = ({ tag }) =>
  createSelector(
    state => state.environmentEntities.language,
    language => {
      const tncList = language.languages[language.languageCode].tnc;
      const found = tncList.find(item => item.tag === tag);
      return found;
    },
  );

export const getHomeBannerMessage = createSelector(
  state => state.environmentEntities.language,
  language => language.languages[language.languageCode]?.bannerMsg,
);
