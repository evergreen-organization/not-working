import { createSlice, isAnyOf } from '@reduxjs/toolkit';
import { REHYDRATE } from 'redux-persist';
import { languages } from 'constant';
import { initApp } from '../version';
import { IDLE, SUCCESS } from 'apis';
import { getLanguageData } from './thunk';
import { callAutoDebitTerminateReason } from 'stores/banking';

const initialState = {
  languageCode: 'EN', //Default Current language
  languages: {
    EN: {
      languageVersion: 0,
      appLanguageVersion: 0,
      autoDebitTerminateReason: [],
    },
    MS: {
      languageVersion: 0,
      appLanguageVersion: 0,
      autoDebitTerminateReason: [],
    },
    ZH: {
      languageVersion: 0,
      appLanguageVersion: 0,
      autoDebitTerminateReason: [],
    },
  },
  autoDebitTerminateReasonStatus: IDLE,
  status: IDLE,
};

const slice = createSlice({
  name: 'language',
  initialState: initialState,
  reducers: {
    updateLanguageObject: (state, { payload }) => {
      for (const key in payload) {
        state[key] = payload[key];
      }
    },
  },
  extraReducers: builder => {
    builder.addCase(REHYDRATE, (state, { payload }) => {
      if (payload?.language) {
        const p = payload.language.languages;
        state.languageCode = payload.language.languageCode;

        for (let key in p) {
          const data = p[key]?.languageVersion > languages[key]?.languageVersion ? p[key] : languages[key];

          state.languages[key] = {
            ...data,
            appLanguageVersion: p[key].appLanguageVersion ?? languages[key].appLanguageVersion,
            tnc: p[key].tnc ?? languages[key].tnc,
            bannerMsg: '',
          };
        }

        const hasReasons = Object.values(state.languages).some(lang => lang.autoDebitTerminateReason?.length > 0);
        if (hasReasons) {
          state.autoDebitTerminateReasonStatus = SUCCESS;
        }
      } else {
        state.languageCode = 'EN';
        state.languages.EN = languages.EN;
        state.languages.MS = languages.MS;
        state.languages.ZH = languages.ZH;
      }
    });

    builder.addCase(callAutoDebitTerminateReason.fulfilled, (state, { payload }) => {
      // Store auto debit terminate reasons for each language
      if (payload && payload?.reason) {
        const languageList = ['EN', 'MS', 'ZH'];
        languageList.forEach(langCode => {
          state.languages[langCode].autoDebitTerminateReason = payload.reason
            .filter(item => item.languageCode === langCode)
            .map(({ id, value }) => ({ id, value }));
        });
      }
      state.autoDebitTerminateReasonStatus = SUCCESS;
    });

    builder.addMatcher(isAnyOf(initApp.fulfilled, getLanguageData.fulfilled), (state, { payload }) => {
      const { languageCode, languageVersion, appLanguageVersion, errorList, tnc, bannerMsg } = payload.language || {};
      state.languageCode = languageCode;

      const selectedLanguage = state?.languages[languageCode];
      selectedLanguage.languageVersion = languageVersion;
      selectedLanguage.appLanguageVersion = appLanguageVersion;

      if (errorList) selectedLanguage.errorList = errorList;
      if (tnc) selectedLanguage.tnc = tnc;
      if (bannerMsg) selectedLanguage.bannerMsg = bannerMsg;
    });
  },
});

export const { updateLanguageObject } = slice.actions;

export default slice.reducer;
