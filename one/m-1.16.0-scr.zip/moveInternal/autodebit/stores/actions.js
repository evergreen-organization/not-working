import { NativeModules } from 'react-native';
import { authStorage } from '../auth/storage';

//lifestyle
import { requestLogout, requestUnbind } from './lifestyle/auth/thunk';
import { lastLoginCleared, tokenCleared, userReset, userInfoReset } from './lifestyle/user/reducer';
import { notificationReset } from './lifestyle/notification/reducer';
import { biometricReset } from './lifestyle/biometric/reducer';
import { loyaltyCardReset } from './lifestyle/loyaltyCard/reducer';
import { scheduledGroupReset } from './lifestyle/scheduledTran/group/reducer';
import { scheduledTranReset } from './lifestyle/scheduledTran/tran/reducer';
import { homeReset } from './lifestyle/home/reducer';

//banking
import { paymentAuthReset, softTokenReset } from './banking/softToken';
import { portfolioReset } from './banking/portfolio/reducer';
import { fundTransferReset } from './banking/fundTransfer/reducer';
import { recurringReset } from './banking/recurring/reducer';
import { duitNowIdReset } from './banking/duitNowId/reducer';
import { billReset } from './banking/bill/reducer';
import { cardPaymentReset } from './banking/cardPayment/reducer';
import { loanPaymentReset } from './banking/loanPayment/reducer';
import { topUpReset } from './banking/topUp/reducer';
import { appointmentReset } from './banking/appointment/reducer';
import { bankingUserReset } from './banking/bankingUser/reducer';
import { initCasa, resetCasa } from './banking/casa/reducer';
import { resetDeposit } from './banking/deposit/reducer';
import { resetInvest } from './banking/invest/reducer';
import { resetLoan } from './banking/loan/reducer';
import { resetCard } from './banking/card/reducer';
import { resetRNID } from './banking/rnid/reducer';
import { journeyReset } from './banking/pbJourney/reducer';
import { remittanceReset } from './banking/remittance/reducer';
import { cardlessReset } from './banking/cardlessWithdraw/reducer';
import { cashAdvanceReset } from './banking/cashAdvance/reducer';
import { flexipayReset } from './banking/flexipay/reducer';
import { trackerReset } from './banking/tracker/reducer';
import { carbonTrackerReset } from './banking/carbonTracker/reducer';
import { goldReset } from './banking/gold/reducer';
import { insuranceReset } from './banking/insurance/reducer';
import { autoDebitReset } from './banking';

//environment
import { casaAppFormReset } from './environment/casaAppForm/reducer';
import { initPublic } from './environment/version/thunk';
import { mailBoxReset } from './banking/mailbox/reducer';
import { resetAuth, updateIsLoginReady } from './lifestyle/auth/reducer';
import { appRatingReset, resetUntrustedSource } from './environment';
const { AiFPSModule } = NativeModules;

//service
import {
  baseQueryApi,
  protectedBaseQueryApi
} from './services';

export const removeAuthStorageData = () => {
  // authStorage.removeAccessToken().then();//Will remove at reInitialize
  authStorage.removePreLoginAccessToken().then();
  authStorage.removePrivateAccessToken().then();
  authStorage.removeAifpsCsid().then();

  authStorage.removeRecentTranBene().then();
  authStorage.removeRecentBillBene().then();
  authStorage.removeRecentCardPaymentBene().then();
  authStorage.removeRecentLoanPaymentBene().then();
  authStorage.removeRecentTopUpBene().then();
  authStorage.removeRecentCardlessWithdraw().then();
  authStorage.removeRecentRemittanceBene().then();
  authStorage.removeEKYCApplyKey().then();
};

export const unbound = () => async dispatch => {
  removeAuthStorageData();
  dispatch(clearAllQueryApiCache()); //clear all data cached
  dispatch(unbind());
  dispatch(userReset());
  dispatch(notificationReset());
  dispatch(biometricReset());
  dispatch(softTokenReset());
  dispatch(casaAppFormReset());
  dispatch(mailBoxReset());
  dispatch(carbonTrackerReset());
  dispatch(goldReset());
  dispatch(appRatingReset());
  dispatch(resetUntrustedSource());
  dispatch(homeReset());
};

export const unBindLocalDevice = () => async dispatch => {
  removeAuthStorageData();
  dispatch(clearAllQueryApiCache()); //clear all data cached
  dispatch(userReset());
  dispatch(notificationReset());
  dispatch(biometricReset());
  dispatch(softTokenReset());
  dispatch(casaAppFormReset());
  dispatch(mailBoxReset());
  dispatch(carbonTrackerReset());
  dispatch(appRatingReset());
  dispatch(resetUntrustedSource());
  dispatch(homeReset());
  dispatch(reInitialize()); //Clear local data before logging out at server
  dispatch(initCasa());
};

const unbind = () => async dispatch => {
  const accessToken = await authStorage.getAccessToken();
  dispatch(reInitialize()); //Clear local data before logging out at server
  dispatch(initCasa());

  await Promise.all([
    dispatch(requestUnbind({ accessToken })), //Unbind will logout public
    dispatch(requestLogout({ isPublic: false })),
  ]);

  dispatch(initPublic());
};

export const logout = () => async dispatch => {
  const accessToken = await authStorage.getAccessToken();
  dispatch(reInitialize()); //Clear local data before logging out at server

  dispatch(updateIsLoginReady(false));
  AiFPSModule.logout();
  await Promise.all([
    dispatch(requestLogout({ isPublic: true, accessToken })),
    dispatch(requestLogout({ isPublic: false })),
  ]);
  dispatch(updateIsLoginReady(true));
};

export const reInitialize =
  (clearAll = true) =>
  dispatch => {
    dispatch(clearProtectedQueryApiCache()); //clear private data cached
    authStorage.removeAccessToken().then();
    dispatch(tokenCleared());
    dispatch(lastLoginCleared());
    dispatch(bankingUserReset());
    dispatch(resetCasa());
    dispatch(resetDeposit());
    dispatch(resetInvest());
    dispatch(resetLoan());
    dispatch(resetCard());
    dispatch(resetRNID());
    dispatch(portfolioReset());
    dispatch(loyaltyCardReset());
    dispatch(scheduledGroupReset());
    dispatch(scheduledTranReset());
    dispatch(fundTransferReset());
    dispatch(recurringReset());
    dispatch(duitNowIdReset());
    dispatch(cardPaymentReset());
    dispatch(loanPaymentReset());
    dispatch(topUpReset());
    dispatch(appointmentReset());
    dispatch(journeyReset());
    dispatch(remittanceReset());
    dispatch(cardlessReset());
    dispatch(cashAdvanceReset());
    dispatch(flexipayReset());
    dispatch(trackerReset());
    dispatch(carbonTrackerReset());
    dispatch(userInfoReset());
    dispatch(goldReset());
    dispatch(insuranceReset());
    dispatch(autoDebitReset());

    if (clearAll) {
      authStorage.removePreLoginAccessToken().then();
      dispatch(resetAuth());
      dispatch(billReset());
      dispatch(paymentAuthReset());
    }
  };

export const clearQueryApiCache = () => async dispatch => {
  dispatch(baseQueryApi.util.resetApiState());
};

export const clearAllQueryApiCache = () => async dispatch => {
  dispatch(baseQueryApi.util.resetApiState());
  dispatch(protectedBaseQueryApi.util.resetApiState());
};

export const clearProtectedQueryApiCache = () => async dispatch => {
  dispatch(protectedBaseQueryApi.util.resetApiState());
};
