import { createSlice, isAnyOf } from '@reduxjs/toolkit';
import { submitFundTransfer } from '../../banking/fundTransfer/index';
import { manageDuitNowProxy, registerDuitNowProxy } from '../../banking/duitNowId/index';
import { getAlipayPlusPayCode, submitAlipayPlus, submitQRPayment } from '../../banking/qrPayment';
import { submitBillPayment } from '../../banking/bill';
import { submitCardlessWithdraw } from '../../banking/cardlessWithdraw/index';
import {
  answerAAOP,
  changeCQ,
  checkPBO,
  closeProfile,
  getCQ,
  initSoftTokenActivation,
  requestAuthChallengeCode,
  requestAuthPac,
  requestBind,
  requestChangePin,
  requestLinkPBe,
  requestSecfaType,
  requestSession,
  sessionLogin,
  submitPostLogin,
  submitQuickLogin,
  submitRegistration,
  updateQuickPayment,
  updateAwarenessConsent,
  validateEmail,
  validateEmailMobile,
  validatePin,
  enrolCQ,
  updateMarketingConsent,
  updateQuizControl,
} from './thunk';
import { submitBakong } from 'stores/banking/remittance';
import { submitCarbonOffset } from 'stores/banking/carbonTracker';
import { submitBuyGold, submitCloseGoldAccount, submitSellGold } from 'stores/banking/gold';
import { submitApproveConsent, submitEditConsent, submitTransferConsent } from 'stores/banking';
import {
  generateTokenInstance,
  getSoftTokenCQStatus,
  registerDSApp,
  submitCardPin,
  submitCashAdvance,
  submitTopUp,
  updateProfileAccess,
} from 'stores/banking';

export const junctionType = Object.freeze({
  OPEN: 'mobileOpen',
  SECURE: 'mobile',
});

export const pacType = Object.freeze({
  PAC: 'PAC',
  HARD_TOKEN: 'HARD_TOKEN',
});

const initialState = {
  email: null,
  pbeEmail: null,
  isUpdateEmail: false,
  phone: null,
  pin: null,
  name: null,
  status: 'idle',
  error: null,
  isPBeUser: false,
  flowType: null,
  cqEnrolQuestion: null,
  challengeQuestion: null,
  isChangeCQ: false,
  cqLastAttempt: false,
  challengeStatus: 'idle',
  cqChallengeResult: null,
  encryptedEKYCApplyKey: null,
  isLoginReady: true,
  isDemo: false,
  cqRemainingAttempt: null,
  marketingConsent: false,
  hasCQStatusInquired: false,
  quizStatus: 'idle'
};

const slice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    authReset: _ => initialState,
    authInit: state => {
      const { cqEnrolQuestion } = state;
      return { ...initialState, cqEnrolQuestion };
    },
    requestAuth: auth => {
      auth.status = 'loading';
      auth.error = null;
    },
    updateAuthObject: (auth, { payload }) => {
      auth.status = 'succeeded';
      for (const key in payload) {
        auth[key] = payload[key];
      }
    },
    updateBoundKey: (auth, payload) => {
      auth.deviceId = payload.deviceId;
      auth.encryptedId = payload.encryptedId;
    },
    updateAAOPQuestion: (auth, { payload }) => {
      auth.cqEnrolQuestion = payload;
    },
    updateAAOPChallenge: (auth, { payload }) => {
      auth.challengeQuestion = payload;
    },
    updateIsLoginReady: (auth, { payload }) => {
      auth.isLoginReady = payload;
    },
    updateCqChallengeResult: (auth, { payload }) => {
      auth.cqChallengeResult = payload;
    },
    resetAAOPChallenge: auth => {
      auth.challengeQuestion = initialState.challengeQuestion;
      auth.isChangeCQ = initialState.isChangeCQ;
    },
  },
  extraReducers: builder => {
    builder.addCase(validateEmailMobile.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(validateEmailMobile.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.isEmailExist = payload.isEmailExist;
      auth.email = payload.email;
      auth.phone = payload.phone;
      auth.flowType = payload.flowType;
    });
    builder.addCase(validateEmailMobile.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(validateEmail.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(validateEmail.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.isEmailExist = payload.isEmailExist;
      auth.email = payload.email;
    });
    builder.addCase(validateEmail.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(requestSession.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(requestSession.fulfilled, auth => {
      auth.status = 'succeeded';
    });
    builder.addCase(requestSession.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(sessionLogin.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(sessionLogin.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(checkPBO.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(checkPBO.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      if (payload.challengeQuestion) {
        auth.challengeQuestion = payload.challengeQuestion;
        auth.isChangeCQ = payload.isChangeCQ;
        auth.cqLastAttempt = payload.cqLastAttempt;
        auth.cqRemainingAttempt = payload.cqRemainingAttempt;
        return;
      }
      auth.isPBeUser = payload.isPBORegistered;
      auth.secfaType = payload.secfaType;
      auth.email = payload.email;
      auth.pbeEmail = payload.pbeEmail;
      if (payload?.aaop) auth.cqEnrolQuestion = payload.aaop;
    });
    builder.addCase(getCQ.fulfilled, (auth, { payload }) => {
      auth.cqEnrolQuestion = payload.aaop;
    });
    builder.addCase(checkPBO.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(requestSecfaType.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(requestSecfaType.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.secfaType = payload.secfaType;
      auth.email = payload.email;
      auth.flowType = payload.flowType;
    });
    builder.addCase(requestSecfaType.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(requestAuthPac.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(requestAuthPac.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      if (!payload.isPublic) auth.phone = payload.phoneNo;
      auth.pacSeqNo = payload.pacSeqNo;
    });
    builder.addCase(requestAuthPac.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(requestAuthChallengeCode.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(requestAuthChallengeCode.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.challengeCode2 = payload.challengeCode2;
      auth.challengeCode1 = payload.challengeCode1;
    });
    builder.addCase(requestAuthChallengeCode.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(submitRegistration.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(submitRegistration.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.deviceId = payload.deviceId;
      auth.encryptedId = payload.encryptedId;
      auth.accessKey = payload.accessKey;
      auth.phone = payload.mobileNo;
      auth.isPBeUser = payload.isPBeUser;
      auth.name = payload.displayName;
      auth.email = payload.email;
    });
    builder.addCase(submitRegistration.rejected, (auth, { payload }) => {
      auth.status = 'failed';
      if (payload.data && typeof payload.data !== 'string') {
        auth.isPinLocked = payload.data.isPinLocked;
        auth.errorAttempt = payload.data.secfaAttempts;
      }
    });
    builder.addCase(requestBind.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(requestBind.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.deviceId = payload.deviceId;
      auth.encryptedId = payload.encryptedId;
      auth.accessKey = payload.accessKey;
      auth.name = payload.displayName;
      auth.isPBeUser = payload.isPBeUser;
      auth.phone = payload.mobileNo;
      auth.pbeId = payload.userId;
    });
    builder.addCase(requestBind.rejected, (auth, { payload }) => {
      auth.status = 'failed';
      if (payload.data && typeof payload.data !== 'string') {
        auth.isPinLocked = payload.data.isPinLocked;
        auth.errorAttempt = payload.data.secfaAttempts;
      }
    });
    builder.addCase(requestLinkPBe.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(requestLinkPBe.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.deviceId = payload.deviceId;
      auth.encryptedId = payload.encryptedId;
      auth.accessKey = payload.accessKey;
      auth.name = payload.displayName;
      auth.isPBeUser = payload.isPBeUser;
      auth.phone = payload.mobileNo;
      auth.pbeId = payload.userId;
    });
    builder.addCase(requestLinkPBe.rejected, (auth, { payload }) => {
      auth.status = 'failed';
      if (payload.data && typeof payload.data !== 'string') {
        auth.isPinLocked = payload.data.isPinLocked;
        auth.errorAttempt = payload.data.secfaAttempts;
      }
    });
    builder.addCase(requestChangePin.pending, (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addCase(requestChangePin.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.pin = payload.pin;
    });
    builder.addCase(requestChangePin.rejected, (auth, { payload }) => {
      auth.status = 'failed';
      if (payload.data && typeof payload.data !== 'string') {
        auth.isPinLocked = payload.data.isPinLocked;
        auth.errorAttempt = payload.data.secfaAttempts;
      }
    });
    builder.addCase(closeProfile.pending, auth => {
      auth.status = 'loading';
    });
    builder.addCase(closeProfile.fulfilled, auth => {
      auth.status = 'succeeded';
    });
    builder.addCase(closeProfile.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(initSoftTokenActivation.pending, auth => {
      auth.status = 'loading';
    });
    builder.addCase(initSoftTokenActivation.fulfilled, (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.phone = payload.phoneNo;
      auth.pacSeqNo = payload.pacSeqNo;
    });
    builder.addCase(initSoftTokenActivation.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(answerAAOP.pending, auth => {
      auth.challengeStatus = 'loading';
    });
    builder.addCase(answerAAOP.fulfilled, (auth, { payload }) => {
      auth.challengeStatus = 'succeeded';
      auth.isPBeUser = payload.isPBORegistered;
      auth.secfaType = payload.secfaType;
      auth.email = payload.email;
    });
    builder.addCase(answerAAOP.rejected, auth => {
      auth.challengeStatus = 'failed';
    });
    builder.addCase(updateAwarenessConsent.pending, auth => {
      auth.status = 'loading';
    });
    builder.addCase(updateAwarenessConsent.fulfilled, auth => {
      auth.status = 'succeeded';
    });
    builder.addCase(updateAwarenessConsent.rejected, auth => {
      auth.status = 'failed';
    });
    builder.addCase(updateMarketingConsent.pending, (auth, { payload }) => {
      auth.marketingConsent = initialState.marketingConsent;
    });
    builder.addCase(updateQuizControl.pending, auth => {
      auth.quizStatus = 'loading';
    })
    builder.addCase(updateQuizControl.fulfilled, auth => {
      auth.quizStatus = 'succeeded';
    });
    builder.addCase(updateQuizControl.rejected, auth => {
      auth.quizStatus = 'failed';
    });


    builder.addCase(getSoftTokenCQStatus.fulfilled, auth => {
      auth.hasCQStatusInquired = true;
    });
    builder.addMatcher(isAnyOf(submitQuickLogin.pending, submitPostLogin.pending), (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addMatcher(isAnyOf(submitQuickLogin.fulfilled, submitPostLogin.fulfilled), (auth, { payload }) => {
      auth.status = 'succeeded';
      auth.accessKey = payload.accessKey;
      auth.isPBeUser = payload.isPBeUser;
      auth.name = payload.displayName;
      auth.phone = payload.mobileNo;
      auth.pbeId = payload.userId;
      auth.email = payload.email;
      auth.marketingConsent = payload.isMarketingConsentRequired;
      if (payload.challengeQuestion) {
        auth.challengeQuestion = payload.challengeQuestion;
        auth.isChangeCQ = payload.isChangeCQ;
        auth.cqLastAttempt = payload.cqLastAttempt;
        auth.cqRemainingAttempt = payload.cqRemainingAttempt;
      }
    });
    builder.addMatcher(isAnyOf(submitQuickLogin.rejected, submitPostLogin.rejected), (auth, { payload }) => {
      auth.status = 'failed';
      if (payload.data && typeof payload.data !== 'string') {
        auth.isPinLocked = payload.data.isPinLocked;
        auth.errorAttempt = payload.data.pinAttempts ?? payload.data.secfaAttempts;
      }
    });
    builder.addMatcher(isAnyOf(validatePin.pending, getAlipayPlusPayCode.pending), (auth, { payload }) => {
      slice.caseReducers.requestAuth(auth, payload);
    });
    builder.addMatcher(isAnyOf(validatePin.fulfilled, getAlipayPlusPayCode.fulfilled), auth => {
      auth.status = 'succeeded';
    });
    builder.addMatcher(isAnyOf(validatePin.rejected, getAlipayPlusPayCode.rejected), (auth, { payload }) => {
      auth.status = 'failed';
      if (payload.data && typeof payload.data !== 'string') {
        auth.isPinLocked = payload.data.isPinLocked;
        auth.errorAttempt = payload.data.pinAttempts;
      }
    });

    builder.addMatcher(
      isAnyOf(
        submitFundTransfer.pending,
        submitQRPayment.pending,
        registerDuitNowProxy.pending,
        manageDuitNowProxy.pending,
        submitBillPayment.pending,
        submitCardlessWithdraw.pending,
        submitBakong.pending,
        submitAlipayPlus.pending,
        requestChangePin.pending,
        submitCarbonOffset.pending,
        submitBuyGold.pending,
        submitSellGold.pending,
        submitCloseGoldAccount.pending,
        updateQuickPayment.pending,
        submitTopUp.pending,
        generateTokenInstance.pending,
        changeCQ.pending,
        registerDSApp.pending,
        updateProfileAccess.pending,
        enrolCQ.pending,
        submitCashAdvance.pending,
        submitCardPin.pending,
        submitApproveConsent.pending,
        submitEditConsent.pending,
        submitTransferConsent.pending,
      ),
      auth => {
        auth.challengeStatus = 'loading';
      },
    );
    builder.addMatcher(
      isAnyOf(
        submitFundTransfer.fulfilled,
        submitQRPayment.fulfilled,
        registerDuitNowProxy.fulfilled,
        manageDuitNowProxy.fulfilled,
        submitBillPayment.fulfilled,
        submitCardlessWithdraw.fulfilled,
        submitBakong.fulfilled,
        submitAlipayPlus.fulfilled,
        requestChangePin.fulfilled,
        submitCarbonOffset.fulfilled,
        submitBuyGold.fulfilled,
        submitSellGold.fulfilled,
        submitCloseGoldAccount.fulfilled,

        updateQuickPayment.fulfilled,
        submitTopUp.fulfilled,
        generateTokenInstance.fulfilled,
        changeCQ.fulfilled,
        registerDSApp.fulfilled,
        updateProfileAccess.fulfilled,
        enrolCQ.fulfilled,
        submitCashAdvance.fulfilled,
        submitCardPin.fulfilled,
        submitApproveConsent.fulfilled,
        submitEditConsent.fulfilled,
        submitTransferConsent.fulfilled,
      ),
      (auth, { payload }) => {
        auth.challengeStatus = 'succeeded';
        if (payload.challengeQuestion) {
          auth.challengeQuestion = payload.challengeQuestion;
          auth.isChangeCQ = payload.isChangeCQ;
          auth.cqLastAttempt = payload.cqLastAttempt;
          auth.cqRemainingAttempt = payload.cqRemainingAttempt;
        }
      },
    );
    builder.addMatcher(
      isAnyOf(
        submitFundTransfer.rejected,
        submitQRPayment.rejected,
        registerDuitNowProxy.rejected,
        manageDuitNowProxy.rejected,
        submitBillPayment.rejected,
        submitCardlessWithdraw.rejected,
        submitBakong.rejected,
        submitAlipayPlus.rejected,
        submitCarbonOffset.rejected,
        requestChangePin.rejected,
        submitBuyGold.rejected,
        submitSellGold.rejected,
        submitCloseGoldAccount.rejected,
        updateQuickPayment.rejected,
        submitTopUp.rejected,
        generateTokenInstance.rejected,
        changeCQ.rejected,
        registerDSApp.rejected,
        updateProfileAccess.rejected,
        enrolCQ.rejected,
        submitCashAdvance.rejected,
        submitCardPin.rejected,
        submitApproveConsent.rejected,
        submitEditConsent.rejected,
        submitTransferConsent.rejected,
      ),
      auth => {
        auth.challengeStatus = 'failed';
      },
    );
  },
});

export const {
  updateAuthObject,
  authReset,
  authInit,
  updateBoundKey,
  updateAAOPQuestion,
  updateAAOPChallenge,
  updateIsLoginReady,
  updateCqChallengeResult,
  resetAAOPChallenge,
} = slice.actions;
export default slice.reducer;

export const resetAuth = () => authReset();
