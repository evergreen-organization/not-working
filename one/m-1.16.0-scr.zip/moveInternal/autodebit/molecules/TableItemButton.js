import React from 'react';
import { TouchableOpacity, StyleSheet, View, Image } from 'react-native';
import { colors } from 'configs';

import { Text } from '../../text';
import RightIcon from 'assets/images/icon/right.png';
import { useTranslation } from 'react-i18next';

const LANG_PREFIX = 'screens.componentConfirmation.text.';

export const TableItemButton = ({ title, value, placeholder, onPress, valueFontStyle }) => {
  const { t } = useTranslation();
  return (
    <View style={styles.container}>
      <Text numberOfLines={1} style={{ fontSize: 14, color: colors.medium }}>
        {title}
      </Text>
      <TouchableOpacity
        accessibilityRole={'button'}
        style={{ height: '100%', flexDirection: 'row', alignItems: 'center' }}
        onPress={onPress}>
        {value !== null ? (
          <Text style={[styles.valueText, valueFontStyle]}>{value}</Text>
        ) : (
          <Text style={{ fontSize: 14, color: colors.lightgrey }}>
            {placeholder ? placeholder : t(LANG_PREFIX + 'buttonPleaseSelect')}
          </Text>
        )}
        <Image source={RightIcon} style={styles.rightIcon} />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    minHeight: 45,
  },
  rightIcon: {
    width: 10,
    height: 10,
    tintColor: colors.black,
    marginLeft: 8,
    marginRight: -2,
  },
  valueText: {
    fontSize: 14,
    color: colors.primary,
  },
});

export default TableItemButton;
