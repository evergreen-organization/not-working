export const NOTIFICATION_ACTION = {
  PENDING_TRX: 'pendingTrx',
  JOURNEY_TASK_UPDATED: 'journeyTaskUpdated',
  TRX_REMINDER: 'trxReminder',
  LOYALTY_CARD: 'loyaltyCard',
  BIRTHDAY: 'birthday',
  ALIPAYPLUS_CPM: 'aplusCpm',
  ALIPAYPLUS_CPM_PAYING: 'aplusCpmPaying',
  RCB_BDAY: 'RCB_BDAY',
  AUTODEBIT_CONSENT: 'consentApproval',
};
