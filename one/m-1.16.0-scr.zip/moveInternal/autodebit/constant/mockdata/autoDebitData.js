import { AUTO_DEBIT_CONSENT_STATUS } from 'screens/autoDebit/constants';
import { mockTransactionDateToday } from './dateTime';
import dayjs from 'dayjs';

const today = dayjs();

const formatDate = date => dayjs(date).format('DD/MM/YYYY HH:mm:ss');

const getRandomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const generateConsentDate = () => today.subtract(getRandomInt(0, 10), 'day').toDate();

const generateRegisterDate = () => today.subtract(getRandomInt(0, 30), 'day').toDate();

const generateReqExpiryDate = baseDate => dayjs(baseDate).add(10, 'day').toDate();

const generateEffectiveDate = date => dayjs(date).add(getRandomInt(1, 7), 'day').toDate();

const generateCompletionDate = () => today.add(getRandomInt(14, 1825), 'day').toDate();

const calculateFrequency = (effectiveDate, completionDate) => {
  const days = dayjs(completionDate).diff(dayjs(effectiveDate), 'day');
  return days <= 29 ? '03' : days <= 365 ? '04' : '06';
};

const generateDatesByStatus = status => {
  let requestDate, registerDate, reqExpiryDate, effectiveDate, completionDate;

  switch (status) {
    case AUTO_DEBIT_CONSENT_STATUS.PNDG.key:
      requestDate = generateConsentDate();
      reqExpiryDate = generateReqExpiryDate(requestDate);
      effectiveDate = generateEffectiveDate(reqExpiryDate);
      completionDate = generateCompletionDate();
      break;

    case AUTO_DEBIT_CONSENT_STATUS.EXPI.key:
      reqExpiryDate = generateConsentDate();
      requestDate = dayjs(reqExpiryDate).subtract(10, 'day').toDate();
      effectiveDate = generateEffectiveDate(reqExpiryDate);
      completionDate = generateCompletionDate();
      break;

    case AUTO_DEBIT_CONSENT_STATUS.ACTV.key:
      registerDate = generateRegisterDate();
      effectiveDate = generateEffectiveDate(registerDate);
      completionDate = generateCompletionDate();
      break;
    case AUTO_DEBIT_CONSENT_STATUS.ACTB.key:
      registerDate = generateRegisterDate();
      effectiveDate = generateEffectiveDate(registerDate);
      completionDate = generateCompletionDate();
      break;
    case AUTO_DEBIT_CONSENT_STATUS.ICTV.key:
      completionDate = today.subtract(getRandomInt(1, 10), 'day').toDate();
      effectiveDate = dayjs(completionDate).subtract(getRandomInt(30, 90), 'day').toDate();
      registerDate = dayjs(effectiveDate).subtract(10, 'day').toDate();
      break;

    default: // INACTIVE, SUSPENDED, TERMINATED, or others
      registerDate = generateConsentDate();
      effectiveDate = generateEffectiveDate(registerDate);
      completionDate = generateCompletionDate();
  }

  const frequency = calculateFrequency(effectiveDate, completionDate);

  return {
    ...(requestDate && { requestDate: formatDate(requestDate) }),
    ...(registerDate && { registerDate: formatDate(registerDate) }),
    ...(reqExpiryDate && { reqExpiryDate: formatDate(reqExpiryDate) }),
    effectiveDate: formatDate(effectiveDate),
    completionDate: formatDate(completionDate),
    frequency,
  };
};

const consentList = {
  pending: [
    {
      consentId: '001',
      productId: '01',
      merchantName: 'Telekom Malaysia',
      consentDesc: 'Electricity Bill',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.PNDG.key),
      maxAmnt: '500',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.PNDG.key,
      duitNowRefNo: '20250617PBBEMYKL3893823928329',
      fromAccNo: '3700025129',
      fromAccNoType: 'CASA',
      otherDetail: 'Bill April', //optional
    },
    {
      consentId: '002',
      productId: '02',
      merchantName: 'Astro Malaysia',
      consentDesc: 'Platinum Plan',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.EXPI.key),
      maxAmnt: '500',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.EXPI.key,
      duitNowRefNo: '20250617PBBEMYKL9898289838336',
      fromAccNo: '3700025129',
      fromAccNoType: 'CREDIT_CARD',
    },
    {
      consentId: '003',
      productId: '03',
      merchantName: 'Maxis',
      consentDesc: 'Phone Bill',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.PNDG.key),
      maxAmnt: '1000',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.PNDG.key,
      duitNowRefNo: '20250617PBBEMYKL9198289838336',
      fromAccNo: '5700025129',
      fromAccNoType: 'CREDIT_CARD',
    },
    {
      consentId: '004',
      productId: '04',
      merchantName: 'Prime Malaysia',
      consentDesc: 'Basic Plan',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.EXPI.key),
      maxAmnt: '7000',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.EXPI.key,
      duitNowRefNo: '20250617PBBEMYKL9298289838336',
      fromAccNo: '3700025129',
      fromAccNoType: 'CASA',
    },
    {
      consentId: '005',
      productId: '05',
      merchantName: 'Netflix Malaysia',
      consentDesc: 'Basic Plan',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.PNDG.key),
      maxAmnt: '300',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.PNDG.key,
      duitNowRefNo: '20250617PBBEMYKL87654324245643',
      fromAccNo: '3700025129',
      fromAccNoType: 'CASA',
    },
  ],
  registered: [
    {
      consentId: '006',
      productId: '06',
      merchantName: 'Astro Malaysia',
      consentDesc: 'Platinum Plan',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.ACTV.key),
      maxAmnt: '300',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.ACTV.key,
      duitNowRefNo: '9398289838336',
      fromAccNo: '47000025129',
      refNo: '123456',
      editable: true,
      terminatable: true,
    },
    {
      consentId: '007',
      productId: '07',
      merchantName: 'Telekom Malaysia',
      consentDesc: 'Unifi Plan',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.ACTB.key),
      maxAmnt: '400',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.ACTB.key,
      duitNowRefNo: '7464783939844',
      fromAccNo: '47000025129',
      refNo: '123456',
    },
    {
      consentId: '008',
      productId: '08',
      merchantName: 'Netflix Malaysia',
      consentDesc: 'Basic Plan',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.SUSP.key),
      maxAmnt: '700',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.SUSP.key,
      duitNowRefNo: '87654324245644',
      fromAccNo: '47000025129',
      refNo: '123456',
    },
    {
      consentId: '009',
      productId: '09',
      merchantName: 'Indah Water',
      consentDesc: 'Water Bill',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.ICTV.key),
      maxAmnt: '200',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.ICTV.key,
      duitNowRefNo: '9498289838336',
      fromAccNo: '47000025129',
      refNo: '123456',
    },
    {
      consentId: '0010',
      productId: '10',
      merchantName: 'Sephora ',
      consentDesc: 'Membership ',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.CANC.key),
      maxAmnt: '1000',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.CANC.key,
      duitNowRefNo: '9598289838336',
      fromAccNo: '47000025129',
    },
    {
      consentId: '0011',
      productId: '11',
      merchantName: 'Telekom Malaysia',
      consentDesc: 'Electricity Bill',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.SUSP.key),
      maxAmnt: '300',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.SUSP.key,
      duitNowRefNo: '3993823928329',
      fromAccNo: '47000025129',
      refNo: '123456',
    },
    {
      consentId: '0012',
      productId: '12',
      merchantName: 'Maxis',
      consentDesc: 'Phone Bill',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.SUSB.key),
      maxAmnt: '1300',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.SUSB.key,
      duitNowRefNo: '9698289838336',
      fromAccNo: '47000025129',
      refNo: '123456',
    },
    {
      consentId: '0013',
      productId: '13',
      merchantName: 'Prime Malaysia',
      consentDesc: 'Basic Plan',
      ...generateDatesByStatus(AUTO_DEBIT_CONSENT_STATUS.CANC.key),
      maxAmnt: '700',
      consentStatus: AUTO_DEBIT_CONSENT_STATUS.CANC.key,
      duitNowRefNo: '9798289838336',
      fromAccNo: '47000025129',
      refNo: '123456',
    },
  ],
};

const approveConsent = {
  refNo: '123456',
  tranDateTime: mockTransactionDateToday,
  consentStatus: AUTO_DEBIT_CONSENT_STATUS.ACTV.key,
  status: 'S',
};

const rejectConsent = {
  status: 'S',
};

const editConsent = {
  status: 'S',
};

const terminateReason = {
  reason: [
    { id: '1', value: 'Banking / Account Changes', languageCode: 'EN' },
    { id: '2', value: 'Billing Issues', languageCode: 'EN' },
    { id: '3', value: 'Change of Payment Methods', languageCode: 'EN' },
    { id: '4', value: 'Changing Provvalueers', languageCode: 'EN' },
    { id: '5', value: 'Contractual Changes', languageCode: 'EN' },
    { id: '6', value: 'End of Contract', languageCode: 'EN' },
    { id: '7', value: 'Financial Reasons', languageCode: 'EN' },
    { id: '8', value: 'Privacy Concerns', languageCode: 'EN' },
    { id: '9', value: 'Service No Longer Needed', languageCode: 'EN' },
    { id: '10', value: 'Service Discontinuation', languageCode: 'EN' },
    { id: '1', value: 'Pertukaran / Perubahan Akaun', languageCode: 'MS' },
    { id: '2', value: 'Masalah Bil', languageCode: 'MS' },
    { id: '3', value: 'Pemindahan Metode Pembayaran', languageCode: 'MS' },
    { id: '4', value: 'Pemindahan Penyedia', languageCode: 'MS' },
    { id: '5', value: 'Perubahan Kontrak', languageCode: 'MS' },
    { id: '6', value: 'Tamat Kontrak', languageCode: 'MS' },
    { id: '7', value: 'Alasan Keuangan', languageCode: 'MS' },
    { id: '8', value: 'Kekhawatiran Privasi', languageCode: 'MS' },
    { id: '9', value: 'Perkhidmatan Tidak Lagi Diperlukan', languageCode: 'MS' },
    { id: '10', value: 'Pembatalan Perkhidmatan', languageCode: 'MS' },
    { id: '1', value: 'Banking / Account Changes', languageCode: 'ZH' },
    { id: '2', value: 'Billing Issues', languageCode: 'ZH' },
    { id: '3', value: 'Change of Payment Methods', languageCode: 'ZH' },
    { id: '4', value: 'Changing Provvalueers', languageCode: 'ZH' },
    { id: '5', value: 'Contractual Changes', languageCode: 'ZH' },
    { id: '6', value: 'End of Contract', languageCode: 'ZH' },
    { id: '7', value: 'Financial Reasons', languageCode: 'ZH' },
    { id: '8', value: 'Privacy Concerns', languageCode: 'ZH' },
    { id: '9', value: 'Service No Longer Needed', languageCode: 'ZH' },
    { id: '10', value: 'Service Discontinuation', languageCode: 'ZH' },
  ],
  status: 'S',
};

const terminateConsent = {
  status: 'S',
};

const pastTranscation = {
  list: [
    {
      transactionDate: '10/06/2024 09:23:54',
      amount: '500',
      remarks: '',
      transactionStatus: 'succeeded',
    },
    {
      transactionDate: '10/07/2024 09:23:54',
      amount: '500',
      remarks: 'Insuffient balance',
      transactionStatus: 'Failed',
    },
  ],
  month: 0,
  status: 'S',
};

const consentInquiry = {
  details: {
    bankId: '55',
    bankName: 'Maybank',
    otherBankAccNo: '123432839344',
    productId: '12',
    merchantName: 'Telekom Malaysia',
    consentDesc: 'Wifi Bill',
    effectiveDate: '10/10/2024 09:12:34',
    completionDate: '10/10/2026 09:12:34',
    frequency: '06',
    maxAmnt: '5000',
    otherDetail: 'Plan 118',
    consentStatus: 'Pending',
    duitNowRefNo: '098897',
  },
  status: 'S',
};

const transferConsent = {
  refNo: '123456',
  consentStatus: AUTO_DEBIT_CONSENT_STATUS.ACTV.key,
  tranDateTime: mockTransactionDateToday,
  status: 'S',
};

const registerAutoDebit = {
  details: {
    consentId: '001',
    productId: '01',
    merchantName: 'PB Enterprise',
    consentDesc: 'Duitnow Request',
    requestDate: formatDate(today),
    effectiveDate: '12/07/2025 09:08:25',
    completionDate: '12/09/2025 09:08:25',
    frequency: '03',
    maxAmnt: '500',
    consentStatus: AUTO_DEBIT_CONSENT_STATUS.PNDG.key,
    duitNowRefNo: '20250617PBBEMYKL3893823928329',
    fromAccNo: '3700025129',
    fromAccNoType: 'CASA',
    otherDetail: '',
  },
};

export const AutoDebit = {
  ConsentList: consentList,
  ApproveConsent: approveConsent,
  RejectConsent: rejectConsent,
  EditConsent: editConsent,
  TerminateReason: terminateReason,
  TerminateConsent: terminateConsent,
  PastTransaction: pastTranscation,
  ConsentInquiry: consentInquiry,
  TransferConsent: transferConsent,
  RegisterAutoDebit: registerAutoDebit,
};
