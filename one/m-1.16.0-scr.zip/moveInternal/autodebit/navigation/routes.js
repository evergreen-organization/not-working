export default Object.freeze({
  //registration
  REGISTER_PBO: 'RegisterPBo',
  REGISTER_NEW: 'RegisterNew',
  REGISTER_EMAIL: 'RegisterEmail',
  REGISTER_DISPLAY_NAME: 'RegisterDisplayName',
  REGISTER_PIN: 'RegisterPin',
  REGISTER_PAC: 'RegisterPAC',
  REGISTER_BIO: 'registerBiometric',
  CONFIRM_UNBIND_AND_BIND: 'unbindAndBind',

  //authentication
  WELCOME: 'welcome',
  LOGIN_PBO: 'LoginPBO',
  LOGIN_CONFIRM: 'LoginConfirm',
  LOGIN_PBE_OLD: 'auth',
  MAIN_TAB: 'tab',
  LOGIN_PIN: 'login',
  APPLY_SA: 'applySA',
  SCAN_QR: 'qrScan',
  MY_QR: 'qrMe',
  CONFIRM_RESET_PIN: 'confirmResetPin',
  CONFIRM_LINK_PBE: 'confirmLinkPBe',
  APPLY_SA_STACK: 'applySAStack',
  HARD_TOKEN_COOLING: 'hardTokenCooling',

  ACCOUNT_TAB: 'AccountTab',
  PROFILE_TAB: 'ProfileTab',

  //home
  HOME: 'home',
  PFM_SUMMARY: 'PfmSummary',
  SCHEDULED_TRAN: 'scheduledTran',
  SCHEDULED_TRAN_DETAIL: 'scheduledTranDetail',
  SCHEDULED_TRAN_ENTITY_FORM: 'scheduledTranEntityForm',
  SCHEDULED_TRAN_EXPENSE_FORM: 'scheduledTranExpenseForm',
  HOME_LOADING: 'homeLoading',
  BLANK_ROUTING: 'blankRouting',
  QUICK_LINKS_ALL: 'quickLinksAll',
  HIGHLIGHT_LIST_ALL: 'highlightListAll',

  //home tab
  WALLET_FORM: 'walletForm',
  WALLET_LIST: 'walletList',
  EXPENSE_LIST: 'expenseList',
  EXPENSE_FORM: 'expenseForm',
  CATEGORY_LIST: 'categoryList',

  //Profile Tab
  PROFILE: 'Profile',
  ACCOUNT_SETTINGS: 'AccountSettings',
  ACCOUNT_FORM: 'AccountForm',
  APP_SETTINGS: 'AppSettings',
  APP_SECURITY: 'AppSecurity',
  LANGUAGE_SETTINGS: 'LanguageSettings',
  CONTACT_US: 'ContactUs',
  TNC: 'Tnc',
  ACCOUNT_UPDATE_NAME: 'AccountUpdateName',
  ACCOUNT_UPDATE_EMAIL: 'AccountUpdateEmail',
  VALIDATE_PIN: 'ValidatePin',
  BIRTHDAY: 'birthday',
  ACCOUNT_UPDATE_PROFILE: 'AccountUpdateProfile',

  //Device Management
  DEVICE_MANAGEMENT: 'DeviceManagement',

  //Notification
  NOTIFICATION: 'Notification',
  MAILBOX: 'Mailbox',
  MAILBOX_DETAIL: 'MailboxDetail',
  ANNOUNCEMENT: 'Announcement',

  //Loyalty Card
  LOYALTY: 'Loyalty',
  LOYALTY_DETAIL: 'LoyaltyDetail',
  LOYALTY_FORM: 'LoyaltyForm',
  LOYALTY_CODE_ZOOM_IN: 'LoyaltyCodeZoomIn',
  LOYALTY_VOUCHER_LIST: 'LoyaltyVoucherList',
  LOYALTY_VOUCHER_AVAILABLE_TAB: 'LoyaltyVoucherAllTab',
  LOYALTY_VOUCHER_CLAIMED_TAB: 'LoyaltyVoucherClaimedTab',
  LOYALTY_VOUCHER_EXPIRED_TAB: 'LoyaltyVoucherExpiredTab',
  LOYALTY_VOUCHER_DETAILS: 'LoyaltyVoucherDetails',

  DIAMOND_JUBILEE_INFO: 'DiamondJubileeInfo',

  //Account Summary
  ACCOUNT_SUMMARY: 'AccountSummary',
  CASA_DETAIL: 'CasaDetail',
  CARD_DETAIL: 'CardDetail',
  DEPOSIT_DETAIL: 'DepositDetail',
  INVEST_DETAIL: 'InvestDetail',
  LOAN_DETAIL: 'LoanDetail',
  RNID_DETAIL: 'RnidDetail',
  CASA_HISTORY: 'CasaHistory',
  CARD_HISTORY: 'CardHistory',
  TRAN_HISTORY: 'TranHistory',
  CARD_HISTORY_DETAIL: 'CardHistoryDetail',
  PBE_RECEIPT: 'PBeReceipt',
  UNDER_REVIEW: 'UnderReview',
  UNDER_REVIEW_DETAIL: 'UnderReviewDetail',
  ACCOUNT_HISTORY_DETAIL: 'AccountHistoryDetail',
  FUND_LOCK_AMOUNT: 'FundLockAmount',
  HIRE_PURCHASE_INFO: 'HirePurchaseInfo',
  LOST_CARD_SELECT: 'LostCardSelect',
  LOST_CARD_REPLACEMENT: 'LostCardReplacement',
  LOST_CARD_BRANCH_MAP: 'LostCardBranchMap',
  LOST_CARD_RECEIPT: 'LostCardReceipt',
  CARD_PIN_UPDATE_SELECT: 'CardPinUpdateSelect',
  CARD_PIN_UPDATE: 'CardPinUpdate',

  //Apply Savings Account
  APPLY_LIST: 'ApplyList',
  APPLY_SA_LOADING: 'ApplySaLoading',
  APPLY_SA_GUIDE: 'ApplySaGuide',
  APPLY_SA_INDIVIDUAL_CHECK: 'ApplySaEligibility',
  APPLY_SA_PAC: 'ApplySaPAC',
  APPLY_SA_PAC_OLD: 'ApplySaPACOld',
  APPLY_SA_PRODUCT: 'ApplySaProduct',
  APPLY_SA_PERSONAL_INFO: 'ApplySaPersonalInfo',
  APPLY_SA_FATCA: 'ApplyFatca',
  APPLY_SA_EMPLOYMENT: 'ApplySaEmployment',
  APPLY_SA_FINANCIAL: 'ApplySaFinancial',
  APPLY_SA_PREFERREDBRANCH: 'ApplySaPreferredBranch',
  APPLY_SA_BANKING: 'ApplySaBanking',
  APPLY_SA_MAP: 'ApplySaMap',
  APPLY_SA_MAP_NEW: 'ApplySaMapNew',
  APPLY_SA_EMPTY: 'ApplySAEmpty',
  APPLY_SA_EMPTY_OLD: 'ApplySAEmptyOld',
  APPLY_SA_ACKNOWLEDGE: 'ApplyAcknowledge',
  APPLY_SA_CTOS_VERIFICATION: 'ApplyCTOSVerify',
  APPLY_SA_CTOS_ADDRESS: 'ApplyCTOSAddress',
  APPLY_SA_CTOS_KBA: 'ApplyCTOSKba',
  APPLY_SA_PBE_USERNAME: 'ApplyPBEUsername',
  APPLY_SA_PBE_PASSWORD: 'ApplyPBEPassword',
  APPLY_SA_PBE_MEMORABLE_QUESTION: 'ApplyPBEMemorableQuestion',

  //FundTransfer
  TRANSFER_TO: 'TransferTo',
  TRANSFER_FAVOURITE: 'TransferFavourite',
  TRANSFER_CONTACT: 'Contact',
  TRANSFER_SELF: 'Self',
  TRANSFER_COUNTRY: 'TransferCountry',
  TRANSFER_BANK: 'Bank',
  TRANSFER_ACCTYPE: 'TransferAccType',
  TRANSFER_ACC: 'TransferAcc',
  TRANSFER_AMOUNT: 'TransferAmount',
  TRANSFER_REFERENCE: 'TransferReference',
  TRANSFER_CONFIRMATION: 'TransferConfirmation',
  TRANSFER_RECEIPT: 'TransferReceipt',
  DUITNOW_ID: 'DuitNowID',
  DUITNOW_REGISTER: 'DuitNowRegister',
  DUITNOW_UPDATE: 'DuitNowUpdate',
  REQUEST_FROM: 'RequestFrom',
  REQUEST_AMOUNT: 'RequestAmount',
  NEW_TRANSFER: 'NewTransfer',

  //Soft Token
  SOFT_TOKEN_CHECKIC: 'SoftTokenCheckIC',
  SOFT_TOKEN_ACTIVATION: 'SoftTokenActivation',
  SOFT_TOKEN_VALIDATEPAC: 'SoftTokenValidatePAC',
  SOFT_TOKEN_FAIL: 'SoftTokenFail',
  SOFT_TOKEN_PENDING_TRAN: 'SoftTokenPendingTran',
  SOFT_TOKEN_PENDING_TRAN_SUCCESS: 'SoftTokenPendingTranSuccess',
  SOFT_TOKEN_CQ_LOADING: 'SoftTokenCQLoading',
  SOFT_TOKEN_SILENT_ENROLMENT_LOADING: 'SoftTokenSilentEnrolmentLoading',

  PREFERRED_ACCOUNT: 'PreferredAccount',
  QUICK_PAYMENT: 'QuickPayment',
  TRANSACTION_PAC: 'TransactionPAC',

  // QR Payment
  QR_PAYMENT: 'QrPayment',
  QR_PAYMENT_PAY: 'QrPaymentPay',
  QR_PAYMENT_RECEIVE: 'QrPaymentReceive',
  QR_PAYMENT_AMOUNT_INPUT: 'QrPaymentAmountInput',
  QR_PAYMENT_CONFIRMATION: 'QrPaymentConfirmation',
  QR_PAYMENT_RECEIPT: 'QrPaymentReceipt',
  QR_PAYMENT_VERIFY_LOADING: 'QrPaymentVerifyLoading',
  QR_PAYMENT_VERIFY_ALIPAYPLUS_LOADING: 'QrPaymentVerifyAlipayPlusLoading',
  QR_PAYMENT_ALIPLAYPLUS_CONFIRMATION: 'QrPaymentAlipayPlusConfirmation',
  QR_PAYMENT_ALIPLAYPLUS_CPM: 'QrPaymentAlipayPlusCPM',
  QR_PAYMENT_ALIPLAYPLUS_CPM_ZOOMIN: 'QrPaymentAlipayPlusCPMZoomIn',
  QR_PAYMENT_ALIPLAYPLUS_RECEIPT: 'QrPaymentAlipayPlusReceipt',

  // Flexipay
  FLEXIPAY: 'Flexipay',
  FLEXIPAY_RECEIPT: 'FlexipayReceipt',

  //Pay BillScreen
  BILL: 'Bill',
  JOMPAY_QR_LOADING: 'JomPayQrLoading',
  JOMPAY_BILLER_CODE: 'JomPayBillerCode',
  JOMPAY_AMOUNT: 'JomPayAmount',
  JOMPAY_REFERENCE: 'JomPayReference',
  JOMPAY_CONFIRMATION: 'JomPayConfirmation',
  JOMPAY_RECEIPT: 'JomPayReceipt',

  BILL_BILLER: 'BillBiller',
  BILL_AMOUNT: 'BillAmount',
  BILL_REFERENCE: 'BillReference',
  BILL_CONFIRMATION: 'BillConfirmation',
  BILL_RECEIPT: 'BillReceipt',

  //Pay Card
  PAY_CARD: 'PayCard',
  PAY_CARD_FAVOURITE: 'PayCardFavourite',
  PAY_CARD_SELF: 'PayCardSelf',
  PAY_CARD_BANK: 'PayCardBank',
  PAY_CARD_ACCOUNT: 'PayCardAccount',
  PAY_CARD_AMOUNT: 'PayCardAmount',
  PAY_CARD_CONFIRMATION: 'PayCardConfirmation',
  PAY_CARD_RECEIPT: 'PayCardReceipt',

  //Pay Loan
  PAY_LOAN: 'PayLoan',
  PAY_LOAN_FAVOURITE: 'PayLoanFavourite',
  PAY_LOAN_SELF: 'PayLoanSelf',
  PAY_LOAN_BANK: 'PayLoanBank',
  PAY_LOAN_ACCOUNT: 'PayLoanAccount',
  PAY_LOAN_NOTENO: 'PayLoanNoteNo',
  PAY_LOAN_AMOUNT: 'PayLoanAmount',
  PAY_LOAN_CONFIRMATION: 'PayLoanConfirmation',
  PAY_LOAN_RECEIPT: 'PayLoanReceipt',

  //Top Up
  TOP_UP: 'TopUp',
  TOP_UP_COUNTRY: 'TopUpCountry',
  TOP_UP_MERCHANT: 'TopUpMerchant',
  TOP_UP_PRODUCT: 'TopUpProduct',
  TOP_UP_MOBILENO: 'TopUpMobileNo',
  TOP_UP_CONFIRMATION: 'TopUpConfirmation',
  TOP_UP_RECEIPT: 'TopUpReceipt',

  FROM_ACC_CASA: 'FromAccCasa',
  FROM_ACC_CARD: 'FromAccCard',

  //Recurring
  ESI: 'Esi',
  RECURRING_DETAILS: 'RecurringDetails',
  RECURRING_HISTORY: 'RecurringHistory',

  // Apply
  OPEN_WEBVIEW: 'openWebview',

  //Cash Advance
  CASH_ADVANCE_FROM: 'CashAdvanceFrom',
  CASH_ADVANCE_TO: 'CashAdvanceTo',
  CASH_ADVANCE_AMOUNT: 'CashAdvanceAmount',
  CASH_ADVANCE_CONFIRM: 'CashAdvanceConfirmation',
  CASH_ADVANCE_RECEIPT: 'CashAdvanceReceipt',

  // Challenge Question
  CQ_ENROLMENT: 'CQEnrolment',
  CQ_ENROLMENT_DONE: 'CQEnrolmentDone',
  CQ_CHALLENGE: 'CQChallenge',

  //PB Journey
  JOURNEY: 'Journey',
  JOURNEY_HISTORY: 'JourneyHistory',
  JOURNEY_WITHDRAW_AMOUNT: 'JourneyWithdrawAmount',
  JOURNEY_WITHDRAW_CONFIRMATION: 'JourneyWithdrawConfirmation',
  JOURNEY_WITHDRAW_SUMMARY: 'JourneyWithdrawSummary',
  POCKET_MONEY_AMOUNT: 'PocketMoneyAmount',
  POCKET_MONEY_REFERENCE: 'PocketMoneyReference',
  POCKET_MONEY_CONFIRMATION: 'PocketMoneyConfirmation',
  POCKET_MONEY_SUMMARY: 'PocketMoneySummary',
  TASK_LIST: 'TaskList',
  TASK_CREATE: 'TaskCreate',
  TASK_AMOUNT: 'TaskAmount',
  TASK_IN_PROGRESS: 'TaskInProgress',
  TASK_HISTORY: 'TaskHistory',
  TASK_DETAIL: 'TaskDetail',
  GOAL_IN_PROGRESS: 'GoalInProgress',
  GOAL_HISTORY: 'GoalHistory',
  GOAL_LIST: 'GoalList',

  //Cardless Withdraw
  CARDLESS_WITHDRAW: 'CardlessWithdraw',
  CARDLESS_MOBILE: 'CardlessMobile',
  CARDLESS_NAME: 'CardlessName',
  CARDLESS_CONTACT: 'CardlessContact',
  CARDLESS_AMOUNT: 'CardlessAmount',
  CARDLESS_CONFIRM: 'CardlessConfirm',
  CARDLESS_RECEIPT: 'CardlessReceipt',
  CARDLESS_HISTORY: 'CardlessHistory',
  CARDLESS_HISTORY_DETAIL: 'CardlessHistoryDetail',
  CARDLESS_SELECTION: 'CardlessSelection',

  //Appointment
  APPOINTMENT: 'Appointment',
  APPOINTMENT_MAKE: 'AppointmentMake',
  APPOINTMENT_BRANCH: 'AppointmentBranch',
  APPOINTMENT_DETAILS: 'AppointmentDetails',
  APPOINTMENT_CONFIRMATION: 'AppointmentConfirmation',
  APPOINTMENT_RECEIPT: 'AppointmentReceipt',

  //Expenses Tracker
  EXPENSE_TRACKER: 'ExpenseTracker',
  EXPENSE_TRACKER_MAIN: 'ExpenseTrackerMain',
  EXPENSE_TRACKER_DETAILS: 'ExpenseTrackerDetails',
  EXPENSE_NEW_ENTRY: 'ExpenseTrackerNewEntry',
  EXPENSE_TRACKER_CATEGORY_LIST: 'ExpenseTrackerCategoryList',

  //Remittance
  REMITTANCE: 'Remittance',
  BAKONG_ACC: 'BakongAcc',
  BAKONG_AMOUNT: 'BakongAmount',
  BAKONG_REFERENCE: 'BakongReference',
  BAKONG_NOTICE: 'BakongNotice',
  BAKONG_CONFIRMATION: 'BakongConfirmation',
  BAKONG_RECEIPT: 'BakongReceipt',
  BAKONG_RECIPIENT_DETAILS: 'BakongRecipientDetails',
  BAKONG_DRB_DECLARATION: 'BakongDRBDeclaration',
  BAKONG_FCY_BORROWING_DECLARATION: 'BakongFCYBorrowingDeclaration',

  //Deposit
  DEPOSIT_OPEN_ACCOUNT_TYPE: 'DepositOpenAccType',
  DEPOSIT_OPEN_FATCA: 'DepositOpenFatca',
  DEPOSIT_OPEN_RECEIPT: 'DepositOpenReceipt',
  DEPOSIT_PLACEMENT: 'DepositPlacement',
  DEPOSIT_PLACEMENT_TENURE: 'DepositPlacementTenure',
  DEPOSIT_PLACEMENT_AMOUNT: 'DepositPlacementAmount',
  DEPOSIT_PLACEMENT_MODE: 'DepositPlacementMode',
  DEPOSIT_PLACEMENT_CONFIRMATION: 'DepositPlacementConfirmation',
  DEPOSIT_PLACEMENT_RECEIPT: 'DepositPlacementReceipt',
  DEPOSIT_WITHDRAW_AMOUNT: 'DepositWithdrawAmount',
  DEPOSIT_WITHDRAW_CONFIRMATION: 'DepositWithdrawConfirmation',
  DEPOSIT_WITHDRAW_RECEIPT: 'DepositWithdrawReceipt',

  //Money Market Deposit
  MONEY_MARKET_PLACEMENT_DETAILS: 'MoneyMarketPlacementDetails',

  SPI_DETAILS: 'SPIDetails',

  //Carbon Tracker
  CARBON_TRACKER: 'CarbonTracker',
  CARBON_TRACKER_INSIGHTS: 'CarbonTrackerInsights',
  CARBON_TRACKER_TRANSACTION: 'CarbonTrackerTransaction',
  CARBON_TRACKER_COMPARISON: 'CarbonTrackerComparison',
  CARBON_TRACKER_OFFSET_PROJECT: 'CarbonTrackerOffsetProject',
  CARBON_TRACKER_OFFSET_PROJECT_DETAILS: 'CarbonTrackerOffsetProjectDetails',
  CARBON_TRACKER_MONTHLY_OFFSET: 'CarbonTrackerMonthlyOffset',
  CARBON_TRACKER_AMOUNT_INPUT: 'CarbonTrackerAmountInput',
  CARBON_TRACKER_CONFIRMATION: 'CarbonTrackerConfirmation',
  CARBON_TRACKER_RECEIPT: 'CarbonTrackerReceipt',
  CARBON_TRACKER_OFFSET_PROJECT_SELECTION: 'CarbonTrackerOffsetProjectionSelection',

  //Gold
  GOLD_LANDING: 'GoldLanding',
  GOLD_OPEN_ACC: 'GoldOpenAcc',
  GOLD_DECLARE: 'GoldDeclare',
  GOLD_ACKNOWLEDGE: 'GoldAcknowledge',
  GOLD_AMOUNT: 'GoldAmount',
  GOLD_CHART: 'GoldChart',
  GOLD_CONFIRMATION: 'GoldConfirmation',
  GOLD_CLOSE_ACC: 'GoldCloseAcc',
  GOLD_RECEIPT_BUY: 'GoldReceiptBuy',
  GOLD_RECEIPT_SELL: 'GoldReceiptSell',
  GOLD_HISTORY: 'GoldHistory',
  GOLD_HISTORY_DETAIL: 'GoldHistoryDetail',

  //Insurance
  INSURANCE: 'Insurance',
  INSURANCE_CONTACT_US: 'InsuranceContactUs',
  INSURANCE_POLICY: 'InsurancePolicy',
  INSURANCE_POLICY_DETAILS: 'InsurancePolicyDetails',
  INSURANCE_POLICY_PDF: 'InsurancePolicyPdf',
  INSURANCE_PURCHASE_LANDING: 'InsurancePurchaseLanding',

  CUSTOMER_FEEDBACK: 'CustomerFeedback',

  //Branch Locator
  BRANCH_LOCATOR_MAP: 'BranchLocatorMap',

  //Kill Switch
  KILL_SWITCH: 'KIllSwitch',

  // Card Tokenization
  PENDING_TOKENIZATION: 'PendingTokenization',
  TOKENIZATION_FAIL: 'TokenizationFail',
  TOKENIZATION_LOADING: 'TokenizationLoading',

  //Security Quiz
  SECURITY_QUIZ: 'SecurityQuiz',
  SECURITY_QUIZ_QUESTION: 'SecurityQuestion',
  SECURITY_QUIZ_RESULT: 'SecurityResult',

  //Promotion
  PROMOTION_LISTING: 'PromotionListing',
  PROMOTION_DETAILS: 'PromotionDetails',
  PROMOTION_REGISTER: 'PromotionRegister',
  
  //Auto Debit
  AUTO_DEBIT: 'AutoDebit',
  AUTO_DEBIT_ALL_CONSENT_LIST: 'AutoDebitAllConsentList',
  AUTO_DEBIT_CONSENT_CONFIRMATION: 'AutoDebitConsentConfirmation',
  AUTO_DEBIT_CONSENT_RECEIPT: 'AutoDebitConsentReceipt',
  AUTO_DEBIT_CONSENT_DETAILS: 'AutoDebitConsentDetails',
  AUTO_DEBIT_CONSENT_HISTORY: 'AutoDebitConsentHistory',
  AUTO_DEBIT_CONSENT_TERMINATION: 'AutoDebitConsentTermination',
  AUTO_DEBIT_TRANSFER_CONSENT_GUIDE: 'AutoDebitTransferConsentGuide',
  AUTO_DEBIT_TRANSFER_CONSENT_ID: 'AutoDebitTransferConsentID',
  AUTO_DEBIT_TRANSFER_CONSENT_CONFIRMATION: 'AutoDebitTransferConsentConfirmation',
  AUTO_DEBIT_TRANSFER_CONSENT_RECEIPT: 'AutoDebitTransferConsentReceipt',
});
