import React, { useEffect } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { useDispatch, useSelector } from 'react-redux';
import UserInactivity from 'react-native-user-inactivity';
import { DeviceEventEmitter, Linking, NativeModules, Platform, View } from 'react-native';

import { TabNavigator } from './TabNavigator';
import { getSettingAccessibility, getUser, logout } from 'stores';
import { showInfo } from 'utils';

import {
  AccountSettings,
  AccountUpdateEmail,
  AccountUpdateName,
  AccountUpdateProfile,
  AppSecurity,
  AppSettings,
  Birthday,
  ContactUs,
  CustomerFeedback,
  DeviceManagement,
  KillSwitch,
  LanguageSettings,
  ValidatePin,
} from 'screens/user';

import {
  ConfirmLinkPBe,
  ConfirmResetPin,
  ConfirmUnbindAndBind,
  HardTokenCooling,
  LoginConfirm,
  LoginPBe,
  LoginPBO,
  LoginPin,
  QuickPayment,
  RegisterBiometric,
  RegisterDisplayName,
  RegisterEmail,
  RegisterPAC,
  RegisterPBo,
  RegisterPin,
} from 'screens/auth';

import {
  AccountHistoryDetail,
  AccountReceipt,
  CardHistory,
  CardHistoryDetail,
  CardPinUpdateScreen,
  CardPinUpdateSelectScreen,
  CasaDetails,
  CasaHistory,
  CreditCardDetails,
  Deposit,
  FundLockAmount,
  HirePurchaseInfo,
  Investment,
  Loan,
  LostCardBranchMapScreen,
  LostCardReceiptScreen,
  LostCardReplacementScreen,
  LostCardSelectScreen,
  PreferredAccount,
  Rnid,
  TranHistory,
  UnderReview,
  UnderReviewDetail,
} from 'screens/accounts';

import {
  TopUp,
  TopUpConfirmation,
  TopUpCountry,
  TopUpMerchant,
  TopUpMobileNo,
  TopUpProduct,
  TopUpReceipt,
} from 'screens/topUp';
import {
  Loyalty,
  LoyaltyForm,
  LoyaltyVoucherDetailsScreen,
  LoyaltyVoucherListScreen,
  LoyaltyZoomIn,
} from 'screens/loyaltycard';
import {
  ApplyList,
  BlankRouting,
  DiamondJubileeInfoScreen,
  HighlightList,
  HomeLoading,
  QuickLinkAll,
} from 'screens/home';
import { AAOPChallenge, AAOPEnrollment } from 'screens/aaop';
import {
  Appointment,
  AppointmentAcknowledgement,
  AppointmentBranch,
  AppointmentDetails,
  Confirmation,
  MakeAppointment,
} from 'screens/appointment';
import { PayCard, PayCardAccount, PayCardAmount, PayCardBank, PayCardConfirmation, PayCardReceipt } from 'screens/card';
import { Esi, RecurringDetails, RecurringHistory } from 'screens/esi';
import {
  DuitNowID,
  DuitNowRegister,
  DuitNowUpdate,
  TransferAcc,
  TransferAccType,
  TransferAmount,
  TransferBank,
  TransferConfirmation,
  TransferCountry,
  TransferReceipt,
  TransferReference,
  TransferTo,
} from 'screens/fundTransfer';
import {
  PayLoan,
  PayLoanAccount,
  PayLoanAmount,
  PayLoanBank,
  PayLoanConfirmation,
  PayLoanNoteNo,
  PayLoanReceipt,
} from 'screens/loan';
import {
  ScheduledTran,
  ScheduledTranDetail,
  ScheduledTranEntityForm,
  ScheduledTranExpenseForm,
} from 'screens/portfolio';
import { ExpenseForm, PfmSummary, WalletForm, WalletList } from 'screens/pfm';
import {
  ApplyAcknowledge,
  ApplyGuide,
  ApplyMap,
  ApplyMapNew,
  ApplyPac,
  ApplyPacOld,
  ApplySA,
  ApplySABank,
  ApplySAEmpty,
  ApplySAEmptyOld,
  ApplySALoadingScreen,
  ApplySAProduct,
  CTOSAddress,
  CTOSKba,
  CTOSVerification,
  Employment,
  Fatca,
  Financial,
  IndividualCheck,
  PbeMemorableQuestion,
  PbePassword,
  PbeUsername,
  PersonalInfo,
  PreferredBranch,
} from 'screens/apply';

import {
  Activation,
  CheckIC,
  CQEnrolmentDone,
  PendingTran,
  PendingTranSuccess,
  SoftTokenCQLoading,
  SoftTokenFail,
  SoftTokenSilentEnrolmentLoading,
  TransactionPAC,
  ValidatePAC,
} from 'screens/softToken';

import { Flexipay, FlexipayReceipt } from 'screens/flexipay';
import { EmptyWebView } from 'screens/EmptyWebview';

import {
  GoalList,
  Journey,
  JourneyHistory,
  JourneyWithdrawAmount,
  JourneyWithdrawConfirmation,
  JourneyWithdrawSummary,
  PocketMoneyAmount,
  PocketMoneyConfirmation,
  PocketMoneyReference,
  PocketMoneySummary,
  TaskAmount,
  TaskCreate,
  TaskDetail,
  TaskList,
} from 'screens/journey';
import {
  AmountScreen,
  ConfirmationScreen,
  ContactScreen,
  DetailScreen,
  HistoryScreen,
  MobileNoScreen,
  NameScreen,
  ReceiptScreen,
  SelectionScreen,
} from 'screens/cardlessWithdraw';
import {
  BillAmount,
  BillConfirmation,
  Biller,
  BillerCode,
  BillReceipt,
  BillReference,
  BillScreen,
  JompayAmount,
  JompayConfirmation,
  JompayReceipt,
  JompayReference,
} from 'screens/bill';
import {
  CashAdvanceAmount,
  CashAdvanceConfirmation,
  CashAdvanceFrom,
  CashAdvanceReceipt,
  CashAdvanceTo,
} from 'screens/cashAdvance';
import {
  ExpenseCategoryTransactionList,
  ExpenseInputScreen,
  ExpenseMainScreen,
  ExpenseTrackerTab,
  TransactionDetailsScreen,
} from 'screens/expenseTracker';
import {
  AlipayPlusCodeZoomIn,
  AlipayPlusConfirmation,
  AlipayPlusPayCPM,
  AlipayPlusReceipt,
  AlipayPlusVerifyLoading,
  JomPayQrLoading,
  QrAmountInput,
  QrConfirmation,
  QrPayment,
  QrReceipt,
  QrReceive,
  QrVerifyLoadingPage,
} from 'screens/qr';
import { MailboxDetail } from 'screens/notification';

import {
  BakongAccount,
  BakongAmount,
  BakongConfirmation,
  BakongNotice,
  BakongReceipt,
  BakongRecipientDetails,
  BakongReference,
  DRBDeclaration,
  Remittance,
} from 'screens/remittance';

import {
  CarbonAmountInputScreen,
  CarbonTrackerComparisonScreen,
  CarbonTrackerInsightsScreen,
  CarbonTrackerMonthlyOffsetScreen,
  CarbonTrackerOffsetProjectScreen,
  CarbonTrackerOffsetProjectSelectionScreen,
  CarbonTrackerProjectDetailsScreen,
  CarbonTrackerScreen,
  CarbonTrackerTransactionScreen,
  CO2TrackerConfirmationScreen,
  CO2TrackerReceiptScreen,
} from 'screens/carbonTracker';

import {
  InsuranceContactUsScreen,
  InsurancePolicyDetailsScreen,
  InsurancePolicyPdfScreen,
  InsurancePolicyScreen,
  InsurancePurchaseLandingScreen,
  InsuranceScreen,
} from 'screens/insurance';

import routes from '../routes';
import useAppVersion from 'hooks/useAppVersion';
import { useRetry } from 'contexts';
import {
  DepositOpenAccType,
  DepositOpenFatca,
  DepositOpenReceipt,
  DepositPlacementAmount,
  DepositPlacementConfirmation,
  DepositPlacementMode,
  DepositPlacementReceipt,
  DepositPlacements,
  DepositPlacementTenure,
} from 'screens/deposit';
import { MoneyMarketDepositPlacementDetails } from 'screens/moneyMarketDeposit';
import { DepositWithdrawAmount, DepositWithdrawConfirmation, DepositWithdrawReceipt } from 'screens/deposit/withdrawal';
import { useTranslation } from 'react-i18next';
import {
  GoldAcknowldegeScreen,
  GoldAmountScreen,
  GoldDeclarationScreen,
  GoldLandingScreen,
  GoldOpenAccScreen,
  GoldChartScreen,
  GoldConfirmationScreen,
  GoldCloseAccScreen,
  GoldReceiptBuyScreen,
  GoldReceiptSellScreen,
  GoldHistoryScreen,
  GoldHistoryDetailScreen,
} from 'screens/gold';
import { LOGIN_TYPE } from 'constant';
import { useDeepLink } from 'hooks/useAppLinking';
import { PendingTokenization, TokenizationFail, TokenizationLoading } from '../../screens/walletTokenization';
import { useWalletTokenization } from 'hooks';
import { SecurityQuiz, SecurityQuizQuestion, SecurityQuizResult } from 'screens/quiz';
import { PromotionDetails, PromotionListing, PromotionRegister } from 'screens/promotion';
import { useAppRootLinking } from 'hooks/rootLinking';
import { BranchLocatorMapScreen } from 'screens/branchLocator';
import { SPIDetails } from 'screens/spi';
import {
  AutoDebit,
  ConsentRegisterReceipt,
  PendingConfirmation,
  AllConsentList,
  ConsentDetails,
  ConsentHistory,
  TerminateReason,
  TransferConsentGuide,
  TransferConsentID,
  TransferConsentConfirmation,
  TransferConsentReceipt,
} from 'screens/autoDebit';

const Stack = createStackNavigator();

const { WalletTokenizationModule } = NativeModules;

export const AppNavigator = () => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'navigation.appNavigator.';
  useAppVersion();
  const dispatch = useDispatch();
  const { globalLoggedIn } = useRetry();
  const importantForAccessibility = useSelector(getSettingAccessibility);
  const { loginType } = useSelector(getUser) || {};
  const isPasswordLogin = loginType === LOGIN_TYPE.PASSWORD;
  const { handleDeepLink } = useDeepLink();
  const { handleWalletTokenization } = useWalletTokenization();
  useAppRootLinking();

  useEffect(() => {
    start();
    const linkingSubscription = Linking.addEventListener('url', handleDeepLink);

    //handle for Android Wallet Tokenization
    if (Platform.OS === 'android') {
      WalletTokenizationModule.notifyJSReady();

      const walletTokenizationListener = DeviceEventEmitter.addListener('onWalletTokenizationTriggered', event => {
        handleWalletTokenization(event);
      });

      return () => {
        linkingSubscription.remove();
        walletTokenizationListener.remove();
      };
    }

    return () => {
      linkingSubscription.remove();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const start = async () => {
    const url = await Linking.getInitialURL();
    handleDeepLink({ url });
  };

  const onAction = val => {
    if (!val && globalLoggedIn.current) {
      dispatch(logout());
      showInfo(t(`${LANG_PREFIX}logoutInactivity`));
    }
  };

  const forFade = ({ current }) => ({
    cardStyle: {
      opacity: current.progress,
    },
  });

  return (
    <UserInactivity
      timeForInactivity={300000} //5 minutes inactivity
      onAction={isActive => onAction(isActive)}
    >
      <View style={{ flex: 1 }} importantForAccessibility={importantForAccessibility}>
        <Stack.Navigator
          screenOptions={() => ({
            // gestureEnabled: true,
            headerMode: false,
          })}
        >
          <Stack.Group>
            <Stack.Screen name={routes.MAIN_TAB} component={TabNavigator} />
            <Stack.Screen name={routes.ACCOUNT_SETTINGS} component={AccountSettings} />
            <Stack.Screen name={routes.APP_SETTINGS} component={AppSettings} />
            <Stack.Screen name={routes.APP_SECURITY} component={AppSecurity} />
            <Stack.Screen name={routes.LANGUAGE_SETTINGS} component={LanguageSettings} />
            <Stack.Screen
              name={routes.HOME_LOADING}
              component={HomeLoading}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen
              name={routes.BLANK_ROUTING}
              component={BlankRouting}
              options={{ cardStyleInterpolator: forFade }}
            />

            <Stack.Screen name={routes.QUICK_LINKS_ALL} component={QuickLinkAll} />
            <Stack.Screen name={routes.HIGHLIGHT_LIST_ALL} component={HighlightList} />

            {/* Declared in ProfileNavigator, duplicated over for access out of ProfileNavigator  */}
            <Stack.Screen name={routes.CONTACT_US} component={ContactUs} />
            <Stack.Screen name={routes.CUSTOMER_FEEDBACK} component={CustomerFeedback} />

            <Stack.Screen name={routes.LOGIN_PBE_OLD} component={LoginPBe} />
            <Stack.Screen
              name={routes.LOGIN_PIN}
              component={LoginPin}
              options={() => ({
                presentation: isPasswordLogin ? 'transparentModal' : 'card',
              })}
            />
            <Stack.Screen name={routes.REGISTER_EMAIL} component={RegisterEmail} />
            <Stack.Screen name={routes.ACCOUNT_UPDATE_EMAIL} component={AccountUpdateEmail} />
            <Stack.Screen name={routes.CONFIRM_RESET_PIN} component={ConfirmResetPin} />
            <Stack.Screen name={routes.CONFIRM_LINK_PBE} component={ConfirmLinkPBe} />
            <Stack.Screen name={routes.CONFIRM_UNBIND_AND_BIND} component={ConfirmUnbindAndBind} />
            <Stack.Screen
              name={routes.HARD_TOKEN_COOLING}
              component={HardTokenCooling}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen name={routes.BIRTHDAY} component={Birthday} />
            <Stack.Screen name={routes.ACCOUNT_UPDATE_PROFILE} component={AccountUpdateProfile} />

            <Stack.Screen name={routes.REGISTER_PBO} component={RegisterPBo} />
            <Stack.Screen name={routes.LOGIN_PBO} component={LoginPBO} />
            <Stack.Screen name={routes.LOGIN_CONFIRM} component={LoginConfirm} />
            <Stack.Screen name={routes.REGISTER_DISPLAY_NAME} component={RegisterDisplayName} />
            <Stack.Screen name={routes.REGISTER_PIN} component={RegisterPin} />
            <Stack.Screen name={routes.REGISTER_PAC} component={RegisterPAC} />
            <Stack.Screen name={routes.REGISTER_BIO} component={RegisterBiometric} />

            <Stack.Screen name={routes.VALIDATE_PIN} component={ValidatePin} />

            <Stack.Screen name={routes.DIAMOND_JUBILEE_INFO} component={DiamondJubileeInfoScreen} />

            <Stack.Screen name={routes.CASA_DETAIL} component={CasaDetails} />
            <Stack.Screen name={routes.CARD_DETAIL} component={CreditCardDetails} />
            <Stack.Screen name={routes.DEPOSIT_DETAIL} component={Deposit} />
            <Stack.Screen name={routes.INVEST_DETAIL} component={Investment} />
            <Stack.Screen name={routes.LOAN_DETAIL} component={Loan} />
            <Stack.Screen name={routes.RNID_DETAIL} component={Rnid} />
            <Stack.Screen name={routes.CASA_HISTORY} component={CasaHistory} />
            <Stack.Screen name={routes.CARD_HISTORY} component={CardHistory} />
            <Stack.Screen name={routes.TRAN_HISTORY} component={TranHistory} />
            <Stack.Screen name={routes.CARD_HISTORY_DETAIL} component={CardHistoryDetail} />
            <Stack.Screen name={routes.PBE_RECEIPT} component={AccountReceipt} />
            <Stack.Screen name={routes.UNDER_REVIEW} component={UnderReview} />
            <Stack.Screen name={routes.UNDER_REVIEW_DETAIL} component={UnderReviewDetail} />
            <Stack.Screen name={routes.ACCOUNT_HISTORY_DETAIL} component={AccountHistoryDetail} />
            <Stack.Screen name={routes.FUND_LOCK_AMOUNT} component={FundLockAmount} />
            <Stack.Screen name={routes.HIRE_PURCHASE_INFO} component={HirePurchaseInfo} />
            <Stack.Screen name={routes.LOST_CARD_SELECT} component={LostCardSelectScreen} />
            <Stack.Screen name={routes.LOST_CARD_REPLACEMENT} component={LostCardReplacementScreen} />
            <Stack.Screen name={routes.LOST_CARD_BRANCH_MAP} component={LostCardBranchMapScreen} />
            <Stack.Screen name={routes.LOST_CARD_RECEIPT} component={LostCardReceiptScreen} />
            <Stack.Screen name={routes.CARD_PIN_UPDATE_SELECT} component={CardPinUpdateSelectScreen} />
            <Stack.Screen name={routes.CARD_PIN_UPDATE} component={CardPinUpdateScreen} />

            <Stack.Screen name={routes.LOYALTY} component={Loyalty} />
            <Stack.Screen name={routes.LOYALTY_VOUCHER_LIST} component={LoyaltyVoucherListScreen} />
            <Stack.Screen name={routes.LOYALTY_VOUCHER_DETAILS} component={LoyaltyVoucherDetailsScreen} />
            <Stack.Screen
              name={routes.LOYALTY_CODE_ZOOM_IN}
              component={LoyaltyZoomIn}
              options={{ gestureEnabled: false, cardStyleInterpolator: forFade }}
            />
            <Stack.Screen name={routes.PFM_SUMMARY} component={PfmSummary} />
            <Stack.Screen name={routes.WALLET_LIST} component={WalletList} />
            {/* <Stack.Screen name={routes.EXPENSE_LIST} component={ExpenseList} /> */}
            <Stack.Screen name={routes.SCHEDULED_TRAN} component={ScheduledTran} />
            <Stack.Screen name={routes.SCHEDULED_TRAN_DETAIL} component={ScheduledTranDetail} />

            <Stack.Screen name={routes.SOFT_TOKEN_CHECKIC} component={CheckIC} />
            <Stack.Screen
              name={routes.SOFT_TOKEN_ACTIVATION}
              component={Activation}
              options={{ gestureEnabled: false, cardStyleInterpolator: forFade }}
            />
            <Stack.Screen name={routes.SOFT_TOKEN_VALIDATEPAC} component={ValidatePAC} />
            <Stack.Screen name={routes.SOFT_TOKEN_FAIL} component={SoftTokenFail} />
            <Stack.Screen name={routes.SOFT_TOKEN_PENDING_TRAN} component={PendingTran} />
            <Stack.Screen name={routes.SOFT_TOKEN_PENDING_TRAN_SUCCESS} component={PendingTranSuccess} />
            <Stack.Screen
              name={routes.SOFT_TOKEN_CQ_LOADING}
              component={SoftTokenCQLoading}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen
              name={routes.SOFT_TOKEN_SILENT_ENROLMENT_LOADING}
              component={SoftTokenSilentEnrolmentLoading}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen name={routes.TRANSACTION_PAC} component={TransactionPAC} />

            <Stack.Screen name={routes.TRANSFER_TO} component={TransferTo} />
            <Stack.Screen name={routes.TRANSFER_COUNTRY} component={TransferCountry} />
            <Stack.Screen name={routes.TRANSFER_BANK} component={TransferBank} />
            <Stack.Screen name={routes.TRANSFER_ACC} component={TransferAcc} />
            <Stack.Screen name={routes.TRANSFER_ACCTYPE} component={TransferAccType} />
            <Stack.Screen name={routes.TRANSFER_AMOUNT} component={TransferAmount} />
            <Stack.Screen name={routes.TRANSFER_REFERENCE} component={TransferReference} />
            <Stack.Screen name={routes.TRANSFER_CONFIRMATION} component={TransferConfirmation} />
            <Stack.Screen name={routes.TRANSFER_RECEIPT} component={TransferReceipt} />

            <Stack.Screen name={routes.PREFERRED_ACCOUNT} component={PreferredAccount} />
            <Stack.Screen name={routes.QUICK_PAYMENT} component={QuickPayment} />

            <Stack.Screen name={routes.QR_PAYMENT} component={QrPayment} />
            <Stack.Screen name={routes.QR_PAYMENT_RECEIVE} component={QrReceive} />
            <Stack.Screen name={routes.QR_PAYMENT_AMOUNT_INPUT} component={QrAmountInput} />
            <Stack.Screen name={routes.QR_PAYMENT_CONFIRMATION} component={QrConfirmation} />
            <Stack.Screen name={routes.QR_PAYMENT_RECEIPT} component={QrReceipt} />
            <Stack.Screen
              name={routes.QR_PAYMENT_VERIFY_LOADING}
              component={QrVerifyLoadingPage}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen
              name={routes.QR_PAYMENT_VERIFY_ALIPAYPLUS_LOADING}
              component={AlipayPlusVerifyLoading}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen name={routes.QR_PAYMENT_ALIPLAYPLUS_CONFIRMATION} component={AlipayPlusConfirmation} />
            <Stack.Screen name={routes.QR_PAYMENT_ALIPLAYPLUS_CPM} component={AlipayPlusPayCPM} />
            <Stack.Screen
              name={routes.QR_PAYMENT_ALIPLAYPLUS_CPM_ZOOMIN}
              component={AlipayPlusCodeZoomIn}
              options={{ gestureEnabled: false, cardStyleInterpolator: forFade }}
            />
            <Stack.Screen name={routes.QR_PAYMENT_ALIPLAYPLUS_RECEIPT} component={AlipayPlusReceipt} />

            <Stack.Screen name={routes.BILL} component={BillScreen} />
            <Stack.Screen
              name={routes.JOMPAY_QR_LOADING}
              component={JomPayQrLoading}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen name={routes.JOMPAY_BILLER_CODE} component={BillerCode} />
            <Stack.Screen name={routes.JOMPAY_AMOUNT} component={JompayAmount} />
            <Stack.Screen name={routes.JOMPAY_REFERENCE} component={JompayReference} />
            <Stack.Screen name={routes.JOMPAY_CONFIRMATION} component={JompayConfirmation} />
            <Stack.Screen name={routes.JOMPAY_RECEIPT} component={JompayReceipt} />
            <Stack.Screen name={routes.BILL_BILLER} component={Biller} />
            <Stack.Screen name={routes.BILL_AMOUNT} component={BillAmount} />
            <Stack.Screen name={routes.BILL_REFERENCE} component={BillReference} />
            <Stack.Screen name={routes.BILL_CONFIRMATION} component={BillConfirmation} />
            <Stack.Screen name={routes.BILL_RECEIPT} component={BillReceipt} />

            <Stack.Screen name={routes.PAY_CARD} component={PayCard} />
            <Stack.Screen name={routes.PAY_CARD_BANK} component={PayCardBank} />
            <Stack.Screen name={routes.PAY_CARD_ACCOUNT} component={PayCardAccount} />
            <Stack.Screen name={routes.PAY_CARD_AMOUNT} component={PayCardAmount} />
            <Stack.Screen name={routes.PAY_CARD_CONFIRMATION} component={PayCardConfirmation} />
            <Stack.Screen name={routes.PAY_CARD_RECEIPT} component={PayCardReceipt} />

            <Stack.Screen name={routes.PAY_LOAN} component={PayLoan} />
            <Stack.Screen name={routes.PAY_LOAN_BANK} component={PayLoanBank} />
            <Stack.Screen name={routes.PAY_LOAN_ACCOUNT} component={PayLoanAccount} />
            <Stack.Screen name={routes.PAY_LOAN_NOTENO} component={PayLoanNoteNo} />
            <Stack.Screen name={routes.PAY_LOAN_AMOUNT} component={PayLoanAmount} />
            <Stack.Screen name={routes.PAY_LOAN_CONFIRMATION} component={PayLoanConfirmation} />
            <Stack.Screen name={routes.PAY_LOAN_RECEIPT} component={PayLoanReceipt} />

            <Stack.Screen name={routes.TOP_UP} component={TopUp} />
            <Stack.Screen name={routes.TOP_UP_COUNTRY} component={TopUpCountry} />
            <Stack.Screen name={routes.TOP_UP_MERCHANT} component={TopUpMerchant} />
            <Stack.Screen name={routes.TOP_UP_PRODUCT} component={TopUpProduct} />
            <Stack.Screen name={routes.TOP_UP_MOBILENO} component={TopUpMobileNo} />
            <Stack.Screen name={routes.TOP_UP_CONFIRMATION} component={TopUpConfirmation} />
            <Stack.Screen name={routes.TOP_UP_RECEIPT} component={TopUpReceipt} />

            <Stack.Screen
              name={routes.APPLY_SA_LOADING}
              component={ApplySALoadingScreen}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen name={routes.APPLY_LIST} component={ApplyList} />
            <Stack.Screen name={routes.APPLY_SA_GUIDE} component={ApplyGuide} />
            <Stack.Screen name={routes.APPLY_SA} component={ApplySA} />
            <Stack.Screen name={routes.APPLY_SA_EMPTY} component={ApplySAEmpty} />
            <Stack.Screen name={routes.APPLY_SA_EMPTY_OLD} component={ApplySAEmptyOld} />
            <Stack.Screen name={routes.APPLY_SA_PRODUCT} component={ApplySAProduct} />
            <Stack.Screen name={routes.APPLY_SA_INDIVIDUAL_CHECK} component={IndividualCheck} />
            <Stack.Screen name={routes.APPLY_SA_PERSONAL_INFO} component={PersonalInfo} />
            <Stack.Screen name={routes.APPLY_SA_FATCA} component={Fatca} />
            <Stack.Screen name={routes.APPLY_SA_EMPLOYMENT} component={Employment} />
            <Stack.Screen name={routes.APPLY_SA_FINANCIAL} component={Financial} />
            <Stack.Screen name={routes.APPLY_SA_PREFERREDBRANCH} component={PreferredBranch} />
            <Stack.Screen name={routes.APPLY_SA_BANKING} component={ApplySABank} />
            <Stack.Screen name={routes.APPLY_SA_PAC} component={ApplyPac} />
            <Stack.Screen name={routes.APPLY_SA_PAC_OLD} component={ApplyPacOld} />
            <Stack.Screen name={routes.APPLY_SA_MAP} component={ApplyMap} />
            <Stack.Screen name={routes.APPLY_SA_MAP_NEW} component={ApplyMapNew} />
            <Stack.Screen name={routes.APPLY_SA_CTOS_VERIFICATION} component={CTOSVerification} />
            <Stack.Screen name={routes.APPLY_SA_CTOS_KBA} component={CTOSKba} />
            <Stack.Screen name={routes.APPLY_SA_CTOS_ADDRESS} component={CTOSAddress} />
            <Stack.Screen name={routes.APPLY_SA_PBE_USERNAME} component={PbeUsername} />
            <Stack.Screen name={routes.APPLY_SA_PBE_PASSWORD} component={PbePassword} />
            <Stack.Screen name={routes.APPLY_SA_PBE_MEMORABLE_QUESTION} component={PbeMemorableQuestion} />
            <Stack.Screen name={routes.APPLY_SA_ACKNOWLEDGE} component={ApplyAcknowledge} />
            <Stack.Screen name={routes.DUITNOW_ID} component={DuitNowID} />
            <Stack.Screen name={routes.DUITNOW_REGISTER} component={DuitNowRegister} />
            <Stack.Screen name={routes.DUITNOW_UPDATE} component={DuitNowUpdate} />

            <Stack.Screen name={routes.ESI} component={Esi} />
            <Stack.Screen name={routes.RECURRING_DETAILS} component={RecurringDetails} />
            <Stack.Screen name={routes.RECURRING_HISTORY} component={RecurringHistory} />

            {/* Device Management */}
            <Stack.Screen name={routes.DEVICE_MANAGEMENT} component={DeviceManagement} />

            {/* Flexipay */}
            <Stack.Screen name={routes.FLEXIPAY} component={Flexipay} />
            <Stack.Screen name={routes.FLEXIPAY_RECEIPT} component={FlexipayReceipt} />

            {/* Journey */}
            <Stack.Screen name={routes.JOURNEY} component={Journey} />
            <Stack.Screen name={routes.POCKET_MONEY_AMOUNT} component={PocketMoneyAmount} />
            <Stack.Screen name={routes.POCKET_MONEY_REFERENCE} component={PocketMoneyReference} />
            <Stack.Screen name={routes.POCKET_MONEY_CONFIRMATION} component={PocketMoneyConfirmation} />
            <Stack.Screen name={routes.POCKET_MONEY_SUMMARY} component={PocketMoneySummary} />
            <Stack.Screen name={routes.JOURNEY_WITHDRAW_AMOUNT} component={JourneyWithdrawAmount} />
            <Stack.Screen name={routes.JOURNEY_WITHDRAW_CONFIRMATION} component={JourneyWithdrawConfirmation} />
            <Stack.Screen name={routes.JOURNEY_WITHDRAW_SUMMARY} component={JourneyWithdrawSummary} />
            <Stack.Screen name={routes.TASK_LIST} component={TaskList} />
            <Stack.Screen name={routes.TASK_CREATE} component={TaskCreate} />
            <Stack.Screen name={routes.TASK_AMOUNT} component={TaskAmount} />
            <Stack.Screen name={routes.TASK_DETAIL} component={TaskDetail} />
            <Stack.Screen name={routes.GOAL_LIST} component={GoalList} />
            <Stack.Screen name={routes.JOURNEY_HISTORY} component={JourneyHistory} />

            {/* Remittance */}
            <Stack.Screen name={routes.REMITTANCE} component={Remittance} />

            {/* Remittance - Bakong */}
            <Stack.Screen name={routes.BAKONG_ACC} component={BakongAccount} />
            <Stack.Screen name={routes.BAKONG_AMOUNT} component={BakongAmount} />
            <Stack.Screen name={routes.BAKONG_REFERENCE} component={BakongReference} />
            <Stack.Screen name={routes.BAKONG_NOTICE} component={BakongNotice} />
            <Stack.Screen name={routes.BAKONG_CONFIRMATION} component={BakongConfirmation} />
            <Stack.Screen name={routes.BAKONG_RECEIPT} component={BakongReceipt} />
            <Stack.Screen name={routes.BAKONG_RECIPIENT_DETAILS} component={BakongRecipientDetails} />
            <Stack.Screen name={routes.BAKONG_DRB_DECLARATION} component={DRBDeclaration} />

            {/* Cash Advance */}
            <Stack.Screen name={routes.CASH_ADVANCE_FROM} component={CashAdvanceFrom} />
            <Stack.Screen name={routes.CASH_ADVANCE_TO} component={CashAdvanceTo} />
            <Stack.Screen name={routes.CASH_ADVANCE_AMOUNT} component={CashAdvanceAmount} />
            <Stack.Screen name={routes.CASH_ADVANCE_CONFIRM} component={CashAdvanceConfirmation} />
            <Stack.Screen name={routes.CASH_ADVANCE_RECEIPT} component={CashAdvanceReceipt} />

            {/* Appointment */}
            <Stack.Screen name={routes.APPOINTMENT} component={Appointment} />
            <Stack.Screen name={routes.APPOINTMENT_MAKE} component={MakeAppointment} />
            <Stack.Screen name={routes.APPOINTMENT_BRANCH} component={AppointmentBranch} />
            <Stack.Screen name={routes.APPOINTMENT_DETAILS} component={AppointmentDetails} />
            <Stack.Screen name={routes.APPOINTMENT_CONFIRMATION} component={Confirmation} />
            <Stack.Screen name={routes.APPOINTMENT_RECEIPT} component={AppointmentAcknowledgement} />

            {/* Expense Tracker*/}
            <Stack.Screen name={routes.EXPENSE_TRACKER_MAIN} component={ExpenseMainScreen} />
            <Stack.Screen name={routes.EXPENSE_TRACKER} component={ExpenseTrackerTab} />
            <Stack.Screen name={routes.EXPENSE_TRACKER_DETAILS} component={TransactionDetailsScreen} />
            <Stack.Screen name={routes.EXPENSE_TRACKER_CATEGORY_LIST} component={ExpenseCategoryTransactionList} />

            {/* Carbon Tracker*/}
            <Stack.Screen name={routes.CARBON_TRACKER} component={CarbonTrackerScreen} />
            <Stack.Screen name={routes.CARBON_TRACKER_INSIGHTS} component={CarbonTrackerInsightsScreen} />
            <Stack.Screen name={routes.CARBON_TRACKER_TRANSACTION} component={CarbonTrackerTransactionScreen} />
            <Stack.Screen name={routes.CARBON_TRACKER_COMPARISON} component={CarbonTrackerComparisonScreen} />
            <Stack.Screen name={routes.CARBON_TRACKER_OFFSET_PROJECT} component={CarbonTrackerOffsetProjectScreen} />
            <Stack.Screen
              name={routes.CARBON_TRACKER_OFFSET_PROJECT_DETAILS}
              component={CarbonTrackerProjectDetailsScreen}
            />
            <Stack.Screen name={routes.CARBON_TRACKER_MONTHLY_OFFSET} component={CarbonTrackerMonthlyOffsetScreen} />
            <Stack.Screen name={routes.CARBON_TRACKER_AMOUNT_INPUT} component={CarbonAmountInputScreen} />
            <Stack.Screen name={routes.CARBON_TRACKER_CONFIRMATION} component={CO2TrackerConfirmationScreen} />
            <Stack.Screen name={routes.CARBON_TRACKER_RECEIPT} component={CO2TrackerReceiptScreen} />
            <Stack.Screen
              name={routes.CARBON_TRACKER_OFFSET_PROJECT_SELECTION}
              component={CarbonTrackerOffsetProjectSelectionScreen}
            />

            {/** Promotion Module */}
            <Stack.Screen name={routes.PROMOTION_LISTING} component={PromotionListing} />
            <Stack.Screen name={routes.PROMOTION_DETAILS} component={PromotionDetails} />
            <Stack.Screen name={routes.PROMOTION_REGISTER} component={PromotionRegister} />

            {/* Apply Using Webview */}
            <Stack.Screen name={routes.OPEN_WEBVIEW} component={EmptyWebView} />

            <Stack.Screen name={routes.CQ_ENROLMENT} component={AAOPEnrollment} />
            <Stack.Screen
              name={routes.CQ_ENROLMENT_DONE}
              component={CQEnrolmentDone}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen
              name={routes.CQ_CHALLENGE}
              component={AAOPChallenge}
              options={{
                gestureEnabled: false,
              }}
            />
            <Stack.Screen name={routes.CARDLESS_CONTACT} component={ContactScreen} />
            <Stack.Screen name={routes.CARDLESS_NAME} component={NameScreen} />
            <Stack.Screen name={routes.CARDLESS_MOBILE} component={MobileNoScreen} />
            <Stack.Screen name={routes.CARDLESS_AMOUNT} component={AmountScreen} />
            <Stack.Screen name={routes.CARDLESS_CONFIRM} component={ConfirmationScreen} />
            <Stack.Screen name={routes.CARDLESS_RECEIPT} component={ReceiptScreen} />
            <Stack.Screen name={routes.CARDLESS_HISTORY} component={HistoryScreen} />
            <Stack.Screen name={routes.CARDLESS_HISTORY_DETAIL} component={DetailScreen} />
            <Stack.Screen name={routes.CARDLESS_SELECTION} component={SelectionScreen} />

            <Stack.Screen name={routes.MAILBOX_DETAIL} component={MailboxDetail} />

            {/* Deposit */}
            <Stack.Screen name={routes.DEPOSIT_OPEN_ACCOUNT_TYPE} component={DepositOpenAccType} />
            <Stack.Screen name={routes.DEPOSIT_OPEN_FATCA} component={DepositOpenFatca} />
            <Stack.Screen
              name={routes.DEPOSIT_OPEN_RECEIPT}
              component={DepositOpenReceipt}
              options={{ cardStyleInterpolator: forFade }}
            />
            <Stack.Screen name={routes.DEPOSIT_PLACEMENT} component={DepositPlacements} />
            <Stack.Screen name={routes.DEPOSIT_PLACEMENT_TENURE} component={DepositPlacementTenure} />
            <Stack.Screen name={routes.DEPOSIT_PLACEMENT_AMOUNT} component={DepositPlacementAmount} />
            <Stack.Screen name={routes.DEPOSIT_PLACEMENT_MODE} component={DepositPlacementMode} />
            <Stack.Screen name={routes.DEPOSIT_PLACEMENT_CONFIRMATION} component={DepositPlacementConfirmation} />
            <Stack.Screen name={routes.DEPOSIT_PLACEMENT_RECEIPT} component={DepositPlacementReceipt} />
            <Stack.Screen name={routes.DEPOSIT_WITHDRAW_AMOUNT} component={DepositWithdrawAmount} />
            <Stack.Screen name={routes.DEPOSIT_WITHDRAW_CONFIRMATION} component={DepositWithdrawConfirmation} />
            <Stack.Screen name={routes.DEPOSIT_WITHDRAW_RECEIPT} component={DepositWithdrawReceipt} />

            {/* Gold */}
            <Stack.Screen name={routes.GOLD_LANDING} component={GoldLandingScreen} />
            <Stack.Screen name={routes.GOLD_OPEN_ACC} component={GoldOpenAccScreen} />
            <Stack.Screen name={routes.GOLD_DECLARE} component={GoldDeclarationScreen} />
            <Stack.Screen name={routes.GOLD_ACKNOWLEDGE} component={GoldAcknowldegeScreen} />
            <Stack.Screen name={routes.GOLD_AMOUNT} component={GoldAmountScreen} />
            <Stack.Screen name={routes.GOLD_CHART} component={GoldChartScreen} />
            <Stack.Screen name={routes.GOLD_CONFIRMATION} component={GoldConfirmationScreen} />
            <Stack.Screen name={routes.GOLD_CLOSE_ACC} component={GoldCloseAccScreen} />
            <Stack.Screen name={routes.GOLD_RECEIPT_BUY} component={GoldReceiptBuyScreen} />
            <Stack.Screen name={routes.GOLD_RECEIPT_SELL} component={GoldReceiptSellScreen} />
            <Stack.Screen name={routes.GOLD_HISTORY} component={GoldHistoryScreen} />
            <Stack.Screen name={routes.GOLD_HISTORY_DETAIL} component={GoldHistoryDetailScreen} />
            {/*Kill Switch */}
            <Stack.Screen name={routes.KILL_SWITCH} component={KillSwitch} />

            {/*Money Market Deposit*/}
            <Stack.Screen name={routes.MONEY_MARKET_PLACEMENT_DETAILS} component={MoneyMarketDepositPlacementDetails} />
            {/* Card Tokenization */}
            <Stack.Screen name={routes.PENDING_TOKENIZATION} component={PendingTokenization} />
            <Stack.Screen name={routes.TOKENIZATION_FAIL} component={TokenizationFail} />
            <Stack.Screen name={routes.TOKENIZATION_LOADING} component={TokenizationLoading} />

            {/*Branch Locator*/}
            <Stack.Screen name={routes.BRANCH_LOCATOR_MAP} component={BranchLocatorMapScreen} />

            {/* Insurance */}
            <Stack.Screen name={routes.INSURANCE} component={InsuranceScreen} />
            <Stack.Screen name={routes.INSURANCE_CONTACT_US} component={InsuranceContactUsScreen} />
            <Stack.Screen name={routes.INSURANCE_POLICY} component={InsurancePolicyScreen} />
            <Stack.Screen name={routes.INSURANCE_POLICY_DETAILS} component={InsurancePolicyDetailsScreen} />
            <Stack.Screen name={routes.INSURANCE_POLICY_PDF} component={InsurancePolicyPdfScreen} />
            <Stack.Screen name={routes.INSURANCE_PURCHASE_LANDING} component={InsurancePurchaseLandingScreen} />

            {/* Security Quiz */}
            <Stack.Screen
              name={routes.SECURITY_QUIZ}
              component={SecurityQuiz}
              options={{
                cardStyleInterpolator: forFade,
                gestureEnabled: false,
              }}
            />
            <Stack.Screen
              name={routes.SECURITY_QUIZ_QUESTION}
              component={SecurityQuizQuestion}
              options={{
                cardStyleInterpolator: forFade,
                gestureEnabled: false,
              }}
            />
            <Stack.Screen
              name={routes.SECURITY_QUIZ_RESULT}
              component={SecurityQuizResult}
              options={{
                cardStyleInterpolator: forFade,
                gestureEnabled: false,
              }}
            />

            {/*SPI*/}
            <Stack.Screen name={routes.SPI_DETAILS} component={SPIDetails} />

            {/* Auto Debit */}
            <Stack.Screen name={routes.AUTO_DEBIT} component={AutoDebit} />
            <Stack.Screen name={routes.AUTO_DEBIT_ALL_CONSENT_LIST} component={AllConsentList} />
            <Stack.Screen name={routes.AUTO_DEBIT_CONSENT_CONFIRMATION} component={PendingConfirmation} />
            <Stack.Screen name={routes.AUTO_DEBIT_CONSENT_RECEIPT} component={ConsentRegisterReceipt} />
            <Stack.Screen name={routes.AUTO_DEBIT_CONSENT_DETAILS} component={ConsentDetails} />
            <Stack.Screen name={routes.AUTO_DEBIT_CONSENT_HISTORY} component={ConsentHistory} />
            <Stack.Screen name={routes.AUTO_DEBIT_CONSENT_TERMINATION} component={TerminateReason} />
            <Stack.Screen name={routes.AUTO_DEBIT_TRANSFER_CONSENT_GUIDE} component={TransferConsentGuide} />
            <Stack.Screen name={routes.AUTO_DEBIT_TRANSFER_CONSENT_ID} component={TransferConsentID} />
            <Stack.Screen
              name={routes.AUTO_DEBIT_TRANSFER_CONSENT_CONFIRMATION}
              component={TransferConsentConfirmation}
            />
            <Stack.Screen name={routes.AUTO_DEBIT_TRANSFER_CONSENT_RECEIPT} component={TransferConsentReceipt} />
          </Stack.Group>

          <Stack.Group screenOptions={{ presentation: 'modal' }}>
            {/* Portfolio */}
            <Stack.Screen name={routes.WALLET_FORM} component={WalletForm} />
            <Stack.Screen name={routes.EXPENSE_FORM} component={ExpenseForm} />
            <Stack.Screen name={routes.SCHEDULED_TRAN_ENTITY_FORM} component={ScheduledTranEntityForm} />
            <Stack.Screen name={routes.SCHEDULED_TRAN_EXPENSE_FORM} component={ScheduledTranExpenseForm} />

            {/* Loyalty */}
            <Stack.Screen name={routes.LOYALTY_FORM} component={LoyaltyForm} />

            {/* Profile */}
            <Stack.Screen name={routes.ACCOUNT_UPDATE_NAME} component={AccountUpdateName} />

            {/* Expenses tracker */}
            <Stack.Screen name={routes.EXPENSE_NEW_ENTRY} component={ExpenseInputScreen} />
          </Stack.Group>
        </Stack.Navigator>
      </View>
    </UserInactivity>
  );
};

export default AppNavigator;
