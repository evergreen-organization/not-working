import {
  getCurrentChildId,
  getErrorList,
  getJourneyTask,
  updateAlipayPlusObject,
  updateNewAlipayPlusObject,
  mailBoxHistoryReset,
} from 'stores';
import { useNavigation } from '@react-navigation/native';
import Toast from 'react-native-toast-message';
import useApi from './useApi';
import { NOTIFICATION_ACTION } from 'constant';
import { useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import routes from 'navigations/routes';
import { LOADING, SUCCESS } from 'apis';
import { useTranslation } from 'react-i18next';
import { useWebViewProvider } from 'screens';

export const useNotificationAction = () => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'hooks.notification.';
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const getJourneyTaskApi = useApi(getJourneyTask);
  const currentChildId = useSelector(getCurrentChildId);
  const errorList = useSelector(getErrorList);
  const journeyRef = useRef();
  const { minimizeWebView } = useWebViewProvider();

  useEffect(() => {
    journeyRef.current = currentChildId;
  }, [currentChildId]);

  const checkAction = ({ body, action, msgId, gender, errorCode, paymentRequestId, availableBalance }) => {
    dispatch(mailBoxHistoryReset());

    switch (action) {
      case NOTIFICATION_ACTION.PENDING_TRX: {
        const currentRouteName = navigation.getCurrentRoute()?.name;
        if (currentRouteName === routes.SOFT_TOKEN_PENDING_TRAN) return { showToast: false };
        return { showToast: true, toastType: 'secureSign', pressAction: () => goPendingTranModule() };
      }
      case NOTIFICATION_ACTION.JOURNEY_TASK_UPDATED:
        journeyUpdateTaskList();
        return { showToast: false };
      case NOTIFICATION_ACTION.TRX_REMINDER:
        return { showToast: true, pressAction: () => goScheduleTranModule() };
      case NOTIFICATION_ACTION.LOYALTY_CARD:
        return { showToast: true, pressAction: () => goLoyaltyCardModule() };
      case NOTIFICATION_ACTION.BIRTHDAY:
        return { showToast: true, pressAction: () => goBirthdayModule({ body, gender }) };
      case NOTIFICATION_ACTION.ALIPAYPLUS_CPM:
        goAlipayPlusCpmReceipt({ msgId, paymentRequestId, errorCode, availableBalance });
        return { showToast: false };
      case NOTIFICATION_ACTION.ALIPAYPLUS_CPM_PAYING:
        alipayplusCpmLoading();
        return { showToast: false };
      case NOTIFICATION_ACTION.AUTODEBIT_CONSENT:
        return { showToast: true, pressAction: () => goAutoDebitModule() };
      default:
        return { showToast: true, pressAction: () => goNotificationModule(msgId) };
    }
  };

  const checkActionInitial = ({ body, action, msgId, gender, errorCode, paymentRequestId, availableBalance }) => {
    switch (action) {
      // Open app will call initUser, no need to call getPendingTransaction
      case NOTIFICATION_ACTION.PENDING_TRX:
        return goPendingTranModule();
      case NOTIFICATION_ACTION.JOURNEY_TASK_UPDATED:
        return;
      case NOTIFICATION_ACTION.TRX_REMINDER:
        return goScheduleTranModule();
      case NOTIFICATION_ACTION.LOYALTY_CARD:
        return goLoyaltyCardModule();
      case NOTIFICATION_ACTION.BIRTHDAY:
        return goBirthdayModule({ body, gender });
      case NOTIFICATION_ACTION.ALIPAYPLUS_CPM:
        return goAlipayPlusCpmReceipt({ msgId, paymentRequestId, errorCode, availableBalance });
      case NOTIFICATION_ACTION.ALIPAYPLUS_CPM_PAYING:
        return alipayplusCpmLoading();
      case NOTIFICATION_ACTION.AUTODEBIT_CONSENT:
        return goAutoDebitModule();
      default:
        return goNotificationModule(msgId);
    }
  };

  const customToast = (notification, pressAction) => {
    if (!notification) return;
    Toast.show({
      type: 'custom',
      text1: notification.title,
      text2: notification.body,
      onPress: () => {
        Toast.hide();
        if (pressAction) {
          minimizeWebView();
          pressAction();
        }
      },
    });
  };

  const secureSignToast = () => {
    Toast.show({
      type: 'secureSign',
      onPress: index => {
        Toast.hide();
        if (index === 1) {
          minimizeWebView();
          goBlankRouting(routes.SOFT_TOKEN_PENDING_TRAN);
        }
      },
    });
  };

  const alipayplusCpmLoading = () => dispatch(updateAlipayPlusObject({ cpmPayingStatus: LOADING }));
  const goBlankRouting = (path, params) => navigation.navigate(routes.BLANK_ROUTING, { path, params });
  const goPendingTranModule = () => goBlankRouting(routes.SOFT_TOKEN_PENDING_TRAN);
  const goScheduleTranModule = () => goBlankRouting(routes.ESI, { tab: 'ScheduledTranTab' });
  const goLoyaltyCardModule = () => goBlankRouting(routes.LOYALTY);
  const goAutoDebitModule = () => goBlankRouting(routes.AUTO_DEBIT);
  const goAlipayPlusCpmReceipt = ({ msgId, paymentRequestId, errorCode, availableBalance }) => {
    navigation.navigate(routes.MAIN_TAB);
    dispatch(updateAlipayPlusObject({ cpmPayingStatus: SUCCESS }));

    if (errorCode) {
      const errorMessage = errorList.find(x => x.errorCode === errorCode)?.errorMessage;

      navigation.navigate(routes.SOFT_TOKEN_FAIL, {
        title: t(`${LANG_PREFIX}paymentFailed`),
        message: errorMessage ?? errorCode,
      });

      return;
    }

    if (msgId) {
      dispatch(updateNewAlipayPlusObject({ aplusRefNo: paymentRequestId, availableBalance }));
      navigation.navigate(routes.QR_PAYMENT_ALIPLAYPLUS_RECEIPT, { msgId });
    }
  };
  const goNotificationModule = msgId => {
    if (msgId) navigation.navigate(routes.MAILBOX_DETAIL, { msgId });
  };
  const goBirthdayModule = params => navigation.navigate(routes.BIRTHDAY, params);

  const journeyUpdateTaskList = () => {
    if (journeyRef) {
      const childId = journeyRef.current;
      getJourneyTaskApi.request({ childId });
    }
  };

  return { checkAction, checkActionInitial, customToast, secureSignToast };
};

export default useNotificationAction;
