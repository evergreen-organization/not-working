import { useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import {
  AAOP_LOCKED,
  BANK_ACC,
  checkTransModeDuitNow,
  findBakongIdType,
  findDuitnowIdTypeName,
  PBSS_APPROVAL_TRAN_TYPE,
  proxyManageType,
  tranApiType,
  transMode,
  ERROR_UUID_DUPLICATED,
} from 'constant';
import routes from 'navigations/routes';
import {
  addCardTokenization,
  changeCQ,
  completeJourneyTask,
  enrolCQ,
  getSecfaAuth,
  getSoftToken,
  manageDuitNowProxy,
  registerDuitNowProxy,
  submitAlipayPlus,
  submitApproveConsent,
  submitBakong,
  submitBillPayment,
  submitBuyGold,
  submitCarbonOffset,
  submitCardlessWithdraw,
  submitCardPayment,
  submitCardPin,
  submitCashAdvance,
  submitCloseGoldAccount,
  submitDepositPlacement,
  submitDepositWithdraw,
  submitEditConsent,
  submitEmailAddress,
  submitFundTransfer,
  submitLonpacInsuranceConsent,
  submitLoanPayment,
  submitLockFund,
  submitOpenEFD,
  submitOpenGoldAcc,
  submitQRPayment,
  submitSellGold,
  submitTopUp,
  submitTransferConsent,
  submitUnlockFund,
  transferJourney,
  updateCardObject,
  updateCasaObject,
  updateCqChallengeResult,
  updateDepositObject,
  updateInvestObject,
  updateLoanObject,
  updateProfileAccess,
  updateQuickPayment,
} from 'stores';
import { useApi } from './useApi';
import { showFailure, showSuccess } from 'utils/message';
import { IDLE } from 'apis';
import { useTranslation } from 'react-i18next';
import { useWalletTokenization } from './useWalletTokenization';
import { checkTransactionActivityDeclined } from 'screens/softToken/utils';

export const useTranApiSubmit = ({ type, navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'softToken.submit.text.';

  const { handleRedirectToWalletSuccess, handleRedirectToWalletFailure } = useWalletTokenization();
  const dispatch = useDispatch();
  const secfaAuth = useSelector(getSecfaAuth);
  const store_softToken = useSelector(getSoftToken);
  const submitFundTransferApi = useApi(submitFundTransfer);
  const submitCardPaymentApi = useApi(submitCardPayment);
  const submitLoanPaymentApi = useApi(submitLoanPayment);
  const submitQrPaymentApi = useApi(submitQRPayment);
  const submitAlipayPlusApi = useApi(submitAlipayPlus);
  const submitTopUpApi = useApi(submitTopUp);
  const submitCashAdvanceApi = useApi(submitCashAdvance);
  const submitBillPaymentApi = useApi(submitBillPayment);
  const manageDuitNowProxyApi = useApi(manageDuitNowProxy);
  const registerDuitNowProxyApi = useApi(registerDuitNowProxy);
  const enrolCQApi = useApi(enrolCQ);
  const changeCQApi = useApi(changeCQ);
  const transferJourneyApi = useApi(transferJourney);
  const transferJourneyTaskApi = useApi(completeJourneyTask);
  const submitCardlessWithdrawApi = useApi(submitCardlessWithdraw);
  const submitBakongTransferApi = useApi(submitBakong);
  const updateQuickPaymentApi = useApi(updateQuickPayment);
  const submitOpenEFDApi = useApi(submitOpenEFD);
  const submitDepositPlacementApi = useApi(submitDepositPlacement);
  const submitDepositWithdrawApi = useApi(submitDepositWithdraw);
  const submitCarbonOffsetApi = useApi(submitCarbonOffset);
  const submitLockFundApi = useApi(submitLockFund);
  const submitUnlockFundApi = useApi(submitUnlockFund);
  const submitEmailAddressApi = useApi(submitEmailAddress);
  const submitCardPinApi = useApi(submitCardPin);
  const submitOpenGoldAccApi = useApi(submitOpenGoldAcc);
  const submitBuyGoldApi = useApi(submitBuyGold);
  const submitSellGoldApi = useApi(submitSellGold);
  const submitCloseGoldAccountApi = useApi(submitCloseGoldAccount);
  const updateProfileAccessApi = useApi(updateProfileAccess);
  const submitCardTokenization = useApi(addCardTokenization);
  const submitInsuranceConsentApi = useApi(submitLonpacInsuranceConsent);
  const submitTransferConsentApi = useApi(submitTransferConsent);
  const submitApproveConsentApi = useApi(submitApproveConsent);
  const submitEditConsentApi = useApi(submitEditConsent);

  const { isPublic } = secfaAuth;
  const isPublicRef = useRef(isPublic);

  useEffect(() => {
    isPublicRef.current = isPublic;
  }, [isPublic]);

  const onSubmit = async ({ secfa, extraParam }) => {
    if (type === tranApiType.FUND_TRANSFER) {
      return submitFundTransferApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CARD_PAYMENT) {
      return submitCardPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.LOAN_PAYMENT) {
      return submitLoanPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.QR_PAYMENT) {
      return submitQrPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.ALIPAY_PLUS) {
      return submitAlipayPlusApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.TOP_UP) {
      return submitTopUpApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CASH_ADVANCE) {
      return submitCashAdvanceApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.JOMPAY_PAYMENT) {
      return submitBillPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.BILL_PAYMENT) {
      return submitBillPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.DUITNOW_MANAGEMENT) {
      return manageDuitNowProxyApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.DUITNOW_REGISTRATION) {
      return registerDuitNowProxyApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CQ_ENROLMENT) {
      return enrolCQApi.request({
        secfa,
      });
    }
    if (type === tranApiType.CQ_CHANGE) {
      return changeCQApi.request({
        secfa,
      });
    }
    if (type === tranApiType.JOURNEY_TRANSFER) {
      return transferJourneyApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.JOURNEY_TRANSFER_TASK) {
      return transferJourneyTaskApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CARDLESS_WITHDRAW) {
      return submitCardlessWithdrawApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.BAKONG_TRANSFER) {
      return submitBakongTransferApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.QUICK_PAYMENT_LIMIT) {
      return updateQuickPaymentApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.DEPOSIT_OPEN_EFD) {
      return submitOpenEFDApi.request({
        secfa,
      });
    }
    if (type === tranApiType.DEPOSIT_PLACEMENT) {
      return submitDepositPlacementApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.DEPOSIT_WITHDRAW) {
      return submitDepositWithdrawApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CARBON_OFFSET) {
      return submitCarbonOffsetApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.LOCK_FUND) {
      return submitLockFundApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.LOCK_FUND_INCREASE) {
      return submitLockFundApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.UNLOCK_FUND) {
      return submitUnlockFundApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.UPDATE_EMAIL) {
      return submitEmailAddressApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.UPDATE_CARD_PIN) {
      return submitCardPinApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.GOLD_OPEN_ACC) {
      return submitOpenGoldAccApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.GOLD_BUY) {
      return submitBuyGoldApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.GOLD_SELL) {
      return submitSellGoldApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.GOLD_CLOSE_ACC) {
      return submitCloseGoldAccountApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CHANGE_PROFILE_VIEW) {
      return updateProfileAccessApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CHANGE_PROFILE_STANDARD) {
      return updateProfileAccessApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.WALLET_TOKENIZATION) {
      return submitCardTokenization.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.INSURANCE_CONSENT) {
        return submitInsuranceConsentApi.request({
          secfa,
          ...extraParam,
        });
    }
    if (type === tranApiType.DUITNOW_AUTODEBIT_TRANSFER) {
      return submitTransferConsentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.DUITNOW_AUTODEBIT_APPROVE) {
      return submitApproveConsentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.DUITNOW_AUTODEBIT_EDIT) {
      return submitEditConsentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
  };

  const onSuccess = ({ extraParam, apiResponse }) => {
    if (type === tranApiType.FUND_TRANSFER) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.TRANSFER_RECEIPT, { ...extraParam });

      //To load only when trying to access next time
      if (extraParam.secfaInfo?.sendMoneyType === transMode.OWN.key)
        dispatch(updateCasaObject({ accountsStatus: IDLE }));
      return;
    }
    if (type === tranApiType.CARD_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.PAY_CARD_RECEIPT, { ...extraParam });

      if (extraParam.secfaInfo?.isOwn) dispatch(updateCardObject({ accountsStatus: IDLE }));
      return;
    }
    if (type === tranApiType.LOAN_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.PAY_LOAN_RECEIPT, { ...extraParam });

      if (extraParam.secfaInfo?.isOwn) dispatch(updateLoanObject({ accountsStatus: IDLE }));
      return;
    }
    if (type === tranApiType.QR_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.QR_PAYMENT_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.ALIPAY_PLUS) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.QR_PAYMENT_ALIPLAYPLUS_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.TOP_UP) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.TOP_UP_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.CASH_ADVANCE) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.CASH_ADVANCE_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.JOMPAY_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.JOMPAY_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.BILL_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.BILL_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.DUITNOW_REGISTRATION) {
      navigation.navigate(routes.DUITNOW_ID);
      return;
    }
    if (type === tranApiType.DUITNOW_MANAGEMENT) {
      if (extraParam.duitNowManageType === proxyManageType.DEREGISTER) {
        showSuccess(t(`${LANG_PREFIX}msgSuccessDuitNowDeregister`));
        navigation.navigate(routes.DUITNOW_ID);
      } else {
        navigation.navigate(routes.DUITNOW_UPDATE, { ...extraParam });
      }
      return;
    }
    if (type === tranApiType.CQ_ENROLMENT) {
      navigation.navigate(routes.CQ_ENROLMENT_DONE);
      return;
    }
    if (type === tranApiType.PBSS_CQ_ENROLMENT_VALIDATE_PAC) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.SOFT_TOKEN_ACTIVATION, { ...extraParam, ...apiResponse });
    }
    if (type === tranApiType.PBSS_CQ_ENROLMENT) {
      navigation.navigate({
        name: routes.SOFT_TOKEN_ACTIVATION,
        params: { cqChallengeResult: apiResponse },
        merge: true, //Add param instead of replace
      });
      return;
    }
    if (type === tranApiType.CQ_CHANGE) {
      navigation.navigate(routes.CQ_ENROLMENT_DONE);
      return;
    }
    if (type === tranApiType.SECURE_SIGN_APPROVAL) {
      navigation.navigate(routes.MAIN_TAB);

      if (extraParam.actionType === 'APPROVE') {
        navigation.navigate(routes.SOFT_TOKEN_PENDING_TRAN_SUCCESS, { ...extraParam });
      } else {
        if (extraParam.tranType === PBSS_APPROVAL_TRAN_TYPE.CALLER_AUTH)
          return showFailure(t(`${LANG_PREFIX}msgAuthenticationRejected`));
        showFailure(t(`${LANG_PREFIX}msgTransactionRejected`));
      }

      return;
    }
    if (type === tranApiType.JOURNEY_TRANSFER) {
      extraParam.updateAmount(extraParam.currentChild, extraParam.amount);
      navigation.navigate(routes.JOURNEY);
      navigation.navigate(routes.POCKET_MONEY_SUMMARY);
      return;
    }
    if (type === tranApiType.JOURNEY_TRANSFER_TASK) {
      extraParam.updateAmount(extraParam.currentChild, extraParam.amount, extraParam.isTaskReward);
      navigation.navigate(routes.JOURNEY);
      navigation.navigate(routes.POCKET_MONEY_SUMMARY);
      return;
    }
    if (type === tranApiType.CARDLESS_WITHDRAW) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.CARDLESS_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.BAKONG_TRANSFER) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.BAKONG_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.QUICK_PAYMENT_LIMIT) {
      if (store_softToken.selectedRoute === routes.QUICK_PAYMENT) return navigation.navigate(routes.APP_SECURITY);
      navigation.replace(store_softToken.selectedRoute);
      return;
    }
    if (type === tranApiType.CHANGE_PIN) {
      navigation.navigate(routes.MAIN_TAB);
      showSuccess(t(`${LANG_PREFIX}msgPinUpdated`));
      return;
    }
    if (type === tranApiType.RESET_PIN) {
      navigation.navigate(routes.MAIN_TAB);
      showSuccess(t(`${LANG_PREFIX}msgPinUpdated`), t(`${LANG_PREFIX}msgPinResetDesc`));
      return;
    }
    if (type === tranApiType.DEPOSIT_OPEN_EFD) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.DEPOSIT_OPEN_RECEIPT);
      return;
    }
    if (type === tranApiType.DEPOSIT_PLACEMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.DEPOSIT_PLACEMENT_RECEIPT, { ...extraParam });

      //To load only when trying to access next time
      dispatch(updateDepositObject({ accountsStatus: IDLE }));
      return;
    }
    if (type === tranApiType.DEPOSIT_WITHDRAW) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.DEPOSIT_WITHDRAW_RECEIPT, { ...extraParam });

      //To load only when trying to access next time
      dispatch(updateCasaObject({ accountsStatus: IDLE }));
      return;
    }

    if (type === tranApiType.CARBON_OFFSET) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.CARBON_TRACKER_RECEIPT, { ...extraParam });
      return;
    }

    if (type === tranApiType.LOCK_FUND || type === tranApiType.LOCK_FUND_INCREASE) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.CASA_DETAIL, { ...extraParam });
      return;
    }

    if (type === tranApiType.UPDATE_EMAIL) {
      showSuccess(t(`${LANG_PREFIX}msgEmailUpdated`));
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.ACCOUNT_SETTINGS, { ...extraParam });
      return;
    }
    if (type === tranApiType.UPDATE_CARD_PIN) {
      showSuccess(
        (extraParam?.isPinCreated
          ? t(`${LANG_PREFIX}msgCardPinChangeSuccess`)
          : t(`${LANG_PREFIX}msgCardPinUpdateSuccess`)
        )?.replace('${cardNo}', extraParam?.cardNo?.slice(-4)),
      );
      navigation.navigate(routes.MAIN_TAB);
      return navigation.navigate(extraParam?.cardRoute?.route, { ...extraParam?.cardRoute?.params });
    }

    if (type === tranApiType.GOLD_OPEN_ACC || type === tranApiType.GOLD_BUY) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.GOLD_RECEIPT_BUY, { ...extraParam });

      //To load only when trying to access next time
      dispatch(updateInvestObject({ accountsStatus: IDLE }));
      return;
    }

    if (type === tranApiType.GOLD_SELL || type === tranApiType.GOLD_CLOSE_ACC) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.GOLD_RECEIPT_SELL, { ...extraParam });

      //To load only when trying to access next time
      dispatch(updateCasaObject({ accountsStatus: IDLE }));
      return;
    }
    if (type === tranApiType.CHANGE_PROFILE_VIEW) {
      return navigation.navigate(routes.MAIN_TAB, { screen: 'HomeTab' });
    }
    if (type === tranApiType.CHANGE_PROFILE_STANDARD) {
      return navigation.navigate(routes.MAIN_TAB, { screen: 'HomeTab' });
    }
    if (
      type === tranApiType.QUICK_LOGIN ||
      type === tranApiType.PASSWORD_LOGIN ||
      type === tranApiType.PASSWORD_LOGIN_MODAL
    ) {
      dispatch(updateCqChallengeResult({ type, ...apiResponse }));
      navigation.goBack();
      return;
    }
    if (type === tranApiType.WALLET_TOKENIZATION) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.TOKENIZATION_LOADING, { ...extraParam });
      showSuccess(t(`${LANG_PREFIX}msgAddCardSuccessful`));
      return;
    }
    if (type === tranApiType.INSURANCE_CONSENT) {
      return navigation.replace(routes.INSURANCE);
	}
    if (type === tranApiType.DUITNOW_AUTODEBIT_TRANSFER) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.AUTO_DEBIT_TRANSFER_CONSENT_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.DUITNOW_AUTODEBIT_APPROVE) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.AUTO_DEBIT_CONSENT_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.DUITNOW_AUTODEBIT_EDIT) {
      navigation.navigate(routes.AUTO_DEBIT_CONSENT_DETAILS, { ...extraParam });
      return;
    }
  };

  const onFailure = ({ title, message, extraParam, data, status }) => {
    if (type === tranApiType.WALLET_TOKENIZATION) {
      return handleRedirectToWalletFailure({ secfaInfo: extraParam?.secfaInfo, errorMessage: message });
    }

    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.SOFT_TOKEN_FAIL, {
      title,
      message,
      isEsiSelected: extraParam?.secfaInfo?.frequency,
      data,
      status,
    });
  };

  const error = () => {
    if (type === tranApiType.FUND_TRANSFER) return submitFundTransferApi.error;
    if (type === tranApiType.CARD_PAYMENT) return submitCardPaymentApi.error;
    if (type === tranApiType.LOAN_PAYMENT) return submitLoanPaymentApi.error;
    if (type === tranApiType.QR_PAYMENT) return submitQrPaymentApi.error;
    if (type === tranApiType.ALIPAY_PLUS) return submitAlipayPlusApi.error;
    if (type === tranApiType.TOP_UP) return submitTopUpApi.error;
    if (type === tranApiType.CASH_ADVANCE) return submitCashAdvanceApi.error;
    if (type === tranApiType.JOMPAY_PAYMENT) return submitBillPaymentApi.error;
    if (type === tranApiType.BILL_PAYMENT) return submitBillPaymentApi.error;
    if (type === tranApiType.DUITNOW_MANAGEMENT) return manageDuitNowProxyApi.error;
    if (type === tranApiType.DUITNOW_REGISTRATION) return registerDuitNowProxyApi.error;
    if (type === tranApiType.CQ_ENROLMENT) return enrolCQApi.error;
    if (type === tranApiType.CQ_CHANGE) return changeCQApi.error;
    if (type === tranApiType.JOURNEY_TRANSFER) return transferJourneyApi.error;
    if (type === tranApiType.JOURNEY_TRANSFER_TASK) return transferJourneyTaskApi.error;
    if (type === tranApiType.CARDLESS_WITHDRAW) return submitCardlessWithdrawApi.error;
    if (type === tranApiType.BAKONG_TRANSFER) return submitBakongTransferApi.error;
    if (type === tranApiType.QUICK_PAYMENT_LIMIT) return updateQuickPaymentApi.error;
    if (type === tranApiType.DEPOSIT_OPEN_EFD) return submitOpenEFDApi.error;
    if (type === tranApiType.DEPOSIT_PLACEMENT) return submitDepositPlacementApi.error;
    if (type === tranApiType.DEPOSIT_WITHDRAW) return submitDepositWithdrawApi.error;
    if (type === tranApiType.CARBON_OFFSET) return submitCarbonOffsetApi.error;
    if (type === tranApiType.LOCK_FUND) return submitLockFundApi.error;
    if (type === tranApiType.UNLOCK_FUND) return submitUnlockFundApi.error;
    if (type === tranApiType.UPDATE_EMAIL) return submitEmailAddressApi.error;
    if (type === tranApiType.UPDATE_CARD_PIN) return submitCardPinApi.error;
    if (type === tranApiType.GOLD_BUY) return submitBuyGoldApi.error;
    if (type === tranApiType.GOLD_SELL) return submitSellGoldApi.error;
    if (type === tranApiType.GOLD_OPEN_ACC) return submitOpenGoldAccApi.error;
    if (type === tranApiType.GOLD_CLOSE_ACC) return submitCloseGoldAccountApi.error;
    if (type === tranApiType.CHANGE_PROFILE_VIEW) return updateProfileAccessApi.error;
    if (type === tranApiType.CHANGE_PROFILE_STANDARD) return updateProfileAccessApi.error;
    if (type === tranApiType.WALLET_TOKENIZATION) return submitCardTokenization.error;
    if (type === tranApiType.INSURANCE_CONSENT) return submitInsuranceConsentApi.error;
    if (type === tranApiType.DUITNOW_AUTODEBIT_TRANSFER) return submitTransferConsentApi.error;
    if (type === tranApiType.DUITNOW_AUTODEBIT_APPROVE) return submitApproveConsentApi.error;
    if (type === tranApiType.DUITNOW_AUTODEBIT_EDIT) return submitEditConsentApi.error;
  };

  const checkJunction = () => {
    if (
      type === tranApiType.DUITNOW_MANAGEMENT ||
      type === tranApiType.DUITNOW_REGISTRATION ||
      type === tranApiType.DEPOSIT_OPEN_EFD ||
      type === tranApiType.DEPOSIT_PLACEMENT ||
      type === tranApiType.DEPOSIT_WITHDRAW ||
      type === tranApiType.INSURANCE_CONSENT ||
      type === tranApiType.QUICK_PAYMENT_LIMIT ||
      type === tranApiType.CHANGE_PROFILE_STANDARD ||
      type === tranApiType.CHANGE_PROFILE_VIEW ||
      type === tranApiType.QUICK_LOGIN ||
      type === tranApiType.LOCK_FUND ||
      type === tranApiType.LOCK_FUND_INCREASE ||
      type === tranApiType.UNLOCK_FUND ||
      type === tranApiType.WALLET_TOKENIZATION
    )
      return 'PUBLIC';
    if (
      type === tranApiType.UPDATE_EMAIL ||
      type === tranApiType.CQ_ENROLMENT ||
      type === tranApiType.PBSS_CQ_ENROLMENT ||
      type === tranApiType.CQ_CHANGE ||
      type === tranApiType.PASSWORD_LOGIN ||
      type === tranApiType.PASSWORD_LOGIN_MODAL
    )
      return 'PRIVATE';
    return 'BOTH';
  };

  const isPublicJunction = junction => {
    if (junction === 'PUBLIC') return true;
    else if (junction === 'PRIVATE') return false;
    return isPublicRef.current;
  };

  const duplicateMessage = () => {
    switch (type) {
      case tranApiType.TOP_UP:
        return t(`${LANG_PREFIX}duplicateMsgTopUp`);
      case tranApiType.FUND_TRANSFER:
        return t(`${LANG_PREFIX}duplicateMsgFundTransfer`);
      case tranApiType.CASH_ADVANCE:
      case tranApiType.JOURNEY_TRANSFER:
      case tranApiType.JOURNEY_TRANSFER_TASK:
      case tranApiType.CARDLESS_WITHDRAW:
      case tranApiType.CARD_PAYMENT:
      case tranApiType.LOAN_PAYMENT:
      case tranApiType.BAKONG_TRANSFER:
        return t(`${LANG_PREFIX}duplicateMsgTransfer`);
      case tranApiType.JOMPAY_PAYMENT:
      case tranApiType.BILL_PAYMENT:
        return t(`${LANG_PREFIX}duplicateMsgBill`);
      default:
        return '';
    }
  };

  const failureTitle = status => {
    if (checkTransactionActivityDeclined(status)) return t(`${LANG_PREFIX}msgActivityDenied`);
    if (status === AAOP_LOCKED) return t(`${LANG_PREFIX}msgAccessDenied`);
    if (status === ERROR_UUID_DUPLICATED) return t(`${LANG_PREFIX}msgInvalidRequest`);
    switch (type) {
      case tranApiType.QR_PAYMENT:
      case tranApiType.ALIPAY_PLUS:
      case tranApiType.CARD_PAYMENT:
      case tranApiType.LOAN_PAYMENT:
      case tranApiType.JOMPAY_PAYMENT:
      case tranApiType.BILL_PAYMENT:
        return t(`${LANG_PREFIX}msgPaymentFailed`);
      case tranApiType.TOP_UP:
        return t(`${LANG_PREFIX}msgTopUpFailed`);
      case tranApiType.CASH_ADVANCE:
        return t(`${LANG_PREFIX}msgAdvanceFailed`);
      case tranApiType.FUND_TRANSFER:
      case tranApiType.DUITNOW_MANAGEMENT:
      case tranApiType.DUITNOW_REGISTRATION:
      case tranApiType.CQ_ENROLMENT:
      case tranApiType.CQ_CHANGE:
      case tranApiType.JOURNEY_TRANSFER:
      case tranApiType.JOURNEY_TRANSFER_TASK:
      case tranApiType.SECURE_SIGN_APPROVAL:
      case tranApiType.BAKONG_TRANSFER:
      case tranApiType.QUICK_PAYMENT_LIMIT:
        return t(`${LANG_PREFIX}msgTransactionFailed`);
      case tranApiType.CARDLESS_WITHDRAW:
        return t(`${LANG_PREFIX}msgCardlessWithdrawalFailed`);
      case tranApiType.DEPOSIT_OPEN_EFD:
        return t(`${LANG_PREFIX}msgOpenFailed`);
      case tranApiType.DEPOSIT_PLACEMENT:
        return t(`${LANG_PREFIX}msgPlacementFailed`);
      case tranApiType.DEPOSIT_WITHDRAW:
        return t(`${LANG_PREFIX}msgDepositWithdrawalFailed`);
      case tranApiType.CARBON_OFFSET:
        return t(`${LANG_PREFIX}msgCarbonOffsetFailed`);
      case tranApiType.LOCK_FUND:
      case tranApiType.LOCK_FUND_INCREASE:
        return t(`${LANG_PREFIX}msgLockFundFailed`);
      case tranApiType.UNLOCK_FUND:
        return t(`${LANG_PREFIX}msgUnlockFundFailed`);
      case tranApiType.UPDATE_EMAIL:
        return t(`${LANG_PREFIX}msgUpdateEmailFailed`);
      case tranApiType.UPDATE_CARD_PIN:
        return t(`${LANG_PREFIX}msgSetupCardPinFailed`);
      case tranApiType.GOLD_BUY:
      case tranApiType.GOLD_SELL:
      case tranApiType.GOLD_OPEN_ACC:
      case tranApiType.GOLD_CLOSE_ACC:
        return t(`${LANG_PREFIX}msgTransactionUnsuccessful`);
      case tranApiType.CHANGE_PROFILE_VIEW:
        return t(`${LANG_PREFIX}msgUpdateProfileAccessRejected`);
      case tranApiType.CHANGE_PROFILE_STANDARD:
        return t(`${LANG_PREFIX}msgUpdateProfileAccessRejected`);
      case tranApiType.QUICK_LOGIN:
        return t(`${LANG_PREFIX}msgAccessDenied`);
      case tranApiType.WALLET_TOKENIZATION:
        return t(`${LANG_PREFIX}msgAddCardFailed`);
      case tranApiType.INSURANCE_CONSENT:
        return t(`${LANG_PREFIX}msgSubmitInsuranceConsentFailed`);
      case tranApiType.DUITNOW_AUTODEBIT_APPROVE:
      case tranApiType.DUITNOW_AUTODEBIT_EDIT:
      case tranApiType.DUITNOW_AUTODEBIT_TRANSFER:
        return t(`${LANG_PREFIX}msgUpdateDuitNowAutoDebitFailed`);
      default:
        return '';
    }
  };

  const showSemakMule = () => {
    switch (type) {
      case tranApiType.FUND_TRANSFER:
        return true;
      default:
        return false;
    }
  };

  const recipientInfoList = trxInfo => {
    switch (type) {
      case tranApiType.BAKONG_TRANSFER: {
        const bakongIdType = findBakongIdType(trxInfo?.idType);

        return [
          { title: t(`${LANG_PREFIX}recipientInfoName`), value: trxInfo?.beneName },
          { title: t(bakongIdType?.langCode), value: trxInfo?.accNo },
        ];
      }
      case tranApiType.FUND_TRANSFER: {
        const mode = trxInfo?.transferMode;
        const title = checkTransModeDuitNow(mode) ? t(findDuitnowIdTypeName(trxInfo?.idType)) : t(BANK_ACC.langCode);

        return [
          { title: t(`${LANG_PREFIX}recipientInfoName`), value: trxInfo?.beneName },
          { title, value: trxInfo?.accNo },
        ];
      }
      default:
        return [];
    }
  };

  return {
    onSubmit,
    onSuccess,
    onFailure,
    error,
    checkJunction,
    isPublicJunction,
    duplicateMessage,
    failureTitle,
    recipientInfoList,
    showSemakMule,
  };
};

export default useTranApiSubmit;
