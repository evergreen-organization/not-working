import { otherUrlTag } from 'constant';
import routes from 'navigations/routes';

import AngpowIcon from 'assets/images/icon/angpow.png';
import CashAdvanceIcon from 'assets/images/basiccolor/withdraw.png';
import CreditCardIcon from 'assets/images/basiccolor/creditcard.png';
import LoanIcon from 'assets/images/basiccolor/loan.png';
import SimIcon from 'assets/images/basiccolor/sim.png';
import KeyIcon from 'assets/images/basiccolor/key.png';
import AlarmIcon from 'assets/images/basiccolor/calendar.png';
import MoneyIcon from 'assets/images/basiccolor/money.png';
import ScanIcon from 'assets/images/basiccolor/scan2.png';
import TransferIcon from 'assets/images/basiccolor/plane.png';
import BillIcon from 'assets/images/basiccolor/bill.png';
import AtmIcon from 'assets/images/basiccolor/atm.png';
import MoreIcon from 'assets/images/basiccolor/more.png';
import CyberSecurityImg from 'assets/images/illustration/cybersecurity.png';
import SavingsImg from 'assets/images/illustration/savings.png';
import CreditCardImg from 'assets/images/illustration/creditcard.png';
import RcbImg from 'assets/images/illustration/rcb.png';
import HouseImg from 'assets/images/illustration/house.png';
import CarImg from 'assets/images/illustration/car.png';
import PromoImg from 'assets/images/illustration/promo.png';
import ShareLinkImg from 'assets/images/illustration/sharelink.png';
import FTTIcon from 'assets/images/basiccolor/ftt.png';
import CalculatorIcon from 'assets/images/basiccolor/calculator.png';
import JourneyIcon from 'assets/images/illustration/pbJourney.png';
import AppointmentIcon from 'assets/images/basiccolor/bank.png';
import MembercardIcon from 'assets/images/basiccolor/giftcard.png';
import ChartIcon from 'assets/images/basiccolor/chart.png';
import CarbonIcon from 'assets/images/basiccolor/carbon.png';
import KillSwitchIcon from 'assets/images/basiccolor/killSwitch.png';
import ShieldIcon from 'assets/images/basiccolor/shield.png';
import MapIcon from 'assets/images/basiccolor/location.png';
import AutoDebitIcon from 'assets/images/basiccolor/autoDebit.png';
import { LABEL_CO2 } from 'screens/carbonTracker/constant';

import HouseIcon from 'assets/images/basiccolor/home.png';
import ApplyCarIcon from 'assets/images/basiccolor/applycar.png';
import CardIcon from 'assets/images/basiccolor/card.png';
import SafeboxIcon from 'assets/images/basiccolor/safebox.png';
import SolarIcon from 'assets/images/basiccolor/solar.png';
import CarpetIcon from 'assets/images/basiccolor/carpet.png';
import ShareLinkIcon from 'assets/images/basiccolor/invest.png';
import BaePFIcon from 'assets/images/basiccolor/moneyBag.png';

const LANG_PREFIX_ICON = 'screens.home.icon.';
const LANG_PREFIX = 'screens.home.text.';

const SCAN = {
  key: 'SCAN',
  icon: ScanIcon,
  label: LANG_PREFIX_ICON + 'scan',
  accessibilityLabel: LANG_PREFIX_ICON + 'scanAcs',
  route: routes.QR_PAYMENT,
  restrictedRoute: routes.QR_PAYMENT_RECEIVE,
  isRestricted: true,
  iconVersion: 0,
  badgeText: LANG_PREFIX_ICON + 'newBadgeText',
};

const SEND_MONEY = {
  key: 'SEND_MONEY',
  icon: TransferIcon,
  label: LANG_PREFIX_ICON + 'send',
  accessibilityLabel: LANG_PREFIX_ICON + 'sendAcs',
  route: routes.TRANSFER_TO,
  isRestricted: true,
  iconVersion: 0,
};

const PAY_BILL = {
  key: 'PAY_BILL',
  icon: BillIcon,
  label: LANG_PREFIX_ICON + 'payBill',
  route: routes.BILL,
  isRestricted: true,
  iconVersion: 0,
};

const CARDLESS_WITHDRAW = {
  key: 'CARDLESS_WITHDRAW',
  icon: AtmIcon,
  label: LANG_PREFIX_ICON + 'withdraw',
  accessibilityLabel: LANG_PREFIX_ICON + 'withdrawAcs',
  route: routes.CARDLESS_SELECTION,
  isRestricted: true,
  iconVersion: 0,
};

const E_ANG_POW = {
  key: 'E_ANG_POW',
  icon: AngpowIcon,
  label: LANG_PREFIX_ICON + 'eAngPow',
  route: routes.TRANSFER_TO,
  param: { tab: routes.TRANSFER_CONTACT },
  isRestricted: true,
  iconVersion: 0,
};

const CASH_ADVANCE = {
  key: 'CASH_ADVANCE',
  icon: CashAdvanceIcon,
  label: LANG_PREFIX_ICON + 'cashAdvance',
  route: routes.CASH_ADVANCE_FROM,
  isRestricted: true,
  iconVersion: 0,
};

const PAY_CARD = {
  key: 'PAY_CARD',
  icon: CreditCardIcon,
  label: LANG_PREFIX_ICON + 'payCard',
  route: routes.PAY_CARD,
  isRestricted: true,
  iconVersion: 0,
  badgeText: LANG_PREFIX_ICON + 'newBadgeText',
};

const PAY_LOAN = {
  key: 'PAY_LOAN',
  icon: LoanIcon,
  label: LANG_PREFIX_ICON + 'payLoan',
  route: routes.PAY_LOAN,
  isRestricted: true,
  iconVersion: 0,
};

const TOP_UP = {
  key: 'TOP_UP',
  icon: SimIcon,
  label: LANG_PREFIX_ICON + 'topUp',
  accessibilityLabel: LANG_PREFIX_ICON + 'topUpAcs',
  route: routes.TOP_UP,
  isRestricted: true,
  iconVersion: 0,
};

const PB_SECURE_SIGN = {
  key: 'PB_SECURE_SIGN',
  icon: KeyIcon,
  label: LANG_PREFIX_ICON + 'pbss',
  route: routes.SOFT_TOKEN_PENDING_TRAN,
  isRestricted: true,
  iconVersion: 0,
};

const SCHEDULE_TRAN = {
  key: 'SCHEDULE_TRAN',
  icon: AlarmIcon,
  label: LANG_PREFIX_ICON + 'esi',
  accessibilityLabel: LANG_PREFIX_ICON + 'esiAcs',
  route: routes.ESI,
  isRestricted: false,
  iconVersion: 0,
};

const WEALTH = {
  key: 'WEALTH',
  icon: MoneyIcon,
  label: LANG_PREFIX_ICON + 'wealth',
  route: routes.PFM_SUMMARY,
  isVisible: true,
  isRestricted: false,
  iconVersion: 0,
};

const REMITTANCE = {
  key: 'REMITTANCE',
  icon: FTTIcon,
  label: LANG_PREFIX_ICON + 'remit',
  accessibilityLabel: LANG_PREFIX_ICON + 'remitAcs',
  route: routes.REMITTANCE,
  isRestricted: true,
  iconVersion: 0,
  badgeText: LANG_PREFIX_ICON + 'newBadgeText',
};

const CALCULATOR = {
  key: 'CALCULATOR',
  icon: CalculatorIcon,
  label: LANG_PREFIX_ICON + 'calculator',
  isVisible: true,
  route: routes.OPEN_WEBVIEW,
  urlTag: otherUrlTag.APPLY_CALCULATOR,
  isRestricted: false,
  iconVersion: 0,
};

const PB_JOURNEY = {
  key: 'PB_JOURNEY',
  icon: JourneyIcon,
  label: LANG_PREFIX_ICON + 'pbJourney',
  route: routes.JOURNEY,
  iconStyle: { aspectRatio: 512 / 397 },
  isRestricted: true,
  iconVersion: 0,
};

const APPOINTMENT = {
  key: 'APPOINTMENT',
  icon: AppointmentIcon,
  label: LANG_PREFIX_ICON + 'appointment',
  accessibilityLabel: LANG_PREFIX_ICON + 'appointmentAcs',
  route: routes.APPOINTMENT,
  isRestricted: true,
  iconVersion: 0,
};

const LOYALTY = {
  key: 'LOYALTY',
  icon: MembercardIcon,
  label: LANG_PREFIX_ICON + 'loyalty',
  accessibilityLabel: LANG_PREFIX_ICON + 'loyaltyAcs',
  route: routes.LOYALTY_VOUCHER_LIST,
  isRestricted: false,
  iconVersion: 745,
  badgeText: LANG_PREFIX_ICON + 'newBadgeText',
};

const EXPENSE_TRACKER = {
  key: 'EXPENSE_TRACKER',
  icon: ChartIcon,
  label: LANG_PREFIX_ICON + 'expenseTracker',
  route: routes.EXPENSE_TRACKER_MAIN,
  isRestricted: false,
  iconVersion: 0,
};

const CARBON_TRACKER = {
  key: 'CARBON_TRACKER',
  icon: CarbonIcon,
  label: (LANG_PREFIX_ICON + 'carbonTracker').replace('${CO2symbol}', LABEL_CO2),
  route: routes.CARBON_TRACKER,
  isRestricted: true,
  iconVersion: 0,
};

const KILL_SWITCH = {
  key: 'KILL_SWITCH',
  icon: KillSwitchIcon,
  label: LANG_PREFIX_ICON + 'killSwitch',
  route: routes.KILL_SWITCH,
  isRestricted: false,
  iconVersion: 0,
};

const INSURE = {
  key: 'INSURE',
  icon: ShieldIcon,
  label: LANG_PREFIX_ICON + 'insure',
  route: routes.INSURANCE,
  isRestricted: true,
  iconVersion: 603,
  badgeText: LANG_PREFIX_ICON + 'newBadgeText',
};

const AUTO_DEBIT = {
  key: 'AUTO_DEBIT',
  icon: AutoDebitIcon,
  label: LANG_PREFIX_ICON + 'autoDebit',
  route: routes.AUTO_DEBIT,
  isRestricted: true,
  iconVersion: 750,
  badgeText: LANG_PREFIX_ICON + 'newBadgeText',
};

const MY_QR_CODE = {
  iconVersion: 0,
  badgeText: LANG_PREFIX_ICON + 'newBadgeText',
};

const BRANCH_LOCATOR = {
  key: 'BRANCH_LOCATOR',
  icon: MapIcon,
  label: LANG_PREFIX_ICON + 'branchLocator',
  route: routes.BRANCH_LOCATOR_MAP,
  isRestricted: false,
  iconVersion: 745,
  badgeText: LANG_PREFIX_ICON + 'newBadgeText',
};

export const MORE = {
  key: 'MORE',
  icon: MoreIcon,
  label: LANG_PREFIX_ICON + 'more',
  accessibilityLabel: LANG_PREFIX_ICON + 'more',
  route: routes.QUICK_LINKS_ALL,
  isVisible: true,
};

export const QUICK_LINKS = {
  SCAN,
  SEND_MONEY,
  PAY_BILL,
  CARDLESS_WITHDRAW,
  E_ANG_POW,
  CASH_ADVANCE,
  PAY_CARD,
  PAY_LOAN,
  TOP_UP,
  PB_SECURE_SIGN,
  SCHEDULE_TRAN,
  WEALTH,
  REMITTANCE,
  CALCULATOR,
  PB_JOURNEY,
  APPOINTMENT,
  LOYALTY,
  EXPENSE_TRACKER,
  CARBON_TRACKER,
  KILL_SWITCH,
  BRANCH_LOCATOR,
  MY_QR_CODE,
  INSURE,
  AUTO_DEBIT,
  MORE,
};

export const MAIN_ICON_LINK = [SEND_MONEY, CARDLESS_WITHDRAW, PB_SECURE_SIGN];

export const MORE_INFO_LIST = [
  {
    icon: CyberSecurityImg,
    title: LANG_PREFIX + 'securityInfo',
    webviewObj: {
      url: otherUrlTag.INFO_CYBER_SEC,
    },
  },
  {
    icon: SavingsImg,
    title: LANG_PREFIX + 'savingsInfo',
    webviewObj: {
      url: otherUrlTag.INFO_SAVINGS,
    },
  },
  {
    icon: CreditCardImg,
    title: LANG_PREFIX + 'cardsInfo',
    webviewObj: {
      url: otherUrlTag.INFO_CARD,
    },
  },
  {
    icon: RcbImg,
    title: `${LANG_PREFIX}rcbInfo`,
    webviewObj: {
      url: otherUrlTag.INFO_RCB,
    },
  },
  {
    icon: HouseImg,
    title: LANG_PREFIX + 'homeLoanInfo',
    webviewObj: {
      url: otherUrlTag.INFO_HOME,
    },
  },
  {
    icon: CarImg,
    title: LANG_PREFIX + 'vehicleFinancingInfo',
    webviewObj: {
      url: otherUrlTag.INFO_CAR,
    },
  },
  {
    icon: PromoImg,
    title: LANG_PREFIX + 'promoInfo',
    webviewObj: {
      url: otherUrlTag.INFO_PROMO,
    },
  },
  {
    icon: ShareLinkImg,
    title: `${LANG_PREFIX}shareLinkInfo`,
    webviewObj: {
      url: otherUrlTag.INFO_SHARE_LINK,
    },
  },
];

export const APPLY_LIST = [
  {
    icon: SafeboxIcon,
    title: 'savingsAccount',
    desc: ['savingsAccountDesc1', 'savingsAccountDesc2'],
    path: routes.APPLY_SA_LOADING,
  },
  {
    icon: CardIcon,
    title: 'creditCard',
    desc: ['creditCardDesc1', 'creditCardDesc2'],
    path: routes.OPEN_WEBVIEW,
    webviewObj: {
      url: otherUrlTag.APPLY_CREDIT_CARD,
      backConfirmation: true,
    },
  },
  {
    icon: ApplyCarIcon,
    title: 'vehicleFinancing',
    desc: ['vehicleFinancingDesc1', 'vehicleFinancingDesc2'],
    path: routes.OPEN_WEBVIEW,
    webviewObj: {
      url: otherUrlTag.APPLY_CAR,
      backConfirmation: true,
    },
  },
  {
    icon: HouseIcon,
    title: 'homeFinancing',
    desc: ['homeFinancingDesc1', 'homeFinancingDesc2'],
    modalName: 'loanModal',
  },
  {
    icon: SolarIcon,
    title: 'solarFinancing',
    desc: ['solarFinancingDesc1', 'solarFinancingDesc2'],
    path: routes.OPEN_WEBVIEW,
    webviewObj: {
      url: otherUrlTag.APPLY_SOLAR,
      backConfirmation: true,
    },
  },
  {
    icon: CarpetIcon,
    title: 'rcbMembership',
    desc: ['rcbMembershipDesc'],
    path: routes.OPEN_WEBVIEW,
    webviewObj: {
      url: otherUrlTag.APPLY_RCB,
      backConfirmation: true,
    },
  },
  {
    icon: ShareLinkIcon,
    title: 'shareTrading',
    desc: ['shareTradingDesc1', 'shareTradingDesc2'],
    path: routes.OPEN_WEBVIEW,
    webviewObj: {
      url: otherUrlTag.APPLY_SHARE_LINK,
      backConfirmation: true,
    },
  },
  {
    icon: BaePFIcon,
    title: 'pibbPersonalFinancing',
    desc: ['pibbPersonalFinancingDesc1', 'pibbPersonalFinancingDesc2'],
    path: routes.OPEN_WEBVIEW,
    webviewObj: {
      url: otherUrlTag.APPLY_PIBB_PF,
      backConfirmation: true,
    },
  },
];
