import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';

import { showFailure, useAccessControl } from 'utils';
import {
  checkProfileType,
  getExistJourney,
  getHomeQuickLinks,
  getOtherUrlList,
  PROMO_CACHE_TWO_DAYS,
  updateHomeQuickLinks,
  useGetBannerImagesMoreQuery,
} from 'stores';
import { QUICK_LINKS } from '../constant';
import { PROFILE_TYPE, showEAnggpow } from '../../../constant';
import { LABEL_CO2 } from '../../carbonTracker/constant';
import { checkIsUnderHomeQuickLinks, checkVisible } from '../utils';
import { QuickLinkAllComp } from './component';

export const QuickLinkAll = ({ navigation }) => {
  const LANG_PREFIX = 'screens.quickLinksAll.text.';
  const LANG_PREFIX_ICON = 'screens.home.icon.';

  const dispatch = useDispatch();
  const { t } = useTranslation();
  const accessControl = useAccessControl({ navigation });

  const isExistJourney = useSelector(getExistJourney);
  const otherUrlList = useSelector(getOtherUrlList);
  const { homeQuickLinks } = useSelector(getHomeQuickLinks) || {};
  const viewOnly = useSelector(checkProfileType(PROFILE_TYPE.VIEW));

  const [modalVisible, setModalVisible] = useState(false);
  const [modalMsg, setModalMsg] = useState('');
  const [isHomeSectionVisible, setIsHomeSectionVisible] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [tempHomeQuickLinks, setTempHomeQuickLinks] = useState(homeQuickLinks);

  const { data: bannerImgData } = useGetBannerImagesMoreQuery(undefined, {
    refetchOnMountOrArgChange: PROMO_CACHE_TWO_DAYS,
  });

  const findUrlByTag = tag => otherUrlList?.find(item => item.tag === tag)?.url;

  const financialQuickLinksList = [
    ...checkVisible(QUICK_LINKS.E_ANG_POW, showEAnggpow),
    QUICK_LINKS.PAY_BILL,
    QUICK_LINKS.CASH_ADVANCE,
    QUICK_LINKS.PAY_CARD,
    QUICK_LINKS.PAY_LOAN,
    QUICK_LINKS.TOP_UP,
    QUICK_LINKS.SCHEDULE_TRAN,
    QUICK_LINKS.REMITTANCE,
    QUICK_LINKS.KILL_SWITCH,
    QUICK_LINKS.AUTO_DEBIT,
  ];

  const lifeStyleQuickLinksList = [
    QUICK_LINKS.INSURE,
    QUICK_LINKS.WEALTH,
    { ...QUICK_LINKS.CALCULATOR, param: { url: findUrlByTag(QUICK_LINKS.CALCULATOR.urlTag), backConfirmation: true } },
    ...checkVisible(QUICK_LINKS.PB_JOURNEY, isExistJourney),
    QUICK_LINKS.APPOINTMENT,
    QUICK_LINKS.LOYALTY,
    QUICK_LINKS.EXPENSE_TRACKER,
    { ...QUICK_LINKS.CARBON_TRACKER, label: t(LANG_PREFIX_ICON + 'carbonTracker').replace('${CO2symbol}', LABEL_CO2) },
    QUICK_LINKS.BRANCH_LOCATOR,
  ];

  const handleNavigation = (path, params) => {
    const result = accessControl.navigate(path, params);
    if (result?.requireFullAccess) {
      setModalVisible(true);
      if (result?.allowCard) setModalMsg(t(LANG_PREFIX + 'pbeAccessCasaCard'));
      else setModalMsg(t(LANG_PREFIX + 'pbeAccessCasa'));
    }
  };

  const handleHomeQuickLinkHeaderPress = () => {
    setIsHomeSectionVisible(!isHomeSectionVisible);
  };

  const handleEdit = () => {
    setIsEditing(true);
    setIsHomeSectionVisible(true);
  };

  const handleSave = () => {
    setIsEditing(false);
    dispatch(updateHomeQuickLinks(tempHomeQuickLinks));
  };

  const handleCancel = () => {
    setIsEditing(false);
    setTempHomeQuickLinks(homeQuickLinks);
  };

  const handleAddToHomeQuickLinks = item => {
    if (tempHomeQuickLinks.length === 5) return showFailure(t(`${LANG_PREFIX}addFailure`));
    setTempHomeQuickLinks([...tempHomeQuickLinks, item]);
  };

  const handleRemoveFromHomeQuickLinks = key => {
    if (tempHomeQuickLinks.length === 2) return showFailure(t(`${LANG_PREFIX}removeFailure`));
    setTempHomeQuickLinks(tempHomeQuickLinks.filter(item => item.key !== key));
  };

  const handleQuickLinkPress = quickLink => {
    isEditing && tempHomeQuickLinks.length !== 5
      ? handleAddToHomeQuickLinks(quickLink)
      : handleNavigation(quickLink?.route, quickLink?.param);
  };

  const canAddToHomeQuickLinks = item =>
    isEditing &&
    tempHomeQuickLinks.length !== 5 &&
    !tempHomeQuickLinks.find(i => i.key === item.key) &&
    item.key !== QUICK_LINKS.E_ANG_POW.key;

  const filterSortQuickLinksList = data => {
    const filteredList = checkIsUnderHomeQuickLinks({ homeQuickLinks: tempHomeQuickLinks, data });
    return filteredList.sort((a, b) => t(a.label).localeCompare(t(b.label)));
  };

  const props = {
    t,
    LANG_PREFIX,
    navigation,
    modalVisible,
    modalMsg,
    financialQuickLinksList: filterSortQuickLinksList(financialQuickLinksList),
    lifeStyleQuickLinksList: filterSortQuickLinksList(lifeStyleQuickLinksList),
    tempHomeQuickLinks,
    setTempHomeQuickLinks,
    isHomeSectionVisible,
    isEditing,
    setModalVisible,
    handleNavigation,
    handleHomeQuickLinkHeaderPress,
    handleEdit,
    handleSave,
    handleCancel,
    handleRemoveFromHomeQuickLinks,
    handleQuickLinkPress,
    canAddToHomeQuickLinks,
    isAbleToRemove: isEditing && tempHomeQuickLinks.length !== 2,
    viewOnly,
    bannerImg: bannerImgData?.data?.bannerImg,
  };

  return <QuickLinkAllComp {...props} />;
};
