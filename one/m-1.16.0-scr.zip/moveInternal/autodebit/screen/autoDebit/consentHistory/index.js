import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';

import { callAutoDebitConsentTrxHistory, getConsentTrxHistory, getCurrentConsent } from 'stores';
import { LOADING, SUCCESS } from 'apis';
import { useHandleDispatch } from 'hooks';

import { ConsentHistoryView } from './component';

export const ConsentHistory = () => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitConsentHistory.text.';
  const handleDispatch = useHandleDispatch();
  const { consentId } = useSelector(getCurrentConsent) || {};
  const { list, status: historyStatus, historyNextKey } = useSelector(getConsentTrxHistory) || {};

  useEffect(() => {
    start();
  }, []);

  const start = () => {
    if (historyStatus === LOADING || historyStatus === SUCCESS) return;
    if (list?.length > 0) return;
    loadHistory();
  };

  const loadHistory = () => handleDispatch(callAutoDebitConsentTrxHistory({ consentId, nextKey: historyNextKey }));

  const pastTitle = t(`${LANG_PREFIX}labelPastTransaction`).replace('${length}', list?.length);

  const props = {
    t,
    LANG_PREFIX,
    pastTitle,
    historyStatus,
  };
  return <ConsentHistoryView {...props} />;
};
