import React from 'react';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';

import { Flex, LoadingFull, ScreenFull } from 'atoms';
import { colors } from 'configs';
import { NavBar } from 'organisms';
import { topTabLabel } from 'utils';
import { LOADING } from 'apis';

import { PastHistory } from '../pastHistory';

const TopTab = createMaterialTopTabNavigator();

export const ConsentHistoryView = props => {
  const { t, LANG_PREFIX, pastTitle, historyStatus } = props;

  return (
    <ScreenFull>
      <NavBar back title={t(`${LANG_PREFIX}navTitle`)} />
      <Flex>
        <TopTab.Navigator
          screenOptions={{
            tabBarStyle: { backgroundColor: colors.bg, shadowRadius: 5 },
            tabBarIndicatorStyle: { backgroundColor: colors.primary, height: 2 },
          }}>
          <TopTab.Screen name={'Past'} children={() => <PastHistory />} options={{ ...topTabLabel(pastTitle) }} />
        </TopTab.Navigator>
        {historyStatus === LOADING && <LoadingFull blur />}
      </Flex>
    </ScreenFull>
  );
};
