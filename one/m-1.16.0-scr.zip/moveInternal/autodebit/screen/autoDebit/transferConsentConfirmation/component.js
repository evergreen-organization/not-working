import React from 'react';
import { Image, View, ScrollView } from 'react-native';
import dayjs from 'dayjs';

import { Divider, LinkText, ScreenFull } from 'atoms';
import { ButtonBottom, Text } from 'components';
import { CasaTab, NavBar, Notes } from 'organisms';
import { BottomDrawerModalMini, TableItemButton, TableItemTag, TnCModal } from 'molecules';
import { TranSigner } from 'softToken';
import { ApiDateFormat, displayDateFormat, tranApiType } from 'constant';

import DuitNowAutoDebit from 'assets/images/corporation/duitnowautodebit.png';

import { styles } from './styles';
import { AD_FREQUENCY, AUTO_DEBIT_CONSENT_STATUS } from '../constants';
import { AutoDebitCustomDuplicateTran } from '../components/duplicateTranContent';

export const TransferConsentConfirmationView = props => {
  const {
    t,
    LANG_PREFIX,
    navigation,
    tranSignerRef,
    consent,
    tncUrl,
    tncName,
    toAcc,
    isPDFVisible,
    isFromAccModalVisible,
    submissionLoading,
    handleSubmit,
    handleAccountChange,
    handleOpenFromAccModal,
    handleCloseFromAccModal,
    handleClosePDFModal,
    handleOpenPDFModal,
    handleStartCheckSecfa,
    handleCancelCheckSecfa,
  } = props;

  const { merchantName, consentId, consentDesc, otherDetail, frequency, maxAmnt, effectiveDate, completionDate } =
    consent;

  const noteItems = [
    {
      title: t(`${LANG_PREFIX}noteDesc1`),
    },
    {
      title: t(`${LANG_PREFIX}noteDesc2`),
    },
    {
      title: t(`${LANG_PREFIX}noteDesc3`),
    },
    { title: t(`${LANG_PREFIX}noteDesc4`) },
  ];

  const renderPIDMNote = () => {
    return (
      <Notes
        data={[
          {
            title: t(`${LANG_PREFIX}itemNote`),
            list: noteItems,
          },
        ]}
      />
    );
  };

  const buttonDesc = () => {
    return (
      <View style={styles.tncView}>
        <LinkText
          preLinkText={t(`${LANG_PREFIX}preLinkText`)}
          linkText={t(`${LANG_PREFIX}linkText`)}
          postLinkText={t(`${LANG_PREFIX}postLinkText`)}
          onPress={handleOpenPDFModal}
          style={styles.tnc}
        />
      </View>
    );
  };

  return (
    <>
      <ScreenFull>
        <NavBar
          title={t(`${LANG_PREFIX}navTitle`)}
          back
          showShadow
          bottom={
            <View style={styles.header}>
              <Image source={DuitNowAutoDebit} style={styles.autoDebitIcon} />
              <View style={styles.headerView}>
                <Text bold style={styles.headerTitle}>
                  {merchantName}
                </Text>
                <Text style={styles.headerSubTitle}>{t(`${LANG_PREFIX}labelConsentID`) + consentId}</Text>
              </View>
            </View>
          }
        />
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.table}>
            <Divider />
            <TableItemButton title={t(`${LANG_PREFIX}labelToAccount`)} value={toAcc} onPress={handleOpenFromAccModal} />
            <Divider />
            <TableItemTag title={t(`${LANG_PREFIX}labelRef`)} value={consentDesc} />
            {otherDetail && <TableItemTag title={t(`${LANG_PREFIX}labelOtherDetail`)} value={otherDetail} />}
            <TableItemTag title={t(`${LANG_PREFIX}labelFrequency`)} value={t(AD_FREQUENCY[frequency]?.langCode)} />
            <TableItemTag title={t(`${LANG_PREFIX}labelMaxAmnt`)} value={maxAmnt} currency={'RM'} />
            <TableItemTag
              title={t(`${LANG_PREFIX}labelEffectiveDate`)}
              value={dayjs(effectiveDate, ApiDateFormat).format(displayDateFormat)}
            />
            <TableItemTag
              title={t(`${LANG_PREFIX}labelCompletionDate`)}
              value={dayjs(completionDate, ApiDateFormat).format(displayDateFormat)}
            />
            <TableItemTag
              title={t(`${LANG_PREFIX}labelStatus`)}
              value={t(AUTO_DEBIT_CONSENT_STATUS.PNDG.label)}
              valueFontStyle={{ color: AUTO_DEBIT_CONSENT_STATUS.PNDG.color }}
              isLast
            />
          </View>
          {renderPIDMNote()}
        </ScrollView>

        <View importantForAccessibility='no'>
          <ButtonBottom desc={buttonDesc()} onPress={handleSubmit} loading={submissionLoading}>
            <Text bold style={styles.btnTxt}>
              {t(`${LANG_PREFIX}buttonSubmit`)}
            </Text>
          </ButtonBottom>
        </View>
      </ScreenFull>
      <TranSigner
        ref={tranSignerRef}
        type={tranApiType.DUITNOW_AUTODEBIT_TRANSFER}
        navigation={navigation}
        onStartCheckSecfa={handleStartCheckSecfa}
        onCancel={handleCancelCheckSecfa}
        renderCustomDuplicateContent={trxInfo => <AutoDebitCustomDuplicateTran trxInfo={trxInfo} />}
      />
      <BottomDrawerModalMini
        variant={BottomDrawerModalMini.variants.modalize}
        isVisible={isFromAccModalVisible}
        closeModal={handleCloseFromAccModal}>
        <CasaTab mini onAccountChange={handleAccountChange} />
      </BottomDrawerModalMini>

      <TnCModal url={tncUrl} title={tncName} isVisible={isPDFVisible} onClose={handleClosePDFModal} />
    </>
  );
};
