import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';

import { getConsentInquiry, getSoftToken, getTncByTag, updateConsentInquiryObject } from 'stores';
import { ApiDateFormat, displayDateFormat, tncCategory } from 'constant';
import { showFailure, utc8DateTime } from 'utils';
import { useCasa } from 'hooks';

import { TransferConsentConfirmationView } from './component';

let secfaInfo;

export const TransferConsentConfirmation = ({ navigation }) => {
  useCasa({});
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitTransferConsentConfirmation.text.';
  const tranSignerRef = useRef();
  const today = utc8DateTime().format(displayDateFormat);
  const dispatch = useDispatch();
  const softToken = useSelector(getSoftToken);
  const consent = useSelector(getConsentInquiry) || {};
  const { name: tncName, url: tncUrl } = useSelector(getTncByTag({ tag: tncCategory.DUITNOW_AUTODEBIT })) || {};
  const { consentId, merchantName, consentDesc, toAcc } = consent;

  const [submissionLoading, setSubmissionLoading] = useState(false);
  const [isPDFVisible, setIsPDFVisible] = useState(false);
  const [isFromAccModalVisible, setIsFromAccModalVisible] = useState(false);

  useEffect(() => {
    start();
  }, []);

  const start = () => {
    if (!toAcc && softToken?.preferredAccountActive)
      dispatch(updateConsentInquiryObject({ toAcc: softToken?.preferredAccountNo }));
  };

  const handleSubmit = () => {
    if (!toAcc) return showFailure(t(`${LANG_PREFIX}errorSelectAccNo`));
    setSubmissionLoading(true);
    secfaInfo = {
      tranType: 'DUITNOW_AUTODEBIT_XFER_CONSENT',
      consentId,
      tranDate: dayjs(today, displayDateFormat).format(ApiDateFormat),
      fromAccNo: toAcc,
      merchantName,
      consentDesc,
    };

    let trxInfo = {
      merchantName,
      consentId,
      consentDesc,
    };

    tranSignerRef.current.checkSecfa({
      secfaInfo,
      onSubmitParam: { consentId, accountNo: toAcc },
      onSuccessParam: { secfaInfo },
      trxInfo,
    });
  };

  const handleAccountChange = item => {
    handleCloseFromAccModal();
    dispatch(updateConsentInquiryObject({ toAcc: item?.accountNo }));
  };

  const handleStartCheckSecfa = () => setSubmissionLoading(true);

  const handleCancelCheckSecfa = () => setSubmissionLoading(false);

  const handleOpenPDFModal = () => setIsPDFVisible(true);

  const handleClosePDFModal = () => setIsPDFVisible(false);

  const handleOpenFromAccModal = () => setIsFromAccModalVisible(true);

  const handleCloseFromAccModal = () => setIsFromAccModalVisible(false);

  const props = {
    t,
    LANG_PREFIX,
    navigation,
    tranSignerRef,
    consent,
    tncUrl,
    tncName,
    toAcc,
    isPDFVisible,
    isFromAccModalVisible,
    submissionLoading,
    handleSubmit,
    handleAccountChange,
    handleOpenFromAccModal,
    handleCloseFromAccModal,
    handleClosePDFModal,
    handleOpenPDFModal,
    handleStartCheckSecfa,
    handleCancelCheckSecfa,
  };

  return <TransferConsentConfirmationView {...props} />;
};
