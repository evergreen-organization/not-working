import { StyleSheet } from 'react-native';
import { colors } from 'configs';

export const styles = StyleSheet.create({
  header: {
    marginHorizontal: 20,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  autoDebitIcon: {
    width: 40,
    height: 40,
  },
  headerView: {
    flex: 1,
    marginLeft: 12,
  },
  headerTitle: {
    marginBottom: 5,
  },
  headerSubTitle: {
    fontSize: 14,
    color: colors.medium,
  },
  consentId: {
    fontSize: 14,
    color: colors.medium,
  },
  changeAcc: {
    marginHorizontal: 0,
    borderRadius: 0,
    marginVertical: 10,
  },
  table: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    marginVertical: 10,
  },
  btnTxt: {
    fontSize: 15,
    color: colors.white,
    textAlign: 'center',
  },
  tncView: {
    padding: 10,
    paddingBottom: 0,
  },
  tnc: {
    fontSize: 12,
    textAlign: 'center',
  },
});
