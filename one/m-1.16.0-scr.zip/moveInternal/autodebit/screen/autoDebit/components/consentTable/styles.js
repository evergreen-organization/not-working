import { colors } from 'configs';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  consentContainer: {
    marginHorizontal: 10,
    backgroundColor: colors.white,
    marginBottom: 10,
    borderRadius: 5,
    overflow: 'hidden',
  },
  titleView: {
    paddingVertical: 12,
    paddingHorizontal: 15,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.lightestRed,
  },
  titleRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  title: {
    fontSize: 14,
  },
  viewMoreText: {
    fontSize: 13,
    color: colors.primary,
  },
  requestDate: {
    fontSize: 12,
    marginTop: 5,
    color: colors.grey,
  },
  divider: {
    marginHorizontal: 15,
  },
  rightStyle: {
    alignItems: 'space-between',
    justifyContent: 'flex-end',
  },
  rightInfoText: {
    flex: 1,
    fontSize: 10,
    color: colors.grey,
    flexShrink: 1,
    flexWrap: 'wrap',
    maxWidth: 120,
    textAlign: 'right',
    // textAlign: 'right',
  },
  noInfoView: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: 25,
  },
  emptyIcon: {
    width: 60,
    height: 50,
    tintColor: colors.grey,
  },
  labelNoPending: {
    fontSize: 14,
    color: colors.grey,
    marginTop: 10,
  },
  expiryView: {
    flexDirection: 'row',
    marginTop: 5,
  },
  expiryDate: {
    fontSize: 12,
    color: colors.red,
  },
});
