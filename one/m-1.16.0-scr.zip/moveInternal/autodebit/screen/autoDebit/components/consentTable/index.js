import React from 'react';
import { Image, TouchableOpacity, View } from 'react-native';
import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';

import { Text } from 'components';
import { Divider } from 'atoms';
import { ApiDateFormat, displayDateFormat, displayDatetimeFormat } from 'constant';
import { colors } from 'configs';

import EmptyIcon from '../../../../assets/images/icon/empty.png';

import { styles } from './styles';
import { ConsentItem } from '../consentItem';
import { AUTO_DEBIT_CONSENT_STATUS, AUTO_DEBIT_TYPE } from '../../constants';
import { checkIfListValid, sortByConsentStatus } from '../../utils';

const LANG_PREFIX = 'screens.autoDebit.text.';

export const ConsentTable = ({ title, list, type, onPress, onViewMore, titleBgColor = colors.lightestRed }) => {
  const { t } = useTranslation();
  const sortedList = sortByConsentStatus({ list, type }).slice(0, 2);
  const hasData = checkIfListValid(sortedList);

  return (
    <View style={styles.consentContainer}>
      <View style={{ ...styles.titleView, backgroundColor: titleBgColor }}>
        <View style={styles.titleRow}>
          <Text bold style={styles.title}>
            {title}
          </Text>
        </View>
        {hasData && (
          <TouchableOpacity onPress={onViewMore}>
            <Text style={styles.viewMoreText}>{t(`${LANG_PREFIX}viewMore`)}</Text>
          </TouchableOpacity>
        )}
      </View>
      {hasData ? (
        <>
          {sortedList?.map((item, index) => (
            <View key={index}>
              <ConsentItem
                t={t}
                onPress={() => onPress(item, type)}
                title={item.merchantName}
                subtitle={item.consentDesc}
                consentStatus={item.consentStatus}
                renderLeft={
                  <View>
                    <Text numberOfLines={1} style={styles.requestDate}>
                      {type === AUTO_DEBIT_TYPE.PENDING
                        ? dayjs(item.requestDate, ApiDateFormat).format(displayDatetimeFormat)
                        : dayjs(item.registerDate, ApiDateFormat).format(displayDatetimeFormat)}
                    </Text>
                    {item.reqExpiryDate && item.consentStatus === AUTO_DEBIT_CONSENT_STATUS.PNDG.key && (
                      <>
                        <View style={styles.expiryView}>
                          <Text style={styles.expiryDate}>{t(`${LANG_PREFIX}labelExpiry`)}</Text>
                          <Text numberOfLines={1} style={styles.expiryDate}>
                            {dayjs(item.reqExpiryDate, ApiDateFormat).format(displayDateFormat)}
                          </Text>
                        </View>
                      </>
                    )}
                  </View>
                }
                rightStyle={styles.rightStyle}
                renderRight={
                  <>
                    <Text numberOfLines={2} style={styles.rightInfoText}>
                      {item.duitNowRefNo}
                    </Text>
                  </>
                }
              />
              {sortedList?.length - 1 !== index && <Divider style={styles.divider} />}
            </View>
          ))}
        </>
      ) : (
        <NoInfoFound t={t} />
      )}
    </View>
  );
};

const NoInfoFound = ({ t }) => (
  <View style={styles.noInfoView}>
    <Image source={EmptyIcon} style={styles.emptyIcon} />
    <Text style={styles.labelNoPending}>{t(`${LANG_PREFIX}noRecord`)}</Text>
  </View>
);
