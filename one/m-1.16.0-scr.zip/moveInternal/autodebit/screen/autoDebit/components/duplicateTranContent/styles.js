import { colors } from 'configs';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  duplicateTitle: {
    marginBottom: 15,
    color: colors.medium,
  },
  detailsList: {
    backgroundColor: colors.lightestBg,
    borderRadius: 5,
    paddingHorizontal: 15,
  },
});
