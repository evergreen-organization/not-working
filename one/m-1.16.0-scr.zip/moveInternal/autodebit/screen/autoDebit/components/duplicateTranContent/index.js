import React from 'react';
import { View } from 'react-native';
import { useTranslation } from 'react-i18next';

import { TableItemTag } from 'molecules';
import { Text } from 'components';

import { styles } from './styles';
export const AutoDebitCustomDuplicateTran = ({ trxInfo }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitComponent.text.';
  return (
    <>
      <Text style={styles.duplicateTitle}>{t(`${LANG_PREFIX}labelDuplicate`)}</Text>
      <View style={styles.detailsList}>
        <TableItemTag title={t(`${LANG_PREFIX}labelMerchantName`)} value={trxInfo?.merchantName} />
        <TableItemTag title={t(`${LANG_PREFIX}labelConsentId`)} value={trxInfo?.consentId} />
        <TableItemTag title={t(`${LANG_PREFIX}labelRef`)} value={trxInfo?.consentDesc} />
      </View>
    </>
  );
};
