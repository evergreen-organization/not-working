import React from 'react';
import { TouchableOpacity, View } from 'react-native';

import { Text } from 'components';
import { Chip } from 'atoms';

import { getMerchantInitials } from '../../utils';
import { AUTO_DEBIT_CONSENT_STATUS } from '../../constants';
import { styles } from './styles';
export const ConsentItem = ({
  t,
  title,
  subtitle,
  showMerchantIcon = true,
  renderMoreDetails,
  renderLeft,
  renderRight,
  onPress,
  style,
  rightStyle,
  consentStatus,
}) => {
  return (
    <TouchableOpacity onPress={onPress} disabled={!onPress} style={[styles.container, style]}>
      <View style={styles.containerView}>
        <View style={styles.flex}>
          <View style={styles.section}>
            {/* Icon section */}
            {(!!title || !!subtitle) && showMerchantIcon && (
              <View style={styles.iconSection}>
                <View style={styles.iconView}>
                  <Text bold style={styles.iconText}>
                    {title ? getMerchantInitials(title) : getMerchantInitials(subtitle)}
                  </Text>
                </View>
              </View>
            )}

            {/* Left section */}
            <View style={styles.leftSection}>
              {!!title && <Text bold>{title}</Text>}
              {!!subtitle && <Text style={styles.leftSubtitle}>{subtitle}</Text>}
              {renderLeft}
            </View>

            {/* Right section */}
            <View style={styles.rightSection}>
              <View style={[styles.rightView, rightStyle]}>
                {renderRight}
                <Chip
                  title={t(AUTO_DEBIT_CONSENT_STATUS[consentStatus]?.label)}
                  colorScheme={AUTO_DEBIT_CONSENT_STATUS[consentStatus]?.chip}
                  titleTypography={'P5'}
                  style={styles.chip}
                  fontStyle={styles.chipText}
                />
              </View>
            </View>
          </View>

          {/* optional details after the three sections */}
          {!!renderMoreDetails && <View style={styles.moreDetails}>{renderMoreDetails}</View>}
        </View>
      </View>
    </TouchableOpacity>
  );
};
