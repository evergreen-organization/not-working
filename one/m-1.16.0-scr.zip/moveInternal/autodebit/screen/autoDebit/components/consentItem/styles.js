import { colors } from 'configs';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 15,
    backgroundColor: colors.white,
  },
  containerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    alignItems: 'center',
  },
  flex: {
    flex: 1,
  },
  section: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  iconSection: {
    marginRight: 10,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  iconView: {
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.bg,
    padding: 5,
    minWidth: 26,
    minHeight: 26,
  },
  iconText: {
    color: colors.grey,
    fontSize: 13,
  },
  leftSection: {
    justifyContent: 'space-between',
    flex: 1,
  },
  leftSubtitle: {
    fontSize: 13,
    marginTop: 5,
    color: colors.medium,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    maxWidth: '40%',
  },
  rightView: {
    justifyContent: 'center',
    flexShrink: 1,
    flexWrap: 'wrap',
  },
  chip: {
    marginRight: 0,
    paddingVertical: 2,
    borderRadius: 4,
    alignItems: 'center',
    marginLeft: 10,
    paddingHorizontal: 6,
  },
  chipText: {
    textAlign: 'center',
  },
  moreDetails: {
    paddingHorizontal: 8,
    backgroundColor: colors.lightestBg,
    marginTop: 8,
    borderRadius: 5,
    paddingVertical: 8,
  },
});
