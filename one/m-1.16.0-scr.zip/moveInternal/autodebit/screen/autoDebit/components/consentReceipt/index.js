import React from 'react';
import { View } from 'react-native';
import { CustomScrollView } from 'atoms';
import { DoneButton, Receipt as TranReceipt } from 'components';
import { TableItemTag } from 'molecules';

export const ConsentReceipt = ({
  receiptItems = [
    {
      title: '',
      value: null,
      tag: '',
      tagColor: null,
      isMasked: false,
      currency: '',
      valueFontStyle: null,
    },
  ],
  handleOK,
  type,
  title,
}) => {
  return (
    <>
      <CustomScrollView showsVerticalScrollIndicator={false}>
        <TranReceipt
          type={type}
          animation
          title={title}
          titleStyle={{ fontSize: 15 }}
          desc={
            <>
              <Content receiptItems={receiptItems} />
            </>
          }
        />
      </CustomScrollView>

      <DoneButton onPress={handleOK} />
    </>
  );
};

const Content = ({ receiptItems }) => {
  let arrayItems = receiptItems;
  return (
    <>
      {arrayItems.map((item, index) => {
        return (
          <View key={item.title ?? index}>
            {item.value && (
              <TableItemTag
                title={item.title}
                icon={item.icon}
                value={item.value}
                valueFontStyle={item.valueFontStyle}
                currency={item.currency}
                isLast={index === arrayItems.length - 1 || item.hideDivider}
                tagList={
                  item?.tagList?.map(tag => ({
                    title: tag.title,
                    color: tag.color,
                    style: { marginTop: 3, ...tag.style },
                    fontStyle: { fontSize: 14, ...tag.fontStyle },
                  })) || []
                }
              />
            )}
          </View>
        );
      })}
    </>
  );
};
