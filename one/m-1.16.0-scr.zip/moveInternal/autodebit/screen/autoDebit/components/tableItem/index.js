import React from 'react';
import { Image, View, TouchableOpacity } from 'react-native';
import { useTranslation } from 'react-i18next';
import Clipboard from '@react-native-clipboard/clipboard';

import { showInfo } from 'utils';
import { Money, Text } from 'components';

import CopyIcon from 'assets/images/icon/copy.png';
import { styles } from './styles';

export const TableItem = ({ title, value, isLast = false, component, copyable = false, currency }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitRegisteredConsent.text.';

  const handleCopyText = () => {
    Clipboard.setString(value);
    showInfo(t(`${LANG_PREFIX}labelCopied`));
  };

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>{title}</Text>
        <View style={styles.rightContainer}>
          {copyable && (
            <TouchableOpacity style={styles.copyBtn} onPress={handleCopyText}>
              <Image source={CopyIcon} style={styles.copyIcon} />
            </TouchableOpacity>
          )}
          {component ? (
            component
          ) : currency ? (
            <Money currency={currency} amount={value} size={14} isBold={false} />
          ) : (
            <Text style={{ fontSize: 14, textAlign: 'right' }}>{value}</Text>
          )}
        </View>
      </View>
      <View style={styles.lastView}>{!isLast && <View style={styles.divider} />}</View>
    </View>
  );
};
