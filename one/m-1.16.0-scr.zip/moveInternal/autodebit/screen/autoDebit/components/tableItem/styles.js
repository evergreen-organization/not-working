import { StyleSheet } from 'react-native';
import { colors } from 'configs';

export const styles = StyleSheet.create({
  container: {
    paddingTop: 12,
  },
  title: {
    fontSize: 14,
    color: colors.medium,
    flex: 1,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 23,
  },
  rightContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    marginLeft: 10,
  },
  copyBtn: {
    padding: 8,
    margin: -8,
    marginRight: 0,
  },
  copyIcon: {
    width: 18,
    height: 18,
    tintColor: colors.primary,
  },
  lastView: {
    paddingTop: 12,
  },
  divider: {
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
});
