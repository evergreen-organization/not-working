import React from 'react';

import { Screen } from 'atoms';

import { ConsentReceipt } from '../components';

export const TransferConsentReceiptView = props => {
  const { t, LANG_PREFIX, receiptItems, handleDone } = props;

  return (
    <Screen singlePage>
      <ConsentReceipt receiptItems={receiptItems} title={t(`${LANG_PREFIX}title`)} handleOK={handleDone} />
    </Screen>
  );
};
