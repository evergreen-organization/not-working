import React from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import dayjs from 'dayjs';

import { tagColors } from 'configs';
import routes from 'navigations/routes';
import { getCasa, getConsentInquiry, getSoftToken, resetConsentListStatus } from 'stores';
import { ApiDateFormat, ApiDateTimeFormat, displayDateFormat, ReceiptDateTimeFormat } from 'constant';

import AutoDebit from 'assets/images/corporation/duitnowautodebit.png';

import { TransferConsentReceiptView } from './component';
import { AD_FREQUENCY, AUTO_DEBIT_CONSENT_STATUS } from '../constants';

export const TransferConsentReceipt = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitTransferConsentReceipt.text.';
  const { secfaInfo } = route.params || {};
  const dispatch = useDispatch();

  const consent = useSelector(getConsentInquiry) || {};
  const casa = useSelector(getCasa);
  const { preferredAccountNo, prefferedAccountName } = useSelector(getSoftToken) || {};

  const accInfo =
    preferredAccountNo === secfaInfo?.fromAccNo
      ? { accountDesc: prefferedAccountName }
      : casa.accounts.find(item => item.accountNo === secfaInfo?.fromAccNo);
  const {
    refNo,
    duitNowRefNo,
    productId,
    consentId,
    tranDateTime,
    merchantName,
    consentDesc,
    frequency,
    maxAmnt,
    effectiveDate,
    completionDate,
    consentStatus,
    otherDetail,
  } = consent;

  const receiptItems = [
    { title: t(`${LANG_PREFIX}itemRefNo`), value: refNo },
    { title: t(`${LANG_PREFIX}itemDuitNowRefNo`), value: duitNowRefNo },
    { title: t(`${LANG_PREFIX}itemProductID`), value: productId },
    { title: t(`${LANG_PREFIX}itemConsentID`), value: consentId },
    {
      title: t(`${LANG_PREFIX}itemDateTime`),
      value: dayjs(tranDateTime, ApiDateTimeFormat).format(ReceiptDateTimeFormat),
    },
    { title: t(`${LANG_PREFIX}itemMerchantName`), value: merchantName },
    { title: t(`${LANG_PREFIX}itemReference`), value: consentDesc },
    { title: t(`${LANG_PREFIX}itemOtherDetail`), value: otherDetail },
    { title: t(`${LANG_PREFIX}itemPaymentMethod`), value: 'AutoDebit', icon: AutoDebit },
    { title: t(`${LANG_PREFIX}itemFrequency`), value: t(AD_FREQUENCY[frequency]?.langCode) },
    { title: t(`${LANG_PREFIX}itemMaxAmnt`), value: maxAmnt, currency: 'RM' },
    {
      title: t(`${LANG_PREFIX}itemEffectiveDate`),
      value: dayjs(effectiveDate, ApiDateFormat).format(displayDateFormat),
    },
    {
      title: t(`${LANG_PREFIX}itemCompletionDate`),
      value: dayjs(completionDate, ApiDateFormat).format(displayDateFormat),
    },
    {
      title: t(`${LANG_PREFIX}itemAccNo`),
      value: accInfo?.accountDesc,
      tagList: [{ title: secfaInfo?.fromAccNo, color: tagColors.red }],
    },
    {
      title: t(`${LANG_PREFIX}itemStatus`),
      value: t(AUTO_DEBIT_CONSENT_STATUS[consentStatus]?.label),
      valueFontStyle: { color: AUTO_DEBIT_CONSENT_STATUS[consentStatus]?.color },
    },
  ];

  const handleDone = () => {
    dispatch(resetConsentListStatus());
    navigation.navigate(routes.MAIN_TAB);
  };

  const props = { t, LANG_PREFIX, receiptItems, handleDone };

  return <TransferConsentReceiptView {...props} />;
};
