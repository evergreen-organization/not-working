import { StyleSheet } from 'react-native';
import { colors } from 'configs';
import { FONT_FAMILY_REGULAR } from 'styles/fonts';

export const styles = StyleSheet.create({
  headerContainer: {
    margin: 10,
    marginTop: 0,
    padding: 20,
    borderRadius: 5,
    //backgroundColor: colors.mediumGreen,
  },
  headerView: {
    alignItems: 'center',
  },
  headerSubtitle: {
    fontSize: 13,
    color: colors.lightestBg,
    textAlign: 'center',
  },
  headerTitle: {
    fontSize: 20,
    color: colors.white,
  },
  bodyContainer: {
    marginHorizontal: 10,
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    marginBottom: 10,
    borderRadius: 5,
  },
  bodyView: {
    lexDirection: 'row',
    alignItems: 'flex-start',
  },
  bodyTitle: {
    flex: 1,
    paddingVertical: 15,
    paddingBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  bodyTitleText: {
    fontSize: 12,
    color: colors.medium,
  },
  subBodyContainer: {
    backgroundColor: colors.white,
    marginHorizontal: 10,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  subBodyView1: {
    paddingHorizontal: 10,
    paddingVertical: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: colors.lightestBg,
    borderRadius: 5,
    marginHorizontal: -10,
    marginBottom: 10,
  },
  amntText: {
    color: colors.medium,
    marginBottom: 10,
    fontSize: 13,
  },
  freqView: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  freq: {
    marginRight: 0,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  subBodyView2: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: -10,
    flex: 1,
  },
  dateView: {
    paddingHorizontal: 10,
    paddingVertical: 15,
    backgroundColor: colors.lightestBg,
    borderRadius: 5,
    flex: 1,
  },
  dateText: {
    color: colors.medium,
    marginBottom: 10,
    fontSize: 13,
  },
  pickerTitle: {
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 5,
  },
  pickerTitleText: {
    color: colors.medium,
    fontFamily: FONT_FAMILY_REGULAR,
    fontSize: 13,
  },
  pickerItem: {
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  pickerItemText: {
    fontSize: 14,
  },
  blackText: {
    color: colors.black,
  },
  whiteText: {
    color: colors.white,
  },
  primaryBackground: {
    backgroundColor: colors.primary,
  },
  whiteBackground: {
    backgroundColor: colors.white,
  },
  warningTitle: {
    marginBottom: 10,
    fontSize: 15,
  },
  warningDesc: {
    color: colors.medium,
  },
});
