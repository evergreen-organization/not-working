import React from 'react';
import { ScrollView, TouchableOpacity, View } from 'react-native';
import dayjs from 'dayjs';

import { ApiDateFormat, displayDateFormat, tranApiType } from 'constant';
import { Divider, LoadingFull, ScreenFull } from 'atoms';
import { Money, Tag, Text } from 'components';
import { CasaTab, NavBar } from 'organisms';
import { TranSigner } from 'softToken';
import { ActionModal, BottomDrawerModalMini, TableItemButton } from 'molecules';
import { OthersQuickLinkSection } from 'screens/accounts/components';

import HistoryIcon from 'assets/images/basiccolor/history.png';
import BinIcon from 'assets/images/basiccolor/bin.png';

import { TableItem } from '../components';
import { styles } from './styles';
import { AD_FREQUENCY, AUTO_DEBIT_CONSENT_STATUS } from '../constants';
import { checkConsentIsActive, checkConsentIsInActive } from '../utils';

export const ConsentDetailsView = props => {
  const {
    t,
    LANG_PREFIX,
    consentDetails,
    pickerValue,
    isFromAccModalVisible,
    isChangeStatusModalVisible,
    isWarningModalVisible,
    submissionLoading,
    showHistory,
    terminateConsent,
    tranSignerRef,
    navigation,
    handleStartCheckSecfa,
    handleCancelCheckSecfa,
    handleProceedChangeStatus,
    handleCancelChangeStatus,
    handleStatusChange,
    handleAccountChange,
    handleOpenFromAccModal,
    handleCloseFromAccModal,
    handleOpenChangeStatusModal,
    handleCloseChangeStatusModal,
  } = props;

  const {
    consentId,
    productId,
    merchantName,
    consentDesc,
    effectiveDate,
    completionDate,
    frequency,
    maxAmnt,
    consentStatus,
    duitNowRefNo,
    refNo,
    otherDetail,
    editable,
    fromAccNo,
  } = consentDetails;

  const isActive = checkConsentIsActive(consentStatus);
  const isInactive = checkConsentIsInActive(consentStatus);

  const statusData = [
    { title: t(`${LANG_PREFIX}labelActive`), value: true },
    { title: t(`${LANG_PREFIX}labelInactive`), value: false },
  ];

  const quickLinkList = [
    {
      label: t(`${LANG_PREFIX}labelHistory`),
      icon: HistoryIcon,
      action: showHistory,
    },
    ...(isActive || isInactive
      ? [
          {
            label: t(`${LANG_PREFIX}labelTerminate`),
            icon: BinIcon,
            action: terminateConsent,
          },
        ]
      : []),
  ];

  const renderWarningContent = () => {
    return (
      <View>
        <Text bold style={styles.warningTitle}>
          {t(`${LANG_PREFIX}updateStatusTitle`)}
        </Text>
        <Text style={styles.warningDesc}>
          {pickerValue ? t(`${LANG_PREFIX}updateStatusDesc1`) : t(`${LANG_PREFIX}updateStatusDesc2`)}
        </Text>
      </View>
    );
  };

  return (
    <>
      <ScreenFull>
        <NavBar back title={t(`${LANG_PREFIX}navTitle`)} />
        <ScrollView showsVerticalScrollIndicator={false}>
          {/** Header container */}
          <View
            style={{
              ...styles.headerContainer,
              backgroundColor: AUTO_DEBIT_CONSENT_STATUS[consentStatus]?.color,
            }}>
            <View style={styles.headerView}>
              <Text bold style={styles.headerTitle}>
                {merchantName}
              </Text>
              <Text style={styles.headerSubtitle}>{consentDesc}</Text>
            </View>
          </View>

          {/** Consent Details body */}
          <View style={styles.bodyContainer}>
            <View style={styles.bodyView}>
              <View style={styles.bodyTitle}>
                <Text style={styles.bodyTitleText}>{t(`${LANG_PREFIX}labelConsentDetails`)}</Text>
              </View>
            </View>

            {(isActive || isInactive) && editable ? (
              <>
                <TableItemButton
                  title={t(`${LANG_PREFIX}itemStatus`)}
                  value={t(AUTO_DEBIT_CONSENT_STATUS[consentStatus]?.label)}
                  valueFontStyle={{ color: AUTO_DEBIT_CONSENT_STATUS[consentStatus]?.color }}
                  onPress={handleOpenChangeStatusModal}
                />
                <Divider />
              </>
            ) : (
              <TableItem
                title={t(`${LANG_PREFIX}itemStatus`)}
                value={t(AUTO_DEBIT_CONSENT_STATUS[consentStatus]?.label)}
                valueStyle={{ color: AUTO_DEBIT_CONSENT_STATUS[consentStatus]?.color }}
              />
            )}

            {isActive && editable ? (
              <>
                <TableItemButton
                  title={t(`${LANG_PREFIX}itemFromAccount`)}
                  value={fromAccNo}
                  onPress={handleOpenFromAccModal}
                />
                <Divider />
              </>
            ) : (
              <>
                <TableItem title={t(`${LANG_PREFIX}itemFromAccount`)} value={fromAccNo} />
              </>
            )}

            <TableItem title={t(`${LANG_PREFIX}itemRefNo`)} value={refNo} />
            <TableItem title={t(`${LANG_PREFIX}itemDuitNowRefNo`)} value={duitNowRefNo} copyable />
            <TableItem
              title={t(`${LANG_PREFIX}itemConsentID`)}
              value={consentId}
              copyable
              isLast={!otherDetail && !productId}
            />
            {productId && (
              <TableItem title={t(`${LANG_PREFIX}itemProductID`)} value={productId} isLast={!otherDetail} />
            )}
            {otherDetail && <TableItem title={t(`${LANG_PREFIX}itemOtherDetails`)} value={otherDetail} isLast={true} />}
          </View>

          {/** Consent More Details body */}
          <View style={styles.subBodyContainer}>
            <View style={styles.subBodyView1}>
              <View>
                <Text style={styles.amntText}>{t(`${LANG_PREFIX}itemMaxAmnt`)}</Text>
                <Money currency={'RM'} amount={maxAmnt} size={20} isBold={true} isCurrencyBold={true} />
              </View>

              <View style={styles.freqView}>
                <Tag title={t(AD_FREQUENCY[frequency]?.langCode)} style={styles.freq} />
              </View>
            </View>

            <View style={styles.subBodyView2}>
              <View style={{ ...styles.dateView, marginRight: 10 }}>
                <View>
                  <Text style={styles.dateText}>{t(`${LANG_PREFIX}itemEffectiveDate`)}</Text>
                  <Text>{effectiveDate ? dayjs(effectiveDate, ApiDateFormat).format(displayDateFormat) : '-'}</Text>
                </View>
              </View>

              <View style={styles.dateView}>
                <View>
                  <Text style={styles.dateText}>{t(`${LANG_PREFIX}itemCompletionDate`)}</Text>
                  <Text>{completionDate ? dayjs(completionDate, ApiDateFormat).format(displayDateFormat) : '-'}</Text>
                </View>
              </View>
            </View>
          </View>
          <OthersQuickLinkSection quickLinksList={quickLinkList} />
          {submissionLoading && <LoadingFull blur />}
        </ScrollView>
      </ScreenFull>

      {/** Change from account modal */}
      <BottomDrawerModalMini
        variant={BottomDrawerModalMini.variants.modalize}
        isVisible={isFromAccModalVisible}
        closeModal={handleCloseFromAccModal}>
        <CasaTab mini fromAcc={consentDetails.fromAcc} onAccountChange={handleAccountChange} />
      </BottomDrawerModalMini>

      {/** Change from consent status modal */}
      <BottomDrawerModalMini
        variant={BottomDrawerModalMini.variants.modalize}
        isVisible={isChangeStatusModalVisible}
        closeModal={handleCloseChangeStatusModal}>
        <>
          <View style={styles.pickerTitle}>
            <Text style={styles.pickerTitleText}>{t(`${LANG_PREFIX}itemStatus`)}</Text>
          </View>
          <ScrollView>
            {statusData?.map(({ title, value }) => (
              <TouchableOpacity
                key={value}
                onPress={() => handleStatusChange(value)}
                style={{
                  ...styles.pickerItem,
                  ...(value === pickerValue ? styles.primaryBackground : styles.whiteBackground),
                }}>
                <Text
                  style={{
                    ...styles.pickerItemText,
                    ...(value === pickerValue ? styles.whiteText : styles.blackText),
                  }}>
                  {title}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </>
      </BottomDrawerModalMini>

      <ActionModal
        variant={ActionModal.variants.modalize}
        isVisible={isWarningModalVisible}
        renderContent={renderWarningContent}
        leftButtonTitle={t(`${LANG_PREFIX}buttonCancel`)}
        rightButtonTitle={t(`${LANG_PREFIX}buttonProceed`)}
        onAccept={handleProceedChangeStatus}
        onDecline={handleCancelChangeStatus}
      />
      <TranSigner
        ref={tranSignerRef}
        type={tranApiType.DUITNOW_AUTODEBIT_EDIT}
        navigation={navigation}
        onStartCheckSecfa={handleStartCheckSecfa}
        onCancel={handleCancelCheckSecfa}
      />
    </>
  );
};
