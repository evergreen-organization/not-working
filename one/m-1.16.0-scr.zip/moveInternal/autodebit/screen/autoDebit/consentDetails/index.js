import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';

import routes from 'navigations/routes';
import { getActiveFromAccCasa, getCurrentConsent, resetConsentHistory } from 'stores';
import { showFailure } from 'utils';

import { ConsentDetailsView } from './component';
import { AUTO_DEBIT_CONSENT_STATUS } from '../constants';
let secfaInfo = {};

export const ConsentDetails = ({ navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitRegisteredConsent.text.';
  const dispatch = useDispatch();
  const tranSignerRef = useRef();
  const consentDetails = useSelector(getCurrentConsent) || {};
  const { accounts: activeCasa } = useSelector(getActiveFromAccCasa) || {};
  const { consentId, fromAccNo, terminatable, consentStatus } = consentDetails;

  const [isFromAccModalVisible, setIsFromAccModalVisible] = useState(false);
  const [isChangeStatusModalVisible, setIsChangeStatusModalVisible] = useState(false);
  const [isWarningModalVisible, setIsWarningModalVisible] = useState(false);
  const [pickerValue, setPickerValue] = useState(
    consentStatus === (AUTO_DEBIT_CONSENT_STATUS.ACTV.key || AUTO_DEBIT_CONSENT_STATUS.ACTB.key),
  );
  const [newFromAcc, setNewFromAcc] = useState(fromAccNo);
  const [submissionLoading, setSubmissionLoading] = useState(false);

  useEffect(() => {
    return () => dispatch(resetConsentHistory());
  }, []);

  const showHistory = () => {
    navigation.navigate(routes.AUTO_DEBIT_CONSENT_HISTORY);
  };

  const terminateConsent = () => {
    if (!terminatable) return showFailure(t(`${LANG_PREFIX}errorMsgTerminate`));
    navigation.navigate(routes.AUTO_DEBIT_CONSENT_TERMINATION);
  };

  const handleProceedChangeStatus = () => {
    setIsWarningModalVisible(false);
    checkSecfa(newFromAcc);
  };

  const handleAccountChange = ({ accountNo }) => {
    handleCloseFromAccModal();
    if (fromAccNo === accountNo) return;
    setNewFromAcc(accountNo);
    checkSecfa(accountNo);
  };

  const checkSecfa = accountNo => {
    setTimeout(() => {
      setSubmissionLoading(true);

      (secfaInfo = {
        tranType: 'DUITNOW_AUTODEBIT_EDIT_CONSENT',
        consentId,
        fromAccNo: accountNo,
        consentStatus: pickerValue,
      }),
        tranSignerRef.current.checkSecfa({
          secfaInfo,
          onSubmitParam: { consentId, fromAccNo: accountNo, consentStatus: pickerValue },
        });
    }, 300);
  };

  const handleStatusChange = value => {
    handleCloseChangeStatusModal();
    if (value !== pickerValue) {
      setPickerValue(value);

      setTimeout(() => setIsWarningModalVisible(true), 500);
    }
  };

  const handleCancelChangeStatus = () => {
    setIsWarningModalVisible(false);
    setPickerValue(consentDetails.consentStatus);
    navigation.navigate(routes.AUTO_DEBIT);
  };

  const handleStartCheckSecfa = () => setSubmissionLoading(true);

  const handleCancelCheckSecfa = () => setSubmissionLoading(false);

  const handleOpenFromAccModal = () => setIsFromAccModalVisible(true);

  const handleCloseFromAccModal = () => {
    if (activeCasa.length === 0) showFailure(t(`${LANG_PREFIX}errorMsgAccInvalid`));
    setIsFromAccModalVisible(false);
  };

  const handleOpenChangeStatusModal = () => setIsChangeStatusModalVisible(true);

  const handleCloseChangeStatusModal = () => setIsChangeStatusModalVisible(false);

  const props = {
    t,
    LANG_PREFIX,
    consentDetails,
    pickerValue,
    isFromAccModalVisible,
    isChangeStatusModalVisible,
    isWarningModalVisible,
    tranSignerRef,
    navigation,
    submissionLoading,
    terminateConsent,
    showHistory,
    handleStartCheckSecfa,
    handleCancelCheckSecfa,
    handleProceedChangeStatus,
    handleCancelChangeStatus,
    handleStatusChange,
    handleAccountChange,
    handleOpenFromAccModal,
    handleCloseFromAccModal,
    handleOpenChangeStatusModal,
    handleCloseChangeStatusModal,
  };
  return <ConsentDetailsView {...props} />;
};

