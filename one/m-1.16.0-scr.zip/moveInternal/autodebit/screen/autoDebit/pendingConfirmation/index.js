import React, { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';

import routes from 'navigations/routes';
import { getSoftToken, getTncByTag, fromAccUpdated, getCurrentConsent, rejectConsent } from 'stores';
import { showFailure, utc8DateTime } from 'utils';
import { ApiDateFormat, displayDateFormat, tncCategory } from 'constant';
import { useHandleDispatch } from 'hooks';

import { PendingConfirmationView } from './component';
import { checkConsentIsPending, checkFromAccTypeCard } from '../utils';
let secfaInfo = {};
export const PendingConfirmation = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitPendingConfirmation.text.';
  const { isRoutedFromDnReq } = route?.params || {};
  const today = utc8DateTime().format(displayDateFormat);
  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();

  const consent = useSelector(getCurrentConsent) || {};
  const { preferredAccountNo, preferredAccountActive } = useSelector(getSoftToken) || {};
  const { name: tncName, url: tncUrl } = useSelector(getTncByTag({ tag: tncCategory.DUITNOW_AUTODEBIT })) || {};

  const [isApprovalModalVisible, setIsApprovalModalVisible] = useState(false);
  const [isRejectModalVisible, setIsRejectModalVisible] = useState(false);
  const [isPDFVisible, setIsPDFVisible] = useState(false);
  const [isFromAccModalVisible, setIsFromAccModalVisible] = useState(false);
  const [submissionLoading, setSubmissionLoading] = useState(false);
  const {
    consentId,
    productId,
    merchantName,
    consentDesc,
    effectiveDate,
    completionDate,
    reqExpiryDate,
    frequency,
    maxAmnt,
    consentStatus,
    fromAccNoType,
    fromAccNo,
    otherDetail,
  } = consent;

  const isCreditCard = checkFromAccTypeCard(fromAccNoType);
  const isPending = checkConsentIsPending(consentStatus);
  const tranSignerRef = useRef();

  useEffect(() => {
    start();
  }, []);

  const start = () => {
    if (isCreditCard) {
      if (preferredAccountActive) {
        dispatch(fromAccUpdated(preferredAccountNo));
      } else {
        dispatch(fromAccUpdated(null));
      }
    }
  };

  const handleStartCheckSecfa = () => setSubmissionLoading(true);

  const handleCancelCheckSecfa = () => setSubmissionLoading(false);

  const isApprovingRef = useRef(false);

  const handleApproveConsent = () => {
    isApprovingRef.current = true;
    closeApprovalModal();
    setSubmissionLoading(true);

    secfaInfo = {
      tranType: 'DUITNOW_AUTODEBIT_APPR_CONSENT',
      consentId: consentId,
      tranDate: dayjs(today, displayDateFormat).format(ApiDateFormat),
      fromAccNo,
    };
  };

  const handleApprovalModalHide = () => {
    if (!isApprovingRef.current) return;
    isApprovingRef.current = false;

    let trxInfo = {
      merchantName,
      consentId,
      consentDesc,
    };

    tranSignerRef.current.checkSecfa({
      secfaInfo,
      onSubmitParam: { consentId, fromAccNo },
      onSuccessParam: { secfaInfo },
      trxInfo,
    });
  };

  const handleRejectConsent = async () => {
    closeRejectModal();
    setSubmissionLoading(true);
    const result = await handleDispatch(rejectConsent({ consentId }));
    if (result?.problem) showFailure(result.problem);
    navigation.navigate(routes.AUTO_DEBIT);
  };

  const handleAccountChange = item => {
    dispatch(fromAccUpdated(item.accountNo));
    closeFromAccModal();
  };

  const openApprovalModal = () => setIsApprovalModalVisible(true);

  const closeApprovalModal = () => setIsApprovalModalVisible(false);

  const openRejectModal = () => setIsRejectModalVisible(true);

  const closeRejectModal = () => setIsRejectModalVisible(false);

  const openPDFModal = () => setIsPDFVisible(true);

  const closePDFModal = () => setIsPDFVisible(false);

  const openFromAccModal = () => setIsFromAccModalVisible(true);

  const closeFromAccModal = () => setIsFromAccModalVisible(false);

  const props = {
    t,
    LANG_PREFIX,
    consentId,
    productId,
    merchantName,
    consentDesc,
    effectiveDate,
    completionDate,
    reqExpiryDate,
    frequency,
    maxAmnt,
    fromAccNo,
    otherDetail,
    isPending,
    isRoutedFromDnReq,
    tncUrl,
    tncName,
    tranSignerRef,
    navigation,
    submissionLoading,
    isPDFVisible,
    isFromAccModalVisible,
    isApprovalModalVisible,
    isRejectModalVisible,
    handleApproveConsent,
    handleRejectConsent,
    handleAccountChange,
    handleStartCheckSecfa,
    handleCancelCheckSecfa,
    closeApprovalModal,
    openApprovalModal,
    openRejectModal,
    closeRejectModal,
    closePDFModal,
    openPDFModal,
    openFromAccModal,
    closeFromAccModal,
    handleApprovalModalHide,
  };
  return <PendingConfirmationView {...props} />;
};
