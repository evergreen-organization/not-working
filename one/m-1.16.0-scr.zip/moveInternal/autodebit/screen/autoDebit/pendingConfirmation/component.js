import React from 'react';
import dayjs from 'dayjs';
import { View, Image, ScrollView } from 'react-native';

import { AvoidKeyboard, BottomView, Divider, LinkText, ScreenFull } from 'atoms';
import { CasaTab, NavBar, Notes } from 'organisms';
import { ActionModal, BottomDrawerModalMini, TableItemButton, TableItemTag, TnCModal } from 'molecules';
import { Text, Button, ButtonBottom } from 'components';
import { ApiDateFormat, displayDateFormat, tranApiType } from 'constant';
import { TranSigner } from 'softToken';
import { colors } from 'configs';

import AutoDebit from 'assets/images/corporation/duitnowautodebit.png';

import { styles } from './styles';
import { AD_FREQUENCY } from '../constants';
import { AutoDebitCustomDuplicateTran } from '../components/duplicateTranContent';

export const PendingConfirmationView = props => {
  const {
    t,
    LANG_PREFIX,
    consentId,
    productId,
    merchantName,
    consentDesc,
    effectiveDate,
    completionDate,
    reqExpiryDate,
    frequency,
    maxAmnt,
    fromAccNo,
    otherDetail,
    isPending,
    isRoutedFromDnReq,
    tncUrl,
    tncName,
    tranSignerRef,
    navigation,
    submissionLoading,
    isApprovalModalVisible,
    isRejectModalVisible,
    isPDFVisible,
    isFromAccModalVisible,
    handleApproveConsent,
    handleRejectConsent,
    handleAccountChange,
    handleStartCheckSecfa,
    handleCancelCheckSecfa,
    closeApprovalModal,
    openApprovalModal,
    openRejectModal,
    closeRejectModal,
    closePDFModal,
    openPDFModal,
    openFromAccModal,
    closeFromAccModal,
    handleApprovalModalHide,
  } = props;

  const infoList = [
    { title: t(`${LANG_PREFIX}itemMerchantName`), value: merchantName },
    { title: t(`${LANG_PREFIX}itemReference`), value: consentDesc },
    { title: t(`${LANG_PREFIX}itemFrequency`), value: t(AD_FREQUENCY[frequency]?.langCode) },
    { title: t(`${LANG_PREFIX}itemMaxAmnt`), value: maxAmnt, currency: 'RM' },
    {
      title: t(`${LANG_PREFIX}itemEffectiveDate`),
      value: dayjs(effectiveDate, ApiDateFormat).format(displayDateFormat),
    },
    {
      title: t(`${LANG_PREFIX}itemCompletionDate`),
      value: dayjs(completionDate, ApiDateFormat).format(displayDateFormat),
    },
  ];

  const noteItems = [
    {
      title: t(`${LANG_PREFIX}noteDesc1`),
    },
    {
      title: t(`${LANG_PREFIX}noteDesc2`),
    },
    {
      title: t(`${LANG_PREFIX}noteDesc3`),
    },
    { title: t(`${LANG_PREFIX}noteDesc4`) },
  ];

  const renderPIDMNote = () => {
    return (
      <Notes
        data={[
          {
            title: t(`${LANG_PREFIX}itemNote`),
            list: noteItems,
          },
        ]}
      />
    );
  };

  const renderApprovalWarning = () => {
    return (
      <View>
        <Text bold style={styles.approvalTitle}>
          {t(`${LANG_PREFIX}approvalTitle`)}
        </Text>
        <Text bold>{t(`${LANG_PREFIX}approvalDesc1`)}</Text>
        <View style={styles.detailsList}>
          {infoList?.map((item, index) => (
            <TableItemTag
              key={index}
              title={item.title}
              value={item.value}
              currency={item?.currency}
              isLast={index === infoList.length - 1}
            />
          ))}
        </View>
        <Text>{t(`${LANG_PREFIX}approvalDesc2`)}</Text>
      </View>
    );
  };

  const renderRejectWarning = () => {
    return (
      <View>
        <Text bold style={styles.rejectTitle}>
          {t(`${LANG_PREFIX}rejectTitle`)}
        </Text>
        <Text style={styles.rejectText}>{t(`${LANG_PREFIX}rejectDesc`)}</Text>
      </View>
    );
  };

  const buttonDesc = () => {
    return (
      <View style={[styles.linkTextView, { ...(isRoutedFromDnReq && { paddingBottom: 0 }) }]}>
        <LinkText
          preLinkText={t(`${LANG_PREFIX}preLinkText`)}
          linkText={t(`${LANG_PREFIX}linkText`)}
          postLinkText={t(`${LANG_PREFIX}postLinkText`)}
          onPress={openPDFModal}
          style={styles.linkText}
        />
      </View>
    );
  };

  return (
    <>
      <ScreenFull>
        <NavBar
          title={isPending ? t(`${LANG_PREFIX}titleConfirmation`) : t(`${LANG_PREFIX}titleDetails`)}
          back
          showShadow
          bottom={
            <View style={styles.header}>
              <Image source={AutoDebit} style={styles.icon} />
              <View style={styles.headerView}>
                <Text bold style={styles.headerTitle}>
                  {merchantName}
                </Text>
                {productId && <Text style={styles.headerSubTitle}>{t(`${LANG_PREFIX}itemProductID`) + productId}</Text>}
                <Text style={styles.headerSubTitle}>{t(`${LANG_PREFIX}itemConsentID`) + consentId}</Text>
              </View>
            </View>
          }
        />
        <AvoidKeyboard>
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={styles.form}>
              {isPending ? (
                <>
                  <TableItemButton
                    title={t(`${LANG_PREFIX}itemFromAccount`)}
                    value={fromAccNo}
                    onPress={openFromAccModal}
                  />
                  <Divider />
                </>
              ) : (
                <TableItemTag title={t(`${LANG_PREFIX}itemFromAccount`)} value={fromAccNo} />
              )}
              <TableItemTag title={t(`${LANG_PREFIX}itemReference`)} value={consentDesc} />
              {otherDetail && <TableItemTag title={t(`${LANG_PREFIX}itemOtherDetails`)} value={otherDetail} />}

              <TableItemTag title={t(`${LANG_PREFIX}itemFrequency`)} value={t(AD_FREQUENCY[frequency]?.langCode)} />
              <TableItemTag title={t(`${LANG_PREFIX}itemMaxAmnt`)} value={maxAmnt} currency={'RM'} />
              <TableItemTag
                title={t(`${LANG_PREFIX}itemEffectiveDate`)}
                value={dayjs(effectiveDate, ApiDateFormat).format(displayDateFormat)}
              />
              <TableItemTag
                title={t(`${LANG_PREFIX}itemCompletionDate`)}
                value={dayjs(completionDate, ApiDateFormat).format(displayDateFormat)}
                isLast={isRoutedFromDnReq}
              />
              {!isRoutedFromDnReq && (
                <TableItemTag
                  title={t(`${LANG_PREFIX}itemExpiryDate`)}
                  value={dayjs(reqExpiryDate, ApiDateFormat).format(displayDateFormat)}
                  isLast
                />
              )}
            </View>
            {renderPIDMNote()}
          </ScrollView>
          {isPending && !isRoutedFromDnReq && (
            <>
              <View style={styles.buttonView}>
                <Divider />
                {buttonDesc()}
              </View>
              <BottomView>
                <View style={styles.btnContainer}>
                  <Button
                    title={t(`${LANG_PREFIX}buttonReject`)}
                    fontStyle={styles.btn1Text}
                    onPress={openRejectModal}
                    disabled={submissionLoading}
                  />
                  <Button
                    title={t(`${LANG_PREFIX}buttonApprove`)}
                    fontStyle={styles.btn2Text}
                    style={[styles.btn2, submissionLoading && { backgroundColor: colors.lightgrey }]}
                    onPress={openApprovalModal}
                    disabled={submissionLoading}
                  />
                </View>
              </BottomView>
            </>
          )}
          {isRoutedFromDnReq && (
            <View importantForAccessibility='no'>
              <ButtonBottom desc={buttonDesc()} onPress={openApprovalModal} loading={submissionLoading}>
                <Text bold style={styles.btn2Text}>
                  {t(`${LANG_PREFIX}buttonApprove`)}
                </Text>
              </ButtonBottom>
            </View>
          )}
        </AvoidKeyboard>
      </ScreenFull>
      <BottomDrawerModalMini
        variant={BottomDrawerModalMini.variants.modalize}
        isVisible={isFromAccModalVisible}
        closeModal={closeFromAccModal}>
        <CasaTab mini fromAcc={fromAccNo} onAccountChange={handleAccountChange} />
      </BottomDrawerModalMini>
      <ActionModal
        variant={ActionModal.variants.modalize}
        isVisible={isApprovalModalVisible}
        renderContent={renderApprovalWarning}
        leftButtonTitle={t(`${LANG_PREFIX}buttonCancel`)}
        rightButtonTitle={t(`${LANG_PREFIX}buttonProceed`)}
        onDecline={closeApprovalModal}
        onAccept={handleApproveConsent}
        onModalHide={handleApprovalModalHide}
      />
      <ActionModal
        variant={ActionModal.variants.modalize}
        isVisible={isRejectModalVisible}
        renderContent={renderRejectWarning}
        leftButtonTitle={t(`${LANG_PREFIX}buttonCancel`)}
        rightButtonTitle={t(`${LANG_PREFIX}buttonConfirm`)}
        onAccept={handleRejectConsent}
        onDecline={closeRejectModal}
      />
      <TnCModal url={tncUrl} title={tncName} isVisible={isPDFVisible} onClose={closePDFModal} />
      <TranSigner
        ref={tranSignerRef}
        type={tranApiType.DUITNOW_AUTODEBIT_APPROVE}
        navigation={navigation}
        onStartCheckSecfa={handleStartCheckSecfa}
        onCancel={handleCancelCheckSecfa}
        renderCustomDuplicateContent={trxInfo => <AutoDebitCustomDuplicateTran trxInfo={trxInfo} />}
      />
    </>
  );
};
