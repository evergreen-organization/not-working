import { StyleSheet } from 'react-native';
import { colors } from 'configs';

export const styles = StyleSheet.create({
  header: {
    marginHorizontal: 20,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    width: 40,
    height: 40,
  },
  headerView: {
    flex: 1,
    marginLeft: 12,
  },
  headerTitle: {
    marginBottom: 5,
  },
  headerSubTitle: {
    fontSize: 14,
    color: colors.medium,
  },
  buttonView: {
    backgroundColor: colors.white,
    shadowColor: colors.black,
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 5,
  },
  linkTextView: {
    backgroundColor: colors.white,
    padding: 10,
  },
  linkText: {
    fontSize: 12,
    textAlign: 'center',
  },
  btnContainer: {
    flexDirection: 'row',
  },
  btn2: {
    backgroundColor: colors.primary,
    borderBottomLeftRadius: 3,
  },
  btn1Text: {
    fontSize: 15,
    color: colors.primary,
  },
  btn2Text: {
    fontSize: 15,
    color: colors.white,
  },
  form: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    marginVertical: 10,
  },
  approvalTitle: {
    fontSize: 16,
    color: colors.primary,
    marginBottom: 20,
  },
  detailsList: {
    backgroundColor: colors.lightestBg,
    borderRadius: 5,
    marginVertical: 20,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rejectTitle: {
    marginBottom: 10,
    fontSize: 15,
  },
  rejectText: {
    color: colors.medium,
  },
});
