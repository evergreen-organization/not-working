import { colors } from 'configs';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    marginTop: 0,
    marginHorizontal: 10,
    marginVertical: 8,
    paddingHorizontal: 20,
    backgroundColor: colors.white,
    borderRadius: 5,
  },
  btn: {
    paddingVertical: 12,
  },
  row: {
    alignItems: 'center',
    flexDirection: 'row',
    minHeight: 28,
  },
  remarks: {
    fontSize: 14,
    color: colors.medium,
    marginTop: 3,
  },
  tag: {
    marginHorizontal: 10,
  },
  info: {
    backgroundColor: colors.white,
    marginTop: 10,
  },
  infoText: {
    color: colors.primary,
  },
  error: {
    backgroundColor: colors.white,
    alignItems: 'center',
    marginTop: 10,
  },
  flex: {
    backgroundColor: colors.bg,
  },
});
