import React, { useMemo } from 'react';
import { FlatList, View } from 'react-native';
import dayjs from 'dayjs';

import { FAIL, LOADING } from 'apis';
import { Flex, Info, Space } from 'atoms';
import { Money, Tag, Text } from 'components';
import { tagColors } from 'configs';
import { ApiDateFormat, displayDateFormat } from 'constant';
import { ItemErrorRetry, LoadingMore, ReachEnd } from 'molecules';

import { styles } from './styles';
import { AUTO_DEBIT_TRX_STATUS } from '../constants';
export const PastHistoryView = props => {
  const {
    t,
    LANG_PREFIX,
    LANG_MOLECULES,
    list,
    historyStatus,
    historyNextKey,
    netInfo,
    insets,
    loadHistory,
    handleLoadHistory,
  } = props;

  const renderHeader = useMemo(() => <Space height={10} />, []);

  const renderFooter = () => <View style={{ marginBottom: insets.bottom }}>{renderFooterInner()}</View>;

  const renderFooterInner = () => {
    if (historyStatus === LOADING && list.length > 0) return <LoadingMore />;
    if (list.length - 1 && list.length > 0) return <ReachEnd />;
    //LoadingMore height 60, Space should be 60 when API error to avoid screen change causing onEndReached to run again and again
    return <Space height={historyStatus === FAIL ? 60 : 10} />;
  };

  const renderEmpty = () => {
    if (historyStatus === LOADING) return null;
    if (historyStatus === FAIL) return <ErrorView onRetry={() => loadHistory(1)} />;
    if (netInfo.type !== 'unknown' && netInfo.isInternetReachable === false)
      return <InfoView title={t(`${LANG_MOLECULES}titleCheckInternetConnection`)} textStyle={styles.infoText} />;
    return <InfoView title={t(`${LANG_MOLECULES}titleNoHistory`)} />;
  };

  const renderRemark = text => {
    if (text) return <Text style={styles.remarks}>{t(`${LANG_PREFIX}labelRemark`).replace('${text}', text)}</Text>;
  };

  const renderStatus = status => {
    if (status === AUTO_DEBIT_TRX_STATUS.SUCCESS) return renderTag(t(`${LANG_PREFIX}tagSuccessful`), tagColors.green);
    return renderTag(t(`${LANG_PREFIX}tagFailed`), tagColors.red);
  };

  const renderTag = (title, color) => <Tag title={title} color={color} style={styles.tag} isBold={false} />;

  const renderItem = ({ item, index }) => {
    return (
      <View key={index} style={styles.container}>
        <View style={styles.btn}>
          <View style={styles.row}>
            <Text>{dayjs(item?.trxDate, ApiDateFormat).format(displayDateFormat)}</Text>
            {renderStatus(item?.trxStatus)}
            <Flex />
            <Money amount={item?.amount} currency={'RM'} size={16} />
          </View>
          <Flex />
          {renderRemark(item?.remarks)}
        </View>
      </View>
    );
  };

  return (
    <Flex style={styles.flex}>
      <FlatList
        showsVerticalScrollIndicator={false}
        keyExtractor={(item, index) => index.toString()}
        ListHeaderComponent={renderHeader}
        ListFooterComponent={renderFooter}
        ListEmptyComponent={renderEmpty}
        data={list}
        renderItem={renderItem}
        onEndReached={() => handleLoadHistory(historyNextKey)}
      />
    </Flex>
  );
};

const ErrorView = onRetry => (
  <View style={styles.error}>
    <ItemErrorRetry onRetry={onRetry} />
  </View>
);

const InfoView = ({ title, textStyle }) => <Info title={title} style={styles.info} {...(textStyle && { textStyle })} />;
