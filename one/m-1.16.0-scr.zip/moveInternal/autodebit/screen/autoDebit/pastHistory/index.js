import React from 'react';
import { useSelector } from 'react-redux';
import { useNetInfo } from '@react-native-community/netinfo';
import { useTranslation } from 'react-i18next';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { callAutoDebitConsentTrxHistory, getConsentTrxHistory, getCurrentConsent } from 'stores';
import { useHandleDispatch } from 'hooks';
import { LOADING } from 'apis';

import { PastHistoryView } from './component';
import { sortListDesc } from '../utils';

export const PastHistory = () => {
  const { t } = useTranslation();
  const LANG_MOLECULES = 'molecules.transactionList.';
  const LANG_PREFIX = 'screens.autoDebitConsentHistory.text.';

  const handleDispatch = useHandleDispatch();
  const netInfo = useNetInfo();
  const insets = useSafeAreaInsets();

  const { consentId } = useSelector(getCurrentConsent) || {};
  const { list, status: historyStatus, historyNextKey, endOfHistory } = useSelector(getConsentTrxHistory) || {};

  const loadHistory = async nextKey => {
    await handleDispatch(callAutoDebitConsentTrxHistory({ consentId, nextKey }));
  };

  const handleLoadHistory = nextKey => {
    if (endOfHistory) return;
    if (historyStatus === LOADING) return;
    loadHistory(nextKey);
  };

  const props = {
    t,
    LANG_MOLECULES,
    LANG_PREFIX,
    list: sortListDesc(list),
    historyStatus,
    netInfo,
    insets,
    historyNextKey,
    loadHistory,
    handleLoadHistory,
  };
  return <PastHistoryView {...props} />;
};
