import React from 'react';
import { View, ScrollView } from 'react-native';
import dayjs from 'dayjs';

import { Divider, Screen, Text } from 'atoms';
import { NavBar } from 'organisms';
import { ApiDateFormat, displayDateFormat, displayDatetimeFormat } from 'constant';

import { AUTO_DEBIT_CONSENT_STATUS, AUTO_DEBIT_TYPE } from '../constants';
import { ConsentItem } from '../components';
import { styles } from './styles';

export const AllConsentListView = props => {
  const { t, LANG_PREFIX, type, viewAll, handleViewConsent } = props;

  return (
    <Screen>
      <NavBar
        back
        title={type === AUTO_DEBIT_TYPE.PENDING ? t(`${LANG_PREFIX}titlePending`) : t(`${LANG_PREFIX}titleRegistered`)}
      />
      <ScrollView showsVerticalScrollIndicator={false}>
        {viewAll?.map((item, index) => (
          <View key={index} style={styles.container}>
            <ConsentItem
              t={t}
              style={styles.consentItem}
              onPress={() => handleViewConsent(item)}
              title={item.merchantName}
              subtitle={item.consentDesc}
              consentStatus={item.consentStatus}
              renderLeft={
                <View>
                  <Text numberOfLines={1} style={styles.requestDate}>
                    {type === AUTO_DEBIT_TYPE.PENDING
                      ? dayjs(item.requestDate, ApiDateFormat).format(displayDatetimeFormat)
                      : dayjs(item.registerDate, ApiDateFormat).format(displayDatetimeFormat)}
                  </Text>
                  {!!item.reqExpiryDate && item.consentStatus === AUTO_DEBIT_CONSENT_STATUS.PNDG.key && (
                    <>
                      <View style={styles.expiryView}>
                        <Text style={styles.expiryDate}>{t(`${LANG_PREFIX}labelExpiry`)}</Text>
                        <Text numberOfLines={1} style={styles.expiryDate}>
                          {dayjs(item.reqExpiryDate, ApiDateFormat).format(displayDateFormat)}
                        </Text>
                      </View>
                    </>
                  )}
                </View>
              }
              rightStyle={styles.rightStyle}
              renderRight={
                <Text numberOfLines={2} style={styles.rightItemText}>
                  {item.duitNowRefNo}
                </Text>
              }
            />
            {viewAll?.length - 1 !== index && <Divider style={styles.divider} />}
          </View>
        ))}
      </ScrollView>
    </Screen>
  );
};
