import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';

import routes from 'navigations/routes';
import { getConsentList, resetCurrentConsentObject, updateCurrentConsentObject } from 'stores';

import { AUTO_DEBIT_TYPE } from '../constants';
import { getConsentListByType, sortByConsentStatus } from '../utils';
import { AllConsentListView } from './component';

export const AllConsentList = ({ navigation, route }) => {
  const { type } = route.params || {};
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebit.text.';
  const dispatch = useDispatch();

  const { pending, registered } = useSelector(getConsentList) || {};

  const pendingList = sortByConsentStatus({ list: pending, type });
  const registeredList = sortByConsentStatus({ list: registered, type });
  const viewAll = getConsentListByType({ type, pendingList, registeredList });

  const handleViewConsent = item => {
    dispatch(resetCurrentConsentObject());
    dispatch(updateCurrentConsentObject({ ...item }));
    if (type === AUTO_DEBIT_TYPE.PENDING) return navigation.navigate(routes.AUTO_DEBIT_CONSENT_CONFIRMATION);
    navigation.navigate(routes.AUTO_DEBIT_CONSENT_DETAILS);
  };

  const props = {
    t,
    LANG_PREFIX,
    type,
    viewAll,
    handleViewConsent,
  };

  return <AllConsentListView {...props} />;
};
