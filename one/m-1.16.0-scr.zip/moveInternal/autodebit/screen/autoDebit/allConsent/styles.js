import { colors } from 'configs';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    marginHorizontal: 10,
    marginTop: 0,
    marginVertical: 8,
  },
  consentItem: {
    borderRadius: 5,
  },
  requestDate: {
    fontSize: 12,
    marginTop: 5,
    color: colors.grey,
  },
  rightStyle: {
    alignItems: 'space-between',
    justifyContent: 'flex-end',
  },
  rightItemText: {
    flex: 1,
    fontSize: 10,
    color: colors.grey,
    flexShrink: 1,
    flexWrap: 'wrap',
    maxWidth: 120,
    textAlign: 'right',
  },
  divider: {
    marginHorizontal: 15,
  },
  expiryView: {
    flexDirection: 'row',
    marginTop: 5,
  },
  expiryDate: {
    fontSize: 12,
    color: colors.red,
  },
});
