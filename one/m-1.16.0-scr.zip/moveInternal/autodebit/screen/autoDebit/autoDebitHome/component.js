import React from 'react';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import ContentLoader, { Rect } from 'react-content-loader/native';
import { RefreshControl } from 'react-native-gesture-handler';

import { Screen } from 'atoms';
import { NavBar } from 'organisms';
import { ButtonBottom, Text } from 'components';
import { colors, skeletonColors } from 'configs';
import { LOADING } from 'apis';

import { ConsentTable } from '../components';
import { styles } from './styles';
import { AUTO_DEBIT_TYPE } from '../constants';

export const AutoDebitComp = props => {
  const {
    t,
    LANG_PREFIX,
    handleTransferConsent,
    pending,
    registered,
    listStatus,
    loadConsent,
    handleViewMore,
    handleViewConsent,
  } = props;

  const { width } = useWindowDimensions();
  const loaderWidth = width - 20;

  return (
    <Screen>
      <NavBar back title={t(`${LANG_PREFIX}navTitle`)} />
      {listStatus === LOADING ? (
        <LoadingView loaderWidth={loaderWidth} />
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={listStatus === LOADING}
              onRefresh={loadConsent}
              colors={[colors.black]}
              tintColor={colors.black}
            />
          }>
          {/* Pending Consent Section */}
          <ConsentTable
            title={t(`${LANG_PREFIX}titlePending`)}
            list={pending}
            type={AUTO_DEBIT_TYPE.PENDING}
            onViewMore={() => handleViewMore(AUTO_DEBIT_TYPE.PENDING)}
            onPress={handleViewConsent}
          />

          {/* Registered Consents Section */}
          <ConsentTable
            title={t(`${LANG_PREFIX}titleRegistered`)}
            titleBgColor={'#FFFDE7'}
            list={registered}
            type={AUTO_DEBIT_TYPE.REGISTERED}
            onViewMore={() => handleViewMore(AUTO_DEBIT_TYPE.REGISTERED)}
            onPress={handleViewConsent}
          />
        </ScrollView>
      )}

      {/* Transfer Consent Section*/}
      <ButtonBottom onPress={handleTransferConsent}>
        <Text bold style={styles.buttonText}>
          {t(`${LANG_PREFIX}buttonTransferConsent`)}
        </Text>
      </ButtonBottom>
    </Screen>
  );
};

const LoadingView = ({ loaderWidth }) => (
  <View style={styles.loadView}>
    <ContentLoader
      width={loaderWidth}
      height={500}
      speed={1}
      backgroundColor={skeletonColors.bone}
      foregroundColor={skeletonColors.highlight}>
      <Rect x={0} y={0} rx='10' ry='10' width='97%' height='200' />
      <Rect x={0} y={210} rx='10' ry='10' width='97%' height='200' />
    </ContentLoader>
  </View>
);
