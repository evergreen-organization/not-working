import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';

import routes from 'navigations/routes';
import {
  autoDebitInit,
  callAutoDebitConsentList,
  getConsentList,
  resetCurrentConsentObject,
  updateCurrentConsentObject,
} from 'stores';
import { useHandleDispatch } from 'hooks';
import { LOADING, SUCCESS } from 'apis';

import { AutoDebitComp } from './component';
import { CONSENT_ROUTE_MAP } from '../constants';

export const AutoDebit = ({ navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebit.text.';
  const handleDispatch = useHandleDispatch();
  const dispatch = useDispatch();
  const { pending, registered, listStatus } = useSelector(getConsentList) || {};

  useEffect(() => {
    dispatch(autoDebitInit());

    if (listStatus === LOADING || listStatus === SUCCESS) return;
    loadConsent().then();
  }, []);

  const loadConsent = async () => await handleDispatch(callAutoDebitConsentList());

  const handleTransferConsent = () => {
    //to transfer consent from another Bank to Public Bank
    navigation.navigate(routes.AUTO_DEBIT_TRANSFER_CONSENT_GUIDE);
  };

  const handleViewMore = type => {
    // to view all the consents list based on user selection (pending and registered)
    navigation.navigate(routes.AUTO_DEBIT_ALL_CONSENT_LIST, { type });
  };

  const handleViewConsent = (item, type) => {
    // to route and view the particular consent details
    dispatch(resetCurrentConsentObject());
    dispatch(updateCurrentConsentObject({ ...item }));
    navigation.navigate(CONSENT_ROUTE_MAP[type]);
  };

  const props = {
    t,
    LANG_PREFIX,
    pending,
    registered,
    listStatus,
    loadConsent,
    handleTransferConsent,
    handleViewMore,
    handleViewConsent,
  };

  return <AutoDebitComp {...props} />;
};
