import { colors } from 'configs';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  buttonText: {
    color: colors.white,
  },
  loadView: {
    flex: 1,
    marginHorizontal: 15,
  },
});
