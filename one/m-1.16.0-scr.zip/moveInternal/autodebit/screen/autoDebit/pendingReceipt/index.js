import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';

import { tagColors } from 'configs';
import routes from 'navigations/routes';
import { getCasa, getCurrentConsent, getSoftToken, resetConsentListStatus } from 'stores';
import { ApiDateFormat, ApiDateTimeFormat, displayDateFormat, ReceiptDateTimeFormat } from 'constant';
import { useCasa } from 'hooks';

import AutoDebit from 'assets/images/corporation/duitnowautodebit.png';

import { ConsentRegisterReceiptView } from './component';
import { AD_FREQUENCY, AUTO_DEBIT_CONSENT_STATUS } from '../constants';

export const ConsentRegisterReceipt = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitPendingConsentReceipt.text.';
  const dispatch = useDispatch();
  const casaUtils = useCasa({ auto: false });
  const { secfaInfo } = route.params || {};

  const consentDetails = useSelector(getCurrentConsent) || {};
  const casa = useSelector(getCasa);
  const { preferredAccountNo, preferredAccountName } = useSelector(getSoftToken) || {};
  const accInfo =
    preferredAccountNo === secfaInfo?.fromAccNo
      ? { accountDesc: preferredAccountName }
      : casa.accounts.find(item => item.accountNo === secfaInfo?.fromAccNo);
  const {
    refNo,
    duitNowRefNo,
    productId,
    consentId,
    tranDateTime,
    merchantName,
    consentDesc,
    frequency,
    maxAmnt,
    effectiveDate,
    completionDate,
    otherDetail,
  } = consentDetails;

  const receiptItems = [
    { title: t(`${LANG_PREFIX}itemRefNo`), value: refNo },
    { title: t(`${LANG_PREFIX}itemDuitNowRefNo`), value: duitNowRefNo },
    { title: t(`${LANG_PREFIX}itemProductID`), value: productId },
    { title: t(`${LANG_PREFIX}itemConsentID`), value: consentId },
    {
      title: t(`${LANG_PREFIX}itemDateTime`),
      value: dayjs(tranDateTime, ApiDateTimeFormat).format(ReceiptDateTimeFormat),
    },
    { title: t(`${LANG_PREFIX}itemMerchantName`), value: merchantName },
    { title: t(`${LANG_PREFIX}itemReference`), value: consentDesc },
    { title: t(`${LANG_PREFIX}itemOtherDetails`), value: otherDetail },
    { title: t(`${LANG_PREFIX}itemPaymentMethod`), value: 'AutoDebit', icon: AutoDebit },
    { title: t(`${LANG_PREFIX}itemFrequency`), value: t(AD_FREQUENCY[frequency]?.langCode) },
    { title: t(`${LANG_PREFIX}itemMaxAmnt`), value: maxAmnt, currency: 'RM' },
    {
      title: t(`${LANG_PREFIX}itemEffectiveDate`),
      value: dayjs(effectiveDate, ApiDateFormat).format(displayDateFormat),
    },
    {
      title: t(`${LANG_PREFIX}itemCompletionDate`),
      value: dayjs(completionDate, ApiDateFormat).format(displayDateFormat),
    },
    {
      title: t(`${LANG_PREFIX}itemFromAcc`),
      value: accInfo?.accountDesc,
      tagList: [{ title: secfaInfo?.fromAccNo, color: tagColors.red }],
    },
    {
      title: t(`${LANG_PREFIX}itemStatus`),
      value: t(AUTO_DEBIT_CONSENT_STATUS.ACTV.label),
      valueFontStyle: { color: AUTO_DEBIT_CONSENT_STATUS.ACTV.color },
    },
  ];

  useEffect(() => {
    if (preferredAccountNo !== secfaInfo?.fromAccNo) {
      casaUtils.load();
    }
  }, []);

  const handleDone = () => {
    dispatch(resetConsentListStatus());
    navigation.navigate(routes.MAIN_TAB);
  };
  const props = { t, LANG_PREFIX, receiptItems, handleDone };

  return <ConsentRegisterReceiptView {...props} />;
};
