import React from 'react';
import { ScrollView, TouchableOpacity, View } from 'react-native';

import { Screen, Space } from 'atoms';
import { ButtonBottom, Checkbox, Text } from 'components';
import { NavBar } from 'organisms';
import { ActionModal } from 'molecules';
import { SUCCESS } from 'apis';

import { styles } from './styles';

export const TerminateReasonView = props => {
  const {
    t,
    LANG_PREFIX,
    productId,
    reasonList,
    status,
    selectedReason,
    confirmationModalVisibility,
    submissionLoading,
    handleConfirm,
    handleCancel,
    handleTerminateConsent,
    handleSelect,
  } = props;

  const renderConfirmation = () => {
    return (
      <View>
        <Text bold style={styles.modalTitleTxt}>
          {t(`${LANG_PREFIX}confirmationTitle`)}
        </Text>
        <Text style={styles.modalContentTxt}>
          {t(`${LANG_PREFIX}confirmationDesc1`).replace('${productId}', productId)}
        </Text>
      </View>
    );
  };
  return (
    <>
      <Screen>
        <NavBar back title={t(`${LANG_PREFIX}navTitle`)} />
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.chooseContainer}>
            <Text style={styles.chooseTxt}>{t(`${LANG_PREFIX}chooseTitle`)}</Text>
          </View>
          <View style={styles.form}>
            {reasonList?.map((item, index) => (
              <TouchableOpacity key={index} style={styles.flex} onPress={() => handleSelect(item.id)}>
                <View style={styles.reasonView}>
                  <Text style={styles.reasonTxt}>{item?.value}</Text>
                  <Checkbox
                    style={styles.reasonCheckbox}
                    onPress={() => handleSelect(item?.id)}
                    status={item?.id === selectedReason}
                  />
                </View>
                {index !== reasonList?.length - 1 && <Space height={10} />}
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
        <ButtonBottom onPress={handleTerminateConsent} loading={status !== SUCCESS || submissionLoading}>
          {t(`${LANG_PREFIX}btnTerminateConsent`)}
        </ButtonBottom>
      </Screen>
      <ActionModal
        variant={ActionModal.variants.modalize}
        isVisible={confirmationModalVisibility}
        renderContent={renderConfirmation}
        leftButtonTitle={t(`${LANG_PREFIX}btnCancel`)}
        rightButtonTitle={t(`${LANG_PREFIX}btnConfirm`)}
        onAccept={handleConfirm}
        onDecline={handleCancel}
      />
    </>
  );
};
