import { StyleSheet } from 'react-native';
import { colors } from 'configs';

export const styles = StyleSheet.create({
  chooseContainer: {
    backgroundColor: colors.lightestRed,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    marginHorizontal: 15,
    marginTop: 10,
  },
  chooseTxt: {
    fontSize: 12,
    color: colors.medium,
    paddingHorizontal: 15,
    paddingVertical: 12,
  },
  form: {
    marginHorizontal: 15,
    backgroundColor: colors.white,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 10,
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  reasonView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  reasonTxt: {
    textAlign: 'center',
  },
  reasonCheckbox: {
    marginRight: 0,
  },
  modalTitleTxt: {
    fontSize: 15,
    paddingBottom: 10,
  },
  modalContentTxt: {
    color: colors.medium,
  },
});
