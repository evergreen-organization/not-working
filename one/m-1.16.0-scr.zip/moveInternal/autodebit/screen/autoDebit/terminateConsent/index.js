import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';

import { showFailure, showInfo } from 'utils';
import routes from 'navigations/routes';
import {
  callAutoDebitTerminateReason,
  getCurrentConsent,
  getAutoDebitTerminateReason,
  terminateConsent,
  getAutoDebitTerminateReasonStatus,
} from 'stores';
import { FAIL, IDLE } from 'apis';
import { useHandleDispatch } from 'hooks';

import { TerminateReasonView } from './component';

export const TerminateReason = ({ navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitTerminateConsent.text.';
  const handleDispatch = useHandleDispatch();

  const reasonList = useSelector(getAutoDebitTerminateReason) || [];
  const reasonListStatus = useSelector(getAutoDebitTerminateReasonStatus) || {};
  const { consentId, productId } = useSelector(getCurrentConsent) || {};

  const [confirmationModalVisibility, setConfirmationModalVisibility] = useState(false);
  const [selectedReason, setSelectedReason] = useState(null);
  const [submissionLoading, setSubmissionLoading] = useState(false);

  useEffect(() => {
    start();
  }, []);

  const start = () => {
    if (reasonListStatus === IDLE || reasonListStatus === FAIL) loadReasons();
  };

  const loadReasons = () => handleDispatch(callAutoDebitTerminateReason());

  const handleSelect = val => setSelectedReason(val);

  const handleTerminateConsent = () => {
    if (!selectedReason) return showInfo(t(`${LANG_PREFIX}errorFieldRequired`));
    setConfirmationModalVisibility(true);
  };

  const handleConfirm = async () => {
    setSubmissionLoading(true);
    setConfirmationModalVisibility(false);
    const result = await handleDispatch(terminateConsent({ consentId, reasonId: selectedReason }));
    if (result?.problem) showFailure(result.problem);
    navigation.navigate(routes.AUTO_DEBIT);
  };

  const handleCancel = () => setConfirmationModalVisibility(false);

  const props = {
    t,
    LANG_PREFIX,
    productId,
    reasonList,
    status: reasonListStatus,
    confirmationModalVisibility,
    selectedReason,
    submissionLoading,
    handleTerminateConsent,
    handleConfirm,
    handleCancel,
    handleSelect,
  };

  return <TerminateReasonView {...props} />;
};
