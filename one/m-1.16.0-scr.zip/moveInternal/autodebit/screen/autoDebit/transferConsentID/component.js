import React from 'react';
import { Image, View } from 'react-native';

import { Screen, TooltipIcon } from 'atoms';
import { NavBar, StringInput } from 'organisms';
import { LOADING } from 'apis';

import InfoIcon from 'assets/images/icon/question.png';
import DuitNowAutoDebit from 'assets/images/corporation/duitnowautodebit.png';

import { styles } from './styles';

export const TransferConsentIDView = props => {
  const { t, LANG_PREFIX, status, onSubmit } = props;

  return (
    <Screen singlePage>
      <NavBar
        title={t(`${LANG_PREFIX}navTitle`)}
        back
        showShadow
        bottom={
          <View style={styles.account}>
            <View style={styles.iconView}>
              <Image source={DuitNowAutoDebit} style={styles.icon} />
            </View>
          </View>
        }
        renderRightButton={
          <View style={styles.tooltipView}>
            <TooltipIcon
              icon={InfoIcon}
              tooltipText={t(`${LANG_PREFIX}desc`)}
              placement='bottom'
              iconStyle={styles.tooltip}
            />
          </View>
        }
      />
      <StringInput
        autoCapitalize='none'
        maxLength={18}
        placeholder='00000000000'
        onSubmit={onSubmit}
        loading={status === LOADING}
      />
    </Screen>
  );
};
