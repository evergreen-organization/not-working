import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';

import { consentInquiry, getConsentInquiry, resetConsentInquiry } from 'stores';
import { useHandleDispatch } from 'hooks';
import { showFailure, showInfo } from 'utils';
import routes from 'navigations/routes';
import { alphanumericRegex } from 'constant';

import { TransferConsentIDView } from './component';

export const TransferConsentID = ({ navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitTransferConsentID.text.';
  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();

  const { status } = useSelector(getConsentInquiry) || {};

  useEffect(() => {
    dispatch(resetConsentInquiry());
  }, []);

  const onSubmit = async consentId => {
    if (consentId.length === 0) return showInfo(t(`${LANG_PREFIX}errorFieldRequired`));

    const isAlphaNum = alphanumericRegex.test(consentId);
    if (!isAlphaNum) return showFailure(t(`${LANG_PREFIX}errorInvalid`));

    const result = await handleDispatch(consentInquiry({ consentId }));
    if (result?.problem) return showFailure(result.problem);
    navigation.navigate(routes.AUTO_DEBIT_TRANSFER_CONSENT_CONFIRMATION);
  };
  const props = { t, LANG_PREFIX, status, onSubmit };

  return <TransferConsentIDView {...props} />;
};
