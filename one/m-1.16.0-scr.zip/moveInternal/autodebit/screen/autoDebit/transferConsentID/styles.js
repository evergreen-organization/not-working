import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  account: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 20,
    minHeight: 65,
  },
  iconView: {
    flex: 1,
    alignItems: 'center',
  },
  icon: {
    width: 55,
    height: 55,
  },
  tooltipView: {
    paddingHorizontal: 12,
    justifyContent: 'center',
    opacity: 1,
    height: 44,
  },
  tooltip: {
    width: 18,
    height: 18,
  },
});
