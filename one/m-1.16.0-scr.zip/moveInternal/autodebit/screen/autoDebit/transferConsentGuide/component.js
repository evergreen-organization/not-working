import React from 'react';
import { Image, TouchableOpacity, View, ScrollView } from 'react-native';

import { Divider, Screen } from 'atoms';
import { Heading2, Text } from 'components';
import { NavBar } from 'organisms';

import { styles } from './styles';
import { transferConsentRequirements } from '../constants';

export const TransferConsentGuideView = props => {
  const { t, LANG_PREFIX, handleNext } = props;
  return (
    <Screen singlePage>
      <NavBar back showShadow bottom={<Heading2 children={t(`${LANG_PREFIX}navTitle`)} />} />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/** Description Section */}
        <View style={styles.content}>
          <Text style={styles.desc}>{t(`${LANG_PREFIX}desc`)}</Text>
          <Divider />
          <View style={styles.requirementContainer}>
            {transferConsentRequirements?.map((item, index) => (
              <View key={index}>
                <View style={styles.requirementView}>
                  <Image source={item?.imageUrl} style={styles.icon} />
                  <Text style={styles.requirementTxt}>{t(item?.desc)}</Text>
                </View>
                {index !== transferConsentRequirements?.length - 1 && <Divider style={styles.divider} />}
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      {/** Bottom Button Section */}
      <View style={styles.btnView}>
        <TouchableOpacity onPress={handleNext} style={styles.btn}>
          <Text bold style={styles.btnTxt}>
            {t(`${LANG_PREFIX}btnNext`)}
          </Text>
        </TouchableOpacity>
      </View>
    </Screen>
  );
};
