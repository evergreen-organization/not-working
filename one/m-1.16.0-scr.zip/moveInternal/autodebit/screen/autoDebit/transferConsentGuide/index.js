import React from 'react';
import routes from 'navigations/routes';
import { useTranslation } from 'react-i18next';

import { TransferConsentGuideView } from './component';

export const TransferConsentGuide = ({ navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.autoDebitTransferConsentGuide.text.';

  const handleNext = () => {
    navigation.navigate(routes.AUTO_DEBIT_TRANSFER_CONSENT_ID);
  };

  const props = {
    t,
    LANG_PREFIX,
    handleNext,
  };

  return <TransferConsentGuideView {...props} />;
};
