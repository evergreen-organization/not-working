import { StyleSheet } from 'react-native';
import { colors } from 'configs';

export const styles = StyleSheet.create({
  content: {
    backgroundColor: colors.white,
    marginTop: 10,
    marginHorizontal: 10,
    borderRadius: 10,
  },
  desc: {
    fontSize: 14,
    color: colors.medium,
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  requirementContainer: {
    marginHorizontal: 20,
  },
  requirementView: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  icon: {
    width: 25,
    height: 25,
  },
  requirementTxt: {
    flex: 1,
    marginLeft: 12,
  },
  divider: {
    marginLeft: 42,
  },
  btnView: {
    marginHorizontal: 30,
    marginBottom: 15,
  },
  btn: {
    backgroundColor: colors.primary,
    borderRadius: 10,
    height: 45,
    justifyContent: 'center',
  },
  btnTxt: {
    fontSize: 15,
    color: colors.white,
    textAlign: 'center',
  },
});
