import dayjs from 'dayjs';
import { ApiDateFormat, ApiDateTimeFormat } from 'constant';

import { AUTO_DEBIT_CONSENT_STATUS, AUTO_DEBIT_TYPE, FROM_ACC_TYPE } from './constants';

// Sorting and Displaying
export const sortByConsentStatus = ({ list = [], type }) => {
  if (!Array.isArray(list) || !type) return list || [];
  return [...list].sort((a, b) => {
    const statusA = AUTO_DEBIT_CONSENT_STATUS[a.consentStatus];
    const statusB = AUTO_DEBIT_CONSENT_STATUS[b.consentStatus];

    const priorityA = statusA?.orderPriority ?? 99;
    const priorityB = statusB?.orderPriority ?? 99;

    if (priorityA !== priorityB) {
      return priorityA - priorityB; // Group by priority
    }

    let dateA, dateB;
    if (type === AUTO_DEBIT_TYPE.PENDING) {
      dateA = dayjs(a.requestDate, ApiDateFormat);
      dateB = dayjs(b.requestDate, ApiDateFormat);
    } else if (type === AUTO_DEBIT_TYPE.REGISTERED) {
      dateA = dayjs(a.registerDate, ApiDateFormat);
      dateB = dayjs(b.registerDate, ApiDateFormat);
    } else {
      dateA = dayjs(a.requestDate ?? a.registerDate, ApiDateTimeFormat);
      dateB = dayjs(b.requestDate ?? b.registerDate, ApiDateTimeFormat);
    }

    return dateB.valueOf() - dateA.valueOf(); // Sort by date descending
  });
};

export const sortListDesc = list => {
  return (list || [])
    .slice()
    .sort(
      (a, b) =>
        dayjs(b.transactionDate, ApiDateTimeFormat).valueOf() - dayjs(a.transactionDate, ApiDateTimeFormat).valueOf(),
    );
};

// joins the first letter of both first word and last word of the merchant name
export const getMerchantInitials = text => {
  if (!text || !text.trim()) return '';
  const words = text.trim().split(/\s+/);
  return words.length > 1
    ? words[0].charAt(0).toUpperCase() + words[words.length - 1].charAt(0).toUpperCase()
    : words[0].charAt(0).toUpperCase();
};

export const getConsentListByType = ({ type, pendingList, registeredList }) => {
  const listMap = {
    [AUTO_DEBIT_TYPE.PENDING]: pendingList,
    [AUTO_DEBIT_TYPE.REGISTERED]: registeredList,
  };

  return listMap[type] ?? [];
};

//Helper functions
export const checkIfListValid = list => Array.isArray(list) && list.length > 0;

export const checkConsentIsPending = type => type === AUTO_DEBIT_CONSENT_STATUS.PNDG.key;

export const checkConsentIsActive = type =>
  type === AUTO_DEBIT_CONSENT_STATUS.ACTV.key || type === AUTO_DEBIT_CONSENT_STATUS.ACTB.key;

export const checkConsentIsInActive = type => type === AUTO_DEBIT_CONSENT_STATUS.SUSP.key;

export const checkFromAccTypeCard = type => type === FROM_ACC_TYPE.CARD.key;
