import routes from 'navigations/routes';

import QuestionnaireImage from 'assets/images/basiccolor/document.png';
import TickImage from 'assets/images/basiccolor/tick.png';
import TopUpImage from 'assets/images/basiccolor/mobilebanking.png';
import AutoDebitImage from 'assets/images/basiccolor/autoDebit.png';

const LANG_PREFIX = 'screens.autoDebitConstant.text.';

const AUTODEBIT_COLORS = {
  lightRed: '#FFF7F7',
  red: '#D42A3B',
  lightGreen: '#F1FBF1',
  green: '#228853',
  lightYellow: '#FFF8E7',
  yellow: '#FF641A',
  lightBlue: '#F3F9FF',
  blue: '#1E88E5',
  lightGrey: '#F5F5F5',
  grey: '#666',
};

export const AUTO_DEBIT_TYPE = {
  PENDING: 'Pending',
  REGISTERED: 'Registered',
};

export const AUTO_DEBIT_CONSENT_STATUS = {
  PNDG: {
    key: 'PNDG',
    name: 'Pending',
    label: `${LANG_PREFIX}statusPending`,
    orderPriority: 1,
    color: AUTODEBIT_COLORS.red,
    chip: {
      primary: AUTODEBIT_COLORS.red,
      secondary: AUTODEBIT_COLORS.lightRed,
    },
  },
  EXPI: {
    key: 'EXPI',
    name: 'Expired',
    label: `${LANG_PREFIX}statusExpired`,
    orderPriority: 2,
    color: AUTODEBIT_COLORS.grey,
    chip: {
      primary: AUTODEBIT_COLORS.grey,
      secondary: AUTODEBIT_COLORS.lightGrey,
    },
  },
  ACTV: {
    key: 'ACTV',
    name: 'Active',
    label: `${LANG_PREFIX}statusActive`,
    orderPriority: 3,
    color: AUTODEBIT_COLORS.green,
    chip: {
      primary: AUTODEBIT_COLORS.green,
      secondary: AUTODEBIT_COLORS.lightGreen,
    },
  },
  ACTB: {
    key: 'ACTB',
    name: 'Active',
    label: `${LANG_PREFIX}statusActive`,
    orderPriority: 3,
    color: AUTODEBIT_COLORS.green,
    chip: {
      primary: AUTODEBIT_COLORS.green,
      secondary: AUTODEBIT_COLORS.lightGreen,
    },
  },
  //if the status changed to inactive by customer, the status key will be SUSP, instructed by paynet
  SUSP: {
    key: 'SUSP',
    name: 'Suspended',
    label: `${LANG_PREFIX}statusSuspended`,
    orderPriority: 4,
    color: AUTODEBIT_COLORS.red,
    chip: {
      primary: AUTODEBIT_COLORS.red,
      secondary: AUTODEBIT_COLORS.lightRed,
    },
  },
  SUSB: {
    key: 'SUSB',
    name: 'Suspended',
    label: `${LANG_PREFIX}statusSuspended`,
    orderPriority: 5,
    color: AUTODEBIT_COLORS.red,
    chip: {
      primary: AUTODEBIT_COLORS.red,
      secondary: AUTODEBIT_COLORS.lightRed,
    },
  },
  ICTV: {
    key: 'ICTV',
    name: 'Completed',
    label: `${LANG_PREFIX}statusCompleted`,
    orderPriority: 6,
    color: AUTODEBIT_COLORS.yellow,
    chip: {
      primary: AUTODEBIT_COLORS.yellow,
      secondary: AUTODEBIT_COLORS.lightYellow,
    },
  },
  CANC: {
    key: 'CANC',
    name: 'Terminated',
    label: `${LANG_PREFIX}statusTerminated`,
    orderPriority: 7,
    color: AUTODEBIT_COLORS.grey,
    chip: {
      primary: AUTODEBIT_COLORS.grey,
      secondary: AUTODEBIT_COLORS.lightGrey,
    },
  },
  // Will be covered under DuitNow Pay
  // PNAU: {
  //   key: 'PNAU',
  //   name: 'Processing',
  //   label: `${LANG_PREFIX}statusProcessing`,
  //   color: AUTODEBIT_COLORS.red, // to chg the color to brown
  //   chip: {
  //     primary: AUTODEBIT_COLORS.red,
  //     secondary: AUTODEBIT_COLORS.lightRed,
  //   },
  // },
};

export const transferConsentRequirements = [
  {
    imageUrl: QuestionnaireImage,
    desc: `${LANG_PREFIX}guideDesc1`,
  },
  {
    imageUrl: TickImage,
    desc: `${LANG_PREFIX}guideDesc2`,
  },
  {
    imageUrl: TopUpImage,
    desc: `${LANG_PREFIX}guideDesc3`,
  },
  {
    imageUrl: AutoDebitImage,
    desc: `${LANG_PREFIX}guideDesc4`,
  },
];

export const FROM_ACC_TYPE = {
  CASA: { key: 'CASA', name: 'Savings / Current' },
  CARD: { key: 'CARD', name: 'Credit Card' },
};

export const AD_FREQUENCY = {
  //maintain the key as it is passed by the backend
  '01': { key: '01', langCode: `${LANG_PREFIX}unlimited`, name: 'Unlimited' },
  '02': { key: '02', langCode: `${LANG_PREFIX}daily`, name: 'Daily' },
  '03': { key: '03', langCode: `${LANG_PREFIX}weekly`, name: 'Weekly' },
  '04': { key: '04', langCode: `${LANG_PREFIX}monthly`, name: 'Monthly' },
  '05': { key: '05', langCode: `${LANG_PREFIX}quarterly`, name: 'Quarterly' },
  '06': { key: '06', langCode: `${LANG_PREFIX}yearly`, name: 'Yearly' },
};

export const CONSENT_ROUTE_MAP = {
  [AUTO_DEBIT_TYPE.PENDING]: routes.AUTO_DEBIT_CONSENT_CONFIRMATION,
  [AUTO_DEBIT_TYPE.REGISTERED]: routes.AUTO_DEBIT_CONSENT_DETAILS,
};

export const AUTO_DEBIT_TRX_STATUS = {
  SUCCESS: 'ACSP',
  FAILED: 'RJCT',
};
