import React from 'react';
import { ActionModal } from 'molecules';
import { useTranslation } from 'react-i18next';
import { StyleSheet, View } from 'react-native';
import { Money, Text } from 'components';
import { colors } from 'configs';
import { Divider } from 'atoms';
import { displayReceiptDateTime } from 'utils';

const LANG_PREFIX = 'softToken.tranSigner.text.';

export const DuplicateTransWarning = ({
  isVisible,
  onAccept,
  onDecline,
  onModalHide,
  duplicateTrxList,
  trxInfo,
  duplicateMessage,
  renderCustomDuplicateContent,
}) => {
  const { t } = useTranslation();
  const onHoldFound = duplicateTrxList?.findIndex(item => item.refNo?.substring(0, 2) === 'OT') !== -1;

  const renderDefaultContent = () => (
    <>
      {trxInfo?.amount && (
        <View style={styles.container}>
          <View style={styles.titleView}>
            <Text style={styles.recipientAccText}>{t(`${LANG_PREFIX}duplicateRecipientAcc`)}</Text>
            <Text bold>{trxInfo?.accNo}</Text>
          </View>
          <Money amount={trxInfo?.amount} currency={trxInfo?.currency} size={20} />
        </View>
      )}

      {duplicateTrxList ? (
        <>
          <Divider />

          <Text style={styles.detectedText}>{t(`${LANG_PREFIX}duplicateDetected`)}</Text>

          <View style={styles.detailsContainer}>
            <View style={styles.modalTableTitleContainer}>
              <Text style={[styles.modalTableTitleText, styles.modalTextLeft]}>
                {t(`${LANG_PREFIX}duplicateRefNo`)}
              </Text>
              <Text style={styles.modalTableTitleText}>{t(`${LANG_PREFIX}duplicateDateTime`)}</Text>
            </View>

            <View style={styles.modalTableContentContainer}>
              {duplicateTrxList?.map((item, index) => (
                <View key={index}>
                  <View style={styles.modalTableRowContainer}>
                    <Text style={styles.modalTextLeft}>
                      {item.refNo?.substring(0, 2) === 'OT' ? `*${item.refNo}` : item.refNo}
                    </Text>
                    <Text style={styles.creationDate}>{displayReceiptDateTime(item.creationDate)}</Text>
                  </View>
                  {index !== duplicateTrxList?.length - 1 && <Divider />}
                </View>
              ))}
            </View>

            {onHoldFound && <Text style={styles.modalTableNote}>{`*${t(`${LANG_PREFIX}onHoldDesc`)}`}</Text>}
          </View>
        </>
      ) : (
        <View>
          <Text style={{ fontSize: 15 }}>{duplicateMessage}</Text>
        </View>
      )}
    </>
  );

  return (
    <ActionModal
      variant={ActionModal.variants.modalize}
      isVisible={isVisible}
      renderContent={() =>
        renderCustomDuplicateContent ? renderCustomDuplicateContent(trxInfo) : renderDefaultContent()
      }
      leftButtonTitle={t(`${LANG_PREFIX}buttonCancelNewRecipient`)}
      rightButtonTitle={t(`${LANG_PREFIX}buttonProceedNewRecipient`)}
      onDecline={onDecline}
      onAccept={onAccept}
      onModalHide={onModalHide}
    />
  );
};

const styles = StyleSheet.create({
  modalTextLeft: {
    fontSize: 13,
    flex: 1,
    paddingRight: 10,
  },
  modalTableTitleText: {
    color: colors.medium,
  },
  modalTableTitleContainer: {
    flexDirection: 'row',
    backgroundColor: colors.bg,
    padding: 10,
    borderTopLeftRadius: 5,
    borderTopRightRadius: 5,
  },
  modalTableRowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
  },
  modalTableContentContainer: {
    borderWidth: 1,
    borderTopWidth: 0,
    borderColor: colors.border,
    borderBottomLeftRadius: 5,
    borderBottomRightRadius: 5,
    paddingHorizontal: 10,
  },
  modalTableNote: {
    fontSize: 13,
    color: colors.medium,
    marginTop: 15,
    paddingHorizontal: 10,
  },
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  titleView: {
    flex: 1,
    paddingRight: 12,
  },
  recipientAccText: {
    color: colors.medium,
    marginBottom: 5,
  },
  detectedText: {
    color: colors.medium,
    marginVertical: 15,
  },
  detailsContainer: {
    marginHorizontal: -3,
  },
  creationDate: {
    fontSize: 13,
  },
});
