import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { Image, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import { colors } from 'configs';
import routes from 'navigations/routes';
import { useApi, usePreLoginApi, useTranApiSubmit } from 'hooks';
import { useTranSigner } from './useTranSigner';
import { ActionModal, BottomDrawerModalMini, Modal } from 'molecules';
import { TextInput } from 'organisms';
import { Heading2WithSub, Text } from 'components';
import { CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MSG, numericKeyboard, secfaType, tranApiType } from 'constant';
import {
  cancelNewRecipientTransfer,
  getSecfaAuth,
  getSoftTokenTransaction,
  paymentAuthReset,
  rejectPendingTransaction,
  selectedSecfaUpdated,
  softTokenPendingTranReset,
  unbound,
  updateSoftTokenAuthObject,
  updateSoftTokenObject,
} from 'stores';

import CloseIcon from 'assets/images/icon/close.png';
import useSoftTokenSigner from './useSoftTokenSigner';
import { PropsDisableAccessibility, showFailure, spellWord } from 'utils';
import { DuplicateTransWarning, NewRecipientWarning } from 'screens/softToken/components';
import { SecurePinSimple } from 'screens/auth/quickPayment/SecurePinSimple';
import { useTranslation } from 'react-i18next';
import { useRetry } from 'contexts';

const secfaTypeArr = Object.entries(secfaType).filter(a => a[1] === secfaType.PAC || a[1] === secfaType.HARD_TOKEN);
let onSubmitParam = {};
let onSuccessParam = {};
let trxInfo = {};

const TranSigner = (
  { type, navigation, onCancel, onStartCheckSecfa, onRetrieved, renderCustomDuplicateContent = null },
  ref,
) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'softToken.tranSigner.text.';
  const LANG_PREFIX_SECFA_TYPE = 'softToken.secfaType.';

  useImperativeHandle(ref, () => ({
    // methods connected to `ref`
    checkSecfa: param => {
      checkSecfa(param);
    },
    retrieveTransaction: param => {
      retrieveTransaction(param);
    },
    approveTransaction: param => {
      setModalPinVisible(true);
      tranTypeRef.current = param.tranType;
    },
    rejectTransaction: param => {
      tranTypeRef.current = param.tranType;
      rejectTransaction(param);
    },
    closePin: () => {
      setModalPinVisible(false);
    },
  }));

  const dispatch = useDispatch();
  const { callApi } = usePreLoginApi();
  const { globalLoggedIn } = useRetry();
  const tranApiUtils = useTranApiSubmit({ type, navigation });
  const junction = tranApiUtils.checkJunction();
  const isPublic = tranApiUtils.isPublicJunction(junction);
  const signerUtils = useTranSigner();
  const softTokenSigner = useSoftTokenSigner();
  const secfaAuth = useSelector(getSecfaAuth);
  const { transactionId, secureChannelMessageSignature } = useSelector(getSoftTokenTransaction) || {};
  // const tranCancelledMessage = useSelector(getErrorMessage('E00076'));
  // const retrieveTransactionStatusApi = useApi(retrieveTransactionStatus);
  const rejectPendingTransactionApi = useApi(rejectPendingTransaction);
  const cancelNewRecipientTransferApi = useApi(cancelNewRecipientTransfer);

  const [isSecfaModalVisible, setIsSecfaModalVisible] = useState(false);
  const [isSecurePacModalVisible, setIsSecurePacModalVisible] = useState(false);
  const [isSecurePacDisplayModalVisible, setIsSecurePacDisplayModalVisible] = useState(false);
  const [securePac, setSecurePac] = useState('');
  const [modalPinVisible, setModalPinVisible] = useState(false);
  const [duplicationModalVisible, setDuplicationModalVisible] = useState(false);
  const [newRecipientModalVisible, setNewRecipientModalVisible] = useState(false);
  const [newRecipientBlockedModalVisible, setNewRecipientBlockedModalVisible] = useState(false);
  const [secfaResult, setSecfaResult] = useState({});

  const modalAction = useRef(null);
  const isPublicRef = useRef(isPublic);
  const transactionIdRef = useRef(transactionId);
  const pendingTransactionIdRef = useRef('');
  const securePacInputRef = useRef();
  const tranTypeRef = useRef('');
  const isSecureSignApproval = type === tranApiType.SECURE_SIGN_APPROVAL;

  useEffect(() => {
    if (junction === 'BOTH') isPublicRef.current = isPublic;
  }, [isPublic]);

  useEffect(() => {
    transactionIdRef.current = transactionId;
  }, [transactionId]);

  const checkSecfa = async ({ secfaInfo, onSubmitParam: p1, onSuccessParam: p2, trxInfo: t }) => {
    onSubmitParam = p1;
    onSuccessParam = p2;
    trxInfo = t;
    retrieveSecfa(secfaInfo);
  };

  const retrieveSecfa = async secfaInfo => {
    onStartCheckSecfa();

    const result = await signerUtils.retrieveSecfa({ isPublic: isPublicRef.current, secfaInfo, func: retrieveSecfa });
    setSecfaResult(result);
    if (!result) return onCancel();
    if (result.isNewRecipientBlocked) return setNewRecipientBlockedModalVisible(true);
    if (result.isDuplicate) return setDuplicationModalVisible(true);

    if (result.isNewRecipient) return setNewRecipientModalVisible(true);

    handleSecfaResult(result);
  };

  const handleSecfaResult = result => {
    if (result.isFailure) {
      onCancel();
      return tranApiUtils.onFailure({
        title: tranApiUtils.failureTitle(),
        message: result.message,
        extraParam: onSuccessParam,
        data: result?.data,
      });
    }
    if (result.isSecfaNotRequired) return onSubmit();
    if (result.showSecfaModal) {
      return setTimeout(() => {
        setIsSecfaModalVisible(true);
        onCancel();
      }, 0);
    } //onCancel after openSecfaModal
    if (result.showPinModal) return setTimeout(() => setModalPinVisible(true), 0);
    if (result.showPac) {
      onCancel();
      onDetectPac();
    }
  };

  const retrieveTransaction = async tran => {
    pendingTransactionIdRef.current = tran.transactionId;
    dispatch(selectedSecfaUpdated(tran.softTokenType));
    const result = await softTokenSigner.retrieveTransaction(tran);

    if (result.status !== 'S') {
      return checkStrongBoxFailure({ ...result, transactionId: tran.transactionId });
    }

    let transaction = JSON.parse(result.transactionStr);
    onRetrieved(transaction.transactionDetails);
  };

  const secureSignApprovalFinished = ({ errorPage = false, problem, actionType = 'APPROVE' }) => {
    dispatch(softTokenPendingTranReset());
    dispatch(paymentAuthReset());

    if (errorPage) {
      tranApiUtils.onFailure({
        title: tranApiUtils.failureTitle(),
        message: problem,
      });
      return;
    }

    tranApiUtils.onSuccess({ extraParam: { actionType, tranType: tranTypeRef.current } });
  };

  const rejectTransaction = async tran => {
    const { transactionId, rejectedFrom } = tran || {};
    const result = await callApi(() =>
      rejectPendingTransactionApi.request({ transactionId, ...(rejectedFrom && { rejectedFrom }) }),
    );
    const errorPage = result.status === 'E00039' || result.status === 'E00076';

    if (result.problem && !errorPage) {
      showFailure(result.problem);
      return onCancel();
    }

    secureSignApprovalFinished({
      errorPage,
      problem: result.problem,
      actionType: 'REJECT',
    });
  };

  const validatePinSuccess = async res => {
    const signResult = await softTokenSigner.sign(res);
    setModalPinVisible(false);

    if (signResult.status !== 'S') {
      checkStrongBoxFailure(signResult);
      return onCancel();
    }

    const signature = signResult?.secureChannelMessageSignature;
    if (isSecureSignApproval) {
      if (secfaAuth.selectedSecfa === 'SECURE_PAC') return (modalAction.current = 'securePacDisplay');
      const submitResult = await softTokenSigner.submit({
        isPublic: true,
        transactionId: transactionIdRef.current,
        signature,
      });
      const errorPage = submitResult.errorPage;

      if (!submitResult) return onCancel();

      secureSignApprovalFinished({
        errorPage,
        problem: submitResult.problem,
        actionType: 'APPROVE',
      });
      return;
    }

    if (secfaAuth.selectedSecfa === 'SECURE_PAC') return (modalAction.current = 'securePac');
    const submitResult = await softTokenSigner.submit({
      isPublic: isPublicRef.current,
      transactionId: transactionIdRef.current,
      signature,
    });
    if (!submitResult) return onCancel();
    await onSubmit();
  };

  const checkStrongBoxFailure = result => {
    const { status, errorCode, signingUnavailable, transactionId, secureStorageEmpty } = result || {};

    dispatch(updateSoftTokenObject({ secureStorageEmpty }));

    if (
      signingUnavailable &&
      (errorCode === 'S1005' || errorCode === 'S1104' || errorCode === 'S1003' || errorCode === 'S1102')
    ) {
      if (transactionId) rejectPendingTransactionApi.request({ transactionId });

      navigation.navigate(routes.MAIN_TAB);

      /*
       * StrongBox signing failure detected. Need to re-enroll PBSS (Soft Token).
       * - If user is already in a public session, proceed directly to silent enrolment
       * - If during CQ enrolment flow, only private session so proceed directly
       * - Otherwise, redirect to PIN login first before proceeding to silent enrolment
       */

      if (globalLoggedIn.current || type === tranApiType.CQ_ENROLMENT) {
        return navigation.navigate(routes.SOFT_TOKEN_SILENT_ENROLMENT_LOADING);
      }

      return navigation.navigate(routes.LOGIN_PIN, {
        newRoute: routes.SOFT_TOKEN_SILENT_ENROLMENT_LOADING,
      });
    }

    const msg = `${t(`screens.softTokenActivation.text.errorCode`)}: ${status}.${errorCode ?? '0'}`;
    showFailure(msg);
  };

  const onSecurePacChanged = async signature => {
    setSecurePac(signature);
    if (signature.length < 6) return;

    const submitResult = await softTokenSigner.submit({
      isPublic: isPublicRef.current,
      transactionId: transactionIdRef.current,
      signature,
    });
    if (!submitResult) return setSecurePac('');

    setIsSecurePacModalVisible(false);
    await onSubmit();
  };

  const onSecfaSelect = key => {
    setIsSecfaModalVisible(false);
    dispatch(selectedSecfaUpdated(key));
    onDetectPac();
  };

  const closeModalSecfa = () => {
    setIsSecfaModalVisible(false);
    onCancel();
  };

  const closeModalSecurePac = () => {
    dispatch(updateSoftTokenAuthObject({ errorMsg: null }));
    setIsSecurePacModalVisible(false);
    onCancel();
  };

  const closeModalSecurePacDisplay = () => {
    dispatch(updateSoftTokenAuthObject({ errorMsg: null }));
    dispatch(softTokenPendingTranReset());
    dispatch(paymentAuthReset());
    setIsSecurePacDisplayModalVisible(false);
    navigation.navigate(routes.MAIN_TAB);
  };

  const closeModalPin = () => {
    setModalPinVisible(false);
    onCancel();
  };

  const onDetectPac = () => {
    navigation.navigate(routes.TRANSACTION_PAC, {
      type,
      onSubmitParam,
      onSuccessParam,
    });
  };

  const onSubmit = async () => {
    const result = await tranApiUtils.onSubmit({ extraParam: onSubmitParam });
    if (result.problem) {
      closeModalPin();

      if (result.status === CONNECTION_TIMEOUT) {
        tranApiUtils.onFailure({
          title: t(CONNECTION_TIMEOUT_MSG),
          message: t(`${LANG_PREFIX}timeoutDesc`),
        });
      } else {
        tranApiUtils.onFailure({
          title: tranApiUtils.failureTitle(result.status),
          message: result.problem,
          extraParam: onSuccessParam,
          data: result?.data,
          status: result?.status,
        });
      }

      return;
    }

    if (result.challengeQuestion) {
      navigation.navigate(routes.CQ_CHALLENGE, { type, onSubmitParam, onSuccessParam });
      onCancel();
      return;
    }

    tranApiUtils.onSuccess({ extraParam: onSuccessParam, apiResponse: result });
    onCancel();
  };

  const checkTransactionStatus = async () => {
    return closeModalSecurePacDisplay();
    // const result = await callApi(() => retrieveTransactionStatusApi.request({ transactionId: pendingTransactionIdRef.current }));

    // switch (result.trxStatus) {
    //   case 'VALIDATED':
    //   case 'REJECTED':
    //   case 'EXPIRED':
    //     return closeModalSecurePacDisplay();
    //   case 'CANCELLED':
    //     secureSignApprovalFinished({
    //       errorPage: true,
    //       problem: tranCancelledMessage,
    //       successMsg: 'Transaction Rejected'
    //     });
    //     return setIsSecurePacDisplayModalVisible(false);
    //   default://PENDING
    //     Alert.alert('Transaction is still pending', 'Do you want to close this screen?', [
    //       {
    //         text: 'Cancel',
    //       },
    //       {
    //         text: 'Close',
    //         style: 'destructive',
    //         onPress: () => closeModalSecurePacDisplay(),
    //       },
    //     ]);
    // }
  };

  const onPinModalHide = () => {
    if (modalAction.current === 'securePacDisplay') setIsSecurePacDisplayModalVisible(true);
    else if (modalAction.current === 'securePac') {
      setIsSecurePacModalVisible(true);
      setTimeout(() => {
        securePacInputRef.current.focus();
      }, 500);
    }

    modalAction.current = null;
  };

  const cancelDuplicateTransaction = () => {
    setDuplicationModalVisible(false);
    navigation.navigate(routes.MAIN_TAB);
    showFailure(t(`${LANG_PREFIX}msgTransactionCancelled`))
  };

  const proceedDuplicateTransaction = () => {
    modalAction.current = 'handleSecfa';
    setDuplicationModalVisible(false);
  };

  const cancelNewRecipient = () => {
    setNewRecipientModalVisible(false);
    navigation.navigate(routes.MAIN_TAB);
    cancelNewRecipientTransferApi.request({});
    showFailure(t(`${LANG_PREFIX}msgTransactionCancelled`))
  };

  const proceedNewRecipient = () => {
    modalAction.current = 'handleSecfa';
    setNewRecipientModalVisible(false);
  };

  const onWarningModalHide = () => {
    if (modalAction.current === 'handleSecfa') handleSecfaResult(secfaResult);

    modalAction.current = null;
  };

  const editESI = () => {
    setNewRecipientBlockedModalVisible(false);
    onCancel();
  };

  const renderNewRecipientWarning = () => {
    const list = tranApiUtils.recipientInfoList(trxInfo);
    return (
      <NewRecipientWarning
        data={list}
        showSemakMule={tranApiUtils.showSemakMule()}
        onLinkPress={() => setNewRecipientModalVisible(false)}
        onLinkCancel={() => setNewRecipientModalVisible(true)}
      />
    );
  };

  const onPacReturn = () => {
    signerUtils.handlePacReturnAction({
      tranType: tranTypeRef.current,
      onStart: () => setIsSecurePacDisplayModalVisible(false),
      onComplete: () => setIsSecurePacDisplayModalVisible(true),
    });
  };

  const renderSecurePacActionButton = () => {
    if (signerUtils.checkPacReturnAction(tranTypeRef.current)) {
      return (
        <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
          <TouchableOpacity style={styles.pacCloseButton} onPress={checkTransactionStatus}>
            <Text bold style={{ color: colors.medium, textAlign: 'center' }}>
              {t(`${LANG_PREFIX}buttonClose`)}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.pacReturnButton} onPress={onPacReturn}>
            <Text bold style={{ color: colors.white, textAlign: 'center' }}>
              {t(`${LANG_PREFIX}buttonReturn`)}
            </Text>
          </TouchableOpacity>
        </View>
      );
    }

    return (
      <TouchableOpacity style={styles.pacDoneButton} onPress={checkTransactionStatus}>
        <Text bold style={{ color: colors.white, textAlign: 'center' }}>
          {t(`${LANG_PREFIX}buttonDone`)}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <>
      <BottomDrawerModalMini
        variant={BottomDrawerModalMini.variants.modalize}
        isVisible={isSecfaModalVisible}
        closeModal={closeModalSecfa}>
        <>
          <View style={{ paddingHorizontal: 20, paddingTop: 12, paddingBottom: 5 }}>
            <Text style={{ fontSize: 13, color: colors.medium }}>{t(`${LANG_PREFIX}labelAuthenticationType`)}</Text>
          </View>
          <ScrollView>
            {secfaTypeArr.map(([key, item], index) => (
              <TouchableOpacity
                key={index}
                onPress={() => onSecfaSelect(key)}
                style={{ backgroundColor: colors.white, paddingHorizontal: 20, paddingVertical: 12 }}>
                <Text style={{ fontSize: 14, color: colors.black }}>{t(`${LANG_PREFIX_SECFA_TYPE}${key}`)}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </>
      </BottomDrawerModalMini>

      <BottomDrawerModalMini
        statusBarTranslucent={false}
        variant={BottomDrawerModalMini.variants.modalize}
        isVisible={isSecurePacModalVisible}
        closeModal={closeModalSecurePac}
        showCancel={false}>
        <TouchableOpacity
          accessibilityLabel={t(`${LANG_PREFIX}acsButtonClosePac`)}
          style={styles.cancelBtn}
          onPress={closeModalSecurePac}>
          <Image source={CloseIcon} style={styles.cancelIcon} />
        </TouchableOpacity>
        <View style={{ paddingHorizontal: 20, paddingVertical: 10 }}>
          <Heading2WithSub
            subtitle={t(`${LANG_PREFIX}pacModalTitleEnter`)}
            title={t(`${LANG_PREFIX}pacModalTitleSecurePac`)}
          />
          <View style={{ backgroundColor: colors.primary, padding: 10, alignSelf: 'flex-start', marginTop: 15 }}>
            <Text style={{ fontSize: 20, color: colors.white }}>{secureChannelMessageSignature}</Text>
          </View>
        </View>
        {secfaAuth.errorMsg !== null && <Text style={styles.errorText}>{secfaAuth.errorMsg}</Text>}
        <View style={{ marginHorizontal: 20, marginBottom: 20 }}>
          <TextInput
            ref={securePacInputRef}
            bold
            onChangeText={text => onSecurePacChanged(text)}
            value={securePac}
            maxLength={6}
            style={{ flex: 0, fontSize: 22, minHeight: 55 }}
            keyboardType={numericKeyboard}
          />
        </View>
      </BottomDrawerModalMini>

      <Modal
        variant={Modal.variants.modalize}
        isVisible={isSecurePacDisplayModalVisible}
        modalStyle={{ flexDirection: 'row', alignSelf: 'center' }}
      >
        <View
          style={{
            ...styles.pacView,
            ...(signerUtils.checkPacReturnAction(tranTypeRef.current) && { minWidth: 230 }),
          }}
        >
          <View
            accessible
            accessibilityLabel={`${t(`${LANG_PREFIX}labelSecurePac`)} ${spellWord(
              secureChannelMessageSignature.toString(),
            )}`}
          >
            <Text {...PropsDisableAccessibility} style={{ fontSize: 16, textAlign: 'center' }}>
              {t(`${LANG_PREFIX}labelSecurePac`)}
            </Text>
            <Text {...PropsDisableAccessibility} bold style={{ fontSize: 22, marginVertical: 20, textAlign: 'center' }}>
              {secureChannelMessageSignature}
            </Text>
          </View>
          <Text style={{ fontSize: 13, marginBottom: 20, color: colors.primary, textAlign: 'center' }}>
            {t(`${LANG_PREFIX}labelDoNotShare`)}
          </Text>
          {renderSecurePacActionButton()}
        </View>
      </Modal>

      <DuplicateTransWarning
        isVisible={duplicationModalVisible}
        onDecline={cancelDuplicateTransaction}
        onAccept={proceedDuplicateTransaction}
        onModalHide={onWarningModalHide}
        trxInfo={trxInfo}
        duplicateMessage={tranApiUtils.duplicateMessage()}
        duplicateTrxList={secfaResult?.duplicateTrxList}
        renderCustomDuplicateContent={renderCustomDuplicateContent}
      />

      <ActionModal
        variant={ActionModal.variants.modalize}
        isVisible={newRecipientModalVisible}
        renderContent={renderNewRecipientWarning}
        leftButtonTitle={t(`${LANG_PREFIX}buttonCancelNewRecipient`)}
        rightButtonTitle={t(`${LANG_PREFIX}buttonProceedNewRecipient`)}
        onDecline={cancelNewRecipient}
        onAccept={proceedNewRecipient}
        onModalHide={onWarningModalHide}
      />

      <ActionModal
        variant={ActionModal.variants.modalize}
        isVisible={newRecipientBlockedModalVisible}
        renderContent={() => (
          <View>
            <Text bold style={{ fontSize: 16, color: colors.primary, marginBottom: 15 }}>
              {t(`${LANG_PREFIX}newRecipientBlockDesc1`)}
            </Text>
            <Text bold style={{ fontSize: 15, marginBottom: 10 }}>
              {t(`${LANG_PREFIX}newRecipientBlockDesc2`)}
            </Text>
            {/* <Divider /> */}
            <Text style={{ fontSize: 13, color: colors.medium }}>{t(`${LANG_PREFIX}newRecipientBlockDesc3`)}</Text>
          </View>
        )}
        leftButtonTitle={t(`${LANG_PREFIX}buttonEdit`)}
        leftButtonType={'normal'}
        onDecline={editESI}
      />

      <BottomDrawerModalMini
        variant={BottomDrawerModalMini.variants.modalize}
        isVisible={modalPinVisible}
        closeModal={closeModalPin}
        onModalHide={onPinModalHide}
        showCancel={false}
        style={{ backgroundColor: colors.bg }}
        modalOptions={{ backdropOpacity: 0.3 }}>
        <SecurePinSimple
          navigation={navigation}
          isPublic={isSecureSignApproval ? true : isPublic}
          onCancel={closeModalPin}
          onSuccess={validatePinSuccess}
        />
      </BottomDrawerModalMini>
    </>
  );
};

const styles = StyleSheet.create({
  cancelBtn: {
    padding: 15,
    position: 'absolute',
    right: 0,
    zIndex: 1,
  },
  cancelIcon: {
    width: 14,
    height: 14,
    tintColor: colors.primary,
  },
  errorText: {
    fontSize: 14,
    color: colors.red,
    marginBottom: 8,
    marginHorizontal: 20,
  },
  pacView: {
    backgroundColor: colors.white,
    borderRadius: 10,
    padding: 20,
    alignSelf: 'center',
  },
  pacDoneButton: {
    backgroundColor: colors.primary,
    borderRadius: 10,
    padding: 10,
  },
  pacCloseButton: {
    backgroundColor: colors.lightestBg,
    borderColor: colors.lightgrey,
    borderWidth: 0.3,
    borderRadius: 10,
    padding: 10,
    flex: 1,
  },
  pacReturnButton: {
    backgroundColor: colors.primary,
    borderRadius: 10,
    padding: 10,
    flex: 1,
    marginLeft: 10,
  },
});

export default forwardRef(TranSigner);
