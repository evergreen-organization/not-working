import PublicBank from "../assets/images/corporation/pbb.png";
import AffinBank from "../assets/images/corporation/affin.png";
import AffinIslamic from "../assets/images/corporation/affin.png";
import AlRajhiBank from "../assets/images/corporation/alrajhi.png";
import AllianceBank from "../assets/images/corporation/alliance.jpg";
import AllianceIslamic from "../assets/images/corporation/alliance.jpg";
import AmBank from "../assets/images/corporation/ambank.jpg";
import AmBankIslamic from "../assets/images/corporation/ambank.jpg";
import BNP from "../assets/images/corporation/bnpparibas.png";
import BangkokBank from "../assets/images/corporation/bangkokbank.png";
import BankIslam from "../assets/images/corporation/bankislam.png";
import BankKerjasama from "../assets/images/corporation/bankrakyat.jpg";
import BankMuamalat from "../assets/images/corporation/bankmuamalat.jpg";
import ArgoBank from "../assets/images/corporation/agro.png";
import BankSimpananNasional from "../assets/images/corporation/banksimpanannasional.png";
import BankOfAmerica from "../assets/images/corporation/bankofamerica.png";
import BankOfChina from "../assets/images/corporation/bankofchina.png";
import BigPay from "../assets/images/corporation/bigpay.png";
import CIMB from "../assets/images/corporation/cimb.jpg";
import CIMBIslamic from "../assets/images/corporation/cimb.jpg";
import ChinaConstruction from "../assets/images/corporation/chinaconstruction.png";
import CitiBank from "../assets/images/corporation/citibank.png";
import DeutscheBank from "../assets/images/corporation/deutschebank.png";
import FinexusCard from "../assets/images/corporation/finexus.png";
import GxBank from "../assets/images/corporation/gx.jpg";
import HSBCAmanah from "../assets/images/corporation/hsbc.png";
import HSBCBank from "../assets/images/corporation/hsbc.png";
import HongLeongBank from "../assets/images/corporation/hongleong.png";
import HongLeongIslamic from "../assets/images/corporation/hongleong.png";
import ICBC from "../assets/images/corporation/icbc.png";
import JPMorgan from "../assets/images/corporation/jpmorgan.png";
import KuwaitFinance from "../assets/images/corporation/kuwaitfinance.png";
import MBSBBank from "../assets/images/corporation/mbsb.png";
import MUFGBank from "../assets/images/corporation/mufg.png";
import MayBank from "../assets/images/corporation/maybank.jpg";
import MayBankIslamic from "../assets/images/corporation/maybank.jpg";
import MerchantTrade from '../assets/images/corporation/merchanttrade.png';
import MizuhoBank from "../assets/images/corporation/mizuho.png";
import OCBCBank from "../assets/images/corporation/ocbc.png";
import OCBCAlAmin from "../assets/images/corporation/ocbc.png";
import RHBBank from "../assets/images/corporation/rhb.png";
import RHBIslamic from "../assets/images/corporation/rhb.png";
import StandardChartered from "../assets/images/corporation/standardchartered.png";
import StandardCharteredSaadiq from "../assets/images/corporation/standardchartered.png";
import SumitomoMitsui from "../assets/images/corporation/sumitomomitsui.png";
import TouchNGo from "../assets/images/corporation/touchngo.png";
import UOBBank from "../assets/images/corporation/uob.png";
import AeonBank from "../assets/images/corporation/aeonbank.png";
import BoostBank from "../assets/images/corporation/boostbank.png";
import Shopee from '../assets/images/corporation/shopeePay.png';
import BoostEWallet from '../assets/images/corporation/boostwallet.png';
import RytBank from '../assets/images/corporation/ryt.png';
import KAFBank from '../assets/images/corporation/kafbank.jpg';
import CoopBank from '../assets/images/corporation/coopbank.png';
import Setel from '../assets/images/corporation/setel.png';
import FassPay from '../assets/images/corporation/fasspay.png';
import Instapay from '../assets/images/corporation/instapay.png';
import Wise from '../assets/images/corporation/wise.png';

// import Altel from ""
// import Astro from ""
// import CandyPoints from ""
// import Celcom from ""
// import Digi from ""
// import GameTower from ""
// import Garena from ""
// import Maxis from ""
// import MerchantTrade from ""
// import MyCard from ""
// import PlayStation from ""
// import RazerGold from ""
// import Steam from ""
// import TRONTalktime from ""
// import TouchnGo from ""
// import TuneTalk from ""
// import UMobile from ""
// import Unifi from ""
// import XOX from ""
// import YES from ""

export const bankLogoMapping = {
  0: PublicBank,
  1: AffinBank,
  3: AffinIslamic,
  10: AlRajhiBank,
  6: AllianceBank,
  9: AllianceIslamic,
  11: AmBank,
  14: AmBankIslamic,
  28: BNP,
  16: BangkokBank,
  17: BankIslam,
  25: BankKerjasama,
  18: BankMuamalat,
  4: ArgoBank,
  26: BankSimpananNasional,
  19: BankOfAmerica,
  20: BankOfChina,
  155: BigPay,
  32: CIMB,
  35: CIMBIslamic,
  97: ChinaConstruction,
  36: CitiBank,
  355: CoopBank,
  38: DeutscheBank,
  115: FinexusCard,
  195: GxBank,
  45: HSBCAmanah,
  46: HSBCBank,
  42: HongLeongBank,
  44: HongLeongIslamic,
  48: ICBC,
  49: JPMorgan,
  336: KAFBank,
  54: KuwaitFinance,
  15: MBSBBank,
  21: MUFGBank,
  55: MayBank,
  58: MayBankIslamic,
  215: MerchantTrade,
  61: MizuhoBank,
  64: OCBCBank,
  63: OCBCAlAmin,
  65: RHBBank,
  67: RHBIslamic,
  335: RytBank,
  70: StandardChartered,
  71: StandardCharteredSaadiq,
  72: SumitomoMitsui,
  135: TouchNGo,
  74: UOBBank,
  235: Shopee,
  275: AeonBank,
  255: BoostBank,
  295: BoostEWallet,
  375: Setel,
  376: FassPay,
  563: Instapay,
  565: Wise,
};

export const prepaidTypeLogoMapping = {
  // 0: Altel,
  // 1: Astro,
  // 2: CandyPoints,
  // 3: Celcom,
  // 4: Celcom,
  // 5: Digi,
  // 6: Digi,
  // 7: GameTower,
  // 8: Garena,
  // 9: Maxis,
  // 10: MerchantTrade,
  // 11: MyCard,
  // 12: PlayStation,
  // 13: RazerGold,
  // 14: Steam,
  // 15: TRONTalktime,
  // 16: TouchnGo,
  // 17: TuneTalk,
  // 18: UMobile,
  // 19: UMobile,
  // 20: UMobile,
  // 21: UMobile,
  // 22: Unifi,
  // 23: XOX,
  // 24: YES,
  // 25: YES,
  // 26: YES,
};


import Flag_Malaysia from "../assets/images/country/malaysia.png";
import Flag_Bangladesh from "../assets/images/country/bangladesh.png";
import Flag_Cambodia from "../assets/images/country/cambodia.png";
import Flag_China from "../assets/images/country/china.png";
import Flag_India from "../assets/images/country/india.png";
import Flag_Indonesia from "../assets/images/country/indonesia.png";
import Flag_Laos from "../assets/images/country/laos.png";
import Flag_Myanmar from "../assets/images/country/myanmar.png";
import Flag_Nepal from "../assets/images/country/nepal.png";
import Flag_Pakistan from "../assets/images/country/pakistan.png";
import Flag_Philippines from "../assets/images/country/philippines.png";
import Flag_Singapore from "../assets/images/country/singapore.png";
import Flag_SriLanka from "../assets/images/country/srilanka.png";
import Flag_Thailand from "../assets/images/country/thailand.png";
import Flag_Vietnam from "../assets/images/country/vietnam.png";
import Flag_Afghanistan from "../assets/images/country/afghanistan.png";
import Flag_Albania from "../assets/images/country/albania.png";
import Flag_Algeria from "../assets/images/country/algeria.png";
import Flag_AmericanSamoa from "../assets/images/country/american-samoa.png";
import Flag_Andorra from "../assets/images/country/andorra.png";
import Flag_Angola from "../assets/images/country/angola.png";
import Flag_Anguilla from "../assets/images/country/anguilla.png";
import Flag_Antarctica from "../assets/images/country/antarctica.png";
import Flag_Antigua from "../assets/images/country/antigua.png";
import Flag_Argentina from "../assets/images/country/argentina.png";
import Flag_Armenia from "../assets/images/country/armenia.png";
import Flag_Aruba from "../assets/images/country/aruba.png";
import Flag_Australia from "../assets/images/country/australia.png";
import Flag_Austria from "../assets/images/country/austria.png";
import Flag_Azerbaijan from "../assets/images/country/azerbaijan.png";
import Flag_Bahamas from "../assets/images/country/bahamas.png";
import Flag_Bahrain from "../assets/images/country/bahrain.png";
import Flag_Barbados from "../assets/images/country/barbados.png";
import Flag_Belarus from "../assets/images/country/belarus.png";
import Flag_Belgium from "../assets/images/country/belgium.png";
import Flag_Belize from "../assets/images/country/belize.png";
import Flag_Benin from "../assets/images/country/benin.png";
import Flag_Bermuda from "../assets/images/country/bermuda.png";
import Flag_Bhutan from "../assets/images/country/bhutan.png";
import Flag_Bolivia from "../assets/images/country/bolivia.png";
import Flag_Bosnia from "../assets/images/country/bosnia.png";
import Flag_Botswana from "../assets/images/country/botswana.png";
import Flag_Brazil from "../assets/images/country/brazil.png";
import Flag_BritishIndianOcean from "../assets/images/country/british-indian-ocean-territory.png";
import Flag_BritishVirginIsland from "../assets/images/country/british-virgin-islands.png";
import Flag_Brunei from "../assets/images/country/brunei.png";
import Flag_Bulgaria from "../assets/images/country/bulgaria.png";
import Flag_BurkinaFaso from "../assets/images/country/burkina-faso.png";
import Flag_Burundi from "../assets/images/country/burundi.png";
import Flag_Cameroon from "../assets/images/country/cameroon.png";
import Flag_Canada from "../assets/images/country/canada.png";
import Flag_Cape from "../assets/images/country/cape-verde.png";
import Flag_CaymanIsland from "../assets/images/country/cayman-islands.png";
import Flag_CentralAfrican from "../assets/images/country/central-african-republic.png";
import Flag_Chad from "../assets/images/country/chad.png";
import Flag_Chile from "../assets/images/country/chile.png";
import Flag_ChristmasIsland from "../assets/images/country/christmas-island.png";
import Flag_Cocos from "../assets/images/country/cocos-island.png";
import Flag_Colombia from "../assets/images/country/colombia.png";
import Flag_Comoros from "../assets/images/country/comoros.png";
import Flag_CongoRepublic from "../assets/images/country/congo-republic.png";
import Flag_CongoDemocratic from "../assets/images/country/congo-democratic.png";
import Flag_CookIslands from "../assets/images/country/cook-islands.png";
import Flag_CostaRica from "../assets/images/country/costa-rica.png";
import Flag_IvoryCoast from "../assets/images/country/ivory-coast.png";
import Flag_Croatia from "../assets/images/country/croatia.png";
import Flag_Cuba from "../assets/images/country/cuba.png";
import Flag_Cyprus from "../assets/images/country/cyprus.png";
import Flag_Czech from "../assets/images/country/czech.png";
import Flag_Denmark from "../assets/images/country/denmark.png";
import Flag_Djibouti from "../assets/images/country/djibouti.png";
import Flag_Dominica from "../assets/images/country/dominica.png";
import Flag_DominicanRepublic from "../assets/images/country/dominican-republic.png";
import Flag_Ecuador from "../assets/images/country/ecuador.png";
import Flag_Egypt from "../assets/images/country/egypt.png";
import Flag_ElSalvador from "../assets/images/country/el-salvador.png";
import Flag_EquatorialGuinea from "../assets/images/country/equatorial-guinea.png";
import Flag_Eritrea from "../assets/images/country/eritrea.png";
import Flag_Estonia from "../assets/images/country/estonia.png";
import Flag_Ethiopia from "../assets/images/country/ethiopia.png";
import Flag_FalklandIslands from "../assets/images/country/falkland-islands.png";
import Flag_FaroeIslands from "../assets/images/country/faroe-islands.png";
import Flag_Fiji from "../assets/images/country/fiji.png";
import Flag_Finland from "../assets/images/country/finland.png";
import Flag_France from "../assets/images/country/france.png";
import Flag_FrenchGuiana from "../assets/images/country/french-guiana.png";
import Flag_FrenchPolynesia from "../assets/images/country/french-polynesia.png";
import Flag_Gabon from "../assets/images/country/gabon.png";
import Flag_Gambia from "../assets/images/country/gambia.png";
import Flag_Georgia from "../assets/images/country/georgia.png";
import Flag_Germany from "../assets/images/country/germany.png";
import Flag_Ghana from "../assets/images/country/ghana.png";
import Flag_Gibraltar from "../assets/images/country/gibraltar.png";
import Flag_Greece from "../assets/images/country/greece.png";
import Flag_Greenland from "../assets/images/country/greenland.png";
import Flag_Grenada from "../assets/images/country/grenada.png";
import Flag_Guam from "../assets/images/country/guam.png";
import Flag_Guatemala from "../assets/images/country/guatemala.png";
import Flag_Guinea from "../assets/images/country/guinea.png";
import Flag_GuineaBissau from "../assets/images/country/guinea-bissau.png";
import Flag_Guyana from "../assets/images/country/guyana.png";
import Flag_Haiti from "../assets/images/country/haiti.png";
import Flag_Honduras from "../assets/images/country/honduras.png";
import Flag_HongKong from "../assets/images/country/hongkong.png";
import Flag_VaticanCity from "../assets/images/country/vatican-city.png";
import Flag_Hungary from "../assets/images/country/hungary.png";
import Flag_Iceland from "../assets/images/country/iceland.png";
import Flag_Iran from "../assets/images/country/iran.png";
import Flag_Iraq from "../assets/images/country/iraq.png";
import Flag_Ireland from "../assets/images/country/ireland.png";
import Flag_Israel from "../assets/images/country/israel.png";
import Flag_Italy from "../assets/images/country/italy.png";
import Flag_Jamaica from "../assets/images/country/jamaica.png";
import Flag_Japan from "../assets/images/country/japan.png";
import Flag_Jordan from "../assets/images/country/jordan.png";
import Flag_Kazakhstan from "../assets/images/country/kazakhstan.png";
import Flag_Kenya from "../assets/images/country/kenya.png";
import Flag_Kiribati from "../assets/images/country/kiribati.png";
import Flag_Kuwait from "../assets/images/country/kuwait.png";
import Flag_Kyrgyzstan from "../assets/images/country/kyrgyzstan.png";
import Flag_Latvia from "../assets/images/country/latvia.png";
import Flag_Lebanon from "../assets/images/country/lebanon.png";
import Flag_Lesotho from "../assets/images/country/lesotho.png";
import Flag_Liberia from "../assets/images/country/liberia.png";
import Flag_Liechtenstein from "../assets/images/country/liechtenstein.png";
import Flag_Lithuania from "../assets/images/country/lithuania.png";
import Flag_NorthKorea from "../assets/images/country/northKorea.png";
import Flag_SouthKorea from "../assets/images/country/southKorea.png";
import Flag_Luxembourg from "../assets/images/country/luxembourg.png";
import Flag_Macao from "../assets/images/country/macao.png";
import Flag_MacedoniaRepublic from "../assets/images/country/macedonia-republic.png";
import Flag_Madagascar from "../assets/images/country/madagascar.png";
import Flag_Malawi from "../assets/images/country/malawi.png";
import Flag_Maldives from "../assets/images/country/maldives.png";
import Flag_Mali from "../assets/images/country/mali.png";
import Flag_Malta from "../assets/images/country/malta.png";
import Flag_MarshallIslands from "../assets/images/country/marshall-island.png";
import Flag_Martinique from "../assets/images/country/martinique.png";
import Flag_Mauritania from "../assets/images/country/mauritania.png";
import Flag_Mauritius from "../assets/images/country/mauritius.png";
import Flag_Mayotte from "../assets/images/country/mayotte.png";
import Flag_Mexico from "../assets/images/country/mexico.png";
import Flag_Micronesia from "../assets/images/country/micronesia.png";
import Flag_Moldova from "../assets/images/country/moldova.png";
import Flag_Monaco from "../assets/images/country/monaco.png";
import Flag_Mongolia from "../assets/images/country/mongolia.png";
import Flag_Montenegro from "../assets/images/country/montenegro.png";
import Flag_Morocco from "../assets/images/country/morocco.png";
import Flag_Mozambique from "../assets/images/country/mozambique.png";
import Flag_Namibia from "../assets/images/country/namibia.png";
import Flag_Nauru from "../assets/images/country/nauru.png";
import Flag_Netherlands from "../assets/images/country/netherlands.png";
import Flag_NewZealand from "../assets/images/country/newZealand.png";
import Flag_Nicaragua from "../assets/images/country/nicaragua.png";
import Flag_Niger from "../assets/images/country/niger.png";
import Flag_Nigeria from "../assets/images/country/nigeria.png";
import Flag_Niue from "../assets/images/country/niue.png";
import Flag_NorfolkIsland from "../assets/images/country/norfolk-island.png";
import Flag_NorthernMarianasIslands from "../assets/images/country/northern-marianas-islands.png";
import Flag_Norway from "../assets/images/country/norway.png";
import Flag_Oman from "../assets/images/country/oman.png";
import Flag_Palau from "../assets/images/country/palau.png";
import Flag_Palestine from "../assets/images/country/palestine.png";
import Flag_Panama from "../assets/images/country/panama.png";
import Flag_Papua from "../assets/images/country/papua-new-guinea.png";
import Flag_Paraguay from "../assets/images/country/paraguay.png";
import Flag_Peru from "../assets/images/country/peru.png";
import Flag_Pitcairn from "../assets/images/country/pitcairn-islands.png";
import Flag_Poland from "../assets/images/country/poland.png";
import Flag_Portugal from "../assets/images/country/portugal.png";
import Flag_PuertoRico from "../assets/images/country/puerto-rico.png";
import Flag_Qatar from "../assets/images/country/qatar.png";
import Flag_Romania from "../assets/images/country/romania.png";
import Flag_Russia from "../assets/images/country/russia.png";
import Flag_Rwanda from "../assets/images/country/rwanda.png";
import Flag_SaintHelena from "../assets/images/country/saint-helena.png";
import Flag_Samoa from "../assets/images/country/samoa.png";
import Flag_sanMarino from "../assets/images/country/san-marino.png";
import Flag_SaoTomeAndPrince from "../assets/images/country/sao-tome-and-prince.png";
import Flag_SaudiArabia from "../assets/images/country/saudi-arabia.png";
import Flag_Senegal from "../assets/images/country/senegal.png";
import Flag_Serbia from "../assets/images/country/serbia.png";
import Flag_Seychelles from "../assets/images/country/seychelles.png";
import Flag_Leone from "../assets/images/country/sierra-leone.png";
import Flag_Slovakia from "../assets/images/country/slovakia.png";
import Flag_Slovenia from "../assets/images/country/slovenia.png";
import Flag_SolomonIslands from "../assets/images/country/solomon-islands.png";
import Flag_Somalia from "../assets/images/country/somalia.png";
import Flag_SouthAfrica from "../assets/images/country/south-africa.png";
import Flag_Spain from "../assets/images/country/spain.png";
import Flag_StKittsAndNevis from "../assets/images/country/saint-kitts-and-nevis.png";
import Flag_StLucia from "../assets/images/country/st-lucia.png";
import Flag_StVincentAndTheGrenadines from "../assets/images/country/st-vincent-and-the-grenadines.png";
import Flag_Sudan from "../assets/images/country/sudan.png";
import Flag_Suriname from "../assets/images/country/suriname.png";
import Flag_SvalbardAndJanMayen from "../assets/images/country/svalbard-and-jan-mayen.png";
import Flag_Swaziland from "../assets/images/country/swaziland.png";
import Flag_Sweden from "../assets/images/country/sweden.png";
import Flag_Switzerland from "../assets/images/country/switzerland.png";
import Flag_Syria from "../assets/images/country/syria.png";
import Flag_Taiwan from "../assets/images/country/taiwan.png";
import Flag_Tajikistan from "../assets/images/country/tajikistan.png";
import Flag_Tanzania from "../assets/images/country/tanzania.png";
import Flag_TimorLeste from "../assets/images/country/timor-leste.png";
import Flag_Togo from "../assets/images/country/togo.png";
import Flag_Tokelau from "../assets/images/country/tokelau.png";
import Flag_Tonga from "../assets/images/country/tonga.png";
import Flag_TrinidadAndTobago from "../assets/images/country/trinidad-and-tobago.png";
import Flag_Tunisia from "../assets/images/country/tunisia.png";
import Flag_Turkey from "../assets/images/country/turkey.png";
import Flag_Turkmenistan from "../assets/images/country/turkmenistan.png";
import Flag_TurksAndCaicos from "../assets/images/country/turks-and-caicos.png";
import Flag_Tuvalu from "../assets/images/country/tuvalu.png";
import Flag_Uganda from "../assets/images/country/uganda.png";
import Flag_Ukraine from "../assets/images/country/ukraine.png";
import Flag_UnitedArabEmirates from "../assets/images/country/united-arab-emirates.png";
import Flag_UnitedKingdom from "../assets/images/country/united-kingdom.png";
import Flag_UnitedStates from "../assets/images/country/united-states.png";
import Flag_Uruguay from "../assets/images/country/uruguay.png";
import Flag_Uzbekistan from "../assets/images/country/uzbekistan.png";
import Flag_Vanuatu from "../assets/images/country/vanuatu.png";
import Flag_Venezuela from "../assets/images/country/venezuela.png";
import Flag_WallisAndFutuna from "../assets/images/country/wallis-and-futuna.png";
import Flag_UnitedStatesVirginIslands from "../assets/images/country/virgin-islands.png";
import Flag_WesternSahara from "../assets/images/country/western-sahara.png";
import Flag_Yemen from "../assets/images/country/yemen.png";
import Flag_Zambia from "../assets/images/country/zambia.png";
import Flag_Zimbabwe from "../assets/images/country/zimbabwe.png";

export const CountryFlag_Prepaid = {
  0: Flag_Malaysia,
  1: Flag_Bangladesh,
  2: Flag_China,
  3: Flag_Indonesia,
  4: Flag_India,
  5: Flag_Laos,
  6: Flag_SriLanka,
  7: Flag_Myanmar,
  8: Flag_Nepal,
  9: Flag_Philippines,
  10: Flag_Pakistan,
  11: Flag_Singapore,
  12: Flag_Thailand,
  13: Flag_Cambodia,
  14: Flag_Vietnam
};

export const CountryFlag = {
  "AFG": Flag_Afghanistan,
  "ALB": Flag_Albania,
  "DZA": Flag_Algeria,
  "ASM": Flag_AmericanSamoa,
  "AND": Flag_Andorra,
  "AGO": Flag_Angola,
  "AIA": Flag_Anguilla,
  "ATA": Flag_Antarctica,
  "ATG": Flag_Antigua,
  "ARG": Flag_Argentina,
  "ARM": Flag_Armenia,
  "ABW": Flag_Aruba,
  "AUS": Flag_Australia,
  "AUT": Flag_Austria,
  "AZE": Flag_Azerbaijan,
  "BHS": Flag_Bahamas,
  "BHR": Flag_Bahrain,
  "BGD": Flag_Bangladesh,
  "BRB": Flag_Barbados,
  "BLR": Flag_Belarus,
  "BEL": Flag_Belgium,
  "BLZ": Flag_Belize,
  "BEN": Flag_Benin,
  "BMU": Flag_Bermuda,
  "BTN": Flag_Bhutan,
  "BOL": Flag_Bolivia,
  "BIH": Flag_Bosnia,
  "BWA": Flag_Botswana,
  // "BVT": null,
  "BRA": Flag_Brazil,
  "IOT": Flag_BritishIndianOcean,
  "VGB": Flag_BritishVirginIsland,
  "BRN": Flag_Brunei,
  "BGR": Flag_Bulgaria,
  "BFA": Flag_BurkinaFaso,
  "BDI": Flag_Burundi,
  "KHM": Flag_Cambodia,
  "CMR": Flag_Cameroon,
  "CAN": Flag_Canada,
  "CPV": Flag_Cape,
  "CYM": Flag_CaymanIsland,
  "CAF": Flag_CentralAfrican,
  "TCD": Flag_Chad,
  "CHL": Flag_Chile,
  "CHN": Flag_China,
  "CXR": Flag_ChristmasIsland,
  "CCK": Flag_Cocos,
  "COL": Flag_Colombia,
  "COM": Flag_Comoros,
  "COG": Flag_CongoRepublic,
  "COK": Flag_CookIslands,
  "CRI": Flag_CostaRica,
  "CIV": Flag_IvoryCoast,
  "HRV": Flag_Croatia,
  "CUB": Flag_Cuba,
  "CYP": Flag_Cyprus,
  "CZE": Flag_Czech,
  "COD": Flag_CongoDemocratic,
  "DNK": Flag_Denmark,
  "DJI": Flag_Djibouti,
  "DMA": Flag_Dominica,
  "DOM": Flag_DominicanRepublic,
  "ECU": Flag_Ecuador,
  "EGY": Flag_Egypt,
  "SLV": Flag_ElSalvador,
  "GNQ": Flag_EquatorialGuinea,
  "ERI": Flag_Eritrea,
  "EST": Flag_Estonia,
  "ETH": Flag_Ethiopia,
  "FLK": Flag_FalklandIslands,
  "FRO": Flag_FaroeIslands,
  "FJI": Flag_Fiji,
  "FIN": Flag_Finland,
  "FRA": Flag_France,
  "GUF": Flag_FrenchGuiana,
  "PYF": Flag_FrenchPolynesia,
  // "ATF": null,
  "GAB": Flag_Gabon,
  "GMB": Flag_Gambia,
  "GEO": Flag_Georgia,
  "DEU": Flag_Germany,
  "GHA": Flag_Ghana,
  "GIB": Flag_Gibraltar,
  "GRC": Flag_Greece,
  "GRL": Flag_Greenland,
  "GRD": Flag_Grenada,
  // "GLP": null,
  "GUM": Flag_Guam,
  "GTM": Flag_Guatemala,
  "GIN": Flag_Guinea,
  "GNB": Flag_GuineaBissau,
  "GUY": Flag_Guyana,
  "HTI": Flag_Haiti,
  // "HMD": null,
  "VAT": Flag_VaticanCity,
  "HND": Flag_Honduras,
  "HKG": Flag_HongKong,
  "HUN": Flag_Hungary,
  "ISL": Flag_Iceland,
  "IND": Flag_India,
  "IDN": Flag_Indonesia,
  "IRN": Flag_Iran,
  "IRQ": Flag_Iraq,
  "IRL": Flag_Ireland,
  "ISR": Flag_Israel,
  "ITA": Flag_Italy,
  "JAM": Flag_Jamaica,
  "JPN": Flag_Japan,
  "JOR": Flag_Jordan,
  "KAZ": Flag_Kazakhstan,
  "KEN": Flag_Kenya,
  "KIR": Flag_Kiribati,
  "PRK": Flag_NorthKorea,
  "KOR": Flag_SouthKorea,
  "KWT": Flag_Kuwait,
  "KGZ": Flag_Kyrgyzstan,
  "LAO": Flag_Laos,
  "LVA": Flag_Latvia,
  "LBN": Flag_Lebanon,
  "LSO": Flag_Lesotho,
  "LBR": Flag_Liberia,
  // "LBY": null,
  "LIE": Flag_Liechtenstein,
  "LTU": Flag_Lithuania,
  "LUX": Flag_Luxembourg,
  "MAC": Flag_Macao,
  "MKD": Flag_MacedoniaRepublic,
  "MDG": Flag_Madagascar,
  "MWI": Flag_Malawi,
  "MYS": Flag_Malaysia,
  "MDV": Flag_Maldives,
  "MLI": Flag_Mali,
  "MLT": Flag_Malta,
  "MHL": Flag_MarshallIslands,
  "MTQ": Flag_Martinique,
  "MRT": Flag_Mauritania,
  "MUS": Flag_Mauritius,
  "MYT": Flag_Mayotte,
  "MEX": Flag_Mexico,
  "FSM": Flag_Micronesia,
  "MDA": Flag_Moldova,
  "MCO": Flag_Monaco,
  "MNG": Flag_Mongolia,
  // "MSR": null,
  "MNE": Flag_Montenegro,
  "MAR": Flag_Morocco,
  "MOZ": Flag_Mozambique,
  "MMR": Flag_Myanmar,
  "NAM": Flag_Namibia,
  "NRU": Flag_Nauru,
  "NPL": Flag_Nepal,
  "NLD": Flag_Netherlands,
  // "ANT": null,
  // "NCL": null,
  "NZL": Flag_NewZealand,
  "NIC": Flag_Nicaragua,
  "NER": Flag_Niger,
  "NGA": Flag_Nigeria,
  "NIU": Flag_Niue,
  "NFK": Flag_NorfolkIsland,
  "MNP": Flag_NorthernMarianasIslands,
  "NOR": Flag_Norway,
  "OMN": Flag_Oman,
  "PAK": Flag_Pakistan,
  "PLW": Flag_Palau,
  "PSE": Flag_Palestine,
  "PAN": Flag_Panama,
  "PNG": Flag_Papua,
  "PRY": Flag_Paraguay,
  "PER": Flag_Peru,
  "PHL": Flag_Philippines,
  "PCN": Flag_Pitcairn,
  "POL": Flag_Poland,
  "PRT": Flag_Portugal,
  "PRI": Flag_PuertoRico,
  "QAT": Flag_Qatar,
  // "REU": null,
  "ROM": Flag_Romania,
  "RUS": Flag_Russia,
  "RWA": Flag_Rwanda,
  "SHN": Flag_SaintHelena,
  "WSM": Flag_Samoa,
  "SMR": Flag_sanMarino,
  "STP": Flag_SaoTomeAndPrince,
  "SAU": Flag_SaudiArabia,
  "SEN": Flag_Senegal,
  "SRB": Flag_Serbia,
  "SYC": Flag_Seychelles,
  "SLE": Flag_Leone,
  "SGP": Flag_Singapore,
  "SVK": Flag_Slovakia,
  "SVN": Flag_Slovenia,
  "SLB": Flag_SolomonIslands,
  "SOM": Flag_Somalia,
  "ZAF": Flag_SouthAfrica,
  // "SGS": null,
  "ESP": Flag_Spain,
  "LKA": Flag_SriLanka,
  "KNA": Flag_StKittsAndNevis,
  "LCA": Flag_StLucia,
  // "SPM": null,
  "VCT": Flag_StVincentAndTheGrenadines,
  "SDN": Flag_Sudan,
  "SUR": Flag_Suriname,
  "SJM": Flag_SvalbardAndJanMayen,
  "SWZ": Flag_Swaziland,
  "SWE": Flag_Sweden,
  "CHE": Flag_Switzerland,
  "SYR": Flag_Syria,
  "TWN": Flag_Taiwan,
  "TJK": Flag_Tajikistan,
  "TZA": Flag_Tanzania,
  "THA": Flag_Thailand,
  "TLS": Flag_TimorLeste,
  "TGO": Flag_Togo,
  "TKL": Flag_Tokelau,
  "TON": Flag_Tonga,
  "TTO": Flag_TrinidadAndTobago,
  "TUN": Flag_Tunisia,
  "TUR": Flag_Turkey,
  "TKM": Flag_Turkmenistan,
  "TCA": Flag_TurksAndCaicos,
  "TUV": Flag_Tuvalu,
  "UGA": Flag_Uganda,
  "UKR": Flag_Ukraine,
  "ARE": Flag_UnitedArabEmirates,
  "GBR": Flag_UnitedKingdom,
  "USA": Flag_UnitedStates,
  // "UMI": null,
  "VIR": Flag_UnitedStatesVirginIslands,
  "URY": Flag_Uruguay,
  "UZB": Flag_Uzbekistan,
  "VUT": Flag_Vanuatu,
  "VEN": Flag_Venezuela,
  "VNM": Flag_Vietnam,
  "WLF": Flag_WallisAndFutuna,
  "ESH": Flag_WesternSahara,
  "YEM": Flag_Yemen,
  "ZMB": Flag_Zambia,
  "ZWE": Flag_Zimbabwe,
};
