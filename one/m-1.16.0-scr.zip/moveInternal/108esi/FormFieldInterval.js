import React, { useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { useFormikContext } from 'formik';
import Moment from 'moment';
import dayjs from 'dayjs';

import { colors } from 'configs';
import { getDisplayFrequencybyKey, getDurationFormatbyKey } from 'constant';
import { Divider } from 'atoms';
import { Text } from '../text';
import { TextInput } from './TextInput';
import { useTranslation } from 'react-i18next';
import { utc8DateTime } from 'utils';
import quarterOfYear from 'dayjs/plugin/quarterOfYear';

dayjs.extend(quarterOfYear);

const numberRegex = /^[1-9]\d{0,2}$/;

const LANG_PREFIX = 'screens.componentConfirmation.text.';

export const FormFieldInterval = ({
  label = null,
  name,
  maxLength,
  frequency,
  dateFormat,
  maxOccurrence = 60,
  ...otherProps
}) => {
  const { t } = useTranslation();

  const { setFieldValue, values } = useFormikContext();

  const [note, setNote] = useState('');
  const [isError, setIsError] = useState(false);

  useEffect(() => {
    constructNote();
  }, [values[name], values.date, frequency]);

  const showError = msg => {
    setNote(msg);
    setIsError(true);
  };

  const constructNote = () => {
    const isValid = numberRegex.test(values[name]);
    if (!isValid) return showError(t(LANG_PREFIX + 'msgIntervalRegex'));
    if (values[name] > maxOccurrence)
      return showError(t(LANG_PREFIX + 'msgIntervalMaximum').replace('${max}', maxOccurrence));

    const durationFormat = getDurationFormatbyKey(frequency);
    const todayTran = dayjs(values.date, dateFormat).isSame(utc8DateTime(), 'day');
    const multiply = frequency === 'HALFYEARLY' ? 6 : 1;

    // Future dated transfer is calculated as 1 occurence, therefore total occurences must decrease once
    const interval = values[name] * multiply - (todayTran ? 0 : multiply);
    if (interval === 0) return showError(t(LANG_PREFIX + 'msgIntervalMin'));

    const endDate = dayjs(values.date, dateFormat).add(interval, durationFormat);

    const displayDate = date => {
      const momentDate = Moment(date, dateFormat);
      return momentDate.calendar({
        sameDay: `[${t(LANG_PREFIX + 'intervalDateToday')}]`,
        nextDay: `[${t(LANG_PREFIX + 'intervalDateTomorrow')}]`,
        nextWeek: dateFormat,
        sameElse: dateFormat,
      });
    };
    setNote(
      t(LANG_PREFIX + 'intervalNote')
        .replace('${frequency}', t(getDisplayFrequencybyKey(frequency)))
        .replace('${startDate}', displayDate(values.date))
        .replace('${endDate}', displayDate(endDate.format(dateFormat))),
    );
    setIsError(false);
  };

  return (
    <>
      <View style={styles.container}>
        <Text style={{ fontSize: 14, color: colors.medium }}>{label}</Text>
        <TextInput
          bold
          onChangeText={text => setFieldValue(name, text)}
          value={values[name]}
          maxLength={maxLength}
          style={styles.input}
          {...otherProps}
        />
      </View>
      <Divider />
      <Text style={[styles.notes, isError && { color: colors.primary }]}>{note}</Text>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  input: {
    borderBottomWidth: 0,
    textAlign: 'right',
  },
  notes: {
    fontSize: 13,
    color: colors.medium,
    marginVertical: 10,
  },
});

export default FormFieldInterval;
