import { createSlice } from '@reduxjs/toolkit';
import { payLoanEnquireName, submitLoanPayment } from './thunk';

const initialState = {
  newLoanPayment: {
    fromAcc: null,
    toAcc: null,
    noteNo: null,
    amount: 0,
    currency: null,
    favName: null,
  },
  nameInquiry: {
    status: 'idle',
    errMsg: null,
  },
  recent: [],
};

const slice = createSlice({
  name: 'loanPayment',
  initialState,
  reducers: {
    loanPaymentReset: _ => initialState,
    loanPaymentInit: state => {
      state.newLoanPayment = initialState.newLoanPayment;
      state.nameInquiry = initialState.nameInquiry;
    },
    loanPaymentNameInquiryInit: state => {
      state.nameInquiry = initialState.nameInquiry;
    },
    updateNewLoanPaymentObject: (state, { payload }) => {
      for (const key in payload) {
        state.newLoanPayment[key] = payload[key];
      }
    },
    loanPaymentRecentUpdated: (state, { payload }) => {
      state.recent = payload;
    },
    payLoanNameInquiryUpdated: (state, { payload }) => {
      state.nameInquiry.status = payload.status;
      state.nameInquiry.errMsg = payload.errMsg;
    },
  },
  extraReducers: builder => {
    builder.addCase(payLoanEnquireName.fulfilled, (state, { payload }) => {
      state.nameInquiry.status = 'succeeded';
      state.nameInquiry.errMsg = null;
      state.newLoanPayment.name = payload.beneName;
      state.newLoanPayment.accountType = payload.accountType;
      state.newLoanPayment.beneProductType = payload?.beneProductType;
    });
    builder.addCase(payLoanEnquireName.rejected, (state, { payload }) => {
      state.nameInquiry.status = 'failed';
      state.nameInquiry.errMsg = payload?.status + ': ' + payload.data?.message;
    });
    builder.addCase(submitLoanPayment.fulfilled, (state, { payload }) => {
      state.newLoanPayment.referenceNo = payload.refNo;
      state.newLoanPayment.tranDateTime = payload.tranDateTime;
      state.newLoanPayment.isESISuccess = payload.isESISuccess;
      state.newLoanPayment.availableBalance = payload.availableBalance;
    });
  },
});

export const {
  loanPaymentReset,
  loanPaymentInit,
  updateNewLoanPaymentObject,
  loanPaymentRecentUpdated,
  payLoanNameInquiryUpdated,
} = slice.actions;

export default slice.reducer;
