import { HIRE_PURCHASE_ACC_TYPE } from 'screens/accounts/constant/loan';

export const getRecurringMaxOccurrence = ({ frequency, accCategory }) => {
  if (frequency === 'MONTHLY' && accCategory === HIRE_PURCHASE_ACC_TYPE) {
    return {
      esiMaxOccurrence: 108,
      esiMaxLength: 3,
    };
  }
  return {
    esiMaxOccurrence: 60,
    esiMaxLength: 2,
  };
};
