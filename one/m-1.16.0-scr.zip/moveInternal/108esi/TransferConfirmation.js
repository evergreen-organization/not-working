import React, { useEffect, useRef, useState } from 'react';
import { Alert, Image, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';

import {
  encodeEmail,
  getRecurringMaxOccurrence,
  HelpButtonAccessibility,
  replaceUnrecognizedSymbol,
  showFailure,
  showInfo,
  utc8DateTime,
} from 'utils';
import { TranSigner } from 'softToken';
import {
  ApiDateFormat,
  checkTransModeDuitNow,
  checkTransModeDuitNowTransfer,
  checkTransModeIBG,
  checkTransModeOwn,
  checkTransModePBB,
  displayDateFormat,
  duitnowIdType,
  duitNowRegex,
  esiFrequency,
  favouriteType,
  findDuitnowIcon,
  findDuitnowIdTypeName,
  findTransferAccTypeName,
  findTransferModeName,
  getKeyByValue,
  HOST_ERROR,
  ibgIdType,
  ibgIdTypeList,
  ibgRegex,
  mobileRegex,
  numericRegex,
  tncCategory,
  tranApiType,
  validationMsg,
  emailRegex,
  duitnowTransIdTypeList,
  duitnowTransIdType,
  checkIdInfo,
  checkAccTypeCASA,
  helpContent,
} from 'constant';
import {
  fromAccountUpdated,
  getCountryNameByCode,
  getFavouriteList,
  getFundTransfer,
  getNameInquiryStatus,
  getServiceFee,
  getSoftToken,
  getTncByTag,
  ibgBeneIdTypeUpdated,
  ibgBeneIdUpdated,
  nameInquiry,
  nameInquiryStatusUpdated,
  referenceUpdated,
} from 'stores';
import { colors, tagColors } from 'configs';
import routes from 'navigations/routes';
import { useApi, usePing, usePostGuard } from 'hooks';
import { AvoidKeyboard, Divider, Flex, LinkText, ScreenFull, SkeletonBar, Space } from 'atoms';
import {
  BankLogo,
  BottomDrawerModalMini,
  FormFieldInvisible,
  MoreLess,
  TableItemButton,
  TableItemTag,
  TnCModal,
  FormCheckBoxWithReturn,
  DynamicConstant,
} from 'molecules';
import { CasaTab, FormFieldInterval, NavBar, Notes } from 'organisms';
import { Form, FormDateCalendarPicker, FormPaymentBtn, FormTableField, Money, Tag, Text } from 'components';
import { FAIL, IDLE, LOADING, SUCCESS } from 'apis';

import DuitNowIcon from 'assets/images/corporation/duitnowfull.png';
import RightIcon from 'assets/images/icon/right.png';
import HelpIcon from 'assets/images/icon/help.png';
import { BeneIdTypeFormPicker } from './components';

const max_length = 20;
const max_length_paymentDetail_duitNow = 140;
const max_length_email = 40;
const max_length_mobile = 11;
const max_length_beneName = 40;

const esiFrequencyArr = Object.entries(esiFrequency).filter(a => a[1] !== esiFrequency.ONE);
let secfaInfo;

const LANG_PREFIX = 'screens.fundTransferConfirmation.text.';
const LANG_PREFIX_FREQUENCY = 'constant.ESI_FREQUENCY.';
const LANG_PREFIX_VALIDATION = 'constant.validationMsg.';

export const TransferConfirmation = ({ navigation }) => {
  const { t } = useTranslation();
  const formRef = useRef();
  const noteItem1 = { title: t(LANG_PREFIX + 'notePidmTIPS') };
  usePostGuard();
  const { pingPrivate } = usePing();
  const today = utc8DateTime().format(displayDateFormat);
  const dispatch = useDispatch();
  const fundTransfer = useSelector(getFundTransfer);
  const store_favourite = useSelector(getFavouriteList);
  const softToken = useSelector(getSoftToken);
  const { ibgFee, duitNowTransferFee, duitNowFee, beneSmsFee, duitNowOnUsFee } = useSelector(getServiceFee) || {};
  const nameInquiryStatus = useSelector(getNameInquiryStatus);
  const countryName = useSelector(getCountryNameByCode(fundTransfer?.country));
  const nameInquiryApi = useApi(nameInquiry);
  const helpModalContent = checkIdInfo(t, LANG_PREFIX);

  const [isRecurring, setIsRecurring] = useState(false);
  const [fromAccModalVisible, setFromAccModalVisible] = useState(false);
  const [isFrequencyModalVisible, setIsFrequencyModalVisible] = useState(false);
  const [modalHelpVisible, setModalHelpVisible] = useState(false);
  const [isNotified, setIsNotified] = useState(false);
  const [submissionLoading, setSubmissionLoading] = useState(false);
  const [modalHelpText, setModalHelpText] = useState(false);
  const [frequency, setFrequency] = useState(getKeyByValue(esiFrequency, esiFrequency.DAILY));
  const [isPDFVisible, setIsPDFVisible] = useState(false);
  const [noteItems, setNoteItems] = useState([noteItem1]);

  const tranSignerRef = useRef();

  const { status } = nameInquiryStatus;

  const {
    fromAcc,
    toAcc,
    name,
    isDuitNowOnUs,
    favName,
    transferMode,
    idType,
    currency,
    amount,
    reference,
    selectedBankId,
    selectedBankName,
    ibgBeneIdType,
    ibgBeneId,
    country,
    ibgFav,
    beneProductType,
  } = fundTransfer;
  const isFavourite = store_favourite?.findIndex(x => x.accNo === toAcc) !== -1;
  const transferModeName = t(findTransferModeName(transferMode));
  const isDuitNowTransferMode = checkTransModeDuitNowTransfer(transferMode);
  const isDuitNowMode = checkTransModeDuitNow(transferMode);
  const isIBGMode = checkTransModeIBG(transferMode);
  const isPBBMode = checkTransModePBB(transferMode);
  const isOwnMode = checkTransModeOwn(transferMode);
  const isCASAType = checkAccTypeCASA(idType);
  const { name: tncName, url: tncUrl } = useSelector(getTncByTag({ tag: tncCategory.DUITNOW_TRANSFER })) || {};
  const refValidation =
    isDuitNowTransferMode || isDuitNowMode
      ? { regex: duitNowRegex, msg: t(validationMsg.duitNow) }
      : { regex: ibgRegex, msg: t(validationMsg.ibg) };

  /*bene id for duitNow and IBG*/
  const BENE_ID_TYPE_CONSTANT = isDuitNowTransferMode ? duitnowTransIdType : ibgIdType;
  const defaultBeneIdValidation = ibgBeneIdType
    ? BENE_ID_TYPE_CONSTANT[ibgBeneIdType]?.validation
    : {
        regex: numericRegex,
        msg: t(validationMsg.numeric),
        max: 12,
        min: 12,
      };
  const isSaveAsSameMode = () => {
    // saved as duitNow transfer favourite, duitNow transfer mode available and casa account can auto populate beneIdValidation
    if (!ibgFav && isDuitNowTransferMode && isCASAType) return true;

    if (ibgFav && isIBGMode) return true;
  };
  const isAutoPopulateBeneIdValidation = !!ibgBeneIdType && !!ibgBeneId && isSaveAsSameMode();
  const { esiMaxOccurrence, esiMaxLength } = getRecurringMaxOccurrence({
    frequency,
    accCategory: beneProductType,
  });

  const [recipientIdValidation, setRecipientIdValidation] = useState(defaultBeneIdValidation);
  const [isBeneIdChecked, setIsBeneIdChecked] = useState(isAutoPopulateBeneIdValidation);
  const [othersVisible, setOthersVisible] = useState(false);

  const validationSchema = Yup.object().shape({
    paymentDetail: Yup.string()
      .notRequired()
      .max(
        140,
        `${LANG_PREFIX_VALIDATION}maxLength`
          .replace('${label}', t(`${LANG_PREFIX}paymentDetail`))
          .replace('${maxLength}', 140),
      )
      .label(t(`${LANG_PREFIX}paymentDetail`))
      .nullable()
      .matches(refValidation?.regex, refValidation?.msg),
    isRecurring: Yup.boolean().notRequired(),
    interval: Yup.number()
      .notRequired()
      .nullable()
      .label(t(`${LANG_PREFIX}itemNumOccurrences`))
      .when('isRecurring', {
        is: true,
        then: Yup.number()
          .typeError(t(`${LANG_PREFIX_VALIDATION}numberOnly`))
          .min(
            1,
            t(`${LANG_PREFIX_VALIDATION}minAmount`)
              .replace('${label}', t(`${LANG_PREFIX}itemNumOccurrences`))
              .replace('${minAmount}', 1),
          )
          .required(t(validationMsg.required)),
      }),
    email: Yup.string()
      .trim(t(`${LANG_PREFIX_VALIDATION}spaceNotAllow`))
      .strict()
      .notRequired()
      .nullable()
      .label(t(`${LANG_PREFIX}email`))
      .min(
        1,
        t(`${LANG_PREFIX_VALIDATION}minLength`)
          .replace('${label}', t(`${LANG_PREFIX}email`))
          .replace('${minLength}', 1),
      )
      .matches(emailRegex, t(`${LANG_PREFIX_VALIDATION}email`)),
    mobile: Yup.string()
      .trim(t(`${LANG_PREFIX_VALIDATION}spaceNotAllow`))
      .strict()
      .notRequired()
      .nullable()
      .label(t(`${LANG_PREFIX}mobileNo`))
      .min(
        8,
        t(`${LANG_PREFIX_VALIDATION}minLength`)
          .replace('${label}', t(`${LANG_PREFIX}mobileNo`))
          .replace('${minLength}', 8),
      )
      .max(
        11,
        t(`${LANG_PREFIX_VALIDATION}maxLength`)
          .replace('${label}', t(`${LANG_PREFIX}mobileNo`))
          .replace('${maxLength}', 11),
      )
      .matches(mobileRegex, t(`${LANG_PREFIX}mobileNoOnly`)),
    isIBGMode: Yup.boolean().notRequired(),
    beneName: Yup.string()
      .notRequired()
      .nullable()
      .label(t(`${LANG_PREFIX}recipientName`))
      .when('isIBGMode', {
        is: true,
        then: Yup.string()
          .nullable()
          .required(t(`${LANG_PREFIX}recipientNameRequired`))
          .min(
            3,
            t(`${LANG_PREFIX_VALIDATION}minLength`)
              .replace('${label}', t(`${LANG_PREFIX}recipientName`))
              .replace('${minLength}', 3),
          )
          .max(
            max_length_beneName,
            t(`${LANG_PREFIX_VALIDATION}maxLength`)
              .replace('${label}', t(`${LANG_PREFIX}recipientName`))
              .replace('${maxLength}', max_length_beneName),
          )
          .matches(refValidation?.regex, refValidation?.msg),
      }),
    beneIdChecked: Yup.boolean().notRequired(),
    beneIdType: Yup.string()
      .notRequired()
      .nullable()
      .when('beneIdChecked', {
        is: true,
        then: Yup.string()
          .nullable()
          .required(t(`${LANG_PREFIX_VALIDATION}required`)),
      }),
    beneID: Yup.string()
      .notRequired()
      .nullable()
      .label(t(`${LANG_PREFIX}idNo`))
      .when('beneIdChecked', {
        is: true,
        then: Yup.string()
          .nullable()
          .required(t(`${LANG_PREFIX_VALIDATION}required`))
          .matches(recipientIdValidation?.regex, t(recipientIdValidation?.msg))
          .min(
            recipientIdValidation?.min,
            t(`${LANG_PREFIX_VALIDATION}minLength`)
              .replace('${label}', t(`${LANG_PREFIX}idNo`))
              .replace('${minLength}', recipientIdValidation?.min),
          )
          .max(
            recipientIdValidation?.max,
            t(`${LANG_PREFIX_VALIDATION}maxLength`)
              .replace('${label}', t(`${LANG_PREFIX}idNo`))
              .replace('${maxLength}', recipientIdValidation?.max),
          ),
      }),
  });

  const initialValues = {
    date: today,
    paymentDetail: null,
    interval: null,
    endDate: null,
    email: '',
    mobile: '',
    beneID: isAutoPopulateBeneIdValidation ? ibgBeneId : null,
    beneIdType: isAutoPopulateBeneIdValidation ? ibgBeneIdType : null,
    beneName: name,
    beneIdChecked: isAutoPopulateBeneIdValidation,
  };

  useEffect(() => {
    start();
  }, []);

  const start = () => {
    // if ((isDuitNowTransferMode || isIBGMode) && idType !== transferAccType.CASA.key) {
    // eSMR2024-305 show PDIM acknowledgement for all send money screens except own PBB acc
    if (!isOwnMode) {
      setNoteItems([
        noteItem1,
        {
          title: t(LANG_PREFIX + 'notePidm'),
        },
      ]);
    }

    if (!fromAcc && toAcc !== softToken.preferredAccountNo && softToken.preferredAccountActive) {
      dispatch(fromAccountUpdated(softToken.preferredAccountNo));
    }

    if (status === IDLE || status === FAIL) inquireName();
  };

  const inquireName = async () => {
    dispatch(nameInquiryStatusUpdated({ status: LOADING }));
    const privateSession = await pingPrivate();

    let bene = null;
    if (isDuitNowMode) {
      bene = {
        type: favouriteType.DUITNOW,
        proxyType: idType,
        proxyValue: toAcc,
        proxyCountry: country,
      };
    } else if (isDuitNowTransferMode) {
      bene = {
        type: favouriteType.OTHER,
        beneAccNo: toAcc,
        beneAccType: idType,
        beneBankId: selectedBankId,
        amount: amount,
      };
    } else if (isPBBMode) {
      bene = {
        type: favouriteType.PBB,
        beneAccNo: toAcc,
      };
    }

    checkRPP(bene, !privateSession);
  };

  const checkRPP = async (bene, isPublic) => {
    if (!bene) return dispatch(nameInquiryStatusUpdated({ status: SUCCESS }));
    const result = await nameInquiryApi.request({ isPublic, bene });
    if (result.status === HOST_ERROR || result.status === 'E00059')
      return Alert.alert('', result.problem, [{ text: 'OK', onPress: () => navigation.navigate(routes.MAIN_TAB) }]);
    if (result.problem) showFailure(result.problem);
  };

  const onStartCheckSecfa = () => setSubmissionLoading(true);
  const cancelPay = () => setSubmissionLoading(false);

  const onNotifySelected = val => {
    setIsNotified(val);
    // if (!val) {
    //   setByEmail(false)
    //   setBySMS(false)
    // }
  };

  const onSubmit = async ({ paymentDetail, interval, date, email, mobile, beneID, beneName, beneIdType }) => {
    const intervalInt = parseInt(interval);

    secfaInfo = {
      tranType: 'SEND_MONEY',
      sendMoneyType: transferMode,
      isFavourite,
      amount,
      tranDate: dayjs(date, displayDateFormat).format(ApiDateFormat),
      fromAccNo: fromAcc,
      currency,
    };

    if (!fromAcc) return showFailure(t(LANG_PREFIX + 'errorFromAccRequired'));

    if (isNotified) {
      if (!email && !mobile) return showInfo(t(LANG_PREFIX + 'infoNotify'));
      if (mobile?.length !== 0) secfaInfo.sms = mobile;
      if (email?.length !== 0) {
        secfaInfo.email = encodeEmail(email);
        secfaInfo.isEmailEncoded = true;
      }
    }
    setSubmissionLoading(true);

    if (!isDuitNowMode) secfaInfo.beneAccNo = toAcc;
    if (!isOwnMode) {
      const formattedRecipientRef = replaceUnrecognizedSymbol(reference);
      dispatch(referenceUpdated(formattedRecipientRef));
      secfaInfo.recipientRef = formattedRecipientRef;
      const trimmedPaymentDetail = paymentDetail?.trim() ?? null;
      if (trimmedPaymentDetail) secfaInfo.otherPaymentDetails = replaceUnrecognizedSymbol(trimmedPaymentDetail);
    }

    let trxInfo = {
      accNo: toAcc,
      beneName: name,
      amount,
      currency,
      transferMode,
      idType,
    };

    if (isDuitNowMode) {
      secfaInfo.proxyType = idType;
      secfaInfo.proxyValue = toAcc;
      secfaInfo.proxyCountry = country;
    } else if (isDuitNowTransferMode) {
      secfaInfo.beneAccType = idType;
      secfaInfo.beneBankId = selectedBankId;
      secfaInfo.ibgBeneficiaryType = beneIdType;
      secfaInfo.ibgBeneficiaryId = beneID;
    } else if (isIBGMode) {
      if (beneName.trim().length === 0) {
        showFailure(t(LANG_PREFIX + 'errorEnterRecipientName'));
        return setSubmissionLoading(false);
      }
      const formattedIBGBeneName = replaceUnrecognizedSymbol(beneName.trim());
      secfaInfo.beneName = formattedIBGBeneName;
      secfaInfo.beneAccType = idType;
      secfaInfo.beneBankId = selectedBankId;
      secfaInfo.ibgBeneficiaryType = beneIdType;
      secfaInfo.ibgBeneficiaryId = beneID;
      trxInfo.beneName = formattedIBGBeneName;
    }

    if (isRecurring && intervalInt > 0) {
      if (intervalInt > esiMaxOccurrence) return setSubmissionLoading(false);

      // Future dated transfer is calculated as 1 occurence, therefore occurence input must be at least 2
      const todayTran = dayjs(date, displayDateFormat).isSame(utc8DateTime(), 'day');
      if (!todayTran && intervalInt === 1) return setSubmissionLoading(false);

      secfaInfo.frequency = frequency;
      secfaInfo.occurence = intervalInt;
    }

    tranSignerRef.current.checkSecfa({
      secfaInfo,
      onSubmitParam: { fromAcc },
      onSuccessParam: { secfaInfo },
      trxInfo,
    });
  };

  const onFrequencySelect = item => {
    setFrequency(item);
    setIsFrequencyModalVisible(false);
  };

  const onFromAccountChange = item => {
    dispatch(fromAccountUpdated(item.accountNo));
    setFromAccModalVisible(false);
  };

  const getIdType = () => {
    if (isDuitNowMode) return t(findDuitnowIdTypeName(idType));
    return selectedBankName;
  };

  const renderHeaderTag = () => {
    if (isOwnMode)
      return <Tag title={t(LANG_PREFIX + 'headerTagSelf')} color={tagColors.grey} style={{ marginRight: 0 }} />;
    if (isFavourite)
      return <Tag title={t(LANG_PREFIX + 'headerTagFavourite')} color={tagColors.grey} style={{ marginRight: 0 }} />;
  };

  const renderName = () => {
    if (isIBGMode || status === IDLE) return;
    if (status === LOADING)
      return (
        <View style={{ marginLeft: -8 }}>
          <SkeletonBar title={true} height={20} color={colors.lightgrey} />
        </View>
      );

    if (status === FAIL)
      return <Text style={[styles.selectedText, { marginBottom: 5 }]}>{t(LANG_PREFIX + 'errorGettingName')}</Text>;
    if (isDuitNowMode || isDuitNowTransferMode || isPBBMode)
      return (
        <Text bold style={{ fontSize: 14, marginBottom: 5 }}>
          {name}
        </Text>
      );
    if (isOwnMode)
      return (
        <Text bold style={{ fontSize: 14, marginBottom: 5 }}>
          {favName}
        </Text>
      );
  };

  const isPaymentDisabled = () => {
    if (fromAcc === toAcc) return true;
    if (submissionLoading) return true;
    if (isIBGMode) return false;
    if (status !== SUCCESS) return true;
    return false;
  };

  const renderFee = () => {
    const title = t(LANG_PREFIX + 'itemFee');
    if (isIBGMode) return <TableItemTag title={title} value={ibgFee} currency={currency} />;

    if (status === SUCCESS) {
      if (isDuitNowOnUs) return <TableItemTag title={title} value={duitNowOnUsFee} currency={currency} />;
      if (isDuitNowTransferMode) return <TableItemTag title={title} value={duitNowTransferFee} currency={currency} />;
      if (isDuitNowMode) return <TableItemTag title={title} value={duitNowFee} currency={currency} />;
    }
  };

  const onBeneIDChecking = val => {
    setIsBeneIdChecked(val);
    if (!val) {
      dispatch(ibgBeneIdTypeUpdated(null));
      formRef?.current?.setFieldValue('beneIdType', null);
      formRef?.current?.setFieldValue('beneID', null);
    }
  };

  const onSelectBeneIdType = key => {
    if (key !== ibgBeneIdType) formRef?.current?.setFieldValue('beneID', null);
    dispatch(ibgBeneIdTypeUpdated(key));
    dispatch(ibgBeneIdUpdated(''));
    setRecipientIdValidation(BENE_ID_TYPE_CONSTANT[key]?.validation);
  };

  const onInputBeneId = val => {
    dispatch(ibgBeneIdUpdated(val));
  };

  const openModalHelp = text => {
    setModalHelpText(text);
    setModalHelpVisible(true);
  };

  const closeModalHelp = () => setModalHelpVisible(false);

  const handleFromAccModalVisible = () => setFromAccModalVisible(!fromAccModalVisible);

  const handleOthersVisible = () => setOthersVisible(!othersVisible);

  const handleFrequencyModalVisible = () => setIsFrequencyModalVisible(!isFrequencyModalVisible);

  const handlePDFVisible = () => setIsPDFVisible(!isPDFVisible);

  const renderPIDMNote = () => (
    <Notes
      data={[
        {
          title: t(LANG_PREFIX + 'itemNote'),
          list: noteItems,
        },
      ]}
    />
  );

  return (
    <>
      <ScreenFull>
        <NavBar
          title={t(LANG_PREFIX + 'title')}
          back
          showShadow={true}
          bottom={
            <View style={styles.headerBlock}>
              {selectedBankId !== null ? (
                <BankLogo id={selectedBankId} name={selectedBankName} size={30} />
              ) : (
                <Image source={findDuitnowIcon(idType)} style={styles.icon2} />
              )}
              <View style={styles.headerField}>
                {renderName()}
                <Text style={styles.itemIdType}>{getIdType()}</Text>
                <Text style={styles.itemName}>{toAcc}</Text>
              </View>
              {renderHeaderTag()}
            </View>
          }
        />

        <AvoidKeyboard>
          <Form
            ref={formRef}
            initialValues={initialValues}
            onSubmit={onSubmit}
            validationSchema={validationSchema}
            enableReinitialize={false}
            button={
              <FormPaymentBtn
                disabled={isPaymentDisabled()}
                loading={submissionLoading}
                title={t(LANG_PREFIX + 'buttonSend')}
                amount={<Money amount={amount} currency={currency} size={18} color={colors.primary} />}
                desc={
                  (isDuitNowMode || isDuitNowTransferMode) && (
                    <>
                      <Divider />
                      <View style={styles.tncBlock}>
                        <LinkText
                          preLinkText={t(LANG_PREFIX + 'tncLinkText1')}
                          linkText={t(LANG_PREFIX + 'tncLinkText2')}
                          postLinkText={t(LANG_PREFIX + 'tncLinkText3').replace(
                            '${transferModeName}',
                            transferModeName,
                          )}
                          onPress={handlePDFVisible}
                          style={styles.tncText}
                        />
                      </View>
                    </>
                  )
                }
              />
            }
          >
            <FormFieldInvisible name='isIBGMode' mode={isIBGMode} />
            <Space />
            <View style={styles.form}>
              <TableItemButton
                title={t(LANG_PREFIX + 'itemFromAccount')}
                value={fromAcc}
                onPress={handleFromAccModalVisible}
              />
              <Divider />
              <View style={styles.detailBlock}>
                <Text numberOfLines={1} style={styles.itemName}>
                  {t(LANG_PREFIX + 'itemTransferDate')}
                </Text>
                <FormDateCalendarPicker name={'date'} showRightIcon={true} style={styles.calendar} />
              </View>
              <Divider />
              <TableItemTag
                title={t(LANG_PREFIX + 'itemTransferMethod')}
                value={transferModeName}
                {...((isDuitNowMode || isDuitNowTransferMode) && { icon: DuitNowIcon })}
                isLast={isOwnMode}
              />

              {(isDuitNowTransferMode || isIBGMode) && (
                <TableItemTag
                  title={t(LANG_PREFIX + 'itemRecipientAccType')}
                  value={t(findTransferAccTypeName(idType))}
                />
              )}
              {renderFee()}
              {reference && (
                <TableItemTag
                  title={t(LANG_PREFIX + 'itemRecipientRef')}
                  value={reference}
                  isLast={!isIBGMode && idType !== duitnowIdType.PASSPORT.key}
                />
              )}
              {isIBGMode && (
                <FormTableField
                  label={t(LANG_PREFIX + 'itemRecipientName')}
                  name='beneName'
                  autoCapitalize='none'
                  maxLength={max_length_beneName}
                  onHelp={() => openModalHelp(helpContent.BENE_NAME)}
                  placeholder={t(LANG_PREFIX + 'placeholderEnterName')}
                />
              )}
              {idType === duitnowIdType.PASSPORT.key && (
                <TableItemTag title={t(LANG_PREFIX + 'itemCountry')} value={countryName} isLast={true} />
              )}
            </View>

            <Space />
            {(isIBGMode || (isDuitNowTransferMode && isCASAType)) && (
              <>
                <View style={styles.othersBlock}>
                  <View style={styles.detailBlock}>
                    <Flex style={styles.detailField}>
                      <Text numberOfLines={1} style={styles.itemName}>
                        {t(LANG_PREFIX + 'itemIdCheck')}
                      </Text>
                      <TouchableOpacity
                        {...HelpButtonAccessibility}
                        style={styles.helpButton}
                        onPress={() => openModalHelp(helpContent.BENE_ID)}
                      >
                        <Image source={HelpIcon} style={styles.helpIcon} />
                      </TouchableOpacity>
                    </Flex>
                    <FormCheckBoxWithReturn name='beneIdChecked' onReturn={val => onBeneIDChecking(val)} />
                  </View>
                  {isBeneIdChecked && (
                    <>
                      <View style={styles.subDetailBlock}>
                        <BeneIdTypeFormPicker
                          name={'beneIdType'}
                          data={isIBGMode ? ibgIdTypeList : duitnowTransIdTypeList}
                          label={t(LANG_PREFIX + 'itemIdType')}
                          onChange={onSelectBeneIdType}
                        />
                        <FormTableField
                          label={t(LANG_PREFIX + 'itemIdNo')}
                          name='beneID'
                          autoCapitalize='none'
                          maxLength={20}
                          placeholder={t(LANG_PREFIX + 'placeholderIdNo')}
                          onChange={onInputBeneId}
                        />
                      </View>
                    </>
                  )}
                </View>
                <Space />
              </>
            )}

            <MoreLess status={othersVisible} onPress={handleOthersVisible} />

            {othersVisible && (
              <View style={styles.othersBlock}>
                <Divider style={styles.divider} />
                {!isOwnMode && !isPBBMode && (
                  <>
                    <FormTableField
                      label={t(LANG_PREFIX + 'itemOtherDetails')}
                      name='paymentDetail'
                      autoCapitalize='none'
                      maxLength={isIBGMode ? max_length : max_length_paymentDetail_duitNow}
                      placeholder={t(LANG_PREFIX + 'placeholderOtherDetailsOptional')}
                    />
                    <Divider />
                  </>
                )}

                <View style={styles.detailBlock}>
                  <Text numberOfLines={1} style={styles.itemName}>
                    {t(LANG_PREFIX + 'itemSetRecurring')}
                  </Text>
                  <FormCheckBoxWithReturn name='isRecurring' onReturn={val => setIsRecurring(val)} />
                </View>
                {isRecurring && (
                  <View style={styles.subDetailBlock}>
                    <View style={styles.detailBlock}>
                      <Text numberOfLines={1} style={styles.itemName}>
                        {t(LANG_PREFIX + 'itemFrequency')}
                      </Text>
                      <TouchableOpacity style={styles.subDetailField} onPress={handleFrequencyModalVisible}>
                        <Text style={styles.selectedText}>{t(LANG_PREFIX_FREQUENCY + frequency)}</Text>
                        <Image source={RightIcon} style={styles.rightIcon} />
                      </TouchableOpacity>
                    </View>
                    <Divider />
                    <FormFieldInterval
                      label={t(LANG_PREFIX + 'itemNumOccurrences')}
                      name='interval'
                      placeholder={t(LANG_PREFIX + 'placeholderNumOccurrences')}
                      frequency={frequency}
                      dateFormat={displayDateFormat}
                      keyboardType='numeric'
                      maxLength={esiMaxLength}
                      maxOccurrence={esiMaxOccurrence}
                    />
                  </View>
                )}

                {!isOwnMode && !isDuitNowMode && (
                  <>
                    <Divider />
                    <View>
                      <View style={styles.detailBlock}>
                        <Text numberOfLines={1} style={styles.itemNotify}>
                          {t(LANG_PREFIX + 'itemNotify')}
                        </Text>
                        <FormCheckBoxWithReturn
                          name='isNotified'
                          onReturn={val => onNotifySelected(val)}
                          clearOnUntick={['byEmail', 'bySMS']}
                        />
                      </View>
                      {isNotified && (
                        <View style={styles.subDetailBlock}>
                          <FormTableField
                            label={t(LANG_PREFIX + 'itemEmail')}
                            name='email'
                            autoCapitalize='none'
                            maxLength={max_length_email}
                            placeholder={t(LANG_PREFIX + 'placeholderEmail')}
                          />
                          <Divider />
                          <FormTableField
                            label={t(LANG_PREFIX + 'itemSMS').replace('${beneSmsFee}', beneSmsFee?.toFixed(2))}
                            name='mobile'
                            autoCapitalize='none'
                            maxLength={max_length_mobile}
                            placeholder={t(LANG_PREFIX + 'placeholderPhone')}
                            keyboardType={'number-pad'}
                          />
                        </View>
                      )}
                    </View>
                  </>
                )}
              </View>
            )}
            {renderPIDMNote()}
          </Form>
        </AvoidKeyboard>
      </ScreenFull>

      <BottomDrawerModalMini
        variant={BottomDrawerModalMini.variants.modalize}
        isVisible={fromAccModalVisible}
        closeModal={handleFromAccModalVisible}
      >
        <CasaTab mini fromAcc={fromAcc} excludedAcc={toAcc} onAccountChange={onFromAccountChange} />
      </BottomDrawerModalMini>

      <BottomDrawerModalMini isVisible={isFrequencyModalVisible} closeModal={handleFrequencyModalVisible}>
        <>
          <View style={styles.drawerTitle}>
            <Text style={styles.drawerTitleText}>{t(LANG_PREFIX + 'itemFrequency')}</Text>
          </View>
          <ScrollView>
            {esiFrequencyArr.map(([key, item], index) => (
              <TouchableOpacity
                key={index}
                onPress={() => onFrequencySelect(key)}
                style={[styles.drawerItem, { backgroundColor: key === frequency ? colors.primary : colors.white }]}
              >
                <Text style={[styles.drawerItemText, { color: key === frequency ? colors.white : colors.black }]}>
                  {t(LANG_PREFIX_FREQUENCY + key)}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </>
      </BottomDrawerModalMini>

      <BottomDrawerModalMini isVisible={modalHelpVisible} closeModal={closeModalHelp}>
        <ScrollView style={styles.helpModal} showsVerticalScrollIndicator={false}>
          <DynamicConstant
            details={helpModalContent[modalHelpText]}
            labelStyle={styles.labelStyle}
            titleStyle={styles.titleStyle}
          />
        </ScrollView>
      </BottomDrawerModalMini>

      <TnCModal url={tncUrl} title={tncName} isVisible={isPDFVisible} onClose={handlePDFVisible} />

      <TranSigner
        ref={tranSignerRef}
        type={tranApiType.FUND_TRANSFER}
        navigation={navigation}
        onStartCheckSecfa={onStartCheckSecfa}
        onCancel={cancelPay}
      />
    </>
  );
};

const styles = StyleSheet.create({
  icon: {
    width: 8,
    height: 8,
    tintColor: colors.black,
  },
  icon2: {
    width: 30,
    height: 30,
  },
  rightIcon: {
    width: 10,
    height: 10,
    tintColor: colors.black,
    marginLeft: 8,
    marginRight: -2,
  },
  detailBlock: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    minHeight: 45,
  },
  form: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
  },
  helpModal: {
    padding: 20,
  },
  drawerTitle: {
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 5,
  },
  drawerTitleText: {
    fontSize: 13,
    color: colors.medium,
  },
  drawerItem: {
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  drawerItemText: {
    fontSize: 14,
  },
  detailField: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemName: {
    fontSize: 14,
    color: colors.medium,
  },
  helpButton: {
    paddingHorizontal: 10,
  },
  helpIcon: {
    width: 15,
    height: 15,
    tintColor: colors.medium,
  },
  subDetailBlock: {
    backgroundColor: colors.bg,
    paddingHorizontal: 12,
    marginBottom: 10,
  },
  subDetailField: {
    height: '100%',
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectedText: {
    fontSize: 14,
    color: colors.primary,
  },
  itemNotify: {
    fontSize: 14,
    flex: 1,
    color: colors.medium,
    marginVertical: 12,
  },
  othersBlock: {
    paddingHorizontal: 20,
    backgroundColor: colors.white,
  },
  divider: {
    marginHorizontal: -20,
  },
  calendar: {
    borderBottomWidth: 0,
    marginBottom: 0,
  },
  tncText: {
    fontSize: 12,
    textAlign: 'center',
  },
  tncBlock: {
    backgroundColor: colors.white,
    padding: 10,
  },
  headerBlock: {
    marginHorizontal: 20,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerField: {
    flex: 1,
    marginLeft: 12,
  },
  itemIdType: {
    fontSize: 14,
    marginBottom: 5,
  },
  labelStyle: {
    fontSize: 14,
  },
  titleStyle: {
    fontWeight: 'bold',
    fontSize: 14,
    marginBottom: 8,
  },
});

export default TransferConfirmation;
