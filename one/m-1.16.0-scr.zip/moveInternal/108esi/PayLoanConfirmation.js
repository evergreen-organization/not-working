import React, { useEffect, useRef, useState } from 'react';
import { Alert, StyleSheet, View } from 'react-native';
import * as Yup from 'yup';
import dayjs from 'dayjs';
import { useDispatch, useSelector } from 'react-redux';

import { colors, tagColors } from 'configs';
import { getRecurringMaxOccurrence, showFailure, utc8DateTime } from 'utils';
import { TranSigner } from 'softToken';
import { useApi, usePing, usePostGuard } from 'hooks';
import routes from 'navigations/routes';
import {
  ApiDateFormat,
  displayDateFormat,
  esiFrequency,
  favouriteType,
  getKeyByValue,
  HOST_ERROR,
  tranApiType,
  validationMsg,
} from 'constant';
import { AvoidKeyboard, Divider, ScreenFull, SkeletonBar } from 'atoms';
import {
  BankLogo,
  BottomDrawerModalMini,
  FormCheckBoxWithReturn,
  ModalListSelect,
  MoreLess,
  TableItemButton,
  TableItemTag,
} from 'molecules';
import { CasaTab, FormFieldInterval, NavBar, Notes } from 'organisms';
import { Form, FormDateCalendarPicker, FormPaymentBtn, Money, Tag, Text } from 'components';
import {
  getActiveLoan,
  getFavouriteList,
  getNameInquiryLoanPayment,
  getNewLoanPayment,
  getSoftToken,
  payLoanEnquireName,
  payLoanNameInquiryUpdated,
  PBB,
  updateNewLoanPaymentObject,
} from 'stores';
import { FAIL, IDLE, LOADING, SUCCESS } from 'apis';
import { useTranslation } from 'react-i18next';

const LANG_PREFIX_FREQUENCY = 'constant.ESI_FREQUENCY.';
const LANG_PREFIX = 'screens.loanConfirmation.text.';
const LANG_PREFIX_VALIDATION = 'constant.validationMsg.';

const esiFrequencyArr = Object.entries(esiFrequency).filter(a => a[1] !== esiFrequency.ONE);

let secfaInfo;

export const PayLoanConfirmation = ({ navigation }) => {
  const { t } = useTranslation();

  const { pingPrivate } = usePing();
  usePostGuard();

  const today = utc8DateTime().format(displayDateFormat);
  const dispatch = useDispatch();
  const loanPayment = useSelector(getNewLoanPayment);
  const store_favourite = useSelector(getFavouriteList);
  const store_activeLoan = useSelector(getActiveLoan);
  const softToken = useSelector(getSoftToken);
  const { status } = useSelector(getNameInquiryLoanPayment) || {};
  const enquireNameApi = useApi(payLoanEnquireName);

  const [isRecurring, setIsRecurring] = useState(false);
  const [frequency, setFrequency] = useState(getKeyByValue(esiFrequency, esiFrequency.DAILY));
  const [othersVisible, setOthersVisible] = useState(false);
  const [modalFrequencyVisible, setModalFrequencyVisible] = useState(false);
  const [fromAccModalVisible, setFromAccModalVisible] = useState(false);
  const [submissionLoading, setSubmissionLoading] = useState(false);

  const tranSignerRef = useRef();

  const { fromAcc, toAcc, noteNo, name, accountType, currency, amount, favName, beneProductType } = loanPayment;
  const isFavourite = store_favourite?.findIndex(x => x.accNo === toAcc) !== -1;
  const ownLoan = store_activeLoan?.accounts.find(x => x.accountNo === toAcc);
  const isOwnLoan = !!ownLoan;

  const { esiMaxOccurrence, esiMaxLength } = getRecurringMaxOccurrence({
    frequency,
    accCategory: isOwnLoan ? ownLoan?.accountType : beneProductType,
  });

  const validationSchema = Yup.object().shape({
    isRecurring: Yup.boolean().notRequired(),
    interval: Yup.number()
      .typeError(t(`${LANG_PREFIX_VALIDATION}numberOnly`))
      .notRequired()
      .nullable()
      .label(t(`${LANG_PREFIX}itemNumOccurrences`))
      .when('isRecurring', {
        is: true,
        then: Yup.number()
          .typeError(t(`${LANG_PREFIX_VALIDATION}numberOnly`))
          .min(
            1,
            t(`${LANG_PREFIX_VALIDATION}minAmount`)
              .replace('${label}', t(`${LANG_PREFIX}itemNumOccurrences`))
              .replace('${minAmount}', 1),
          )
          .required(t(validationMsg.required)),
      }),
  });

  const initialValues = {
    date: today,
    interval: null,
    endDate: null,
  };

  useEffect(() => {
    start();
  }, []);

  const start = () => {
    if (!fromAcc && softToken.preferredAccountActive)
      dispatch(updateNewLoanPaymentObject({ fromAcc: softToken.preferredAccountNo }));
    if (status === IDLE || status === FAIL) checkRPP({ type: favouriteType.PBB, beneAccNo: `${toAcc}${noteNo}` });
  };

  const checkRPP = async bene => {
    dispatch(payLoanNameInquiryUpdated({ status: LOADING }));
    const privateSession = await pingPrivate();
    if (isOwnLoan) return dispatch(payLoanNameInquiryUpdated({ status: SUCCESS }));
    const result = await enquireNameApi.request({ isPublic: !privateSession, bene });
    if (result.status === HOST_ERROR || result.status === 'E00059')
      return Alert.alert('', result.problem, [
        { text: t(LANG_PREFIX + 'alertButtonOK'), onPress: () => navigation.navigate(routes.MAIN_TAB) },
      ]);
    if (result.problem) showFailure(result.problem);
  };

  const onStartCheckSecfa = () => setSubmissionLoading(true);
  const cancelPay = () => setSubmissionLoading(false);

  const onSubmit = async ({ interval, date }) => {
    setSubmissionLoading(true);
    const intervalInt = parseInt(interval);

    secfaInfo = {
      tranType: 'LOAN_PAY',
      isOwn: isOwnLoan,
      isFavourite,
      amount,
      tranDate: dayjs(date, displayDateFormat).format(ApiDateFormat),
      fromAccNo: fromAcc,
      beneAccNo: toAcc,
      noteNo,
    };

    if (isRecurring && intervalInt > 0) {
      if (intervalInt > esiMaxOccurrence) return setSubmissionLoading(false);

      // Future dated transfer is calculated as 1 occurence, therefore occurence input must be at least 2
      const todayTran = dayjs(date, displayDateFormat).isSame(utc8DateTime(), 'day');
      if (!todayTran && intervalInt === 1) return setSubmissionLoading(false);

      secfaInfo = {
        ...secfaInfo,
        frequency,
        occurence: intervalInt,
      };
    }

    tranSignerRef.current.checkSecfa({
      secfaInfo,
      onSubmitParam: { fromAcc },
      onSuccessParam: { secfaInfo },
    });
  };

  const renderHeaderTag = () => {
    if (isOwnLoan) return <Tag title={t(LANG_PREFIX + 'tagSelf')} color={tagColors.grey} style={{ marginRight: 0 }} />;
    if (isFavourite)
      return <Tag title={t(LANG_PREFIX + 'tagFavourite')} color={tagColors.grey} style={{ marginRight: 0 }} />;
  };

  const renderName = () => {
    if (status === IDLE) return;
    if (status === LOADING)
      return (
        <View style={{ marginLeft: -8 }}>
          <SkeletonBar title={true} height={20} color={colors.lightgrey} />
        </View>
      );

    if (status === FAIL)
      return (
        <Text style={{ fontSize: 14, color: colors.primary, marginBottom: 5 }}>
          {t(LANG_PREFIX + 'headerErrorGettingName')}
        </Text>
      );
    if (isOwnLoan)
      return (
        <Text bold style={{ fontSize: 14, marginBottom: 5 }}>
          {favName}
        </Text>
      );
    return (
      <Text bold style={{ fontSize: 14, marginBottom: 5 }}>
        {name}
      </Text>
    );
  };

  const isPaymentDisabled = () => {
    if (fromAcc === toAcc) return true;
    if (submissionLoading) return true;
    if (status !== SUCCESS) return true;
    return false;
  };

  return (
    <>
      <ScreenFull>
        <NavBar
          title={t(LANG_PREFIX + 'titleConfirmation')}
          back
          showShadow={true}
          bottom={
            <View style={{ marginHorizontal: 20, paddingVertical: 12, flexDirection: 'row', alignItems: 'center' }}>
              <BankLogo id={PBB.beneBankId} name={PBB.bankName} size={30} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                {renderName()}
                <Text style={{ fontSize: 14, marginBottom: 5 }}>{PBB.bankName}</Text>
                {accountType && <Text style={{ fontSize: 14, marginBottom: 5 }}>{accountType}</Text>}
                <Text style={{ fontSize: 14, color: colors.medium }}>{`${toAcc} | ${noteNo}`}</Text>
              </View>
              {renderHeaderTag()}
            </View>
          }
        />

        <AvoidKeyboard>
          <Form
            initialValues={initialValues}
            onSubmit={onSubmit}
            validationSchema={validationSchema}
            button={
              <FormPaymentBtn
                disabled={isPaymentDisabled()}
                loading={submissionLoading}
                title={t(LANG_PREFIX + 'buttonPay')}
                amount={<Money amount={amount} currency={currency} size={18} color={colors.primary} />}
              />
            }
          >
            <View style={styles.mandatory}>
              <TableItemButton
                title={t(LANG_PREFIX + 'itemFromAccount')}
                value={fromAcc}
                onPress={() => setFromAccModalVisible(true)}
              />
              <Divider />
              <View style={styles.detailBlock}>
                <Text numberOfLines={1} style={{ fontSize: 14, color: colors.medium }}>
                  {t(LANG_PREFIX + 'itemTransferDate')}
                </Text>
                <FormDateCalendarPicker
                  name={'date'}
                  showRightIcon={true}
                  style={{ borderBottomWidth: 0, marginBottom: 0 }}
                />
              </View>
              <Divider />
              <TableItemTag
                title={t(LANG_PREFIX + 'itemTransferMethod')}
                value={isOwnLoan ? t(LANG_PREFIX + 'labelOwnLoan') : t(LANG_PREFIX + 'labelOtherLoan')}
                isLast={true}
              />
            </View>

            <MoreLess status={othersVisible} onPress={() => setOthersVisible(!othersVisible)} />
            {othersVisible && (
              <View style={styles.optional}>
                <Divider style={{ marginHorizontal: -20 }} />
                <View style={styles.detailBlock}>
                  <Text numberOfLines={1} style={{ fontSize: 14, color: colors.medium }}>
                    {t(LANG_PREFIX + 'itemSetRecurring')}
                  </Text>
                  <FormCheckBoxWithReturn name='isRecurring' onReturn={val => setIsRecurring(val)} />
                </View>

                {isRecurring && (
                  <View style={{ backgroundColor: colors.bg, paddingHorizontal: 12, marginBottom: 10 }}>
                    <TableItemButton
                      title={t(LANG_PREFIX + 'itemFrequency')}
                      value={t(LANG_PREFIX_FREQUENCY + frequency)}
                      onPress={() => setModalFrequencyVisible(true)}
                    />
                    <Divider />
                    <FormFieldInterval
                      label={t(LANG_PREFIX + 'itemNumOccurrences')}
                      name='interval'
                      placeholder={t(LANG_PREFIX + 'placeholderNumOccurrences')}
                      frequency={frequency}
                      dateFormat={displayDateFormat}
                      keyboardType='numeric'
                      maxLength={esiMaxLength}
                      maxOccurrence={esiMaxOccurrence}
                    />
                  </View>
                )}
              </View>
            )}

            <Notes
              data={[
                {
                  title: t(LANG_PREFIX + 'labelNote'),
                  list: [
                    {
                      title: t(LANG_PREFIX + 'labelNoteDesc1'),
                    },
                    {
                      title: t(LANG_PREFIX + 'labelNoteDesc2'),
                    },
                  ],
                },
              ]}
            />
          </Form>
        </AvoidKeyboard>
      </ScreenFull>
      <BottomDrawerModalMini
        variant={BottomDrawerModalMini.variants.modalize}
        isVisible={fromAccModalVisible}
        closeModal={() => setFromAccModalVisible(false)}
      >
        <CasaTab
          mini
          fromAcc={fromAcc}
          onAccountChange={item => {
            dispatch(updateNewLoanPaymentObject({ fromAcc: item.accountNo }));
            setFromAccModalVisible(false);
          }}
        />
      </BottomDrawerModalMini>

      <ModalListSelect
        isVisible={modalFrequencyVisible}
        closeModal={() => setModalFrequencyVisible(false)}
        title={t(LANG_PREFIX + 'modalLabelFrequency')}
        data={esiFrequencyArr}
        value={frequency}
        onSelect={val => {
          setFrequency(val);
          setModalFrequencyVisible(false);
        }}
      />

      <TranSigner
        ref={tranSignerRef}
        type={tranApiType.LOAN_PAYMENT}
        navigation={navigation}
        onStartCheckSecfa={onStartCheckSecfa}
        onCancel={cancelPay}
      />
    </>
  );
};

const styles = StyleSheet.create({
  mandatory: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    marginVertical: 10,
  },
  optional: {
    paddingHorizontal: 20,
    backgroundColor: colors.white,
  },
  detailBlock: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    minHeight: 45,
  },
  errorText: {
    fontSize: 14,
    color: colors.red,
    marginBottom: 8,
    marginHorizontal: 20,
  },
});
