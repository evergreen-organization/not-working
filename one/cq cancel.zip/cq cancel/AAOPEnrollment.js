import React, { useEffect, useRef, useState } from 'react';
import { View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import * as Yup from 'yup';

import { showFailure } from 'utils/message';
import { TranSigner } from 'softToken';
import {
  alphanumericSpaceRegex,
  CQ_ENROLMENT_ACTION,
  noConsecutiveSpaceRegex,
  noStartEndSpaceRegex,
  tranApiType,
  validationMsg,
} from 'constant';
import { Form, FormButtonBottom, FormConditionalDisplay, FormField, FormPicker } from 'components';
import { NavBar, Notes } from 'organisms';
import { AvoidKeyboard, ScreenFull } from 'atoms';
import { getAuth, getCQ, getSoftToken, preEnrolCQ, updateAAOPQuestion } from 'stores';
import { useTranslation } from 'react-i18next';
import { useHandleDispatch, usePing } from 'hooks';
import routes from 'navigations/routes';
import { useRetry } from 'contexts';

let secfaInfo;
const maxLength = 40;
const initialValues = {
  question1: '',
  question2: '',
  question3: '',
  answer1: '',
  answer2: '',
  answer3: '',
};

export const AAOPEnrollment = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.aaopEnrollment.text.';
  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const { action } = route.params || {};
  const { pingPrivate } = usePing();
  const { setIsPBeLoginVisible, setFunctionToRetry } = useRetry();
  const { cqEnrolQuestion } = useSelector(getAuth) || {};
  const { aaopEnrollmentQuestionSet1, aaopEnrollmentQuestionSet2, aaopEnrollmentQuestionSet3 } = cqEnrolQuestion || {};
  const { isActivated: isSoftTokenActivated } = useSelector(getSoftToken) || {};
  const [submissionLoading, setSubmissionLoading] = useState(false);

  const tranSignerRef = useRef();

  const regexMsg = t(`${LANG_PREFIX}regexMsg`);

  const validationSchema = Yup.object().shape({
    question1: Yup.string()
      .required(t(validationMsg.required))
      .label(t(`${LANG_PREFIX}secureQs1`)),
    question2: Yup.string()
      .required(t(validationMsg.required))
      .label(t(`${LANG_PREFIX}secureQs2`)),
    question3: Yup.string()
      .required(t(validationMsg.required))
      .label(t(`${LANG_PREFIX}secureQs3`)),
    answer1: Yup.string()
      .required(t(validationMsg.required))
      .label(t(`${LANG_PREFIX}answer1`))
      .matches(alphanumericSpaceRegex, regexMsg)
      .matches(noStartEndSpaceRegex, t(validationMsg.noStartEndSpace))
      .test('no-consecutive-spaces', t(validationMsg.noConsecutiveSpace), function (value) {
        return !noConsecutiveSpaceRegex.test(value);
      })
      .min(3, t(`${LANG_PREFIX}minLength`).replace('${minLength}', 3)),
    answer2: Yup.string()
      .required(t(validationMsg.required))
      .label(t(`${LANG_PREFIX}answer2`))
      .matches(alphanumericSpaceRegex, regexMsg)
      .matches(noStartEndSpaceRegex, t(validationMsg.noStartEndSpace))
      .test('no-consecutive-spaces', t(validationMsg.noConsecutiveSpace), function (value) {
        return !noConsecutiveSpaceRegex.test(value);
      })
      .min(3, t(`${LANG_PREFIX}minLength`).replace('${minLength}', 3)),
    answer3: Yup.string()
      .required(t(validationMsg.required))
      .label(t(`${LANG_PREFIX}answer3`))
      .matches(alphanumericSpaceRegex, regexMsg)
      .matches(noStartEndSpaceRegex, t(validationMsg.noStartEndSpace))
      .test('no-consecutive-spaces', t(validationMsg.noConsecutiveSpace), function (value) {
        return !noConsecutiveSpaceRegex.test(value);
      })
      .min(3, t(`${LANG_PREFIX}minLength`).replace('${minLength}', 3)),
  });

  const findDuplicates = arr => arr.filter((item, index) => arr.indexOf(item) != index);

  useEffect(() => {
    start();

    return () => dispatch(updateAAOPQuestion(null));
  }, []);

  const start = async () => {
    if (action !== CQ_ENROLMENT_ACTION.CHANGE) return;

    setSubmissionLoading(true);
    const privateSession = await pingPrivate();
    if (privateSession) return getChallengeQuestions();

    setIsPBeLoginVisible(true);
    setFunctionToRetry(() => () => getChallengeQuestions());
  };

  const getChallengeQuestions = () => {
    handleDispatch(getCQ());
    setSubmissionLoading(false);
  };

  const checkWordFromQuestion = (question, answer) => {
    // Split question and answer into words (using regex to account for punctuation)
    const questionWords = question.toLowerCase().match(/\b\w+\b/g); // ['what', 'is', 'your', 'name']
    const answerWords = answer.toLowerCase().match(/\b\w+\b/g); // ['my', 'name']

    // Check if any word in the answer is in the question
    const hasCommonWord = answerWords.some(word => questionWords.includes(word));

    return hasCommonWord;
  };

  const onSubmit = async ({ question1, question2, question3, answer1, answer2, answer3 }) => {
    const loweredCaseAnswer1 = answer1.toLowerCase();
    const loweredCaseAnswer2 = answer2.toLowerCase();
    const loweredCaseAnswer3 = answer3.toLowerCase();
    const answerList = [loweredCaseAnswer1, loweredCaseAnswer2, loweredCaseAnswer3];

    if (findDuplicates(answerList).length > 0) return showFailure(t(`${LANG_PREFIX}msgSameAnswer`));

    const foundQuestion1 = aaopEnrollmentQuestionSet1.find(q => q.questionId === question1)?.questionText;
    const foundQuestion2 = aaopEnrollmentQuestionSet2.find(q => q.questionId === question2)?.questionText;
    const foundQuestion3 = aaopEnrollmentQuestionSet3.find(q => q.questionId === question3)?.questionText;

    if (
      checkWordFromQuestion(foundQuestion1, loweredCaseAnswer1) ||
      checkWordFromQuestion(foundQuestion2, loweredCaseAnswer2) ||
      checkWordFromQuestion(foundQuestion3, loweredCaseAnswer3)
    ) {
      return showFailure(t(`${LANG_PREFIX}msgAnswerInQuestion`));
    }

    setSubmissionLoading(true);

    const aaopAnswers = [
      {
        questionId: question1,
        actualAnswer: loweredCaseAnswer1,
      },
      {
        questionId: question2,
        actualAnswer: loweredCaseAnswer2,
      },
      {
        questionId: question3,
        actualAnswer: loweredCaseAnswer3,
      },
    ];

    if (isSoftTokenActivated) {
      secfaInfo = {
        tranType: action === CQ_ENROLMENT_ACTION.CHANGE ? 'CHANGE_CHALLENGE_QUESTION' : 'REGISTER_AAOP',
        aaopAnswers,
      };
      return tranSignerRef.current.checkSecfa({
        secfaInfo,
        onSubmitParam: {},
        onSuccessParam: { secfaInfo },
      });
    }

    handleCQPreEnrolment(aaopAnswers);
  };

  const handleCQPreEnrolment = async aaopAnswers => {
    const result = await handleDispatch(preEnrolCQ({ aaopAnswers }));
    setSubmissionLoading(false);

    if (result.problem) return showFailure(result.problem);

    navigation.navigate(routes.SOFT_TOKEN_VALIDATEPAC, route.params);
  };

  const onStartCheckSecfa = () => setSubmissionLoading(true);
  const cancelEnroll = () => setSubmissionLoading(false);

  const formatQuestionArray = questionArray =>
    questionArray?.map(question => ({
      label: question.questionText,
      value: question.questionId,
    }));

  const renderNotes = () => (
    <Notes
      style={{ marginTop: 0 }}
      data={[
        {
          title: t(`${LANG_PREFIX}labelNote`),
          list: [
            {
              title: t(`${LANG_PREFIX}labelNoteDesc1`),
            },
            {
              title: t(`${LANG_PREFIX}labelNoteDesc2`),
            },
            {
              title: t(`${LANG_PREFIX}labelNoteDesc3`),
            },
          ],
        },
      ]}
    />
  );

  return (
    <>
      <ScreenFull>
        <NavBar
          title={
            action === CQ_ENROLMENT_ACTION.CHANGE ? t(`${LANG_PREFIX}titleChange`) : t(`${LANG_PREFIX}titleEnrolment1`)
          }
          back
          showShadow={false}
        />
        <AvoidKeyboard>
          <Form
            initialValues={initialValues}
            onSubmit={onSubmit}
            validationSchema={validationSchema}
            enableReinitialize={false}
            button={<FormButtonBottom loading={submissionLoading} title={t(`${LANG_PREFIX}buttonSubmit`)} />}
          >
            <View style={{ padding: 20 }}>
              <FormPicker
                name='question1'
                label={t(`${LANG_PREFIX}secureQs1`)}
                data={formatQuestionArray(aaopEnrollmentQuestionSet1)}
              />
              <FormConditionalDisplay condition={values => values.question1}>
                <FormField name='answer1' label={t(`${LANG_PREFIX}answer1`)} maxLength={maxLength} showCounter={true} />
              </FormConditionalDisplay>

              <FormConditionalDisplay condition={values => values.answer1.length !== 0}>
                <FormPicker
                  name='question2'
                  label={t(`${LANG_PREFIX}secureQs2`)}
                  data={formatQuestionArray(aaopEnrollmentQuestionSet2)}
                />
                <FormConditionalDisplay condition={values => values.question2}>
                  <FormField
                    name='answer2'
                    label={t(`${LANG_PREFIX}answer2`)}
                    maxLength={maxLength}
                    showCounter={true}
                  />
                </FormConditionalDisplay>
              </FormConditionalDisplay>

              <FormConditionalDisplay condition={values => values.answer2.length !== 0}>
                <FormPicker
                  name='question3'
                  label={t(`${LANG_PREFIX}secureQs3`)}
                  data={formatQuestionArray(aaopEnrollmentQuestionSet3)}
                />
                <FormConditionalDisplay condition={values => values.question3}>
                  <FormField
                    name='answer3'
                    label={t(`${LANG_PREFIX}answer3`)}
                    maxLength={maxLength}
                    showCounter={true}
                  />
                </FormConditionalDisplay>
              </FormConditionalDisplay>
            </View>
            {renderNotes()}
          </Form>
        </AvoidKeyboard>
      </ScreenFull>

      <TranSigner
        ref={tranSignerRef}
        type={action === CQ_ENROLMENT_ACTION.CHANGE ? tranApiType.CQ_CHANGE : tranApiType.CQ_ENROLMENT}
        navigation={navigation}
        onStartCheckSecfa={onStartCheckSecfa}
        onCancel={cancelEnroll}
      />
    </>
  );
};

export default AAOPEnrollment;
