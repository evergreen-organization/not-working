import React, { useEffect, useState } from 'react';
import { Alert, Image, StyleSheet, TouchableOpacity, View } from 'react-native';
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';

import { useApi } from 'hooks';
import { colors } from 'configs';
import { failMsg, tranApiType, validationMsg } from 'constant';
import { answerAAOP, getAuth, resetAAOPChallenge } from 'stores';
import { AvoidKeyboard, Screen } from 'atoms';
import { Form, FormButton, FormButtonBottom, FormField, Text } from 'components';
import { Notes } from 'organisms';
import { useTranslation } from 'react-i18next';
import { LOADING } from 'apis';
import { ActionModal, BoldTextWithBTag } from 'molecules';
import WarningIcon from 'assets/images/icon/warning.png';

const initialValues = {
  answer: '',
};

const LANG_PREFIX = 'screens.aaopChallenge.text.';
const LANG_PREFIX_VALIDATION = 'constant.validationMsg.';
export const Challenge = ({ onSuccess, onFailure, onCancelChallenge, fullScreen = false, isPublic, type }) => {
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const store_auth = useSelector(getAuth);
  const { challengeQuestion, isChangeCQ, cqRemainingAttempt } = store_auth || {};
  const answerAAOPApi = useApi(answerAAOP);
  const [attemptCount, setAttemptCount] = useState(cqRemainingAttempt);
  const [isCancelModalVisible, setIsCancelModalVisible] = useState(false);
  const [cancelModalContent, setCancelModalContent] = useState({ title: '', message: '' });

  const validationSchema = Yup.object().shape({
    answer: Yup.string()
      .required(t(validationMsg.required))
      .label(t(`${LANG_PREFIX}labelAnswer`))
      .max(
        40,
        `${LANG_PREFIX_VALIDATION}maxLength`
          .replace('${label}', t(`${LANG_PREFIX}labelAnswer`))
          .replace('${maxLength}', 40),
      ),
  });

  useEffect(() => {
    return () => {
      dispatch(resetAAOPChallenge());
    };
  }, []);

  const onSubmit = async ({ answer }) => {
    const result = await answerAAOPApi.request({ aaopAnswer: answer.toLowerCase(), isPublic });
    //AAOP invalid answer
    if (result.status === 'E00043') return wrongAnswerAlert(result.problem);

    //AIFPS invalid answer with counter
    if (result.status === 'E00153') {
      const count = result.data?.count;
      setAttemptCount(count);
      return wrongAnswerAlert(result.problem);
    }

    if (result.problem) return onFailure(result);
    onSuccess(result);
  };

  const wrongAnswerAlert = msg => {
    Alert.alert(msg);
  };

  const onCancelTransaction = () => {
    setIsCancelModalVisible(true);
    if (type === tranApiType.CQ_ENROLMENT || type === tranApiType.PBSS_CQ_ENROLMENT_VALIDATE_PAC) {
      return setCancelModalContent({
        title: t(`${LANG_PREFIX}alertCancelEnrolment`),
        message: `${t(`${LANG_PREFIX}alertCancelEnrolment2`)}`,
      });
    }
    return setCancelModalContent({
      title: t(`${LANG_PREFIX}alertCancelTransaction01`),
      message: t(`${LANG_PREFIX}alertCancelTransaction02`),
    });
  };

  const onAcceptCancelChallenge = () => {
    setIsCancelModalVisible(false);
    const attemptCountDec = attemptCount - 1;
    setAttemptCount(attemptCountDec);
    onCancelChallenge({ attemptCount: attemptCountDec, cqRemainingAttempt, message: t(failMsg.aaopChallengeCancel) });
  };

  const onCloseCancelModal = () => setIsCancelModalVisible(false);

  const renderNotes = () => (
    <Notes
      style={styles.note}
      data={[
        {
          title: t(`${LANG_PREFIX}note`),
          list: [
            {
              title: t(`${LANG_PREFIX}noteDesc1`),
            },
            {
              title: t(`${LANG_PREFIX}noteDescBold2`),
            },
            {
              title: t(`${LANG_PREFIX}noteDesc3`),
            },
          ],
        },
      ]}
    />
  );

  const renderContent = () => {
    return (
      <>
        <TouchableOpacity style={styles.cancelButton} onPress={onCancelTransaction}>
          <Text bold style={styles.cancelText}>
            {t(`${LANG_PREFIX}buttonCancel`)}
          </Text>
        </TouchableOpacity>

        <View style={styles.navTitle}>
          <Text bold style={styles.navTitleText}>
            {t(`${LANG_PREFIX}titleChallengeQuestion`)}
          </Text>
        </View>

        {isChangeCQ && (
          <View style={styles.highlightView}>
            <Image source={WarningIcon} style={styles.icon} />
            <BoldTextWithBTag text={t(`${LANG_PREFIX}previousNote`)} style={styles.highlightText} />
          </View>
        )}

        <Form
          initialValues={initialValues}
          onSubmit={onSubmit}
          validationSchema={validationSchema}
          enableReinitialize={false}
          button={
            fullScreen ? (
              <FormButtonBottom
                title={t(`${LANG_PREFIX}buttonSubmit`)}
                loading={store_auth?.challengeStatus === LOADING}
              />
            ) : (
              <FormButton label={t(`${LANG_PREFIX}buttonSubmit`)} loading={store_auth?.challengeStatus === LOADING} />
            )
          }>
          <View style={styles.challengeView}>
            {challengeQuestion && (
              <View style={styles.questionView}>
                {isChangeCQ && <View style={styles.square} />}
                <View style={styles.question}>
                  <Text style={styles.questionText}>{challengeQuestion}</Text>
                </View>
              </View>
            )}
            <FormField
              name='answer'
              placeholder={t(`${LANG_PREFIX}placeholderEnterAnswer`)}
              maxLength={40}
              style={styles.formField}
            />
          </View>
          {renderNotes()}
        </Form>
      </>
    );
  };

  if (fullScreen) {
    return (
      <Screen>
        <AvoidKeyboard>{renderContent()}</AvoidKeyboard>

        <CancelModal
          isVisible={isCancelModalVisible}
          onClose={onCloseCancelModal}
          onCancelChallenge={onAcceptCancelChallenge}
          t={t}
          title={cancelModalContent?.title}
          message={cancelModalContent?.message}
        />
      </Screen>
    );
  }

  return <View style={styles.screen}>{renderContent()}</View>;
};

const CancelModal = ({ title, message, isVisible, onClose, onCancelChallenge, t }) => (
  <ActionModal
    isVisible={isVisible}
    renderContent={() => (
      <View>
        <Text bold style={{ fontSize: 14 }}>
          {title}
        </Text>
        <Text style={{ marginTop: 5 }}>{message}</Text>
      </View>
    )}
    onAccept={onCancelChallenge}
    onDecline={onClose}
    leftButtonTitle={t(`${LANG_PREFIX}alertButtonNo`)}
    rightButtonTitle={t(`${LANG_PREFIX}alertButtonYes`)}
  />
);

export default Challenge;

const styles = StyleSheet.create({
  screen: {
    backgroundColor: colors.white,
    marginBottom: 10,
  },
  cancelButton: {
    paddingHorizontal: 20,
    height: 44,
    justifyContent: 'center',
    alignSelf: 'flex-start',
  },
  cancelText: {
    color: colors.primary,
  },
  navTitle: {
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  navTitleText: { fontSize: 15 },
  highlightView: {
    backgroundColor: colors.lightPink,
    marginHorizontal: 15,
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  highlightText: {
    fontSize: 14,
    color: colors.black,
    marginLeft: 8,
    flexShrink: 1,
  },
  icon: {
    tintColor: colors.yellow,
    width: 16,
    height: 16,
  },
  challengeView: {
    marginTop: 10,
    marginHorizontal: 20,
  },
  questionView: {
    flexDirection: 'row',
    marginBottom: 10,
    marginTop: 5,
  },
  square: {
    marginLeft: -3,
    backgroundColor: colors.primary,
    marginRight: 10,
    alignSelf: 'center',
    borderRadius: 1,
    width: 7,
    height: 7,
  },
  question: {
    justifyContent: 'center',
    flexWrap: 'wrap',
    flex: 1,
  },
  questionText: {
    fontSize: 15,
    alignSelf: 'center',
  },
  formField: {
    height: 55,
    fontSize: 15,
  },
  note: {
    marginTop: 15,
  },
});
