import React from 'react';
import { View, StyleSheet } from 'react-native';

import { colors } from 'configs';
import { Money, Text } from 'components';
import { balanceAmountColorSets, getColorBasedOnValue } from 'screens/accounts/utils';

export const BalanceAmount = ({
  currency,
  amount,
  title,
  colorSets = balanceAmountColorSets.positiveRed,
  style,
  fontStyle,
  amountColor,
  renderTooltip,
}) => {
  return (
    <View
      style={{
        backgroundColor: getColorBasedOnValue(amount, colorSets),
        ...styles.container,
        ...style,
      }}>
      <View style={styles.balanceContainer}>
        <View style={[styles.balanceIcon, { marginLeft: renderTooltip ? 10 : 0 }]}>
          <Text bold style={{ ...styles.title, ...fontStyle }}>
            {title}
          </Text>
          {renderTooltip}
        </View>

        <Money
          isCurrencyBold={true}
          currency={currency}
          amount={amount}
          size={25}
          color={amountColor ?? colors.white}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    margin: 10,
    marginTop: 0,
    padding: 20,
    borderRadius: 5,
  },
  balanceContainer: {
    alignItems: 'center',
  },
  balanceIcon: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 13,
    color: colors.lightestBg,
  },
});
