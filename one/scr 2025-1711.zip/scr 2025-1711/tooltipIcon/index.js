import React, { useState } from 'react';
import Tooltip from 'react-native-walkthrough-tooltip';
import { Image, StyleSheet, TouchableOpacity } from 'react-native';
import { Text } from 'components';
import { colors } from 'configs';
import InfoIcon from 'assets/images/icon/help.png';

export const TooltipIcon = ({
  icon,
  customTooltipContent,
  tooltipText,
  iconStyle,
  placement = 'top',
  children,
}) => {
  const [isTooltipVisible, setIsTooltipVisible] = useState(false);

  const handleIconPress = () => setIsTooltipVisible(true);

  const handleCloseTooltip = () => setIsTooltipVisible(false);

  const renderTooltipContent = () => {
    if (customTooltipContent) return customTooltipContent;
    return <Text style={{ fontSize: 13, flex: 1, flexGrow: 1 }}>{tooltipText}</Text>;
  };

  return (
    <Tooltip
      isVisible={isTooltipVisible}
      onClose={handleCloseTooltip}
      disableShadow={true}
      placement={placement}
      content={renderTooltipContent()}>
      <TouchableOpacity onPress={handleIconPress} style={styles.iconButton}>
        {children ?? <Image source={icon ?? InfoIcon} style={[styles.iconImage, iconStyle]} />}
      </TouchableOpacity>
    </Tooltip>
  );
};

const styles = StyleSheet.create({
  iconButton: {
    padding: 8,
    margin: -8,
    marginLeft: 0,
  },
  iconImage: {
    width: 15,
    height: 15,
    tintColor: colors.medium
  },
});
