import { useLazyFetchMoneyPlusQuery } from 'stores';
import useHandleQueryResponse from './useHandleQueryResponse';
import { isYtdSameAsUpdatedDate } from 'screens';

export const useCheckMoneyPlus = ({ accountNo, isMoneyPlus, moneyPlusDetails }) => {
  const handleQuery = useHandleQueryResponse();
  const [fetchMoneyPlus, { isLoading }] = useLazyFetchMoneyPlusQuery();

  const checkMoneyPlus = async () => {
    if (!isMoneyPlus) {
      return;
    }
    if (!isYtdSameAsUpdatedDate(moneyPlusDetails?.moneyPlusDate)) {
      await handleQuery(fetchMoneyPlus(accountNo));
    }
  };

  const handleRetryMoneyPlus = async () => {
    await handleQuery(fetchMoneyPlus(accountNo));
  };

  return { isLoading, handleRetryMoneyPlus, checkMoneyPlus };
};
