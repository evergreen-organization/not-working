import { useDispatch, useSelector } from 'react-redux';
import Toast from 'react-native-toast-message';

import { ACCESS_DENIED, CONNECTION_TIMEOUT, HOST_ERROR } from 'constant';
import { useRetry } from 'contexts';
import { logout } from 'stores/actions';
import { getErrorList } from 'stores/environment';
import { showFailure } from 'utils/message';
import { formatDuplicateLoginMsg } from 'utils/login';
import { requestLogoutWebseal } from 'stores/lifestyle';
import { mapAccessDeniedFields } from 'apis/utils';
import { AppMessage } from 'screens/AppMessage';

export const useHandleQueryResponse = params => {
  const { queryOnly = true } = params || {};

  const { globalLoggedIn } = useRetry();
  const dispatch = useDispatch();
  const store_errorList = useSelector(getErrorList);

  const execute = async query => {
    try {
      const result = await query.unwrap();
      if (result?.error) return handleError(result?.error);
      return result?.data || {};
    } catch (error) {
      return handleError(error);
    }
  };

  const handleError = (payload = {}) => {
    //JS Error
    if (payload instanceof Error) {
      return { ...payload, problem: payload?.message };
    }

    //Host Error
    if (payload?.status === HOST_ERROR) {
      return { ...payload, problem: payload.data?.message };
    }

    if (payload?.status === CONNECTION_TIMEOUT) {
      return payload;
    }

    //API Error
    const errorMessage = store_errorList.find(x => x.errorCode === payload.status)?.errorMessage;
    payload = { ...payload, problem: errorMessage ?? payload.status };

    if (payload.status === 'E00016') {
      //Logout webseal so next private api will require password login
      //Cannot logout private as api will delete keys from database which causes new login channel (eg. ebanking) being logged out.
      dispatch(requestLogoutWebseal());
      return {
        ...payload,
        problem: formatDuplicateLoginMsg({
          msg: payload.problem,
          time: payload.data?.errorParam?.previousLoginDate,
          device: payload.data?.errorParam?.previousDeviceInfo,
        }),
      };
    }

    //Logout if access denies error / backend trigger return logout error
    if (payload?.status === ACCESS_DENIED) {
      handleAccessDenied(payload);
      return payload;
    }

    checkErrorLogout(payload);

    return payload;
  };

  const handleAccessDenied = payload => {
    const fields = mapAccessDeniedFields(payload?.data);

    Toast.show({
      type: AppMessage.variants.accessDeniedHardBlock,
      autoHide: false,
      swipeable: false,
      topOffset: 0,
      props: { referenceId: fields?.referenceId, description: fields?.description },
    });
    if (globalLoggedIn.current) dispatch(logout());
  };

  const checkErrorLogout = result => {
    if (String(result?.status).charAt(0) === 'L' && globalLoggedIn.current) {
      //Context useRef to get value instantly
      dispatch(logout());
      if (result?.status !== 'L00001') showFailure(result.problem);
    }
  };

  return queryOnly ? execute : { handleQueryDispatch: execute, handleQueryError: handleError };
};

export default useHandleQueryResponse;
