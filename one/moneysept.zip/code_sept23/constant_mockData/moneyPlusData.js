const data = {
  mpDetails: {
    monthlyAverageBal: 6690.0,
    eligibleAmount: 5000.0,
    moneyPlusDate: '28/04/2025',
    saveAmount: 1245.0,
    saveAmountTarget: 5000.0,
    payAmount: 318.0,
    payAmountTarget: 500.0,
    spendAmount: 500.13,
    spendAmountTarget: 500.0,
  },
};

export const MoneyPlus = {
  MoneyPlus: data,
};
