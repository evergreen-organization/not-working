import { combineReducers } from 'redux';
import lifestyleEntities from './lifestyle/lifestyleEntities';
import bankingEntities from './banking/bankingEntities';
import environmentEntities from './environment/environmentEntities';
import { persistReducer } from 'redux-persist';
import { baseQueryApi } from './services';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';
import { transformUserStore } from './utils';

// const bankingPersistConfig = {
//   key: 'bankingEntities',
//   storage: reduxStorage,
//   stateReconciler: autoMergeLevel2,
//   whitelist: [
//     'casa',
//     'card',
//     'deposit',
//     'invest',
//     'loan',
//     'rnid',
//     'softToken',
//     'flexipay',
//     'topUp',
//     'mailbox',
//     'carbonTracker',
//     'depositPlacement',
//   ],
//   timeout: 0,
// };
//
// const lifestylePersistConfig = {
//   key: 'lifestyleEntities',
//   storage: reduxStorage,
//   stateReconciler: autoMergeLevel2,
//   transforms: [transformUserStore],
//   whitelist: ['user', 'casaApplication', 'notification', 'biometric', 'ctos', 'demo'],
//   timeout: 0,
// };
//
// const environmentPersistConfig = {
//   key: 'environmentEntities',
//   storage: reduxStorage,
//   stateReconciler: autoMergeLevel2,
//   whitelist: [
//     'version',
//     'language',
//     'setting',
//     'scheduledTran',
//     'loyalty',
//     'bank',
//     'branch',
//     'country',
//     'pfmCategory',
//     'remittance',
//   ],
//   timeout: 0,
// };
//Whitelist allows it to be found in REHYDRATE payload

export const createRootReducer = async reduxStorage => {
  const bankingPersistConfig = {
    key: 'bankingEntities',
    storage: reduxStorage,
    stateReconciler: autoMergeLevel2,
    whitelist: [
      'casa',
      'card',
      'deposit',
      'invest',
      'loan',
      'rnid',
      'softToken',
      'flexipay',
      'topUp',
      'mailbox',
      'carbonTracker',
      'depositPlacement',
    ],
    timeout: 0,
  };

  const lifestylePersistConfig = {
    key: 'lifestyleEntities',
    storage: reduxStorage,
    stateReconciler: autoMergeLevel2,
    transforms: [transformUserStore],
    whitelist: ['user', 'casaApplication', 'notification', 'biometric', 'ctos', 'demo', 'home'],
    timeout: 0,
  };

  const environmentPersistConfig = {
    key: 'environmentEntities',
    storage: reduxStorage,
    stateReconciler: autoMergeLevel2,
    whitelist: [
      'version',
      'language',
      'setting',
      'scheduledTran',
      'loyalty',
      'bank',
      'branch',
      'country',
      'pfmCategory',
      'remittance',
    ],
    timeout: 0,
  };

  return combineReducers({
    lifestyleEntities: persistReducer(lifestylePersistConfig, lifestyleEntities),
    bankingEntities: persistReducer(bankingPersistConfig, bankingEntities),
    environmentEntities: persistReducer(environmentPersistConfig, environmentEntities),
    [baseQueryApi.reducerPath]: baseQueryApi.reducer,
  });
};

// export default combineReducers({
//   lifestyleEntities: persistReducer(lifestylePersistConfig, lifestyleEntities),
//   bankingEntities: persistReducer(bankingPersistConfig, bankingEntities),
//   environmentEntities: persistReducer(environmentPersistConfig, environmentEntities),
//   [pdfSlipApi.reducerPath]: pdfSlipApi.reducer,
// });
