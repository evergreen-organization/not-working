import { FLUSH, PAUSE, PERSIST, persistReducer, PURGE, REGISTER, REHYDRATE } from 'redux-persist';
import { configureStore as configure } from '@reduxjs/toolkit';
import { createRootReducer } from './reducer';
import { baseQueryApi } from './services';
import { getReduxMMKVStorage } from '../utils/storage';

import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';

// const persistConfig = {
//   key: 'root',
//   storage: reduxStorage,
//   //Blacklist all first layer persist, because second layer whitelist will allow it to be found in REHYDRATE payload
//   blacklist: ['lifestyleEntities', 'bankingEntities', 'environmentEntities'],
//   stateReconciler: autoMergeLevel2,
//   timeout: 0,
// };

// const persistedReducer = persistReducer(persistConfig, reducer);

export const configureStore = async () => {
  const reduxStorage = await getReduxMMKVStorage();
  if (!reduxStorage) return;

  const persistConfig = {
    key: 'root',
    storage: reduxStorage,
    //Blacklist all first layer persist, because second layer whitelist will allow it to be found in REHYDRATE payload
    blacklist: ['lifestyleEntities', 'bankingEntities', 'environmentEntities'],
    stateReconciler: autoMergeLevel2,
    timeout: 0,
  };

  const reducer = await createRootReducer(reduxStorage);

  const persistedReducer = persistReducer(persistConfig, reducer);

  if (__DEV__) {
    await require('../../ReactotronConfig').reactotron();
  }

  return configure({
    reducer: persistedReducer,
    enhancers: existingEnhancers => {
      const enhancersArray = Array.isArray(existingEnhancers) ? existingEnhancers : [];
      if (__DEV__) {
        const reactotronEnhancer = require('../../ReactotronConfig').getEnhancer();
        return [reactotronEnhancer, ...enhancersArray];
      }
      return enhancersArray;
    },
    middleware: getDefaultMiddleware =>
      getDefaultMiddleware({
        serializableCheck: {
          ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
        },
      })
        .concat(baseQueryApi.middleware)
        .concat(logger),
  });
};

const logger = store => next => action => {
  // console.group(action.type);
  // console.info('dispatching', action);
  let result = next(action);
  // console.log('next state', store.getState());
  // console.groupEnd();
  return result;
};
