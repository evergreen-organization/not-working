import { createEntityAdapter, createSlice, isAnyOf } from '@reduxjs/toolkit';
import { REHYDRATE } from 'redux-persist';
import { submitFundTransfer } from '../fundTransfer/index';
import { completeJourneyTask, hasJourneyAccount, transferJourney, withdrawJourney } from '../pbJourney/thunk';
import { submitAlipayPlus, submitQRPayment } from '../qrPayment';
import { submitCardPayment } from '../cardPayment/index';
import { submitLoanPayment } from '../loanPayment/index';
import { submitBillPayment } from '../bill/index';
import { submitTopUp } from '../topUp/index';
import { cancelCardlessWithdrawal, submitCardlessWithdraw } from '../cardlessWithdraw';
import {
  cancelUnderReviewTran,
  changeCasaAccountNickname,
  getPreLoginBalance,
  loadCasa,
  loadCasaHistory,
  loadCasaPBeHistory,
  loadCasaPrivate,
  loadCasaUnderReview,
  updateDisplayBalance,
  loadMoneyMarketDeposit,
  loadLockFundAmount,
  submitCancelUnlock,
  submitLockFund,
  submitUnlockFund,
} from './thunk';
import { submitBakong } from '../remittance';
import { ONHOLD_STATUS } from 'constant/account';
import { submitDepositPlacement } from '../depositPlacement';
import { submitCarbonOffset } from '../carbonTracker/index';
import { FAIL, IDLE, LOADING, SUCCESS } from 'apis';
import { utc8DateTime } from 'utils';
import { updatePrefAccount } from '../softToken';
import { accountService } from 'stores/services';

export const moneyMarketDepositAdapter = createEntityAdapter({
  selectId: moneyMarketDeposit => moneyMarketDeposit.id,
});

const initialState = {
  accounts: [],
  accountsStatus: 'idle',
  historyAccountNo: null,

  history: [],
  historyStatus: 'idle',
  historyNextKey: 1,
  endOfHistory: false,

  pbeHistory: [],
  pbeHistoryStatus: 'idle',
  pbeHistoryNextKey: 1,
  endOfPBeHistory: false,

  isExistJourney: false,

  underReview: [],
  underReviewStatus: 'idle',

  minLockFundAmount: 0,
  lockAmountStatus: IDLE,
  fundLockStatus: IDLE,

  preferredAccountNo: '',

  allowShowBalance: false,
  allowShowBalanceStatus: IDLE,
  balanceLastEnquiryTime: null,
  balanceStatus: IDLE,

  moneyMarketDeposit: moneyMarketDepositAdapter.getInitialState(),
  moneyMarketDepositStatus: 'idle',

  moneyPlusStatus: 'idle',
  moneyPlus: [],
};

const slice = createSlice({
  name: 'casa',
  initialState,
  reducers: {
    casaInit: ({ isExistJourney }) => {
      return { ...initialState, isExistJourney };
    },
    casaReset: ({ isExistJourney, preferredAccountNo, accounts, allowShowBalance, balanceLastEnquiryTime }) => {
      let preferredAccountDetails = {};
      const allowShowPreLoginBalance = allowShowBalance;
      if (allowShowPreLoginBalance) {
        const { accountNo, availableBalance, accountStatus } =
          accounts.find(item => item.accountNo === preferredAccountNo) || {};
        preferredAccountDetails = {
          accountNo,
          availableBalance,
          accountStatus,
        };
      }
      return {
        ...initialState,
        isExistJourney,
        ...(allowShowPreLoginBalance && {
          accounts: [{ ...preferredAccountDetails }],
          allowShowBalance,
          preferredAccountNo,
          balanceLastEnquiryTime,
        }),
      };
    },
    casaHistoryReset: state => {
      state.history = [];
      state.historyStatus = 'idle';
      state.endOfHistory = false;

      state.pbeHistory = [];
      state.pbeHistoryStatus = 'idle';
      state.endOfPBeHistory = false;
    },
    casaUnderReviewReset: state => {
      state.underReview = [];
      state.underReviewStatus = 'idle';
    },
    updateCasaObject: (state, { payload }) => {
      for (const key in payload) {
        state[key] = payload[key];
      }
    },
    updateAccountBalance: (state, { payload }) => {
      const found = state.accounts.find(item => item.accountNo === payload.fromAcc);
      if (found) {
        if (payload.availableBalance || payload.availableBalance === 0)
          found.availableBalance = payload.availableBalance;
        if (payload.currentBalance || payload.currentBalance === 0) found.currentBalance = payload.currentBalance;
        // if (payload.lockedAmount) found.currentBalance = payload.lockedAmount;
      }
    },
    casaUnderReviewCancelled: (state, payload) => {
      const newList = state.underReview.filter(item => item.refNo !== payload);
      state.underReview = newList;
    },
  },
  extraReducers: builder => {
    builder.addCase(REHYDRATE, (state, { payload }) => {
      if (payload?.casa !== undefined) {
        state.accounts = payload.casa.accounts;
        state.isExistJourney = payload.casa.isExistJourney;
        state.allowShowBalance = payload.casa.allowShowBalance;
        state.preferredAccountNo = payload.casa.preferredAccountNo;
      }
    });
    builder.addCase(loadCasaHistory.pending, state => {
      state.historyStatus = 'loading';
    });
    builder.addCase(loadCasaHistory.fulfilled, (state, { payload, meta }) => {
      state.historyStatus = 'succeeded';
      if (payload.accountHistory) {
        if (meta.arg.month === 1) state.history = payload.accountHistory;
        else state.history.push(...payload.accountHistory);

        state.historyNextKey = payload.month;
      }
      if (payload.month === 0) state.endOfHistory = true;
    });
    builder.addCase(loadCasaHistory.rejected, state => {
      state.historyStatus = 'failed';
    });
    builder.addCase(loadCasaPBeHistory.pending, state => {
      state.pbeHistoryStatus = 'loading';
    });
    builder.addCase(loadCasaPBeHistory.fulfilled, (state, { payload, meta }) => {
      state.pbeHistoryStatus = 'succeeded';

      if (payload.pbeHistory && payload.pbeHistory.length > 0) {
        if (meta.arg.pageNo === 1) state.pbeHistory = payload.pbeHistory;
        else state.pbeHistory.push(...payload.pbeHistory);

        state.pbeHistoryNextKey = meta.arg.pageNo + 1;
      } else state.endOfPBeHistory = true;
    });
    builder.addCase(loadCasaPBeHistory.rejected, state => {
      state.pbeHistoryStatus = 'failed';
    });
    builder.addCase(changeCasaAccountNickname.fulfilled, (state, { payload, meta }) => {
      const found = state.accounts.find(item => item.accountNo === meta.arg.accountNo);
      found.nickName = meta.arg.nickName;
    });
    builder.addCase(hasJourneyAccount.fulfilled, (state, { payload }) => {
      state.isExistJourney = payload.journeyAccExists;
    });

    builder.addCase(loadCasaUnderReview.pending, state => {
      state.underReviewStatus = 'loading';
    });
    builder.addCase(loadCasaUnderReview.fulfilled, (state, { payload }) => {
      state.underReviewStatus = 'succeeded';
      state.underReview = payload.onHoldList;
    });
    builder.addCase(loadCasaUnderReview.rejected, state => {
      state.underReviewStatus = 'failed';
    });

    builder.addCase(cancelUnderReviewTran.fulfilled, (state, { meta }) => {
      slice.caseReducers.casaUnderReviewCancelled(state, meta.arg.refNo);
    });
    builder.addCase(cancelUnderReviewTran.rejected, (state, { payload, meta }) => {
      const refNo = meta.arg.refNo;
      if (payload.status === 'E00081') {
        slice.caseReducers.casaUnderReviewCancelled(state, refNo);
      } else if (payload.status === 'E00080') {
        const found = state.underReview.find(item => item.refNo === refNo);
        found.status = ONHOLD_STATUS.PROCESSING.key;
      }
    });
    builder.addCase(getPreLoginBalance.fulfilled, (state, { meta, payload }) => {
      const accountNo = meta.arg.accountNo;
      const { prefAccountBalance, prefAccountStatus } = payload || {};
      const found = state.accounts.find(item => item.accountNo === accountNo);
      if (found) {
        found.availableBalance = prefAccountBalance;
        found.accountStatus = prefAccountStatus;
      } else {
        if (prefAccountStatus) {
          state.accounts = [
            {
              accountNo,
              availableBalance: prefAccountBalance,
              accountStatus: prefAccountStatus,
            },
          ];
        }
      }
      state.balanceStatus = SUCCESS;
      state.balanceLastEnquiryTime = utc8DateTime().valueOf();
    });
    builder.addCase(getPreLoginBalance.pending, state => {
      state.balanceStatus = LOADING;
    });
    builder.addCase(getPreLoginBalance.rejected, state => {
      state.balanceStatus = FAIL;
    });
    builder.addCase(updatePrefAccount.fulfilled, (state, { meta }) => {
      state.preferredAccountNo = meta.arg.accountNo;
    });
    builder.addCase(updateDisplayBalance.fulfilled, (state, { meta }) => {
      state.allowShowBalance = meta.arg.allowShowBalance;
      state.allowShowBalanceStatus = SUCCESS;
      state.preferredAccountNo = meta.arg?.preferredAccountNo;
    });
    builder.addCase(updateDisplayBalance.pending, state => {
      state.allowShowBalanceStatus = LOADING;
    });
    builder.addCase(updateDisplayBalance.rejected, state => {
      state.allowShowBalanceStatus = FAIL;
    });
    builder.addCase(submitUnlockFund.fulfilled, (state, { meta, payload }) => {
      state.fundLockStatus = SUCCESS;
      const found = state.accounts.find(item => item.accountNo === meta.arg.fromAcc);
      if (found) {
        found.isPendingUnlock = true;
      }
    });
    builder.addCase(submitCancelUnlock.fulfilled, (state, { meta }) => {
      const found = state.accounts.find(item => item.accountNo === meta.arg.fromAccNo);
      if (found) {
        found.isPendingUnlock = false;
      }
      state.fundLockStatus = SUCCESS;
    });
    builder.addCase(loadLockFundAmount.pending, (state, { meta }) => {
      state.lockAmountStatus = LOADING;
    });
    builder.addCase(loadLockFundAmount.rejected, (state, { meta }) => {
      state.lockAmountStatus = FAIL;
    });
    builder.addCase(loadLockFundAmount.fulfilled, (state, { meta, payload }) => {
      state.lockAmountStatus = SUCCESS;
      // If payload.lockedAmount is undefined HOST return error, it means the lock fund service is not available
      if (payload?.lockedAmount === undefined) state.fundLockService = false;
      const found = state.accounts.find(item => item.accountNo === meta.arg.fromAccNo);
      if (found) {
        found.lockedAmount = payload.lockedAmount;
      }
    });
    builder.addCase(submitLockFund.fulfilled, (state, { meta, payload }) => {
      state.fundLockStatus = SUCCESS;
      const found = state.accounts.find(item => item.accountNo === meta.arg.fromAcc);
      if (found) {
        found.lockedAmount = payload.lockedAmount;
        found.holdAmount = payload.holdAmount;
      }
    });

    builder.addCase(loadMoneyMarketDeposit.pending, state => {
      state.moneyMarketDepositStatus = 'loading';
    });
    builder.addCase(loadMoneyMarketDeposit.fulfilled, (state, { payload }) => {
      state.moneyMarketDepositStatus = 'succeeded';
      moneyMarketDepositAdapter.upsertMany(state.moneyMarketDeposit, payload.mmdList);
    });
    builder.addCase(loadMoneyMarketDeposit.rejected, state => {
      state.moneyMarketDepositStatus = 'failed';
    });

    builder.addMatcher(isAnyOf(submitCancelUnlock.pending, submitUnlockFund.pending, submitLockFund.pending), state => {
      state.fundLockStatus = LOADING;
    });
    builder.addMatcher(
      isAnyOf(submitCancelUnlock.rejected, submitUnlockFund.rejected, submitLockFund.rejected),
      state => {
        state.fundLockStatus = FAIL;
      },
    );

    builder.addMatcher(isAnyOf(loadCasa.pending, loadCasaPrivate.pending), state => {
      state.accountsStatus = 'loading';
    });
    builder.addMatcher(isAnyOf(loadCasa.fulfilled, loadCasaPrivate.fulfilled), (state, { payload }) => {
      state.accountsStatus = 'succeeded';
      if (payload.accountSummary) state.accounts = payload.accountSummary;
      state.isExistJourney = payload.journeyAccExists;
      state.balanceLastEnquiryTime = utc8DateTime().valueOf();

      //lock Fund
      state.minLockFundAmount = payload.minLockFundAmount;
      state.fundLockService = payload.fundLockService;
    });
    builder.addMatcher(isAnyOf(loadCasa.rejected, loadCasaPrivate.rejected), state => {
      state.accountsStatus = 'failed';
    });

    builder.addMatcher(accountService.endpoints.fetchMoneyPlus.matchPending, state => {
      state.moneyPlusStatus = 'loading';
    });
    builder.addMatcher(accountService.endpoints.fetchMoneyPlus.matchFulfilled, (state, { payload, meta }) => {
      state.moneyPlusStatus = 'succeeded';
      if (payload?.data !== undefined) {
        state.moneyPlus = payload.data;
      }
    });
    builder.addMatcher(accountService.endpoints.fetchMoneyPlus.matchRejected, state => {
      state.moneyPlusStatus = 'failed';
    });

    builder.addMatcher(
      isAnyOf(
        submitFundTransfer.fulfilled,
        submitCardPayment.fulfilled,
        submitLoanPayment.fulfilled,
        submitQRPayment.fulfilled,
        submitBillPayment.fulfilled,
        submitTopUp.fulfilled,
        transferJourney.fulfilled,
        completeJourneyTask.fulfilled,
        withdrawJourney.fulfilled,
        submitCardlessWithdraw.fulfilled,
        cancelCardlessWithdrawal.fulfilled,
        submitBakong.fulfilled,
        submitAlipayPlus.fulfilled,
        submitDepositPlacement.fulfilled,
        submitCarbonOffset.fulfilled,
        submitLockFund.fulfilled,
      ),
      (state, { payload, meta }) => {
        const found = state.accounts.find(item => item.accountNo === meta.arg.fromAcc);
        if (found) {
          if (payload.availableBalance || payload.availableBalance === 0)
            found.availableBalance = payload.availableBalance;
          if (payload.currentBalance || payload.currentBalance === 0) found.currentBalance = payload.currentBalance;
        }
      },
    );
  },
});

export const { casaInit, casaReset, casaHistoryReset, casaUnderReviewReset, updateCasaObject, updateAccountBalance } =
  slice.actions;
export default slice.reducer;

export const resetCasa = () => casaReset();
export const initCasa = () => casaInit();
