import { createApi } from '@reduxjs/toolkit/query/react';
import * as clientObj from 'apis';
import { CONNECTION_TIMEOUT, Demo } from 'constant';
import { RTK_QUERY_TAGS } from './rtkQueryTags';
import { requestTimeout } from 'apis/utils';

const baseQuery = async (
  {
    url,
    method = 'get',
    params,
    data,
    axiosConfig = {},
    apiClientType = 'publicClient',
    responseHandler,
    demoResponse,
  },
  { getState },
) => {
  //Direct Fetch URL
  if (method === 'fetch') {
    try {
      if (Demo.User.Check(getState) && demoResponse) return { data: { data: demoResponse } };
      const result = await requestTimeout(fetch(url, data), { timeout: 15000, ...axiosConfig });
      if (result.status === CONNECTION_TIMEOUT) return { error: { status: CONNECTION_TIMEOUT, data: result } };
      const response = responseHandler ? await responseHandler(result) : await result.json();
      return response?.error ? { error: response.error } : { data: response };
    } catch (error) {
      return { error: { status: 'R01', data: error.message } };
    }
  }

  if (Demo.User.Check(getState)) return { data: { data: demoResponse } };

  //Call PBe API
  const arg2 = ['post', 'put', 'patch'].includes(method) ? data : params;

  const result = await clientObj[apiClientType][method](url, arg2, axiosConfig);

  // remove headers and config from result

  const { headers, config, ...cleanedResult } = result;

  return cleanedResult.ok
    ? {
        data: {
          ...cleanedResult,
          originalError: null,
        },
      }
    : {
        error: {
          ...cleanedResult,
          originalError: {
            code: cleanedResult?.originalError?.code,
            message: cleanedResult?.originalError?.message,
            status: cleanedResult?.originalError?.status,
          },
        },
      };
};

const baseQueryApi = createApi({
  reducerPath: 'baseQuery',
  baseQuery,
  refetchOnMountOrArgChange: true,
  keepUnusedDataFor: 0,
  tagTypes: [...RTK_QUERY_TAGS.PUBLIC, ...RTK_QUERY_TAGS.PRIVATE],
  endpoints: () => ({}),
});

export { baseQueryApi };
