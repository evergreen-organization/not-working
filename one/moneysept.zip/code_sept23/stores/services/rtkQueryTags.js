export const RTK_PUBLIC_TAG = {
  PDF: 'PDF',
  MONEYPLUS: 'MONEYPLUS',
};

export const RTK_PRIVATE_TAG = {};

export const RTK_QUERY_TAGS = {
  PUBLIC: Object.values(RTK_PUBLIC_TAG),
  PRIVATE: Object.values(RTK_PRIVATE_TAG),
};
