import { apiEndpoint } from 'apis';
import { baseQueryApi } from '../baseQuery';
import { RTK_PUBLIC_TAG } from '../rtkQueryTags';

//Account services
export const accountService = baseQueryApi.injectEndpoints({
  endpoints: builder => ({
    fetchMoneyPlus: builder.query({
      query: accNo => ({
        url: `${apiEndpoint.public}/mpDetails`,
        method: 'post',
        data: { accountNo: accNo },
      }),
      providesTags: [RTK_PUBLIC_TAG.MONEYPLUS],
      keepUnusedDataFor: 86400,
    }),
  }),
  overrideExisting: true,
});

export const { useFetchMoneyPlusQuery, useLazyFetchMoneyPlusQuery } = accountService;
