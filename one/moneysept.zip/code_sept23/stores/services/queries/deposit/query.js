import { convertBlobToBase64 } from 'utils';
import { baseQueryApi } from '../../baseQuery';
import { RTK_PUBLIC_TAG } from '../../rtkQueryTags';

// Deposit Placement Slip PDF
export const depositService = baseQueryApi.injectEndpoints({
  endpoints: builder => ({
    fetchPdf: builder.query({
      query: url => ({
        method: 'fetch',
        url,
        responseHandler: response => response.blob(),
      }),
      transformResponse: async response => {
        try {
          const pdfSlip = await convertBlobToBase64(response);
          return { data: pdfSlip };
        } catch (e) {
          return { data: null };
        }
      },
      providesTags: [RTK_PUBLIC_TAG.PDF],
      keepUnusedDataFor: 86400, //cache for 1 day
    }),
  }),
  overrideExisting: true,
});

export const { useLazyFetchPdfQuery } = depositService;
