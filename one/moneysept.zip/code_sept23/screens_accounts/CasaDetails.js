import React, { useEffect, useState } from 'react';
import { Image, Linking, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { useActionSheet } from '@expo/react-native-action-sheet';

import { useApi, useCasa, useHandleDispatch, useCheckMoneyPlus } from 'hooks';
import routes from 'navigations/routes';
import { colors } from 'configs';
import { formatAmountDisplay, showFailure, showSuccess, useAccessControl } from 'utils';
import { ScreenFull, SkeletonCasaDetails, Space, LinkText, Loading } from 'atoms';
import { Text } from 'components';
import { NavBar } from 'organisms';
import {
  casaHistoryReset,
  casaUnderReviewReset,
  changeCasaAccountNickname,
  getCasa,
  getOtherUrlByTag,
  getMoneyPlus,
  getSoftToken,
  loadLockFundAmount,
  updateCasaObject,
  updatePrefAccount,
} from 'stores';

import HistoryIcon from 'assets/images/basiccolor/history.png';
import ReviewDocIcon from 'assets/images/basiccolor/reviewdoc.png';
import MoreIcon from 'assets/images/icon/more.png';
import TransferIcon from 'assets/images/basiccolor/plane.png';
import InfoIcon from 'assets/images/icon/info.png';
import {
  AccountDetailsTable,
  BalanceAmount,
  DebitCard,
  EditNicknamePopUp,
  MultiForeignCurrencySection,
  OthersQuickLinkSection,
  MoneyPlusCategorySection,
  MoneyPlusMabSection,
} from './components';

import { useTranslation } from 'react-i18next';
import { balanceAmountColorSets, isMoneyPlusAccount } from 'screens/accounts/utils';
import { FAIL, LOADING, SUCCESS } from 'apis';
import _ from 'lodash';
import { otherUrlTag } from '../../constant';
import { BottomDrawerModalMini } from 'molecules';
import InfoNotFound from '../../components/atoms/InfoNotFound';
import CreditCardIcon from 'assets/images/basiccolor/creditcard.png';
import LoanIcon from 'assets/images/basiccolor/loan.png';
import PercentIcon from 'assets/images/basiccolor/percent.png';
import { LockFund } from './components/lockFund';

const nickNameRegex = /^[-a-zA-Z0-9 ]+$/g;
const LANG_PREFIX = 'screens.casaDetails.text.';

const renderMabNotEligibleSection = msg => {
  return (
    <View style={styles.mabNotEligibleContainer}>
      <Text style={styles.mabNotEligibleText}>{msg}</Text>
    </View>
  );
};

export const CasaDetails = ({ navigation, route }) => {
  const { load: loadCasa } = useCasa({});
  const { t } = useTranslation();
  const { showActionSheetWithOptions } = useActionSheet();
  const accessControl = useAccessControl({ navigation });
  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const store_casa = useSelector(getCasa);
  const store_softToken = useSelector(getSoftToken);
  const { fundLockService, lockAmountStatus, accountsStatus: casaStatus } = store_casa;
  const accountIndex = store_casa.accounts.findIndex(item => item.accountNo === route.params?.accountNo);
  const fundLockURL = useSelector(getOtherUrlByTag({ tag: otherUrlTag.INFO_FUND_LOCK }))?.url;

  const updatePrefAccountApi = useApi(updatePrefAccount);
  const changeAccountNicknameApi = useApi(changeCasaAccountNickname);
  const [isEditNicknameModalVisible, setIsEditNicknameModalVisible] = useState(false);
  const {
    availableBalance,
    accountNo,
    accountStatus,
    statusType,
    accountDesc,
    nickName,
    currency,
    currentBalance,
    debitCardNo,
    debitCardExpiryDate,
    debitCardType,
    debitCardLimit,
    productType,
    lockFundAvailable,
    mfcAccountInfo,
    holdAmount,
    lockedAmount,
    accName,
    mmdExist,
  } = store_casa.accounts[accountIndex] || {};
  const isMultiFcyAccount = mfcAccountInfo?.length > 0;
  const sortedMultiFCDDetailsList = _.sortBy(mfcAccountInfo, 'currency');
  const [selectedMultiFcy, setSelectedMultiFcy] = useState(isMultiFcyAccount ? sortedMultiFCDDetailsList[0] : null);
  const [isFundLockDowntimeInfoModalVisible, setIsFundLockDowntimeInfoModalVisible] = useState(false);

  const hasFinancialAccess = accountStatus && currency === 'RM' && productType !== 'SHARE_LINK' && !isMultiFcyAccount;

  // const debitCardNo = "5362800053260475";
  // const debitCardExpiryDate = "12/25";
  // const debitCardType = "M";
  // const debitCardLimit = 1000;
  const isMoneyPlus = isMoneyPlusAccount(productType);
  const moneyPlus = useSelector(getMoneyPlus(accountNo));
  const moneyPlusDetails = moneyPlus?.data?.mpDetails || {};
  const { isLoading, handleRetryMoneyPlus, checkMoneyPlus } = useCheckMoneyPlus({
    accountNo,
    isMoneyPlus,
    moneyPlusDetails,
  });

  useEffect(() => {
    return () => {
      dispatch(casaHistoryReset());
      dispatch(casaUnderReviewReset());
    };
  }, []);

  useEffect(() => {
    if (casaStatus === SUCCESS) checkMoneyPlus().then();
  }, [casaStatus]);

  useEffect(() => {
    dispatch(casaHistoryReset());
    dispatch(casaUnderReviewReset());
  }, [selectedMultiFcy]);

  useEffect(() => {
    /*Fetch lock fund amount when navigating directly to preferred account details from home
     This ensures we have the latest data after the casa list is successfully retrieved*/
    if (casaStatus === SUCCESS) getLockFundAmount().then();
  }, [casaStatus]);

  const getLockFundAmount = async () => {
    /*fund lock service down 12am-2am or when host return error which lockedAmount equals undefined don't call the inquiry again*/
    if (!fundLockService || !lockFundAvailable || lockAmountStatus === LOADING || lockedAmount !== undefined) return;
    await handleDispatch(loadLockFundAmount({ fromAccNo: accountNo }));
  };
  const showHistory = () => {
    dispatch(
      updateCasaObject({
        historyAccountNo: route.params?.accountNo,
        childAcc: selectedMultiFcy?.accountNo,
        foreignCurrency: isMultiFcyAccount ? selectedMultiFcy.currency : '',
      }),
    );
    navigation.navigate(routes.CASA_HISTORY, {
      type: 'casa',
    });
  };

  const showUnderReview = () => {
    dispatch(updateCasaObject({ historyAccountNo: route.params?.accountNo }));
    navigation.navigate(routes.UNDER_REVIEW);
  };

  const showMoneyMarketDeposit = () => {
    navigation.navigate(routes.MONEY_MARKET_PLACEMENT_DETAILS, { accountNo });
  };

  const setPreferred = async () => {
    if (accountNo === store_softToken.preferredAccountNo) return;
    const result = await updatePrefAccountApi.request({ accountNo, accountDesc, accName });
    if (result.problem) return showFailure(result.problem);
    showSuccess(t(`${LANG_PREFIX}msgSuccessful`));
  };

  const transfer = () => accessControl.navigate(routes.TRANSFER_TO, { fromAcc: accountNo });

  const transferCard = () => accessControl.navigate(routes.PAY_CARD, { fromAcc: accountNo });

  const transferLoan = () => accessControl.navigate(routes.PAY_LOAN, { fromAcc: accountNo });

  const handleEditNicknamePress = () => setIsEditNicknameModalVisible(true);

  const handleRemoveNickname = () => onEditNicknameConfirm(null);

  const handleCurrencyPress = item => {
    setSelectedMultiFcy(item);
  };

  const optionConditions = [
    {
      enable: hasFinancialAccess,
      options: [t(`${LANG_PREFIX}actionSheetPreferredAccountOption`)],
      actions: [setPreferred],
    },
    {
      enable: true,
      options: [t(`${LANG_PREFIX}actionSheetUpdateNicknameOption`)],
      actions: [handleEditNicknamePress],
    },
    {
      enable: nickName,
      options: [t(`${LANG_PREFIX}actionSheetRemoveNicknameOption`)],
      actions: [handleRemoveNickname],
    },
    {
      enable: true,
      options: [t(`${LANG_PREFIX}actionSheetCancelOption`)],
    },
  ];

  const actionSheetOptions = optionConditions.reduce(
    (result, { enable, options, actions }, index) => {
      if (enable) {
        result.options.push(...options);
        result.actions.push(...(actions || []));
      }
      if (index === optionConditions.length - 1) {
        result.cancelButtonIndex = result.options.length - 1;
        if (optionConditions[optionConditions.length - 2]?.enable) {
          result.destructiveButtonIndex = result.options.length - 2;
        }
      }
      return result;
    },
    { options: [], actions: [] },
  );

  const handleOpenMoreAS = () => {
    showActionSheetWithOptions({ ...actionSheetOptions, userInterfaceStyle: 'light' }, index =>
      actionSheetOptions.actions[index]?.(),
    );
  };

  const onEditNicknameConfirm = async nickName => {
    setIsEditNicknameModalVisible(false);
    if (nickName === '') nickName = null;
    const result = await changeAccountNicknameApi.request({ accountNo, nickName });
    if (result.problem) return showFailure(result.problem);
  };

  const initialValues = {
    nickName: nickName,
  };

  const onSubmit = async ({ nickName }) => onEditNicknameConfirm(nickName);

  const handleCloseEditNicknamePopup = () => setIsEditNicknameModalVisible(false);

  const handleCloseFundLockInfoModal = () => setIsFundLockDowntimeInfoModalVisible(false);
  const handleOpenFundLockInfoModal = () => setIsFundLockDowntimeInfoModalVisible(true);

  const handleOpenUrl = () => Linking.openURL(fundLockURL);

  const tableItems = [
    { title: t(`${LANG_PREFIX}itemAccountName`), value: accountDesc },
    { title: t(`${LANG_PREFIX}itemAccountNo`), value: accountNo, copyable: true },
    {
      title: isMultiFcyAccount ? t(`${LANG_PREFIX}itemTotalCurrentBalance`) : t(`${LANG_PREFIX}itemCurrentBalance`),
      value: currentBalance,
      currency,
    },
    ...(fundLockService && lockFundAvailable
      ? [
          {
            title: t(`${LANG_PREFIX}itemHoldAmount`),
            value: lockedAmount ? holdAmount - lockedAmount : holdAmount,
            currency,
            status: lockAmountStatus,
            handleRetry: getLockFundAmount,
          },
        ]
      : []),
    ...(!fundLockService && lockFundAvailable
      ? [
          {
            title: t(`${LANG_PREFIX}itemHoldAndLockedAmount`),
            value: holdAmount,
            currency,
            icon: InfoIcon,
            handleIconPress: handleOpenFundLockInfoModal,
          },
        ]
      : []),
  ];

  const quickLinkList =
    currency === 'RM' && !isMultiFcyAccount
      ? [
          { label: t(`${LANG_PREFIX}labelHistory`), icon: HistoryIcon, action: showHistory },
          { label: t(`${LANG_PREFIX}labelOnHold`), icon: ReviewDocIcon, action: showUnderReview },
          ...(mmdExist
            ? [
                {
                  label: t(`${LANG_PREFIX}labelMoneyMarketDeposit`),
                  icon: PercentIcon,
                  action: showMoneyMarketDeposit,
                },
              ]
            : []),
        ]
      : [{ label: t(`${LANG_PREFIX}labelHistory`), icon: HistoryIcon, action: showHistory }];

  const quickLinkList_action = [
    { label: t(`${LANG_PREFIX}labelSendMoney`), icon: TransferIcon, action: transfer },
    { label: t(`${LANG_PREFIX}labelPayCard`), icon: CreditCardIcon, action: transferCard },
    { label: t(`${LANG_PREFIX}labelPayLoan`), icon: LoanIcon, action: transferLoan },
  ];

  if (casaStatus === LOADING)
    return (
      <ScreenFull>
        <NavBar title={t(`${LANG_PREFIX}titleAccounts`)} back />
        <SkeletonCasaDetails />
      </ScreenFull>
    );

  if (casaStatus === FAIL || accountIndex === -1)
    return (
      <ScreenFull>
        <NavBar title={t(`${LANG_PREFIX}titleAccounts`)} back />
        <InfoNotFound title={'Info Not Found'} onRefresh={loadCasa} />
      </ScreenFull>
    );

  return (
    <ScreenFull>
      <NavBar
        title={t(`${LANG_PREFIX}titleAccounts`)}
        back
        renderRightButton={
          accountStatus && (
            <TouchableOpacity
              accessibilityLabel={t(`${LANG_PREFIX}labelMore`)}
              accessibilityRole={'button'}
              onPress={handleOpenMoreAS}
              style={styles.sideBtn}>
              <Image source={MoreIcon} style={styles.sideBtnIcon} />
            </TouchableOpacity>
          )
        }
      />
      <ScrollView showsVerticalScrollIndicator={false}>
        <BalanceAmount
          title={isMultiFcyAccount ? t(`${LANG_PREFIX}titleTotalBalanceAmount`) : t(`${LANG_PREFIX}titleBalanceAmount`)}
          amount={availableBalance}
          currency={currency}
          colorSets={balanceAmountColorSets.positiveGreen}
        />
        <AccountDetailsTable
          statusType={statusType}
          isActive={accountStatus}
          nickName={nickName}
          tableItems={tableItems}
          isPreferredAccount={accountNo === store_softToken.preferredAccountNo}
        />

        {lockFundAvailable && <LockFund navigation={navigation} accountIndex={accountIndex} />}

        {isMultiFcyAccount && (
          <MultiForeignCurrencySection
            handleCurrencySelect={handleCurrencyPress}
            quickLinkList={quickLinkList}
            mfcAccountInfo={mfcAccountInfo}
            selectedCurrency={selectedMultiFcy?.currency}
          />
        )}

        {debitCardNo !== '' && (
          <DebitCard
            currency={currency}
            debitCardNo={debitCardNo}
            debitCardExpiryDate={debitCardExpiryDate}
            debitCardLimit={debitCardLimit}
            debitCardType={debitCardType}
          />
        )}

        {isMoneyPlus && (
          <>
            <MoneyPlusMabSection
              isLoading={isLoading}
              currency={currency}
              data={moneyPlusDetails}
              handleRetryMoneyPlus={handleRetryMoneyPlus}
            />
            <MoneyPlusCategorySection isLoading={isLoading} currency={currency} data={moneyPlusDetails} />
            {moneyPlusDetails?.monthlyAverageBal < moneyPlusDetails?.eligibleAmount &&
              renderMabNotEligibleSection(
                t(`${LANG_PREFIX}mabNotEligibleText`)
                  .replace(
                    '${amount}',
                    moneyPlusDetails?.eligibleAmount ? formatAmountDisplay(moneyPlusDetails?.eligibleAmount) : '',
                  )
                  .replace('${currency}', currency ? currency : ''),
              )}
          </>
        )}

        {!isMultiFcyAccount && <OthersQuickLinkSection quickLinksList={quickLinkList} />}
        {hasFinancialAccess && (
          <OthersQuickLinkSection quickLinksList={quickLinkList_action} title={t(`${LANG_PREFIX}labelQuickAccess`)} />
        )}

        <Space height={50} />
      </ScrollView>

      <EditNicknamePopUp
        isVisible={isEditNicknameModalVisible}
        onSubmit={onSubmit}
        onClose={handleCloseEditNicknamePopup}
        initialValues={initialValues}
        regexValidation={nickNameRegex}
      />
      {store_casa?.fundLockStatus === LOADING && <Loading variant={Loading.variants.fullscreen} />}

      <FundLockDownTimeInfoModal
        isVisible={isFundLockDowntimeInfoModalVisible}
        onClose={handleCloseFundLockInfoModal}
        onOpenUrl={handleOpenUrl}
        t={t}
      />
    </ScreenFull>
  );
};

const FundLockDownTimeInfoModal = ({ t, isVisible, onClose, onOpenUrl }) => (
  <BottomDrawerModalMini isVisible={isVisible} closeModal={onClose}>
    <View style={{ padding: 20 }}>
      <Text>{t(`${LANG_PREFIX}tooltipFundLockDowntimePreLinkLine1`)}</Text>
      <Text style={{ marginVertical: 10 }}>{t(`${LANG_PREFIX}tooltipFundLockDowntimePreLinkLine2`)}</Text>
      <LinkText
        preLinkText={t(`${LANG_PREFIX}tooltipFundLockDowntimePreLinkText`)}
        linkText={t(`${LANG_PREFIX}tooltipFundLockDowntimeLinkText`)}
        postLinkText={t(`${LANG_PREFIX}tooltipFundLockDowntimePostLinkText`)}
        onPress={onOpenUrl}
      />
    </View>
  </BottomDrawerModalMini>
);
export default CasaDetails;

const styles = StyleSheet.create({
  cardContainer: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    paddingVertical: 12,
    marginBottom: 10,
  },
  detailContainer: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  btn: {
    paddingHorizontal: 12,
    backgroundColor: colors.primary,
    borderRadius: 10,
    marginLeft: 12,
    justifyContent: 'center',
  },
  sideBtn: {
    height: 44,
    width: 42,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sideBtnIcon: {
    width: 15,
    height: 15,
    tintColor: colors.black,
    marginRight: 5,
  },
  mabNotEligibleContainer: {
    borderRadius: 5,
    backgroundColor: colors.lightestRed,
    marginHorizontal: 10,
    padding: 10,
    marginBottom: 10,
  },
  mabNotEligibleText: {
    fontSize: 12,
    textAlign: 'center',
    color: colors.medium,
  },
});
