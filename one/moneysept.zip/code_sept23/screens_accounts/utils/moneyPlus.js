import { utc8DateTime } from 'utils';

export const isYtdSameAsUpdatedDate = mabDate => {
  const aDayBefore = utc8DateTime().subtract(1, 'day').format('DD/MM/YYYY'); // Format today's date
  return aDayBefore === mabDate; // Compare the two dates
};

export const isMoneyPlusAccount = productType => {
  return productType === 'MONEY_PLUS';
};
