import React from 'react';
import { LinkText, SkeletonMoneyPlusCircle } from 'atoms';
import { colors } from 'configs';
import { useTranslation } from 'react-i18next';
import { Text, View } from 'react-native';
import { styles } from './styles';
import MoneyPlusCircles from 'components/molecules/MoneyPlusCircles';
import PayIcon from 'assets/images/icon/mpPay.png';
import SaveIcon from 'assets/images/icon/mpSave.png';
import SpendIcon from 'assets/images/icon/mpSpend.png';

export const MoneyPlusCategorySectionView = ({ isLoading, handleDisplayBonusInterestRate, data, currency }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.casaDetails.text.';

  const {
    payAmount,
    payAmountTarget,
    saveAmount,
    saveAmountTarget,
    spendAmount,
    spendAmountTarget,
    monthlyAverageBal,
    eligibleAmount,
  } = data || {};

  const mabAchieved = monthlyAverageBal > eligibleAmount;
  const isDataAvailable = !!payAmountTarget && !!saveAmountTarget && !!spendAmountTarget;
  const isPayAmountValid = (!!payAmount || payAmount === 0) && !!payAmountTarget;
  const isSaveAmountValid = (!!saveAmount || saveAmount === 0) && !!saveAmountTarget;
  const isSpendAmountValid = (!!spendAmount || spendAmount === 0) && !!spendAmountTarget;

  return (
    <View>
      <View style={styles.container}>
        <View style={styles.circleContainer}>
          {isLoading ? (
            <View style={styles.skeletonContainer}>
              <SkeletonMoneyPlusCircle />
            </View>
          ) : (
            <View style={styles.circleRowContainer}>
              {isPayAmountValid && (
                <MoneyPlusCircles
                  amount={payAmount}
                  targetAmount={payAmountTarget}
                  isMabAchieved={mabAchieved}
                  circleIcon={PayIcon}
                  circleLabel={t(`${LANG_PREFIX}payCategoryTitle`)}
                  currency={currency}
                  data={data}
                />
              )}
              {isSaveAmountValid && (
                <MoneyPlusCircles
                  amount={saveAmount}
                  targetAmount={saveAmountTarget}
                  isMabAchieved={mabAchieved}
                  circleIcon={SaveIcon}
                  circleLabel={t(`${LANG_PREFIX}saveCategoryTitle`)}
                  currency={currency}
                  data={data}
                />
              )}
              {isSpendAmountValid && (
                <MoneyPlusCircles
                  amount={spendAmount}
                  targetAmount={spendAmountTarget}
                  isMabAchieved={mabAchieved}
                  circleIcon={SpendIcon}
                  circleLabel={t(`${LANG_PREFIX}spendCategoryTitle`)}
                  currency={currency}
                  data={data}
                />
              )}
            </View>
          )}
        </View>

        {(isLoading || isDataAvailable) && <View style={styles.border} />}

        <View style={styles.disclaimerContainer}>
          <Text style={styles.disclaimerText}>{t(`${LANG_PREFIX}interestRateDisclaimer`)}</Text>
          <LinkText
            preLinkText={t(`${LANG_PREFIX}bonusInterestPreLinkText`)}
            linkText={t(`${LANG_PREFIX}bonusInterestLinkText`)}
            postLinkText={t(`${LANG_PREFIX}bonusInterestPostLinkText`)}
            onPress={handleDisplayBonusInterestRate}
            style={styles.disclaimerDesc}
            linkStyle={{ color: colors.primary }}
          />
        </View>
      </View>
    </View>
  );
};
