import { StyleSheet } from 'react-native';
import { colors } from 'configs';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginHorizontal: 10,
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 10,
  },
  circleContainer: {
    marginTop: 15,
  },
  border: {
    borderTopWidth: 1,
    paddingBottom: 15,
    marginTop: 13,
    borderColor: colors.border,
  },
  disclaimerContainer: {
    marginBottom: 15,
    gap: 2,
  },
  disclaimerText: {
    fontSize: 12,
    color: colors.medium,
  },
  disclaimerDesc: {
    fontSize: 12,
    color: colors.medium,
  },
  circleRowContainer: {
    flexDirection: 'row',
    flex: 1,
  },
  skeletonContainer: {
    backgroundColor: colors.white,
    alignItems: 'center',
  },
});
