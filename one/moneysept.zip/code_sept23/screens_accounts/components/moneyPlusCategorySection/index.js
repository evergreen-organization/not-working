import React from 'react';
import { MoneyPlusCategorySectionView } from './component';
import { Linking } from 'react-native';

export const MoneyPlusCategorySection = ({ isLoading, currency, data }) => {
  const handleDisplayBonusInterestRate = () => {
    Linking.openURL('https://www.pbebank.com/en/banking/savings-account/moneyplus-savings-account');
  };

  return (
    <MoneyPlusCategorySectionView
      isLoading={isLoading}
      handleDisplayBonusInterestRate={handleDisplayBonusInterestRate}
      currency={currency}
      data={data}
    />
  );
};
