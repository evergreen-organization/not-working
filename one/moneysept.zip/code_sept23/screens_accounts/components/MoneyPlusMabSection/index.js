/* eslint-disable react/react-in-jsx-scope */
import { Linking } from 'react-native';
import { MoneyPlusMabSectionView } from './component';
import { useState } from 'react';

export const MoneyPlusMabSection = ({ isLoading, currency, data, handleRetryMoneyPlus }) => {
  const [mabInfoModalVisible, setMabInfoModalVisible] = useState(false);

  const handleDisplayMabInfo = () => {
    Linking.openURL('https://www.pbebank.com/en/rates-charges/illustration-of-interest-earned/#moneyplus');
  };

  const handleDisplayMabModal = () => {
    setMabInfoModalVisible(true);
  };
  const handleCloseMabInfo = () => {
    setMabInfoModalVisible(false);
  };

  return (
    <MoneyPlusMabSectionView
      isLoading={isLoading}
      handleDisplayMabInfo={handleDisplayMabInfo}
      handleDisplayMabModal={handleDisplayMabModal}
      handleCloseMabInfo={handleCloseMabInfo}
      handleRetryMoneyPlus={handleRetryMoneyPlus}
      mabInfoModalVisible={mabInfoModalVisible}
      currency={currency}
      data={data}
    />
  );
};
