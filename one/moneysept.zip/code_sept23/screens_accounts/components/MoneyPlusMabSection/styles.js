import { StyleSheet } from 'react-native';
import { colors } from 'configs';
import { FONT_FAMILY_BOLD } from 'styles/fonts';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginHorizontal: 10,
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 10,
  },
  titleView: {
    marginTop: 15,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  titleText: {
    fontSize: 12,
    color: colors.medium,
  },
  icon: {
    height: 12,
    width: 12,
    tintColor: colors.medium,
  },
  mabTextContainer: {
    marginVertical: 20,
    flex: 1,
    alignItems: 'center',
  },
  mabTextView: {
    alignItems: 'center',
  },
  mabTextValue: {
    fontSize: 26,
    color: colors.black,
    fontFamily: FONT_FAMILY_BOLD,
  },
  mabUpdateText: {
    fontSize: 12,
    color: colors.medium,
  },
  mabContentContainer: {
    gap: 10,
  },
  mabInfoTitleText: {
    fontSize: 14,
    fontFamily: FONT_FAMILY_BOLD,
  },
  mabInfoText: {
    fontSize: 14,
    color: colors.medium,
  },
  skeletonContainer: {
    gap: 10,
    flex: 1,
    marginVertical: 4,
  },
});
