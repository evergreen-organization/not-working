import React from 'react';
import { Flex, LinkText, SkeletonSingleItem } from 'atoms';
import { Image, Text, TouchableOpacity } from 'react-native';
import { View } from 'react-native';
import { styles } from './styles';
import { Money } from 'components';
import { colors } from 'configs';
import InfoIcon from 'assets/images/icon/help.png';
import { ActionModal, ItemErrorRetry } from 'molecules';
import { ApiDateFormat, displayDateFullMonthFormat } from 'constant';
import dayjs from 'dayjs';
import { formatAmountDisplay } from 'utils';
import { useTranslation } from 'react-i18next';

export const MoneyPlusMabSectionView = ({
  isLoading,
  handleDisplayMabInfo,
  handleDisplayMabModal,
  mabInfoModalVisible,
  handleCloseMabInfo,
  handleRetryMoneyPlus,
  currency,
  data,
}) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.casaDetails.text.';

  const { eligibleAmount, monthlyAverageBal, moneyPlusDate } = data || {};

  const renderMabModalContent = () => {
    return (
      <View style={styles.mabContentContainer}>
        <Text style={styles.mabInfoTitleText}>
          {t(`${LANG_PREFIX}mabInfoTitle`)
            .replace('${amount}', eligibleAmount ? formatAmountDisplay(eligibleAmount) : '')
            .replace('${currency}', currency ? currency : '')}
        </Text>
        <Text style={styles.mabUpdateText}>{t(`${LANG_PREFIX}mabInfoSubtitle`)}</Text>
        <LinkText
          preLinkText={t(`${LANG_PREFIX}mabInfoPreLinkText`)}
          linkText={t(`${LANG_PREFIX}mabInfoLinkText`)}
          onPress={handleDisplayMabInfo}
          style={styles.mabInfoText}
        />
      </View>
    );
  };

  const handleDate = date => {
    return dayjs(date, ApiDateFormat).format(displayDateFullMonthFormat);
  };

  return (
    <View>
      <Flex style={styles.container}>
        <View style={styles.titleView}>
          <Text style={styles.titleText}>{t(`${LANG_PREFIX}titleMab`)}</Text>
          <TouchableOpacity onPress={handleDisplayMabModal}>
            <Image source={InfoIcon} style={styles.icon} />
          </TouchableOpacity>
        </View>
        <View style={styles.mabTextContainer}>
          {isLoading ? (
            <View style={styles.skeletonContainer}>
              <SkeletonSingleItem height={20} />
              <SkeletonSingleItem height={20} />
            </View>
          ) : (
            <View style={styles.mabTextView}>
              {monthlyAverageBal ? (
                <>
                  <Money
                    isCurrencyBold={true}
                    currency={currency}
                    amount={monthlyAverageBal}
                    size={25}
                    color={colors.black}
                  />
                  {moneyPlusDate && (
                    <Text style={styles.mabUpdateText}>
                      {t(`${LANG_PREFIX}amountDate`) + ' ' + `${handleDate(moneyPlusDate)}`}
                    </Text>
                  )}
                </>
              ) : (
                <>
                  <ItemErrorRetry onRetry={handleRetryMoneyPlus} />
                </>
              )}
            </View>
          )}
        </View>

        <ActionModal
          isVisible={mabInfoModalVisible}
          leftButtonType={'normal'}
          rightButtonTitle={'Close'}
          renderContent={renderMabModalContent}
          onDecline={handleCloseMabInfo}
        />
      </Flex>
    </View>
  );
};
