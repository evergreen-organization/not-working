import React, { useEffect, useRef, useState } from 'react';
import { Image, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { useActionSheet } from '@expo/react-native-action-sheet';

import routes from 'navigations/routes';
import { colors, tagColors } from 'configs';
import { useApi, useDepositPlacement } from 'hooks';
import { ScreenFull, Space } from 'atoms';
import { showFailure } from 'utils';
import { NavBar } from 'organisms';
import {
  changeDepositAccountNickname,
  getDeposit,
  loadDepositHistory,
  resetDepositHistory,
  resetFdDetails,
  updateNewDepositPlacementObject,
  updateNewDepositWithdrawObject,
  getDepositDetailByAccNo,
  getUser,
  getOtherUrlByTag,
  useLazyFetchPdfQuery,
} from 'stores';
import { alphanumericSpaceRegex } from 'constant';

import HistoryIcon from 'assets/images/basiccolor/history.png';
import PercentIcon from 'assets/images/basiccolor/percent.png';
import MoreIcon from 'assets/images/icon/more.png';
import {
  AccountDetailsTable,
  BalanceAmount,
  EditNicknamePopUp,
  MultiForeignCurrencySection,
  OthersQuickLinkSection,
  EFDCertSection,
} from './components';
import { useTranslation } from 'react-i18next';
import { balanceAmountColorSets } from 'screens/accounts/utils';
import _ from 'lodash';
import { editDepositPlacementPdf, isPlacementMatured } from 'screens/deposit/utils';
import { useAccessControl } from 'utils';
import PlusIcon from 'assets/images/icon/plus.png';
import MinusIcon from 'assets/images/icon/minus.png';
import { Text, PDFLinks } from 'components';
import { FD_TYPE, otherUrlTag } from 'constant';

export const Deposit = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.depositDetails.text.';

  const { showActionSheetWithOptions } = useActionSheet();
  const dispatch = useDispatch();
  const store_deposit = useSelector(getDeposit);
  const changeAccountNicknameApi = useApi(changeDepositAccountNickname);
  const accountIndex = store_deposit.accounts.findIndex(item => item.accountNo === route.params?.accountNo);
  const {
    accountDesc,
    accountNo,
    accountStatus,
    statusType,
    nickName,
    availableBalance,
    currency,
    currentBalance,
    mfcAccountInfo,
  } = store_deposit.accounts[accountIndex] || {};
  const isMultiFcyAccount = mfcAccountInfo?.length > 0;
  const sortedMultiFCDDetailsList = _.sortBy(mfcAccountInfo, 'currency');
  const [isEditNicknameModalVisible, setIsEditNicknameModalVisible] = useState(false);
  const [selectedMultiFcy, setSelectedMultiFcy] = useState(isMultiFcyAccount ? sortedMultiFCDDetailsList[0] : null);
  const options = nickName
    ? [
        t(`${LANG_PREFIX}actionSheetUpdateNicknameOption`),
        t(`${LANG_PREFIX}actionSheetRemoveNicknameOption`),
        t(`${LANG_PREFIX}actionSheetCancelOption`),
      ]
    : [t(`${LANG_PREFIX}actionSheetSetNicknameOption`), t(`${LANG_PREFIX}actionSheetCancelOption`)];
  const { idNo, fullName } = useSelector(getUser) || {};
  const pdfLinksRef = useRef();
  const { fdDetails, creditingAcc, efdEtdAllowed, fdType } = useSelector(getDepositDetailByAccNo({ accountNo })) || {};
  const { url: eFDUrl } = useSelector(getOtherUrlByTag({ tag: otherUrlTag.EFD_PLACEMENT_SLIP }));
  const { url: eTDUrl } = useSelector(getOtherUrlByTag({ tag: otherUrlTag.ETD_PLACEMENT_SLIP }));
  const [prematureModal, setPrematureModal] = useState(false);
  const [selectedPlacement, setSelectedPlacement] = useState(null);
  const accessControl = useAccessControl({ navigation });
  const depositPlacementUtils = useDepositPlacement({ accountNo, auto: false });
  const placementSlipUrl = fdType === FD_TYPE.CONVENTIONAL ? eFDUrl : eTDUrl;
  const [fetchPdf] = useLazyFetchPdfQuery();

  useEffect(() => {
    if (!isMultiFcyAccount) depositPlacementUtils.load();
    return () => {
      dispatch(resetDepositHistory());
    };
  }, []);

  useEffect(() => {
    if (isMultiFcyAccount) {
      dispatch(resetDepositHistory());
      dispatch(resetFdDetails({ accountNo }));
    }
  }, [selectedMultiFcy]);

  const showHistory = () => {
    navigation.navigate(routes.TRAN_HISTORY, {
      item: getDeposit,
      load: loadDepositHistory,
      loadParam: {
        accountNo: accountNo,
        childAcc: selectedMultiFcy?.accountNo,
      },
      currency: isMultiFcyAccount ? selectedMultiFcy.currency : currency,
    });
  };

  const showPlacement = () => {
    navigation.navigate(routes.DEPOSIT_PLACEMENT, {
      accountNo: accountNo,
      foreignCurrency: selectedMultiFcy?.currency,
      childAcc: selectedMultiFcy?.accountNo,
    });
  };

  const openNicknameAS = () => {
    showActionSheetWithOptions(
      {
        title: nickName,
        options,
        cancelButtonIndex: nickName ? 2 : 1,
        destructiveButtonIndex: nickName ? 1 : -1,
        userInterfaceStyle: 'light',
      },
      index => {
        if (index === 0) return setIsEditNicknameModalVisible(true);
        if (index === 1 && !!nickName) return onEditNicknameConfirm(null);
      },
    );
  };

  const onEditNicknameConfirm = async nickName => {
    setIsEditNicknameModalVisible(false);
    if (nickName === '') nickName = null;
    const result = await changeAccountNicknameApi.request({ accountNo, nickName });
    if (result.problem) return showFailure(result.problem);
  };

  const initialValues = {
    nickName: nickName,
  };

  const handleSubmit = async ({ nickName }) => onEditNicknameConfirm(nickName);

  const handleCloseNickNamePopup = () => setIsEditNicknameModalVisible(false);
  const handleCurrencyPress = item => {
    setSelectedMultiFcy(item);
  };

  const newPlacement = () => {
    dispatch(updateNewDepositPlacementObject({ fromAcc: creditingAcc, toAcc: accountNo }));
    accessControl.navigate(routes.DEPOSIT_PLACEMENT_TENURE);
  };

  const navigateToPlacement = ({ withdraw }) => {
    navigation.navigate(routes.DEPOSIT_PLACEMENT, {
      accountNo: accountNo,
      childAcc: selectedMultiFcy?.accountNo,
      isWithdraw: withdraw,
    });
  };

  const renderButton = () => {
    if (isMultiFcyAccount) {
      return renderInvalidMsg(t(`${LANG_PREFIX}msgNotAvailableMakeNewCertificates`));
    }
    if (!efdEtdAllowed) {
      return renderInvalidMsg(t(`${LANG_PREFIX}msgNotEligibleMakeNewPlacement`));
    }
    if (!accountStatus) {
      return renderInvalidMsg(t(`${LANG_PREFIX}msgInactiveAccountMakeNewPlacement`));
    }

    return (
      <View style={styles.rowContainer}>
        <>
          <TouchableOpacity style={styles.placementButtonContainer} onPress={newPlacement}>
            <Text bold style={styles.newPlacementLabel}>
              {t(`${LANG_PREFIX}labelNewPlacement`)}
            </Text>
            <Image source={PlusIcon} style={styles.plusIcon} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.withdrawButtonContainer}
            onPress={() => {
              navigateToPlacement({
                withdraw: true,
              });
            }}
          >
            <Text bold style={styles.buttonText}>
              {t(`${LANG_PREFIX}labelWithdraw`)}
            </Text>
            <Image source={MinusIcon} style={styles.minusIcon} />
          </TouchableOpacity>
        </>
      </View>
    );
  };

  const renderInvalidMsg = msg => {
    return (
      <View
        style={{
          borderRadius: 5,
          backgroundColor: colors.lightestRed,
          marginHorizontal: 10,
          padding: 10,
          marginBottom: 10,
        }}
      >
        <Text style={{ textAlign: 'center', color: colors.medium }}>{msg}</Text>
      </View>
    );
  };

  const handlePrematureContent = () => (
    <View>
      <Text bold style={{ fontSize: 16, color: colors.primary, marginBottom: 20 }}>
        {t(`${LANG_PREFIX}titleEarlyWithdrawal`)}
      </Text>
      <Text bold style={{ fontSize: 15, marginBottom: 10 }}>
        {t(`${LANG_PREFIX}labelMaturityDate`)?.replace('${nextMaturityDate}', selectedPlacement?.nextMaturityDate)}
      </Text>
      <Text style={{ color: colors.medium, marginBottom: 20 }}>{t(`${LANG_PREFIX}labelEarlyWithdrawal`)}</Text>
      <Text bold style={{ fontSize: 15 }}>
        {t(`${LANG_PREFIX}labelProceedEarlyWithdrawal`)}
      </Text>
    </View>
  );

  const handlePrematureWithdrawal = () => {
    setPrematureModal(false);
    const item = fdDetails.find(item => item.cdNumber === selectedPlacement?.cdNumber);
    newWithdraw(item);
  };

  const handleNewWithdrawal = item => {
    if (!accountStatus) return showFailure(t(`${LANG_PREFIX}msgInactiveAccountMakeNewPlacement`));
    const isMatured = isPlacementMatured(item.renewalDate, item.nextMaturityDate);
    dispatch(updateNewDepositWithdrawObject({ maturityInd: isMatured ? 'A' : 'B' }));
    if (isMatured) return newWithdraw(item);

    setSelectedPlacement(item);
    setPrematureModal(true);
  };

  const handleCloseMaturityModal = () => {
    setPrematureModal(false);
  };

  const newWithdraw = ({ cdNumber, balance }) => {
    // Disable Partial Withdrawal until SMR2022-997 released (Requested by Abby)
    // New SMR required later to re-enable Partial Withdrawal (Agreed by Abby)
    // if (partialWithdrawalAllowed(fdType, balance)) return accessControl.navigate(routes.DEPOSIT_WITHDRAW_AMOUNT);
    dispatch(
      updateNewDepositWithdrawObject({
        amount: balance,
        isFullWithdrawal: true,
        currency,
        cdNumber,
        fromAcc: accountNo,
      }),
    );
    return accessControl.navigate(routes.DEPOSIT_WITHDRAW_CONFIRMATION);
  };

  const share = async ({
    cdNumber,
    balance,
    maturityIns,
    renewalDate,
    nextMaturityDate,
    term,
    termUnit,
    interestRate,
  }) => {
    const ind = await accessControl.isSoftTokenFullyActivated(routes.MAIN_TAB);
    if (!ind) return;

    const base64String = await editDepositPlacementPdf({
      fetchPdf,
      url: placementSlipUrl,
      fdType,
      info: {
        accountNo,
        cdNumber,
        creditingAcc,
        fullName,
        idNo,
        amount: balance,
        paymentMode: maturityIns,
        effectiveDate: renewalDate,
        maturityDate: nextMaturityDate,
        term,
        termUnit,
        rate: interestRate,
      },
    });
    if (!base64String) return showFailure(t(`${LANG_PREFIX}errorTryAgain`));
    pdfLinksRef.current.share(`data:application/pdf;base64,${base64String}`);
  };

  const tableItems = [
    { title: t(`${LANG_PREFIX}itemAccountName`), value: accountDesc },
    { title: t(`${LANG_PREFIX}itemAccountNo`), value: accountNo, copyable: true },
    {
      title: isMultiFcyAccount ? t(`${LANG_PREFIX}itemTotalCurrentBalance`) : t(`${LANG_PREFIX}itemCurrentBalance`),
      value: currentBalance,
      currency,
    },
  ];

  const quickLinkList = [
    {
      label: t(`${LANG_PREFIX}labelHistory`),
      icon: HistoryIcon,
      action: showHistory,
    },
    {
      label: isMultiFcyAccount ? t(`${LANG_PREFIX}labelCertificates`) : t(`${LANG_PREFIX}labelPlacements`),
      icon: PercentIcon,
      action: showPlacement,
    },
  ];

  return (
    <ScreenFull>
      <NavBar
        title={t(`${LANG_PREFIX}titleDeposit`)}
        back
        renderRightButton={
          accountStatus && (
            <TouchableOpacity
              accessibilityLabel={t(`${LANG_PREFIX}labelMore`)}
              accessibilityRole={'button'}
              onPress={openNicknameAS}
              style={styles.sideBtn}
            >
              <Image source={MoreIcon} style={styles.sideBtnIcon} />
            </TouchableOpacity>
          )
        }
      />
      <ScrollView showsVerticalScrollIndicator={false}>
        <BalanceAmount
          title={isMultiFcyAccount ? t(`${LANG_PREFIX}titleTotalBalanceAmount`) : t(`${LANG_PREFIX}titleBalanceAmount`)}
          amount={availableBalance}
          currency={currency}
          colorSets={balanceAmountColorSets.positiveGreen}
        />
        <AccountDetailsTable
          isActive={accountStatus}
          statusType={statusType}
          nickName={nickName}
          nickNameColour={tagColors.grey}
          tableItems={tableItems}
        />

        {renderButton()}
        {!isMultiFcyAccount && (
          <EFDCertSection
            data={fdDetails}
            navigation={navigation}
            route={route}
            handlePrematureContent={handlePrematureContent}
            handlePrematureWithdrawal={handlePrematureWithdrawal}
            handleNewWithdrawal={handleNewWithdrawal}
            handleCloseMaturityModal={handleCloseMaturityModal}
            prematureModalVisible={prematureModal}
            share={share}
            handleViewAll={() =>
              navigateToPlacement({
                withdraw: false,
              })
            }
          />
        )}

        {isMultiFcyAccount ? (
          <MultiForeignCurrencySection
            handleCurrencySelect={handleCurrencyPress}
            quickLinkList={quickLinkList}
            mfcAccountInfo={mfcAccountInfo}
            selectedCurrency={selectedMultiFcy?.currency}
          />
        ) : (
          <OthersQuickLinkSection quickLinksList={quickLinkList.slice(0, 1)} />
        )}
        <Space height={50} />
      </ScrollView>

      <EditNicknamePopUp
        isVisible={isEditNicknameModalVisible}
        initialValues={initialValues}
        onClose={handleCloseNickNamePopup}
        onSubmit={handleSubmit}
        regexValidation={alphanumericSpaceRegex}
      />
      <PDFLinks ref={pdfLinksRef} showQuickLinks={false} />
    </ScreenFull>
  );
};

export default Deposit;

const styles = StyleSheet.create({
  sideBtn: {
    height: 44,
    width: 42,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sideBtnIcon: {
    width: 15,
    height: 15,
    tintColor: colors.black,
    marginRight: 5,
  },
  quickLinkIcon: {
    tintColor: colors.primary,
  },
  rowContainer: {
    flexDirection: 'row',
    flex: 1,
    marginBottom: 10,
    marginHorizontal: 20,
    gap: 10,
  },
  placementButtonContainer: {
    backgroundColor: colors.black,
    borderRadius: 15,
    borderWidth: 0.33,
    borderColor: colors.black,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    flex: 1,
    gap: 8,
    padding: 10,
  },
  withdrawButtonContainer: {
    backgroundColor: colors.lightestRed,
    borderRadius: 15,
    borderWidth: 0.33,
    borderColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    flex: 1,
    gap: 8,
    padding: 10,
  },
  plusIcon: {
    width: 8,
    height: 8,
    tintColor: colors.white,
  },
  minusIcon: {
    width: 8,
    height: 8,
    tintColor: colors.primary,
  },
  newPlacementLabel: {
    color: colors.white,
  },
  buttonText: {
    color: colors.red,
  },
});
