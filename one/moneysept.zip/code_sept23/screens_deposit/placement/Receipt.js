import React, { useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { CustomScrollView, Screen } from 'atoms';
import { Receipt as TranReceipt, DoneButton, PDFLinks } from 'components';
import {
  depositPlacementInit,
  getActiveFromAccCasa,
  getDepositDetailByAccNo,
  getDepositPlacementById,
  getNewDepositPlacement,
  getOtherUrlByTag,
  getSoftToken,
  getUser,
  useLazyFetchPdfQuery,
} from 'stores';
import { tagColors } from 'configs';
import { TableItemTag } from 'molecules';
import {
  FD_TYPE,
  findDepositInterestName,
  findDepositPaymentModeName,
  findDepositTypeName,
  otherUrlTag
} from 'constant';
import routes from 'navigations/routes';
import { displayDateTime, displayReceiptDateTime, showFailure } from 'utils';
import { editDepositPlacementPdf } from '../utils';
import { useTranslation } from 'react-i18next';


export const Receipt = ({ navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.placementReceipt.text.';
  const title = `${LANG_PREFIX}titleMoneyDeposited`;

  const dispatch = useDispatch();
  const { referenceNo, tranDateTime, currency, toAcc, fromAcc, availableBalance, cdNumber } =
    useSelector(getNewDepositPlacement) || {};
  const {
    accountDesc: toAccDesc,
    fdType,
    creditingAcc,
  } = useSelector(getDepositDetailByAccNo({ accountNo: toAcc })) || {};
  const { balance, maturityIns, term, interestRate, renewalDate, nextMaturityDate } =
    useSelector(getDepositPlacementById({ accountNo: toAcc, cdNumber })) || {};
  const { preferredAccountNo, preferredAccountName } = useSelector(getSoftToken) || {};
  const casa = useSelector(getActiveFromAccCasa);
  const { idNo, fullName } = useSelector(getUser) || {};
  const { url: eFDUrl } = useSelector(getOtherUrlByTag({ tag: otherUrlTag.EFD_PLACEMENT_SLIP }));
  const { url: eTDUrl } = useSelector(getOtherUrlByTag({ tag: otherUrlTag.ETD_PLACEMENT_SLIP }));

  const placementSlipUrl = fdType === FD_TYPE.CONVENTIONAL ? eFDUrl : eTDUrl;
  const [fetchPdf] = useLazyFetchPdfQuery();


  const found =
    preferredAccountNo === fromAcc
      ? { accountDesc: preferredAccountName, availableBalance }
      : casa.accounts.find(item => item.accountNo === fromAcc);

  const profitLabel = t(findDepositInterestName(fdType));

  const pdfLinksRef = useRef();

  useEffect(() => {
    constructPdf();

    return () => {
      dispatch(depositPlacementInit());
    };
  }, []);

  const onOKPress = () => navigation.navigate(routes.MAIN_TAB);

  const Content = () => (
    <>
      <TableItemTag title={t(`${LANG_PREFIX}infoReferenceNo`)} value={referenceNo} />
      <TableItemTag title={t(`${LANG_PREFIX}infoDateTime`)} value={displayReceiptDateTime(tranDateTime)} />
      <TableItemTag
        title={t(`${LANG_PREFIX}infoTransferMethod`)}
        value={t(`${LANG_PREFIX}valueDepositType`)?.replace('${fdType}', t(findDepositTypeName(fdType)))}
      />
      <TableItemTag
        title={t(`${LANG_PREFIX}infoTenureRate`)?.replace('${profitLabel}', profitLabel)}
        value={`${t(`${LANG_PREFIX}valueInterestRate`).replace('${term}', term)} | ${interestRate}%`}
      />
      <TableItemTag
        title={t(`${LANG_PREFIX}infoPaymentMode`)?.replace('${profitLabel}', profitLabel)}
        value={t(findDepositPaymentModeName(maturityIns))}
      />
      <TableItemTag title={t(`${LANG_PREFIX}infoEffectiveDate`)} value={displayDateTime(renewalDate)} />
      <TableItemTag title={t(`${LANG_PREFIX}infoMaturityDate`)} value={displayDateTime(nextMaturityDate)} />

      <TableItemTag title={t(`${LANG_PREFIX}placementSerialNo`)} value={cdNumber} />
      <TableItemTag
        title={t(`${LANG_PREFIX}placementRecipientAccount`)}
        value={toAccDesc}
        tagList={[
          {
            title: toAcc,
            color: tagColors.red,
            style: { marginTop: 3 },
            fontStyle: { fontSize: 14 },
          },
        ]}
      />
    </>
  );

  const constructPdf = async () => {
    const base64String = await editDepositPlacementPdf({fdType,
      fetchPdf,
      url: placementSlipUrl,
      info: {
      accountNo: toAcc,
      cdNumber,
      creditingAcc,
      fullName,
      idNo,
      amount: balance,
      paymentMode: maturityIns,
      effectiveDate: renewalDate,
      maturityDate: nextMaturityDate,
      term,
      rate: interestRate,
    }});
    if (!base64String) return showFailure(t(`${LANG_PREFIX}errorTryAgain`));
    pdfLinksRef.current.updateContent(`data:application/pdf;base64,${base64String}`);
  };

  return (
    <Screen singlePage>
      <CustomScrollView showsVerticalScrollIndicator={false}>
        <TranReceipt
          animation
          amount={balance}
          currency={currency}
          title={t(title)}
          desc={
            <>
              <Content />
              <TableItemTag
                title={t(`${LANG_PREFIX}tagFromAccount`)}
                value={found?.accountDesc}
                tagList={[
                  { title: fromAcc, color: tagColors.grey, style: { marginTop: 3 }, fontStyle: { fontSize: 14 } },
                ]}
              />
              <TableItemTag
                title={t(`${LANG_PREFIX}tagAvailableBalance`)}
                value={found?.availableBalance}
                currency={currency}
                isLast={true}
              />
            </>
          }
        />
      </CustomScrollView>

      <PDFLinks ref={pdfLinksRef} />

      <DoneButton onPress={onOKPress} />
    </Screen>
  );
};

export default Receipt;
