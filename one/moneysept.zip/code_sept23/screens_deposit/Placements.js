import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ScrollView,
  Image,
  StyleSheet,
  TouchableOpacity,
  View,
  useWindowDimensions,
  FlatList,
  RefreshControl,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { useActionSheet } from '@expo/react-native-action-sheet';
import { useFocusEffect } from '@react-navigation/native';

import { BottomView, Flex, Info, LoadingFull, Screen, Space, TooltipIcon } from 'atoms';
import { NavBar } from 'organisms';
import { PDFLinks, Text } from 'components';
import { colors } from 'configs';
import {
  depositPlacementInit,
  getDepositDetailByAccNo,
  getOtherUrlByTag,
  getUser,
  updateNewDepositPlacementObject,
  updateNewDepositWithdrawObject,
  useLazyFetchPdfQuery,
  updatePlacementView,
  getUpdatedPlacementView,
} from 'stores';
import { showFailure, useAccessControl } from 'utils';
import routes from 'navigations/routes';
import { editDepositPlacementPdf, isPlacementMatured } from './utils';
import { ActionModal, BottomDrawerModalMini } from 'molecules';
import { useCasa, useDeposit, useDepositPlacement } from 'hooks';

import PlusIcon from 'assets/images/icon/plus.png';
import GridViewIcon from 'assets/images/icon/gridView.png';
import ListViewIcon from 'assets/images/icon/list.png';
import SortIcon from 'assets/images/icon/sortArrow.png';
import InfoIcon from 'assets/images/icon/question.png';
import { LOADING } from 'apis';
import { useTranslation } from 'react-i18next';
import { PlacementItem, PlacementItemCard } from 'screens/deposit/components';
import { placementSortingCategory, sortPlacementByCategory } from './utils';
import { FD_TYPE, otherUrlTag } from 'constant';

export const Placements = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.placements.text.';

  useCasa({});
  useDeposit({});
  const dispatch = useDispatch();
  const { width } = useWindowDimensions();
  const styles = makeStyles(width);
  const { showActionSheetWithOptions } = useActionSheet();
  const accessControl = useAccessControl({ navigation });
  const { accountNo, foreignCurrency, childAcc, isWithdraw = false } = route.params || {};
  const { idNo, fullName } = useSelector(getUser) || {};
  const { currency, fdDetails, efdEtdAllowed, creditingAcc, fdType, placementStatus, accountStatus } =
    useSelector(getDepositDetailByAccNo({ accountNo })) || {};
  const { url: eFDUrl } = useSelector(getOtherUrlByTag({ tag: otherUrlTag.EFD_PLACEMENT_SLIP }));
  const { url: eTDUrl } = useSelector(getOtherUrlByTag({ tag: otherUrlTag.ETD_PLACEMENT_SLIP }));

  const options = [
    `${t(`${LANG_PREFIX}withdrawOption`)} `,
    `${t(`${LANG_PREFIX}shareOption`)} `,
    `${t(`${LANG_PREFIX}cancelOption`)} `,
  ];
  const depositPlacementUtils = useDepositPlacement({ accountNo, childAcc });

  const [prematureModal, setPrematureModal] = useState(false);
  const [selectedPlacement, setSelectedPlacement] = useState(null);
  const pdfLinksRef = useRef();
  const updatedPlacementView = useSelector(getUpdatedPlacementView);
  const [expandedView, setExpandedView] = useState(updatedPlacementView);
  const [showSortByCategoryPopUp, setShowSortByCategoryPopUp] = useState(false);
  const [placementList, setPlacementList] = useState(fdDetails);
  const [selectedSortCategory, setSelectedSortCategory] = useState(placementSortingCategory[0].id);

  const placementSlipUrl = fdType === FD_TYPE.CONVENTIONAL ? eFDUrl : eTDUrl;
  const [fetchPdf] = useLazyFetchPdfQuery();

  useFocusEffect(
    useCallback(() => {
      dispatch(depositPlacementInit());
    }, []),
  );

  const onRefresh = () => depositPlacementUtils.refresh();

  useEffect(() => {
    setPlacementList(sortPlacementByCategory[selectedSortCategory](fdDetails));
  }, [fdDetails]);

  const openPlacementAS = item => {
    if (isWithdraw) {
      preNewWithdraw(item);
      return;
    }
    showActionSheetWithOptions(
      {
        options,
        cancelButtonIndex: 2,
        userInterfaceStyle: 'light',
      },
      index => {
        if (index === 0) return preNewWithdraw(item);
        if (index === 1) return share(item);
      },
    );
  };

  const share = async ({
    cdNumber,
    balance,
    maturityIns,
    renewalDate,
    nextMaturityDate,
    term,
    termUnit,
    interestRate,
  }) => {
    const ind = await accessControl.isSoftTokenFullyActivated(routes.DEPOSIT_PLACEMENT, { accountNo });
    if (!ind) return;
    const base64String = await editDepositPlacementPdf({
      fetchPdf,
      url: placementSlipUrl,
      fdType,
      info: {
        accountNo,
        cdNumber,
        creditingAcc,
        fullName,
        idNo,
        amount: balance,
        paymentMode: maturityIns,
        effectiveDate: renewalDate,
        maturityDate: nextMaturityDate,
        term,
        termUnit,
        rate: interestRate,
      },
    });
    if (!base64String) return showFailure(t(`${LANG_PREFIX}errorTryAgain`));
    pdfLinksRef.current.share(`data:application/pdf;base64,${base64String}`);
  };

  const preNewWithdraw = item => {
    if (!accountStatus) return showFailure(t(`${LANG_PREFIX}msgInactiveAccountMakeNewPlacement`));

    const isMatured = isPlacementMatured(item.renewalDate, item.nextMaturityDate);
    dispatch(updateNewDepositWithdrawObject({ maturityInd: isMatured ? 'A' : 'B' }));
    if (isMatured) return newWithdraw(item);

    setSelectedPlacement(item);
    setPrematureModal(true);
  };

  const newWithdraw = ({ cdNumber, balance }) => {
    dispatch(updateNewDepositWithdrawObject({ currency, cdNumber, fromAcc: accountNo }));

    // Disable Partial Withdrawal until SMR2022-997 released (Requested by Abby)
    // New SMR required later to re-enable Partial Withdrawal (Agreed by Abby)
    // if (partialWithdrawalAllowed(fdType, balance)) return accessControl.navigate(routes.DEPOSIT_WITHDRAW_AMOUNT);

    dispatch(updateNewDepositWithdrawObject({ amount: balance, isFullWithdrawal: true }));
    return accessControl.navigate(routes.DEPOSIT_WITHDRAW_CONFIRMATION);
  };

  const newPlacement = () => {
    dispatch(updateNewDepositPlacementObject({ fromAcc: creditingAcc, toAcc: accountNo }));
    accessControl.navigate(routes.DEPOSIT_PLACEMENT_TENURE);
  };

  const proceedPrematureWithdrawal = () => {
    setPrematureModal(false);
    const item = fdDetails.find(item => item.cdNumber === selectedPlacement?.cdNumber);
    newWithdraw(item);
  };

  const toggleView = toggledView => {
    setExpandedView(toggledView);
    dispatch(updatePlacementView(toggledView));
  };

  const handleCloseSortCategoryModal = () => {
    setShowSortByCategoryPopUp(false);
  };

  const handleSorting = category => {
    setPlacementList(sortPlacementByCategory[category](placementList));
    setSelectedSortCategory(category);
  };

  const renderHeader = useMemo(() => <Space height={10} />);
  const renderFooter = useMemo(() => <Space height={isWithdraw ? 50 : 10} />);
  const renderEmpty = useMemo(() => (
    <Info title={t(`${LANG_PREFIX}labelNoPlacements`)} style={{ backgroundColor: colors.white }} />
  ));

  const renderPrematureContent = () => (
    <View>
      <Text bold style={{ fontSize: 16, color: colors.primary, marginBottom: 20 }}>
        {t(`${LANG_PREFIX}titleEarlyWithdrawal`)}
      </Text>
      <Text bold style={{ fontSize: 15, marginBottom: 10 }}>
        {t(`${LANG_PREFIX}labelMaturityDate`)?.replace('${nextMaturityDate}', selectedPlacement?.nextMaturityDate)}
      </Text>
      <Text style={{ color: colors.medium, marginBottom: 20 }}>{t(`${LANG_PREFIX}labelEarlyWithdrawal`)}</Text>
      <Text bold style={{ fontSize: 15 }}>
        {t(`${LANG_PREFIX}labelProceedEarlyWithdrawal`)}
      </Text>
    </View>
  );

  const renderHeaderTitle = () => {
    if (foreignCurrency) {
      return (
        <View
          style={{ flexDirection: 'row', marginHorizontal: 20, marginTop: 10, marginBottom: 15, alignItems: 'center' }}
        >
          <Text bold style={{ fontSize: 16 }}>
            {t(`${LANG_PREFIX}labelTotalCertificates`)?.replace('${totalFD}', placementList?.length ?? '0')}
          </Text>
          <TooltipIcon icon={InfoIcon} tooltipText={t(`${LANG_PREFIX}tooltipMFFD`)} placement={'bottom'} />
        </View>
      );
    }

    return (
      <View style={styles.titleContainer}>
        <Text bold style={styles.title}>
          {isWithdraw ? t(`${LANG_PREFIX}labelWithdraw`) : t(`${LANG_PREFIX}labelPlacements`)}
        </Text>
        {placementList?.length > 0 && (
          <View style={styles.toggleViewContainer}>
            <TouchableOpacity
              onPress={() => {
                setShowSortByCategoryPopUp(true);
              }}
            >
              <View
                style={{
                  flexDirection: 'row',
                  borderRadius: 5,
                  backgroundColor: colors.lightestBg,
                  paddingHorizontal: 10,
                  paddingVertical: 5,
                  margin: -3,
                  alignItems: 'center',
                }}
              >
                <Text style={{ fontSize: 13, paddingRight: 3 }}> {t(`${LANG_PREFIX}labelSort`)}</Text>
                <Image source={SortIcon} style={styles.sortIcon} />
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.gridViewButton} onPress={() => toggleView(!expandedView)}>
              <Image
                source={expandedView ? GridViewIcon : ListViewIcon}
                style={expandedView ? styles.gridViewIcon : styles.listViewIcon}
              />
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  };

  const renderItem = ({ item, index }) => {
    if (expandedView) {
      return (
        <PlacementItemCard
          index={index}
          disabled={!efdEtdAllowed || !!foreignCurrency}
          onPress={() => openPlacementAS(item)}
          interestRate={item.interestRate}
          term={item.term}
          termUnit={item.termUnit}
          renewalDate={item.renewalDate}
          nextMaturityDate={item.nextMaturityDate}
          cdNumber={item.cdNumber}
          initialDeposit={item.initialDeposit}
          originalDepositDate={item.originalDepositDate}
          balance={item.balance}
          currency={foreignCurrency ?? currency}
          isMultiFcyAccount={!!foreignCurrency}
          reduceCardWidth={20}
          containerStyle={{ marginBottom: 10, borderWidth: 0 }}
        />
      );
    }

    return (
      <PlacementItem
        index={index}
        disabled={!efdEtdAllowed || !!foreignCurrency}
        onPress={() => openPlacementAS(item)}
        interestRate={item.interestRate}
        term={item.term}
        termUnit={item.termUnit}
        renewalDate={item.renewalDate}
        nextMaturityDate={item.nextMaturityDate}
        cdNumber={item.cdNumber}
        initialDeposit={item.initialDeposit}
        originalDepositDate={item.originalDepositDate}
        balance={item.balance}
        currency={foreignCurrency ?? currency}
        isMultiFcyAccount={!!foreignCurrency}
      />
    );
  };

  const renderButton = () => {
    if (foreignCurrency) {
      return <InvalidMessage message={t(`${LANG_PREFIX}msgNotAvailableMakeNewCertificates`)} />;
    }
    if (!efdEtdAllowed) {
      return <InvalidMessage message={t(`${LANG_PREFIX}msgNotEligibleMakeNewPlacement`)} />;
    }
    if (!accountStatus) {
      return <InvalidMessage message={t(`${LANG_PREFIX}msgInactiveAccountMakeNewPlacement`)} />;
    }

    return (
      <BottomView minBottomGap={10}>
        <TouchableOpacity style={styles.btmBtn} onPress={newPlacement}>
          <Image source={PlusIcon} style={styles.btmIcon} />
          <Text bold style={styles.btmText}>
            {t(`${LANG_PREFIX}labelNewPlacement`)}
          </Text>
        </TouchableOpacity>
      </BottomView>
    );
  };

  return (
    <Screen>
      <NavBar back showShadow={true} bottom={renderHeaderTitle()} />

      <Flex>
        <FlatList
          key={expandedView}
          refreshControl={
            <RefreshControl refreshing={false} onRefresh={onRefresh} colors={[colors.black]} tintColor={colors.black} />
          }
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={'handled'}
          keyExtractor={(item, index) => index.toString()}
          ListHeaderComponent={renderHeader}
          ListFooterComponent={renderFooter}
          ListEmptyComponent={renderEmpty}
          data={placementList}
          numColumns={expandedView ? 1 : 2}
          renderItem={renderItem}
        />

        {!isWithdraw && renderButton()}
        {placementStatus === LOADING && <LoadingFull blur />}
      </Flex>

      <PDFLinks ref={pdfLinksRef} showQuickLinks={false} />

      <ActionModal
        variant={ActionModal.variants.modalize}
        isVisible={prematureModal}
        leftButtonType={'normal'}
        rightButtonTitle={t(`${LANG_PREFIX}buttonProceed`)}
        renderContent={renderPrematureContent}
        onDecline={() => setPrematureModal(false)}
        onAccept={proceedPrematureWithdrawal}
      />

      <BottomDrawerModalMini isVisible={showSortByCategoryPopUp} closeModal={handleCloseSortCategoryModal}>
        <View style={styles.sortingModalHeaderContainer}>
          <Text style={styles.sortingModalTitle}> {t(`${LANG_PREFIX}labelSortBy`)}</Text>
        </View>
        <ScrollView showsVerticalScrollIndicator={false}>
          {placementSortingCategory.map(item => (
            <View key={item.id} style={selectedSortCategory === item.id && { backgroundColor: colors.primary }}>
              <TouchableOpacity
                onPress={() => {
                  handleSorting(item.id);
                  handleCloseSortCategoryModal();
                }}
                key={item.id}
                style={styles.sortingItems}
              >
                <Text
                  style={
                    selectedSortCategory === item.id ? styles.selectedSortingItemsLabels : styles.sortingItemsLabels
                  }
                >
                  {t(item.name)}
                </Text>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      </BottomDrawerModalMini>
    </Screen>
  );
};

const InvalidMessage = ({ message }) => {
  return (
    <BottomView minBottomGap={10} style={{ backgroundColor: colors.bg }}>
      <View style={{ marginHorizontal: 20, marginTop: 10 }}>
        <Text style={{ textAlign: 'center', color: colors.medium }}>{message}</Text>
      </View>
    </BottomView>
  );
};

export default Placements;

const makeStyles = width =>
  StyleSheet.create({
    heading: {
      marginHorizontal: 20,
      marginTop: 10,
      marginBottom: 15,
      fontSize: 16,
    },
    btnContainer: {
      backgroundColor: colors.white,
      width: (width - 25) * 0.5,
      marginBottom: 10,
      borderRadius: 5,
      borderWidth: 1,
      borderColor: colors.border,
      overflow: 'hidden',
    },
    rateContainer: {
      backgroundColor: colors.yellow,
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderBottomLeftRadius: 8,
      minWidth: '30%',
    },
    rateText: {
      color: colors.white,
      textAlign: 'center',
    },
    dot: {
      width: 2,
      height: 2,
      tintColor: colors.grey,
      marginHorizontal: 5,
    },
    btmBtn: {
      backgroundColor: colors.primary,
      borderRadius: 10,
      justifyContent: 'center',
      alignItems: 'center',
      height: 45,
      marginHorizontal: 30,
      marginTop: 10,
      flexDirection: 'row',
    },
    btmIcon: {
      height: 12,
      width: 12,
      tintColor: colors.white,
    },
    btmText: {
      color: colors.white,
      fontSize: 15,
      marginLeft: 10,
    },
    titleContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginHorizontal: 20,
      marginVertical: 12,
    },
    title: {
      flex: 1,
      fontSize: 18,
    },
    toggleViewContainer: {
      flexDirection: 'row',
      gap: 15,
      alignItems: 'center',
    },
    listViewIcon: {
      width: 16,
      height: 16,
      tintColor: colors.black,
    },
    gridViewButton: {
      padding: 5,
      margin: -5,
    },
    gridViewIcon: {
      width: 16,
      height: 16,
      tintColor: colors.black,
    },
    sortIcon: {
      width: 12,
      height: 12,
      tintColor: colors.medium,
    },
    sortingItems: {
      paddingVertical: 12,
      paddingHorizontal: 20,
    },
    sortingItemsLabels: {
      fontSize: 14,
      color: colors.black,
    },
    selectedSortingItemsLabels: {
      fontSize: 14,
      color: colors.white,
    },
    sortingModalHeaderContainer: {
      marginHorizontal: 20,
      marginVertical: 12,
    },
    sortingModalTitle: {
      fontSize: 11,
      color: colors.medium,
    },
  });
