import { Platform } from 'react-native';
import RNFS from 'react-native-fs';
import { PDFDocument } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import { encode } from 'base-64';

import { formatAmountDisplay, formatAmountInWords } from 'utils';
import { FD_TYPE, findDepositPaymentModeEnglishName } from 'constant';

const FONT_NAME = 'Nunito-Bold.ttf';

export const editDepositPlacementPdf = async ({ fdType, info, fetchPdf, url }) => {
  const formattedInfo = {
    accountNo: info?.accountNo ?? '',
    effectiveDate: info?.effectiveDate ?? '',
    cdNumber: info?.cdNumber ?? '',
    maturityDate: info?.maturityDate ?? '',
    creditingAcc: info?.creditingAcc ?? '',
    term: `${info?.term} ${info?.termUnit === 'D' ? 'day(s)' : 'month(s)'}` ?? '',
    nameIc: `${info?.fullName}\n(${info?.idNo})` ?? '',
    rate: `${info?.rate.toFixed(2)}` ?? '',
    amountInWords: `${formatAmountInWords(info?.amount)?.toUpperCase()} ONLY` ?? '',
    amount: `${formatAmountDisplay(info?.amount)}` ?? '',
    mode: findDepositPaymentModeEnglishName(info?.paymentMode) ?? '',
  };

  try {
    const { data: pdfSlip } = await fetchPdf(url, true).unwrap();
    if (!pdfSlip) return null;

    if (fdType === FD_TYPE.CONVENTIONAL) return editEFDPlacementPdf(pdfSlip, formattedInfo);
    return editETDPlacementPdf(pdfSlip, formattedInfo);
  } catch (e) {
    return null;
  }
};

const editEFDPlacementPdf = async (res, info) => {
  try {
    const base64String = await modifyEFDPlacementPdf(res, info);
    return base64String;
  } catch (e) {
    return null;
  }
};

const modifyEFDPlacementPdf = async (bytes, info) => {
  const pdfDoc = await PDFDocument.load(bytes);
  pdfDoc.registerFontkit(fontkit);

  const pages = pdfDoc.getPages();
  const firstPage = pages[0];

  const fontBase64 = await readFontAsset();
  const boldFont = await pdfDoc.embedFont(fontBase64);

  firstPage.drawText(info?.accountNo, {
    x: 204,
    y: 699,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.effectiveDate, {
    x: 507,
    y: 700,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.cdNumber, {
    x: 204,
    y: 660,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.maturityDate, {
    x: 507,
    y: 660,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.creditingAcc, {
    x: 204,
    y: 620,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.term, {
    x: 507,
    y: 620,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.nameIc, {
    x: 204,
    y: 582,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.rate, {
    x: 507,
    y: 582,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.amountInWords, {
    x: 204,
    y: 504,
    size: 9,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.amount, {
    x: 412,
    y: 499,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.mode, {
    x: 204,
    y: 454,
    size: 9,
    font: boldFont,
    maxWidth: 200,
    lineHeight: 9,
  });

  const pdfBytes = await pdfDoc.save();
  const base64String = encode(
    [].reduce.call(
      new Uint8Array(pdfBytes),
      function (p, c) {
        return p + String.fromCharCode(c);
      },
      '',
    ),
  );
  return base64String;
};

const readFontAsset = async () => {
  try {
    if (Platform.OS === 'ios') {
      return await RNFS.readFile(`${RNFS.MainBundlePath}/${FONT_NAME}`, 'base64');
    }

    return await RNFS.readFileAssets(`fonts/${FONT_NAME}`, 'base64');
  } catch (e) {
    return null;
  }
};

const editETDPlacementPdf = async (res, info) => {
  try {
    const base64String = await modifyETDPlacementPdf(res, info);
    return base64String;
  } catch (e) {
    console.log(e);
    return null;
  }
};

const modifyETDPlacementPdf = async (bytes, info) => {
  const pdfDoc = await PDFDocument.load(bytes);
  pdfDoc.registerFontkit(fontkit);

  const pages = pdfDoc.getPages();
  const firstPage = pages[0];

  const fontBase64 = await readFontAsset();
  const boldFont = await pdfDoc.embedFont(fontBase64);

  firstPage.drawText(info?.accountNo, {
    x: 204,
    y: 715,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.effectiveDate, {
    x: 507,
    y: 714,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.cdNumber, {
    x: 204,
    y: 680,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.maturityDate, {
    x: 507,
    y: 681,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.creditingAcc, {
    x: 204,
    y: 641,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.term, {
    x: 507,
    y: 641,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.nameIc, {
    x: 204,
    y: 602,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.rate, {
    x: 507,
    y: 602,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.amountInWords, {
    x: 204,
    y: 532,
    size: 9,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.amount, {
    x: 412,
    y: 528,
    size: 10,
    font: boldFont,
    maxWidth: 180,
    lineHeight: 9,
  });

  firstPage.drawText(info?.mode, {
    x: 204,
    y: 484.5,
    size: 9,
    font: boldFont,
    maxWidth: 200,
    lineHeight: 9,
  });

  const pdfBytes = await pdfDoc.save();
  const base64String = encode(
    [].reduce.call(
      new Uint8Array(pdfBytes),
      function (p, c) {
        return p + String.fromCharCode(c);
      },
      '',
    ),
  );
  return base64String;
};
