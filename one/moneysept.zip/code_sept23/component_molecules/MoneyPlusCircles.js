import React from 'react';
import { Text } from 'atoms';
import { colors } from 'configs';
import { View, StyleSheet, Image, Dimensions } from 'react-native';
import * as Progress from 'react-native-progress';

import { Money } from 'components/text';
import { useTranslation } from 'react-i18next';

export const MoneyPlusCircles = ({ currency, amount, targetAmount, circleIcon, circleLabel, isMabAchieved }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.casaDetails.text.';

  const screenWidth = Dimensions.get('window').width;
  const circleSize = Math.round((screenWidth - 60) * 0.28);

  return (
    <View style={styles.container}>
      <View style={styles.parentCircleContainer}>
        <View style={styles.circleContainer}>
          <Progress.Circle
            size={circleSize}
            thickness={5}
            color={isMabAchieved ? colors.green : colors.grey}
            borderWidth={0}
            borderColor={colors.lightgrey}
            unfilledColor={colors.lightgrey}
            progress={amount / targetAmount}
            strokeCap={'round'}
          />

          <View style={[styles.overlay, { width: circleSize, height: circleSize }]}>
            <Image
              source={circleIcon}
              style={{ width: circleSize * 0.32, height: circleSize * 0.32, tintColor: colors.medium }}
            />
            <Text style={styles.categoryLabel}>{circleLabel}</Text>
          </View>
        </View>
        <View style={styles.statusContainer}>
          {amount < targetAmount ? (
            <View style={styles.moneyContainer}>
              <Money
                isCurrencyBold={false}
                isBold={false}
                currency={currency}
                amount={targetAmount - amount}
                size={11}
                color={colors.black}
              />
              <Text style={styles.toGoLabel}>{t(`${LANG_PREFIX}labelToGo`)}</Text>
            </View>
          ) : (
            <View>
              {isMabAchieved ? (
                <Text style={styles.statusLabel}>{t(`${LANG_PREFIX}labelAchieve`)}</Text>
              ) : (
                <Text style={styles.notEligibleLabel}>{t(`${LANG_PREFIX}labelNotEligible`)}</Text>
              )}
            </View>
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
  },
  parentCircleContainer: {
    alignItems: 'center',
    flex: 1,
  },
  circleContainer: {
    alignItems: 'center',
  },
  overlay: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 3,
  },
  categoryLabel: {
    fontSize: 10,
    fontWeight: 'bold',
    color: colors.medium,
  },
  statusContainer: {
    marginTop: 8,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 4,
    flex: 1,
  },
  statusLabel: {
    fontSize: 14,
    color: colors.mediumGreen,
    fontWeight: 'bold',
  },
  notEligibleLabel: {
    fontSize: 12,
    color: colors.medium,
  },
  toGoLabel: {
    fontSize: 10,
    color: colors.medium,
  },
  moneyContainer: {
    alignItems: 'center',
    marginHorizontal: 8,
  },
});

export default MoneyPlusCircles;
