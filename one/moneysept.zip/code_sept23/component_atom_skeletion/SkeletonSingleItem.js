import React from 'react';
import ContentLoader, { Rect } from 'react-content-loader/native';
import { useWindowDimensions } from 'react-native';

export const SkeletonSingleItem = () => {
  const { width } = useWindowDimensions();
  const loaderWidth = width * 0.5; // Half screen width
  const loaderHeight = loaderWidth * 0.1; // Adjust height proportionally

  return (
    <ContentLoader height={loaderHeight} width={loaderWidth} viewBox={`0 0 ${loaderWidth} ${loaderHeight}`}>
      <Rect x='0' y='0' rx='15' ry='15' width={loaderWidth} height={loaderHeight} />
    </ContentLoader>
  );
};
