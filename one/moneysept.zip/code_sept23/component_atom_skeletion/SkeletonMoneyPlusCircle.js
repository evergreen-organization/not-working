import React from 'react';
import ContentLoader, { Circle } from 'react-content-loader/native';
import { useWindowDimensions, View } from 'react-native';
import { skeletonColors } from 'configs';
import { StyleSheet } from 'react-native';

export const SkeletonMoneyPlusCircle = () => {
  const { width } = useWindowDimensions();
  const loaderWidth = width - 40;
  const loaderHeight = 40;
  const spacing = loaderWidth / 6;

  return (
    <View style={styles.container}>
      <ContentLoader
        width={loaderWidth}
        height={loaderHeight}
        speed={1}
        backgroundColor={skeletonColors.bone}
        foregroundColor={skeletonColors.highlight}
        style={styles.contentLoader}
      >
        <Circle cx={spacing} cy='20' r='15' />
        <Circle cx={spacing * 3} cy='20' r='15' />
        <Circle cx={spacing * 5} cy='20' r='15' />
      </ContentLoader>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
  },
  contentLoader: {
    alignSelf: 'center',
    marginVertical: 12,
    alignItems: 'center',
  },
});
