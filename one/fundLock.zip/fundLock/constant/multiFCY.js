export const MULTI_FCY_COUNTRY = {
  USD: 'USA',
  AUD: 'AUS',
  EUR: 'DEU',
  HKD: 'HKG',
  GBP: 'GBR',
  NZD: 'NZL',
  CHF: 'CHE',
  THB: 'THA',
  SGD: 'SGP',
  CAD: 'CAN',
  JPY: 'JPN',
  CNY: 'CHN',
};
