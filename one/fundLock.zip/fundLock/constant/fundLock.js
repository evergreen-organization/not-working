const LANG_PREFIX = 'screens.fundLockConstant.text.';

const LIMIT_FUNCTION = [
  { id: 1, text: `${LANG_PREFIX}fundTransfer` },
  { id: 2, text: `${LANG_PREFIX}payment` },
  { id: 3, text: `${LANG_PREFIX}investment` },
  { id: 4, text: `${LANG_PREFIX}standingInstruction` },
  { id: 5, text: `${LANG_PREFIX}directDebit` },
  { id: 6, text: `${LANG_PREFIX}chequeClearing` },
  { id: 7, text: `${LANG_PREFIX}cashWithdrawal` },
];

export const FUND_LOCK = {
  LIMIT_FUNCTION: LIMIT_FUNCTION,
};
