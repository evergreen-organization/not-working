import { useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import {
  AAOP_TRANSACTION_DECLINED,
  BANK_ACC,
  checkTransModeDuitNow,
  findBakongIdType,
  findDuitnowIdTypeName,
  proxyManageType,
  tranApiType,
  transMode,
} from 'constant';
import routes from 'navigations/routes';
import {
  completeJourneyTask,
  enrollAAOP,
  getSecfaAuth,
  getSoftToken,
  manageDuitNowProxy,
  registerDuitNowProxy,
  submitAlipayPlus,
  submitBakong,
  submitBillPayment,
  submitCarbonOffset,
  submitCardlessWithdraw,
  submitCardPayment,
  submitCardPin,
  submitCashAdvance,
  submitDepositPlacement,
  submitDepositWithdraw,
  submitEmailAddress,
  submitFundTransfer,
  submitLoanPayment,
  submitLockFund,
  submitOpenEFD,
  submitQRPayment,
  submitTopUp,
  submitUnlockFund,
  transferJourney,
  updateCardObject,
  updateCasaObject,
  updateDepositObject,
  updateLoanObject,
  updateQuickPayment,
} from 'stores';
import { useApi } from './useApi';
import quickLogin from 'screens/auth/login/object/quickLogin';
import { showSuccess } from 'utils/message';
import { IDLE } from 'apis';
import { getAuthDeviceTokenCookie, getRSAMobileInfo } from 'utils/rsaMobileInfo';
import { useTranslation } from 'react-i18next';

export const useTranApiSubmit = ({ type, navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'softToken.submit.text.';

  const dispatch = useDispatch();
  const secfaAuth = useSelector(getSecfaAuth);
  const store_softToken = useSelector(getSoftToken);
  const submitFundTransferApi = useApi(submitFundTransfer);
  const submitCardPaymentApi = useApi(submitCardPayment);
  const submitLoanPaymentApi = useApi(submitLoanPayment);
  const submitQrPaymentApi = useApi(submitQRPayment);
  const submitAlipayPlusApi = useApi(submitAlipayPlus);
  const submitTopUpApi = useApi(submitTopUp);
  const submitCashAdvanceApi = useApi(submitCashAdvance);
  const submitBillPaymentApi = useApi(submitBillPayment);
  const manageDuitNowProxyApi = useApi(manageDuitNowProxy);
  const registerDuitNowProxyApi = useApi(registerDuitNowProxy);
  const enrollAAOPApi = useApi(enrollAAOP);
  const transferJourneyApi = useApi(transferJourney);
  const transferJourneyTaskApi = useApi(completeJourneyTask);
  const submitCardlessWithdrawApi = useApi(submitCardlessWithdraw);
  const submitBakongTransferApi = useApi(submitBakong);
  const updateQuickPaymentApi = useApi(updateQuickPayment);
  const submitOpenEFDApi = useApi(submitOpenEFD);
  const submitDepositPlacementApi = useApi(submitDepositPlacement);
  const submitDepositWithdrawApi = useApi(submitDepositWithdraw);
  const submitCarbonOffsetApi = useApi(submitCarbonOffset);
  const submitLockFundApi = useApi(submitLockFund);
  const submitUnlockFundApi = useApi(submitUnlockFund);
  const submitEmailAddressApi = useApi(submitEmailAddress);
  const submitCardPinApi = useApi(submitCardPin);

  const { isPublic } = secfaAuth;
  const isPublicRef = useRef(isPublic);

  useEffect(() => {
    isPublicRef.current = isPublic;
  }, [isPublic]);

  const onSubmit = async ({ secfa, extraParam }) => {
    const mobileSdkData = await getRSAMobileInfo();
    const deviceTokenCookie = await getAuthDeviceTokenCookie();

    if (type === tranApiType.FUND_TRANSFER) {
      return submitFundTransferApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.CARD_PAYMENT) {
      return submitCardPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.LOAN_PAYMENT) {
      return submitLoanPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.QR_PAYMENT) {
      return submitQrPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.ALIPAY_PLUS) {
      return submitAlipayPlusApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.TOP_UP) {
      return submitTopUpApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CASH_ADVANCE) {
      return submitCashAdvanceApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.JOMPAY_PAYMENT) {
      return submitBillPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.BILL_PAYMENT) {
      return submitBillPaymentApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.DUITNOW_MANAGEMENT) {
      return manageDuitNowProxyApi.request({
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.DUITNOW_REGISTRATION) {
      return registerDuitNowProxyApi.request({
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.AAOP_REGISTRATION) return enrollAAOPApi.request({ secfa });
    if (type === tranApiType.JOURNEY_TRANSFER) {
      return transferJourneyApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.JOURNEY_TRANSFER_TASK) {
      return transferJourneyTaskApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CARDLESS_WITHDRAW) {
      return submitCardlessWithdrawApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
      });
    }
    if (type === tranApiType.BAKONG_TRANSFER) {
      return submitBakongTransferApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
      });
    }
    if (type === tranApiType.QUICK_PAYMENT_LIMIT) {
      return updateQuickPaymentApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.DEPOSIT_OPEN_EFD) {
      return submitOpenEFDApi.request({
        secfa,
      });
    }
    if (type === tranApiType.DEPOSIT_PLACEMENT) {
      return submitDepositPlacementApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.DEPOSIT_WITHDRAW) {
      return submitDepositWithdrawApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.CARBON_OFFSET) {
      return submitCarbonOffsetApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.LOCK_FUND) {
      return submitLockFundApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.LOCK_FUND_INCREASE) {
      return submitLockFundApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.UNLOCK_FUND) {
      return submitUnlockFundApi.request({
        isPublic: isPublicRef.current,
        secfa,
        mobileSdkData,
        deviceTokenCookie,
        ...extraParam,
      });
    }
    if (type === tranApiType.UPDATE_EMAIL) {
      return submitEmailAddressApi.request({
        secfa,
        ...extraParam,
      });
    }
    if (type === tranApiType.UPDATE_CARD_PIN) {
      return submitCardPinApi.request({
        isPublic: isPublicRef.current,
        secfa,
        ...extraParam,
      });
    }
  };

  const onSuccess = ({ extraParam }) => {
    if (type === tranApiType.FUND_TRANSFER) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.TRANSFER_RECEIPT, { ...extraParam });

      //To load only when trying to access next time
      if (extraParam.secfaInfo?.sendMoneyType === transMode.OWN.key)
        dispatch(updateCasaObject({ accountsStatus: IDLE }));
      return;
    }
    if (type === tranApiType.CARD_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.PAY_CARD_RECEIPT, { ...extraParam });

      if (extraParam.secfaInfo?.isOwn) dispatch(updateCardObject({ accountsStatus: IDLE }));
      return;
    }
    if (type === tranApiType.LOAN_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.PAY_LOAN_RECEIPT, { ...extraParam });

      if (extraParam.secfaInfo?.isOwn) dispatch(updateLoanObject({ accountsStatus: IDLE }));
      return;
    }
    if (type === tranApiType.QR_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.QR_PAYMENT_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.ALIPAY_PLUS) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.QR_PAYMENT_ALIPLAYPLUS_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.TOP_UP) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.TOP_UP_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.CASH_ADVANCE) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.CASH_ADVANCE_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.JOMPAY_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.JOMPAY_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.BILL_PAYMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.BILL_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.DUITNOW_REGISTRATION) {
      navigation.navigate(routes.DUITNOW_ID);
      return;
    }
    if (type === tranApiType.DUITNOW_MANAGEMENT) {
      if (extraParam.duitNowManageType === proxyManageType.DEREGISTER) {
        showSuccess(t(`${LANG_PREFIX}msgSuccessDuitNowDeregister`));
        navigation.navigate(routes.DUITNOW_ID);
      } else {
        navigation.navigate(routes.DUITNOW_UPDATE, { ...extraParam });
      }
      return;
    }
    if (type === tranApiType.AAOP_REGISTRATION) {
      showSuccess(t(`${LANG_PREFIX}msgSuccessAaopEnrolment`), t(`${LANG_PREFIX}msgSuccessAaopEnrolmentDesc`));
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.LOGIN_PIN, { flow: new quickLogin() });
      return;
    }
    if (type === tranApiType.SECURE_SIGN_APPROVAL) {
      navigation.navigate(routes.MAIN_TAB);

      if (extraParam.actionType === 'APPROVE') {
        navigation.navigate(routes.SOFT_TOKEN_PENDING_TRAN_SUCCESS, { ...extraParam });
      } else {
        showSuccess(t(`${LANG_PREFIX}msgTransactionRejected`));
      }

      return;
    }
    if (type === tranApiType.JOURNEY_TRANSFER) {
      extraParam.updateAmount(extraParam.currentChild, extraParam.amount);
      navigation.navigate(routes.JOURNEY);
      navigation.navigate(routes.POCKET_MONEY_SUMMARY);
      return;
    }
    if (type === tranApiType.JOURNEY_TRANSFER_TASK) {
      extraParam.updateAmount(extraParam.currentChild, extraParam.amount, extraParam.isTaskReward);
      navigation.navigate(routes.JOURNEY);
      navigation.navigate(routes.POCKET_MONEY_SUMMARY);
      return;
    }
    if (type === tranApiType.CARDLESS_WITHDRAW) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.CARDLESS_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.BAKONG_TRANSFER) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.BAKONG_RECEIPT, { ...extraParam });
      return;
    }
    if (type === tranApiType.QUICK_PAYMENT_LIMIT) {
      if (store_softToken.selectedRoute === routes.QUICK_PAYMENT) return navigation.navigate(routes.APP_SECURITY);
      navigation.replace(store_softToken.selectedRoute);
      return;
    }
    if (type === tranApiType.CHANGE_PIN) {
      navigation.navigate(routes.MAIN_TAB);
      showSuccess(t(`${LANG_PREFIX}msgPinUpdated`));
      return;
    }
    if (type === tranApiType.RESET_PIN) {
      navigation.navigate(routes.MAIN_TAB);
      showSuccess(t(`${LANG_PREFIX}msgPinUpdated`), t(`${LANG_PREFIX}msgPinResetDesc`));
      return;
    }
    if (type === tranApiType.DEPOSIT_OPEN_EFD) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.DEPOSIT_OPEN_RECEIPT);
      return;
    }
    if (type === tranApiType.DEPOSIT_PLACEMENT) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.DEPOSIT_PLACEMENT_RECEIPT, { ...extraParam });

      //To load only when trying to access next time
      dispatch(updateDepositObject({ accountsStatus: IDLE }));
      return;
    }
    if (type === tranApiType.DEPOSIT_WITHDRAW) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.DEPOSIT_WITHDRAW_RECEIPT, { ...extraParam });

      //To load only when trying to access next time
      dispatch(updateCasaObject({ accountsStatus: IDLE }));
      return;
    }

    if (type === tranApiType.CARBON_OFFSET) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.CARBON_TRACKER_RECEIPT, { ...extraParam });
      return;
    }

    if (type === tranApiType.LOCK_FUND || type === tranApiType.LOCK_FUND_INCREASE) {
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.CASA_DETAIL, { ...extraParam });
      return;
    }

    if (type === tranApiType.UPDATE_EMAIL) {
      showSuccess(t(`${LANG_PREFIX}msgEmailUpdated`));
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.ACCOUNT_SETTINGS, { ...extraParam });
      return;
    }
    if (type === tranApiType.UPDATE_CARD_PIN) {
      showSuccess(
        (extraParam?.isPinCreated
          ? t(`${LANG_PREFIX}msgCardPinChangeSuccess`)
          : t(`${LANG_PREFIX}msgCardPinUpdateSuccess`)
        )?.replace('${cardNo}', extraParam?.cardNo?.slice(-4)),
      );
      navigation.navigate(routes.MAIN_TAB);
      return navigation.navigate(extraParam?.cardRoute?.route, { ...extraParam?.cardRoute?.params });
    }
  };

  const onFailure = ({ title, message, extraParam, data, status }) => {
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.SOFT_TOKEN_FAIL, {
      title,
      message,
      isEsiSelected: extraParam?.secfaInfo?.frequency,
      data,
      status,
    });
  };

  const error = () => {
    if (type === tranApiType.FUND_TRANSFER) return submitFundTransferApi.error;
    if (type === tranApiType.CARD_PAYMENT) return submitCardPaymentApi.error;
    if (type === tranApiType.LOAN_PAYMENT) return submitLoanPaymentApi.error;
    if (type === tranApiType.QR_PAYMENT) return submitQrPaymentApi.error;
    if (type === tranApiType.ALIPAY_PLUS) return submitAlipayPlusApi.error;
    if (type === tranApiType.TOP_UP) return submitTopUpApi.error;
    if (type === tranApiType.CASH_ADVANCE) return submitCashAdvanceApi.error;
    if (type === tranApiType.JOMPAY_PAYMENT) return submitBillPaymentApi.error;
    if (type === tranApiType.BILL_PAYMENT) return submitBillPaymentApi.error;
    if (type === tranApiType.DUITNOW_MANAGEMENT) return manageDuitNowProxyApi.error;
    if (type === tranApiType.DUITNOW_REGISTRATION) return registerDuitNowProxyApi.error;
    if (type === tranApiType.AAOP_REGISTRATION) return enrollAAOPApi.error;
    if (type === tranApiType.JOURNEY_TRANSFER) return transferJourneyApi.error;
    if (type === tranApiType.JOURNEY_TRANSFER_TASK) return transferJourneyTaskApi.error;
    if (type === tranApiType.CARDLESS_WITHDRAW) return submitCardlessWithdrawApi.error;
    if (type === tranApiType.BAKONG_TRANSFER) return submitBakongTransferApi.error;
    if (type === tranApiType.QUICK_PAYMENT_LIMIT) return updateQuickPaymentApi.error;
    if (type === tranApiType.DEPOSIT_OPEN_EFD) return submitOpenEFDApi.error;
    if (type === tranApiType.DEPOSIT_PLACEMENT) return submitDepositPlacementApi.error;
    if (type === tranApiType.DEPOSIT_WITHDRAW) return submitDepositWithdrawApi.error;
    if (type === tranApiType.CARBON_OFFSET) return submitCarbonOffsetApi.error;
    if (type === tranApiType.LOCK_FUND) return submitLockFundApi.error;
    if (type === tranApiType.UNLOCK_FUND) return submitUnlockFundApi.error;
    if (type === tranApiType.UPDATE_EMAIL) return submitEmailAddressApi.error;
    if (type === tranApiType.UPDATE_CARD_PIN) return submitCardPinApi.error;
  };

  const checkJunction = () => {
    if (
      type === tranApiType.DUITNOW_MANAGEMENT ||
      type === tranApiType.DUITNOW_REGISTRATION ||
      type === tranApiType.DEPOSIT_OPEN_EFD ||
      type === tranApiType.DEPOSIT_PLACEMENT ||
      type === tranApiType.DEPOSIT_WITHDRAW ||
      type === tranApiType.LOCK_FUND ||
      type === tranApiType.LOCK_FUND_INCREASE ||
      type === tranApiType.UNLOCK_FUND ||
      type === tranApiType.QUICK_PAYMENT_LIMIT
    )
      return 'PUBLIC';
    if (type === tranApiType.AAOP_REGISTRATION || type === tranApiType.UPDATE_EMAIL) return 'PRIVATE';
    return 'BOTH';
  };

  const isPublicJunction = junction => {
    if (junction === 'PUBLIC') return true;
    else if (junction === 'PRIVATE') return false;
    return isPublicRef.current;
  };

  const duplicateMessage = () => {
    switch (type) {
      case tranApiType.TOP_UP:
        return t(`${LANG_PREFIX}duplicateMsgTopUp`);
      case tranApiType.FUND_TRANSFER:
        return t(`${LANG_PREFIX}duplicateMsgFundTransfer`);
      case tranApiType.CASH_ADVANCE:
      case tranApiType.JOURNEY_TRANSFER:
      case tranApiType.JOURNEY_TRANSFER_TASK:
      case tranApiType.CARDLESS_WITHDRAW:
      case tranApiType.CARD_PAYMENT:
      case tranApiType.LOAN_PAYMENT:
      case tranApiType.BAKONG_TRANSFER:
        return t(`${LANG_PREFIX}duplicateMsgTransfer`);
      case tranApiType.JOMPAY_PAYMENT:
      case tranApiType.BILL_PAYMENT:
        return t(`${LANG_PREFIX}duplicateMsgBill`);
      default:
        return '';
    }
  };

  const failureTitle = status => {
    if (status === AAOP_TRANSACTION_DECLINED) return t(`${LANG_PREFIX}msgActivityDenied`);
    switch (type) {
      case tranApiType.QR_PAYMENT:
      case tranApiType.ALIPAY_PLUS:
      case tranApiType.CARD_PAYMENT:
      case tranApiType.LOAN_PAYMENT:
      case tranApiType.JOMPAY_PAYMENT:
      case tranApiType.BILL_PAYMENT:
        return t(`${LANG_PREFIX}msgPaymentFailed`);
      case tranApiType.TOP_UP:
        return t(`${LANG_PREFIX}msgTopUpFailed`);
      case tranApiType.CASH_ADVANCE:
        return t(`${LANG_PREFIX}msgAdvanceFailed`);
      case tranApiType.FUND_TRANSFER:
      case tranApiType.DUITNOW_MANAGEMENT:
      case tranApiType.DUITNOW_REGISTRATION:
      case tranApiType.AAOP_REGISTRATION:
      case tranApiType.JOURNEY_TRANSFER:
      case tranApiType.JOURNEY_TRANSFER_TASK:
      case tranApiType.SECURE_SIGN_APPROVAL:
      case tranApiType.BAKONG_TRANSFER:
      case tranApiType.QUICK_PAYMENT_LIMIT:
        return t(`${LANG_PREFIX}msgTransactionFailed`);
      case tranApiType.CARDLESS_WITHDRAW:
        return t(`${LANG_PREFIX}msgCardlessWithdrawalFailed`);
      case tranApiType.DEPOSIT_OPEN_EFD:
        return t(`${LANG_PREFIX}msgOpenFailed`);
      case tranApiType.DEPOSIT_PLACEMENT:
        return t(`${LANG_PREFIX}msgPlacementFailed`);
      case tranApiType.DEPOSIT_WITHDRAW:
        return t(`${LANG_PREFIX}msgDepositWithdrawalFailed`);
      case tranApiType.CARBON_OFFSET:
        return t(`${LANG_PREFIX}msgCarbonOffsetFailed`);
      case tranApiType.LOCK_FUND:
      case tranApiType.LOCK_FUND_INCREASE:
        return t(`${LANG_PREFIX}msgLockFundFailed`);
      case tranApiType.UNLOCK_FUND:
        return t(`${LANG_PREFIX}msgUnlockFundFailed`);
      case tranApiType.UPDATE_EMAIL:
        return t(`${LANG_PREFIX}msgUpdateEmailFailed`);
      case tranApiType.UPDATE_CARD_PIN:
        return t(`${LANG_PREFIX}msgSetupCardPinFailed`);
      default:
        return '';
    }
  };

  const showSemakMule = () => {
    switch (type) {
      case tranApiType.FUND_TRANSFER:
        return true;
      default:
        return false;
    }
  };

  const recipientInfoList = trxInfo => {
    switch (type) {
      case tranApiType.BAKONG_TRANSFER: {
        const bakongIdType = findBakongIdType(trxInfo?.idType);

        return [
          { title: t(`${LANG_PREFIX}recipientInfoName`), value: trxInfo?.beneName },
          { title: t(bakongIdType?.langCode), value: trxInfo?.accNo },
        ];
      }
      case tranApiType.FUND_TRANSFER: {
        const mode = trxInfo?.transferMode;
        const title = checkTransModeDuitNow(mode) ? t(findDuitnowIdTypeName(trxInfo?.idType)) : t(BANK_ACC.langCode);

        return [
          { title: t(`${LANG_PREFIX}recipientInfoName`), value: trxInfo?.beneName },
          { title, value: trxInfo?.accNo },
        ];
      }
      default:
        return [];
    }
  };

  return {
    onSubmit,
    onSuccess,
    onFailure,
    error,
    checkJunction,
    isPublicJunction,
    duplicateMessage,
    failureTitle,
    recipientInfoList,
    showSemakMule,
  };
};

export default useTranApiSubmit;
