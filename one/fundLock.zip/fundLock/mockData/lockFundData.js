const submitLockFund = {
  availableBalance: 4000,
  currentBalance: 4000,
  lockedAmount: 1000,
};

const unLock = {
  isPendingUnlock: true,
};

const cancelRelease = {
  isPendingUnlock: false,
};

const lockFundAmount = {
  lockedAmount: 1000,
  holdAmount: 1000,
};

export const LockFund = {
  Submit: submitLockFund,
  Unlock: unLock,
  CancelRelease: cancelRelease,
  LockedAmount: lockFundAmount,
};
