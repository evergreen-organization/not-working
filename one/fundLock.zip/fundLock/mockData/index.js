import { User } from './userData';
import { Auth } from './authData';
import { SoftToken } from './softTokenData';
import { Casa } from './casaData';
import { Deposit } from './depositData';
import { Card } from './cardData';
import { Loan } from './loanData';
import { RNID } from './rnidData';
import { FundTransfer } from './fundTransferData';
import { Bill } from './billData';
import { CardWithdrawal } from './withdrawData';
import { CashAdvance } from './cashAdvanceData';
import { CardPayment } from './cardPaymentData';
import { LoanPayment } from './loanPaymentData';
import { TopUp } from './topUpData';
import { Loyalty } from './loyaltyData';
import { QR } from './qrData';
import { Tracker } from './trackerData';
import { ScheduledTran } from './scheduledTranData';
import { Flexipay } from './flexipayData';
import { Appointment } from './appointmentData';
import { DuitNow } from './duitnowData';
import { Portfolio } from './portfolioData';
import { Mailbox } from './mailboxData';
import { Journey } from './journeyData';
import { Remittance } from './remittanceData';
import { DepositPlacement } from './depositPlacementData';
import { CarbonTracker } from './carbonTrackerData';
import { LockFund } from './lockFundData';
import { Language } from './languageData';

export const Demo = Object.assign(User, {
  User,
  Auth,
  SoftToken,
  Casa,
  Deposit,
  Card,
  Loan,
  RNID,
  FundTransfer,
  QR,
  Tracker,
  ScheduledTran,
  Flexipay,
  Appointment,
  Bill,
  CardWithdrawal,
  CashAdvance,
  CardPayment,
  LoanPayment,
  TopUp,
  Loyalty,
  DuitNow,
  Portfolio,
  Mailbox,
  Journey,
  Remittance,
  DepositPlacement,
  CarbonTracker,
  LockFund,
  Language,
});
