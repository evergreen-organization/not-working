import React from 'react';
import { Divider, Screen } from 'atoms';
import { NavBar, NumberInput } from 'organisms';
import { View } from 'react-native';
import { ActionModal, BankLogo, ListItem } from 'molecules';
import { PBB } from 'stores';
import { Money, Tag, Text } from 'components';
import { colors, tagColors } from 'configs';
import LockIcon from 'assets/images/icon/lock.png';
import { max_length_amount } from 'constant';
import { TranSigner } from 'softToken';
import { FUND_LOCK } from 'screens/accounts/constant/fundLock';
import { styles } from './styles';

export const FundLockAmountComp = ({
  LANG_PREFIX,
  t,
  availableBalance,
  currency,
  lockAmount,
  accountDesc,
  accountNo,
  minLockFundAmount,
  numberInputRef,
  submissionLoading,
  onSubmit,
  isConfirmationModalVisible,
  handleCloseModal,
  handleConfirm,
  tranSignerRef,
  type,
  navigation,
  onStartCheckSecfa,
  cancelPay,
}) => {
  const renderContent = () => (
    <View>
      <Text bold style={styles.alertTitle}>
        {`${t(`${LANG_PREFIX}alertLockFund1`)}!`}
      </Text>
      <Text bold>{t(`${LANG_PREFIX}alertLockFund2`)}</Text>

      <View style={styles.container}>
        <View style={styles.rowContainer}>
          <Text style={styles.textStyle}>{t(`${LANG_PREFIX}alertLockFund3`)} </Text>
          <Money
            amount={availableBalance}
            currency={currency}
            color={colors.black}
            size={15}
            isBold={true}
            isCurrencyBold={true}
          />
        </View>
        <Divider />
        <View style={styles.rowContainer}>
          <Text style={styles.textStyle}>{t(`${LANG_PREFIX}alertLockFund4`)} </Text>
          <Money
            amount={lockAmount}
            currency={currency}
            color={colors.black}
            size={15}
            isBold={true}
            isCurrencyBold={true}
          />
        </View>
      </View>

      <ListItem isLast={true}>
        <Text>{t(`${LANG_PREFIX}alertLockFund11`)}</Text>
      </ListItem>

      <ListItem isLast={true}>
        <Text>
          {t(`${LANG_PREFIX}alertLockFund5`)}
          <Text bold>
            {' '}
            {t(`${LANG_PREFIX}alertLockFund6`)} {''}
          </Text>
          {t(`${LANG_PREFIX}alertLockFund7`)}
        </Text>
      </ListItem>

      <View style={styles.listView}>
        {FUND_LOCK.LIMIT_FUNCTION.map(item => (
          <ListItem key={item.id} isLast={true} style={{ minHeight: 5, marginVertical: -10 }}>
            <Text>{t(item.text)}</Text>
          </ListItem>
        ))}
      </View>
      <ListItem isLast={true}>
        <Text>
          {t(`${LANG_PREFIX}alertLockFund8`)} {''}
          <Text bold>{t(`${LANG_PREFIX}alertLockFund9`)}</Text> {t(`${LANG_PREFIX}alertLockFund10`)}
        </Text>
      </ListItem>
    </View>
  );

  return (
    <>
      <Screen singlePage>
        <NavBar
          title={t(`${LANG_PREFIX}titleEnterAmount`)}
          back
          showShadow={true}
          bottom={
            <View style={styles.account}>
              <BankLogo id={PBB.beneBankId} name={PBB.bankName} size={30} />
              <View style={styles.detail}>
                <Text style={styles.accountDesc}>{accountDesc}</Text>
                <Text style={styles.accountNo}>{accountNo}</Text>
                <Tag
                  title={`${t(`${LANG_PREFIX}valueMinAmount`)}: ${currency}${minLockFundAmount}`}
                  color={tagColors.red}
                  style={styles.tag}
                  isBold={false}
                />
              </View>
            </View>
          }
        />

        <View style={styles.balanceView}>
          <Text style={styles.availableBalanceText}>{t(`${LANG_PREFIX}labelAvailableBalance`)}</Text>
          <Money amount={availableBalance} currency={currency} color={colors.black} size={15} isBold={false} />
        </View>
        <NumberInput
          ref={numberInputRef}
          btnTitle={t(`${LANG_PREFIX}buttonLockFund`)}
          btnIcon={LockIcon}
          loading={submissionLoading}
          maxLength={max_length_amount}
          onSubmit={onSubmit}
          showDecimal={false}
        />
      </Screen>

      <ActionModal
        isVisible={isConfirmationModalVisible}
        renderContent={renderContent}
        leftButtonTitle={t(`${LANG_PREFIX}buttonCancel`)}
        leftButtonType={'normal'}
        rightButtonTitle={t(`${LANG_PREFIX}buttonProceed`)}
        onDecline={handleCloseModal}
        onAccept={handleConfirm}
      />

      <TranSigner
        ref={tranSignerRef}
        type={type}
        navigation={navigation}
        onStartCheckSecfa={onStartCheckSecfa}
        onCancel={cancelPay}
      />
    </>
  );
};
