import React, { useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import { getCasaDetailByAccNo, getErrorMessage } from 'stores';
import { showFailure } from 'utils';
import { tranApiType } from 'constant';
import { FundLockAmountComp } from 'screens/accounts/casa/fundLockAmount/component';
import { useCasa } from 'hooks';

let secfaInfo;
const INSUFFICIENT_AMOUNT_ERROR = 'E00112';
const AMOUNT_EXCEED_ERROR = 'E00113';

export const FundLockAmount = ({ navigation, route }) => {
  // getCasa again when casa details not in redux
  useCasa({});
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.depositFundLockAmount.text.';

  const amountExceededMessage = useSelector(getErrorMessage(AMOUNT_EXCEED_ERROR));
  const insufficientAmountMessage = useSelector(getErrorMessage(INSUFFICIENT_AMOUNT_ERROR));

  const { accountNo, minLockFundAmount, type } = route.params || {};
  const numberInputRef = useRef();
  const { accountDesc, availableBalance, currency } = useSelector(getCasaDetailByAccNo({ accountNo })) || {};
  const [isConfirmationModalVisible, setIsConfirmationModalVisible] = useState(false);
  const [lockAmount, setLockAmount] = useState(0);
  const [submissionLoading, setSubmissionLoading] = useState(false);

  const tranSignerRef = useRef();
  const onStartCheckSecfa = () => setSubmissionLoading(true);
  const cancelPay = () => setSubmissionLoading(false);

  const onSubmit = ({ amount }) => {
    if (amount < minLockFundAmount)
      return showFailure(insufficientAmountMessage?.replace('${MinAmt}', `${minLockFundAmount}`));
    if (amount > availableBalance) {
      showFailure(amountExceededMessage);
      return numberInputRef.current.updateValue(0);
    }
    setLockAmount(amount);
    setIsConfirmationModalVisible(true);
  };

  const handleCloseModal = () => setIsConfirmationModalVisible(false);

  const handleConfirm = () => {
    secfaInfo = {
      tranType: type === tranApiType.LOCK_FUND ? 'LOCK_FUND' : 'LOCK_FUND_INCREASE',
      amount: lockAmount,
      fromAccNo: accountNo,
    };

    tranSignerRef.current.checkSecfa({
      secfaInfo,
      onSubmitParam: { fromAcc: accountNo },
      onSuccessParam: { secfaInfo, accountNo },
    });
    handleCloseModal();
  };

  const props = {
    onSubmit,
    onStartCheckSecfa,
    cancelPay,
    handleCloseModal,
    handleConfirm,
    LANG_PREFIX,
    t,
    availableBalance,
    currency,
    lockAmount,
    accountDesc,
    accountNo,
    minLockFundAmount,
    numberInputRef,
    submissionLoading,
    isConfirmationModalVisible,
    tranSignerRef,
    type,
    navigation,
  };

  return <FundLockAmountComp {...props} />;
};
