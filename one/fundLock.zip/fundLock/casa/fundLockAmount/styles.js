import { StyleSheet } from 'react-native';
import { colors } from 'configs';

export const styles = StyleSheet.create({
  account: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 85,
    marginHorizontal: 20,
    paddingVertical: 12,
  },
  detail: {
    marginLeft: 12,
    flex: 1,
  },
  icon: {
    width: 30,
    height: 30,
  },
  tag: {
    marginTop: 8,
    alignSelf: 'flex-start',
  },
  container: {
    backgroundColor: colors.lightestBg,
    borderRadius: 5,
    marginVertical: 20,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rowContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 15,
  },
  textStyle: {
    alignSelf: 'center',
    color: colors.medium,
  },
  alertTitle: {
    fontSize: 16,
    color: colors.primary,
    marginBottom: 20,
  },
  listView: {
    paddingHorizontal: 20,
    marginTop: 5,
    marginBottom: 10,
  },
  accountDesc: {
    fontSize: 15,
    marginBottom: 5,
  },
  accountNo: {
    fontSize: 15,
    color: colors.medium,
  },
  balanceView: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    paddingVertical: 12,
    borderRadius: 5,
    marginTop: 10,
    marginHorizontal: 20,
    paddingHorizontal: 12,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  availableBalanceText: {
    lineHeight: 15,
    fontSize: 12,
    color: colors.medium,
    textAlign: 'center',
  },
});
