import React from 'react';
import { useDispatch } from 'react-redux';

import { authStorage } from 'auth/storage';
import routes from 'navigations/routes';
import { useTranApiSubmit } from 'hooks';
import { CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MSG, proxyManageType, tranApiType } from 'constant';
import {
  duitNowIdAvailableItemAdded,
  duitNowIdAvailableItemRemoved,
  duitNowIdRegisteredItemAccountUpdated,
  duitNowIdRegisteredItemAdded,
  duitNowIdRegisteredItemRemoved,
  duitNowIdRegisteredItemStatusUpdated,
  referenceNoUpdated,
  tranDateTimeUpdated,
  updateAccountBalance,
  updateCardBalance,
  updateNewBillObject,
  updateNewJompayObject,
  updateSuccessTransaction,
  updateCardlessWithdrawObject,
  fundTransferESISuccessUpdated,
  fundTransferTrxOnHoldUpdated,
  updateNewAlipayPlusObject,
  storeBiometric,
  carbonPaymentChallengeCompleted,
  updateNewBakongObject,
  duitNowBizMsgIdUpdated,
  duitNowStatusCodeUpdated,
} from 'stores';

import { Challenge } from './component';
import { useTranslation } from 'react-i18next';

export const AAOPChallenge = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.aaopChallenge.text.';

  const dispatch = useDispatch();
  const { type, onSubmitParam, onSuccessParam } = route?.params || {};
  const tranApiUtils = useTranApiSubmit({ type, navigation });
  const junction = tranApiUtils.checkJunction();
  const isPublic = tranApiUtils.isPublicJunction(junction);

  const onChallengeSuccess = async result => {
    const { deviceTokenCookie } = result;
    if (deviceTokenCookie) authStorage.storeDeviceTokenCookie(deviceTokenCookie).then();

    if (type === tranApiType.FUND_TRANSFER) {
      //CASA only
      dispatch(referenceNoUpdated(result.refNo));
      dispatch(tranDateTimeUpdated(result.tranDateTime));
      dispatch(fundTransferESISuccessUpdated(result.isESISuccess));
      dispatch(fundTransferTrxOnHoldUpdated(result.isTrxOnHold));
      dispatch(duitNowBizMsgIdUpdated(result?.duitNowBizMsgId));
      dispatch(duitNowStatusCodeUpdated(result?.rppStatusCode));
      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
          currentBalance: result.currentBalance,
        }),
      );
    } else if (type === tranApiType.LOCK_FUND || type === tranApiType.LOCK_FUND_INCREASE) {
      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
          currentBalance: result.currentBalance,
          lockedAmount: result.lockedAmount,
          holdAmount: result.holdAmount,
        }),
      );
    } else if (type === tranApiType.DUITNOW_MANAGEMENT) {
      if (onSubmitParam.duitNowManageType === proxyManageType.DEREGISTER) {
        dispatch(duitNowIdRegisteredItemRemoved(onSubmitParam));
        dispatch(duitNowIdAvailableItemAdded(onSubmitParam));
      } else if (
        onSubmitParam.duitNowManageType === proxyManageType.ACTIVATE ||
        onSubmitParam.duitNowManageType === proxyManageType.DEACTIVATE
      ) {
        dispatch(duitNowIdRegisteredItemStatusUpdated(onSubmitParam));
      } else {
        dispatch(duitNowIdRegisteredItemAccountUpdated(onSubmitParam));
      }
    } else if (type === tranApiType.DUITNOW_REGISTRATION) {
      dispatch(duitNowIdAvailableItemRemoved(onSubmitParam));
      dispatch(duitNowIdRegisteredItemAdded(result.updatedProxy));
    } else if (type === tranApiType.QR_PAYMENT) {
      // CASA and card
      dispatch(updateSuccessTransaction(result));
      if (result.outstandingBalance)
        dispatch(
          updateCardBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            outstandingBalance: result.outstandingBalance,
          }),
        );
      else
        dispatch(
          updateAccountBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            currentBalance: result.currentBalance,
          }),
        );
    } else if (type === tranApiType.BILL_PAYMENT) {
      // CASA and card
      dispatch(
        updateNewBillObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
          isESISuccess: result.isESISuccess,
          availableBalance: result.availableBalance,
        }),
      );
      if (result.outstandingBalance)
        dispatch(
          updateCardBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            outstandingBalance: result.outstandingBalance,
          }),
        );
      else
        dispatch(
          updateAccountBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            currentBalance: result.currentBalance,
          }),
        );
    } else if (type === tranApiType.JOMPAY_PAYMENT) {
      // CASA and card
      dispatch(
        updateNewJompayObject({
          referenceNo: result.refNo,
          jompayReferenceNo: result.nbpsRefNo,
          tranDateTime: result.tranDateTime,
          isESISuccess: result.isESISuccess,
          availableBalance: result.availableBalance,
        }),
      );
      if (result.outstandingBalance)
        dispatch(
          updateCardBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            outstandingBalance: result.outstandingBalance,
          }),
        );
      else
        dispatch(
          updateAccountBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            currentBalance: result.currentBalance,
          }),
        );
    } else if (type === tranApiType.CARDLESS_WITHDRAW) {
      dispatch(
        updateCardlessWithdrawObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
          tCode: result.tCode,
          availableBalance: result.availableBalance,
        }),
      );
      if (result.currentBalance && result.availableBalance)
        dispatch(
          updateAccountBalance({
            fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
            availableBalance: result.availableBalance,
            currentBalance: result.currentBalance,
          }),
        );
    } else if (type === tranApiType.BAKONG_TRANSFER) {
      dispatch(
        updateNewBakongObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
          bakongRefNo: result.bakongRefNo,
          availableBalance: result.availableBalance,
        }),
      );

      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
          currentBalance: result.currentBalance,
        }),
      );
    } else if (type === tranApiType.ALIPAY_PLUS) {
      dispatch(
        updateNewAlipayPlusObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
          aplusRefNo: result.aplusRefNo,
          aplusRefOrderId: result.aplusRefOrderId,
          customerId: result.customerId,
          availableBalance: result.availableBalance,
        }),
      );

      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
          currentBalance: result.currentBalance,
        }),
      );
    } else if (type === tranApiType.CARBON_OFFSET) {
      dispatch(carbonPaymentChallengeCompleted(result));
      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
        }),
      );
    } else if (type === tranApiType.RESET_PIN || type === tranApiType.CHANGE_PIN) {
      if (onSubmitParam?.isBioStored) dispatch(storeBiometric(onSubmitParam?.pin, true));
    }
    // else if (type === tranApiType.UPDATE_CARD_PIN) {
    //   dispatch(updateCardAccount({ fromAcc: onSuccessParam?.secfaInfo.fromAccNo }));
    // }

    tranApiUtils.onSuccess({ extraParam: onSuccessParam });
  };

  const onChallengeFailure = result => {
    const { deviceTokenCookie } = result;
    if (deviceTokenCookie) authStorage.storeDeviceTokenCookie(deviceTokenCookie).then();

    if (result.status === CONNECTION_TIMEOUT) {
      tranApiUtils.onFailure({
        title: t(CONNECTION_TIMEOUT_MSG),
        message: t(`${LANG_PREFIX}timeoutDesc`),
      });
    } else {
      tranApiUtils.onFailure({
        title: tranApiUtils.failureTitle(result?.status),
        message: result.problem,
        extraParam: onSuccessParam,
        data: result?.data,
        status: result?.status,
      });
    }
  };

  const onCancelChallenge = message => {
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.SOFT_TOKEN_FAIL, { message });
  };

  return (
    <Challenge
      fullScreen={true}
      isPublic={isPublic}
      onSuccess={onChallengeSuccess}
      onFailure={onChallengeFailure}
      onCancelChallenge={onCancelChallenge}
    />
  );
};

export default AAOPChallenge;
