import { useDispatch, useSelector } from 'react-redux';

import routes from 'navigations/routes';
import { useSoftToken } from 'hooks/useSoftToken';
import { FAIL, SUCCESS } from 'apis/data';
import { getActiveFromAccCasa, getSoftToken, isBound, isFullAccess, isQuickPayment, routeSelected } from 'stores';
import quickLogin from 'screens/auth/login/object/quickLogin';

import { showFailure } from './message';
import { useRetry } from 'contexts';
import { SOFT_TOKEN_ACTIVATION_STATUS } from 'constant';
import { useTranslation } from 'react-i18next';

// Types of access checking
const bound = true;
const fullAccess = true;
const preferredAccount = true;
const secureSign = true;
const quickPayment = true;
const loggedIn = true;
const allowCardOnly = true;

// Configure access rights by navigation routes
const access = {
  //Financial
  [routes.CASH_ADVANCE_FROM]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.CASH_ADVANCE_TO]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },

  [routes.PAY_LOAN]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.PAY_LOAN_AMOUNT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },

  [routes.PAY_CARD]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.PAY_CARD_AMOUNT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },

  [routes.JOURNEY]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.APPOINTMENT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.TRANSFER_TO]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.CARDLESS_SELECTION]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },

  [routes.REMITTANCE]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },

  [routes.DUITNOW_ID]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },

  [routes.DEPOSIT_OPEN_ACCOUNT_TYPE]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.DEPOSIT_PLACEMENT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.DEPOSIT_WITHDRAW_AMOUNT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.DEPOSIT_WITHDRAW_CONFIRMATION]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.DEPOSIT_PLACEMENT_TENURE]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },
  [routes.FUND_LOCK_AMOUNT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign },

  //Financial Card Only
  [routes.TOP_UP]: { bound, fullAccess, preferredAccount, allowCardOnly, loggedIn, secureSign },
  [routes.BILL]: { bound, fullAccess, preferredAccount, allowCardOnly, loggedIn, secureSign },
  [routes.QR_PAYMENT]: { bound, fullAccess, preferredAccount, allowCardOnly, secureSign, quickPayment },
  [routes.CARBON_TRACKER]: { bound, fullAccess, allowCardOnly, loggedIn, secureSign },
  [routes.CARD_PIN_UPDATE_SELECT]: { bound, fullAccess, allowCardOnly, loggedIn, secureSign },
  [routes.CARD_PIN_UPDATE]: { bound, fullAccess, allowCardOnly, loggedIn, secureSign },

  //Financial no login
  [routes.SOFT_TOKEN_PENDING_TRAN]: { bound, fullAccess, secureSign },
  [routes.QUICK_PAYMENT]: { bound, fullAccess, secureSign },
  [routes.ACCOUNT_UPDATE_EMAIL]: { bound, loggedIn, fullAccess, secureSign },

  //Require Login
  [routes.ESI]: { bound, loggedIn },
  [routes.PFM_SUMMARY]: { bound, loggedIn },
  [routes.LOYALTY]: { bound, loggedIn },
  [routes.EXPENSE_TRACKER_MAIN]: { bound, fullAccess, loggedIn },
  [routes.CUSTOMER_FEEDBACK]: { bound, loggedIn },
  [routes.DEVICE_MANAGEMENT]: { bound, loggedIn },

  //No authentication
  [routes.OPEN_WEBVIEW]: {},
};

export const useAccessControl = ({ navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'utils.accessControl.';
  const dispatch = useDispatch();
  const { globalLoggedIn } = useRetry();
  const softToken = useSoftToken({ navigation });
  const store_isBound = useSelector(isBound);
  const store_fullAccess = useSelector(isFullAccess);
  const hasQuickPayment = useSelector(isQuickPayment);
  const casaStore = useSelector(getActiveFromAccCasa);
  const softTokenStore = useSelector(getSoftToken);
  const { selectedRoute, preferredAccountActive, isLicenseAvailable, isActivated, softTokenActivationStatus } =
    softTokenStore || {};

  const requireBind = path => (access[path]?.bound ? !store_isBound : false);
  const requireFullAccess = path => (access[path]?.fullAccess ? !store_fullAccess : false);
  const requireQuickPayment = path => (access[path]?.quickPayment ? !hasQuickPayment : false);
  const requireLogin = path => (access[path]?.loggedIn ? !globalLoggedIn.current : false);
  const requirePreferredAccount = path => (access[path]?.preferredAccount ? !preferredAccountActive : false);
  const requireSecureSign = path => access[path]?.secureSign;
  const canAllowCardOnly = path => access[path]?.allowCardOnly;

  const routeParams = path => ({
    flow: new quickLogin(),
    newRoute: path,
  });

  const navigate = (path, param) => {
    dispatch(routeSelected(path));

    if (requireBind(path)) return navigation.navigate(routes.LOGIN_PBE_OLD);

    if (requireFullAccess(path)) {
      return navigation.navigate(routes.LOGIN_PBE_OLD);
      // const allowCard = canAllowCardOnly(path);
      // return { requireFullAccess: true, allowCard };
    }

    if (requirePreferredAccount(path)) {
      const allowCardOnly = canAllowCardOnly(path);
      if (globalLoggedIn.current) return navigation.navigate(routes.PREFERRED_ACCOUNT, { allowCardOnly });
      return navigation.navigate(routes.LOGIN_PIN, {
        ...routeParams(routes.PREFERRED_ACCOUNT),
        params: { allowCardOnly },
      });
    }

    lastCheck(path, param);
  };

  const lastCheck = (path, param, toValidateSecureSign = true) => {
    if (requireSecureSign(path) && toValidateSecureSign) {
      if (isActivated) {
        if (softTokenActivationStatus === SOFT_TOKEN_ACTIVATION_STATUS.ACTIVE) {
          //Fully activated - proceed to next checking
        } else {
          return navigation.navigate(routes.HOME_LOADING, { action: 'checkSoftTokenStatus', params: param });
        }
      } else {
        return activateSoftToken();
      }
    }

    if (requireQuickPayment(path)) {
      if (globalLoggedIn.current) return navigation.navigate(routes.QUICK_PAYMENT, { tranType: 'UPDATE_QUICKPAYMENT' });
      return navigation.navigate(routes.LOGIN_PIN, {
        ...routeParams(routes.QUICK_PAYMENT),
        params: { tranType: 'UPDATE_QUICKPAYMENT' },
      });
    }

    if (requireLogin(path)) {
      return navigation.navigate(routes.LOGIN_PIN, {
        ...routeParams(path),
        params: param,
      });
    }

    navigation.navigate(path, param);
  };

  const activateSoftToken = () => {
    const activationInd = globalLoggedIn.current ? softToken.activate() : softToken.activateAfterPinLogin(routeParams);

    if (activationInd) return;

    return showFailure(t(`${LANG_PREFIX}pbssUnavailable`), t(`${LANG_PREFIX}pbssUnavailableDesc`));
  };

  const isSoftTokenFullyActivated = (currentPath, params) => {
    dispatch(routeSelected(currentPath));

    if (isActivated) {
      if (softTokenActivationStatus === SOFT_TOKEN_ACTIVATION_STATUS.ACTIVE) return true;
      navigation.navigate(routes.HOME_LOADING, { action: 'checkSoftTokenStatus', params });
    } else activateSoftToken();

    return false;
  };

  const fromAccountCheck = () => {
    switch (casaStore.accountsStatus) {
      case FAIL: {
        checkIC();
        break;
      }
      case SUCCESS: {
        const isCardOnlyUser = casaStore.accounts.length === 0;
        if (isCardOnlyUser) checkIC();
        else navigation.replace(routes.PREFERRED_ACCOUNT, { isFromBinding: true });
        break;
      }
    }
  };

  const softTokenStatusActivated = params => {
    lastCheck(selectedRoute, params, false);
  };

  const checkIC = () => {
    navigation.navigate(routes.MAIN_TAB);
    if (isLicenseAvailable && !isActivated)
      navigation.navigate(routes.SOFT_TOKEN_CHECKIC, {
        isFromBinding: true,
        disableBack: true,
      });
  };

  return {
    navigate,
    isSoftTokenFullyActivated,
    fromAccountCheck,
    softTokenStatusActivated,
    activateSoftToken,
  };
};
