import { StyleSheet } from 'react-native';
import { colors } from 'configs';

export const styles = StyleSheet.create({
  infoView: {
    margin: 15,
    marginBottom: 5,
  },
  cancelReleaseContentText: {
    fontSize: 16,
    color: colors.primary,
    marginBottom: 15,
  },
  emptyContainer: {
    flexDirection: 'row',
    backgroundColor: colors.lightestRed,
    marginHorizontal: 10,
    marginBottom: 10,
    borderRadius: 5,
    padding: 10,
    paddingRight: 0,
  },
  descriptionView: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
  },
  descriptionText: { flex: 1, fontSize: 13 },
  infoButtonView: {
    padding: 10,
    marginLeft: 10,
  },
  infoIcon: { width: 15, height: 15, tintColor: colors.medium },
  divider: {
    marginVertical: 10,
  },
  lockFundButton: {
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  lockFundButtonText: {
    fontSize: 13,
    color: colors.primary,
  },
  lockAmountExistContainer: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    paddingVertical: 15,
    marginHorizontal: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  titleView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  titleText: {
    fontSize: 12,
    color: colors.medium,
  },
  infoButtonView2: {
    paddingHorizontal: 10,
  },
  lockAmountSectionView: {
    marginTop: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
  lockAmountView: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  increaseButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  plusIcon: {
    width: 7,
    height: 7,
    tintColor: colors.primary,
  },
  increaseText: {
    fontSize: 13,
    paddingLeft: 3,
    color: colors.primary,
  },
  unlockButton: { backgroundColor: colors.black, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  buttonText: {
    fontSize: 13,
    color: colors.white,
  },
  cancelReleaseButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  unlockInstructionView: {
    marginTop: 15,
    backgroundColor: colors.lightestBg,
    borderRadius: 5,
    padding: 20,
    paddingVertical: 15,
  },
  unlockInstructionTitle: {
    fontSize: 13,
  },
  unlockInstructionText: {
    fontSize: 12,
  },
  row: {
    flexDirection: 'row',
  },
  emailText: {
    fontSize: 12,
    color: colors.primary,
  },
  serviceUnavailableChip: {
    borderBottomLeftRadius: 5,
    borderBottomRightRadius: 5,
    paddingVertical: 3,
    borderRadius: 0,
    marginRight: 0,
  },
  titleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  serviceUnavailableContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: -15,
  },
  tooltipIcon: {
    width: 12,
    height: 12,
    tintColor: colors.red,
    marginLeft: 5,
  },
});
