import React, { useRef, useState } from 'react';
import { showFailure, useAccessControl } from 'utils';

import { LockFundView } from './component';
import { useSelector } from 'react-redux';
import { getCasa, getErrorMessage, getOtherUrlByTag, loadLockFundAmount, submitCancelUnlock } from 'stores';
import { useTranslation } from 'react-i18next';
import { otherUrlTag, tranApiType } from 'constant';
import { useHandleDispatch } from 'hooks';
import routes from 'navigations/routes';
import { Linking } from 'react-native';

let secfaInfo;

const INACTIVE_ACC_ERROR = 'E00110';
const INSUFFICIENT_AMOUNT_ERROR = 'E00111';

export const LockFund = ({ navigation, accountIndex }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.depositLockFund.text.';
  const accessControl = useAccessControl({ navigation });
  const dispatch = useHandleDispatch();
  const store_casa = useSelector(getCasa);
  const fundLockURL = useSelector(getOtherUrlByTag({ tag: otherUrlTag.INFO_FUND_LOCK }))?.url;
  const inactiveAccountMessage = useSelector(getErrorMessage(INACTIVE_ACC_ERROR));
  const insufficientAmountMessage = useSelector(getErrorMessage(INSUFFICIENT_AMOUNT_ERROR));

  const { minLockFundAmount, lockAmountStatus } = store_casa || {};
  const { availableBalance, accountNo, currency, lockedAmount, isPendingUnlock, accountStatus } =
    store_casa.accounts[accountIndex] || {};
  const [isCancelReleaseModalVisible, setIsCancelReleaseModalVisible] = useState(false);
  const [isInfoModalVisible, setIsInfoModalVisible] = useState(false);
  const [submissionLoading, setSubmissionLoading] = useState(false);

  const tranSignerRef = useRef();

  const checkLockFundAvailable = () => {
    if (!accountStatus) {
      showFailure(inactiveAccountMessage);
      return false;
    }
    if (availableBalance < minLockFundAmount) {
      showFailure(insufficientAmountMessage?.replace('${MinAmt}', `${minLockFundAmount}`));
      return false;
    }
    return true;
  };

  const handleRetryLoadLockAmount = () => dispatch(loadLockFundAmount({ fromAccNo: accountNo }));

  const handleCloseCancelReleaseModal = () => setIsCancelReleaseModalVisible(false);

  const handleConfirmCancelReleaseFund = async () => {
    setIsCancelReleaseModalVisible(false);
    const result = await dispatch(submitCancelUnlock({ fromAccNo: accountNo }));
    if (result.problem) showFailure(result.problem);
  };

  const handleCancelReleaseFundPress = () => setIsCancelReleaseModalVisible(true);
  const handleLockFund = () => {
    if (checkLockFundAvailable())
      return accessControl.navigate(routes.FUND_LOCK_AMOUNT, {
        accountNo,
        minLockFundAmount,
        type: tranApiType.LOCK_FUND,
      });
  };
  const handleIncreaseLockFund = () => {
    if (checkLockFundAvailable())
      return accessControl.navigate(routes.FUND_LOCK_AMOUNT, {
        accountNo,
        minLockFundAmount,
        type: tranApiType.LOCK_FUND_INCREASE,
      });
  };

  const handleUnlockFund = () => {
    if (!accountStatus) return showFailure(inactiveAccountMessage);
    const isSecureSignActivated = accessControl.isSoftTokenFullyActivated(routes.MAIN_TAB);
    if (!isSecureSignActivated) return;

    secfaInfo = {
      tranType: 'UNLOCK_FUND',
      fromAccNo: accountNo,
    };

    tranSignerRef.current.checkSecfa({
      secfaInfo,
      onSubmitParam: { fromAcc: accountNo },
      onSuccessParam: { secfaInfo, accountNo },
    });
  };

  const handleInfoPress = () => setIsInfoModalVisible(true);
  const handleCloseInfo = () => setIsInfoModalVisible(false);

  const onStartCheckSecfa = () => setSubmissionLoading(true);
  const cancelPay = () => setSubmissionLoading(false);

  const handleOpenUrl = () => Linking.openURL(fundLockURL);

  const props = {
    handleOpenUrl,
    handleLockFund,
    handleInfoPress,
    handleIncreaseLockFund,
    handleUnlockFund,
    handleCancelReleaseFundPress,
    handleCloseCancelReleaseModal,
    handleConfirmCancelReleaseFund,
    handleCloseInfo,
    onStartCheckSecfa,
    cancelPay,
    handleRetryLoadLockAmount,
    lockedAmount,
    isPendingUnlock,
    currency,
    isCancelReleaseModalVisible,
    isInfoModalVisible,
    t,
    LANG_PREFIX,
    minLockFundAmount,
    tranSignerRef,
    submissionLoading,
    navigation,
    lockAmountStatus,
  };

  return <LockFundView {...props} />;
};
