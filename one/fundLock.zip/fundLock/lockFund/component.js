import React from 'react';
import { Image, ScrollView, TouchableOpacity, View } from 'react-native';

import { ActionModal, BottomDrawerModalMini, ItemErrorRetry, ListItem } from 'molecules';
import { Money, Text } from 'components';
import { Divider, LinkText, Space } from 'atoms';
import HelpIcon from 'assets/images/icon/help.png';
import PlusIcon from 'assets/images/icon/plus.png';

import { styles } from './styles';
import { TranSigner } from 'softToken';
import { tranApiType } from 'constant';
import { useTranslation } from 'react-i18next';
import { FAIL } from 'apis';
import { FUND_LOCK } from 'screens/accounts/constant/fundLock';
import { colors } from 'configs';

const LANG_PREFIX = 'screens.depositLockFund.text.';

export const LockFundView = ({
  handleOpenUrl,
  handleLockFund,
  handleInfoPress,
  handleIncreaseLockFund,
  handleUnlockFund,
  handleCancelReleaseFundPress,
  handleCloseCancelReleaseModal,
  handleConfirmCancelReleaseFund,
  handleCloseInfo,
  onStartCheckSecfa,
  cancelPay,
  handleRetryLoadLockAmount,
  lockedAmount,
  isPendingUnlock,
  currency,
  isCancelReleaseModalVisible,
  isInfoModalVisible,
  minLockFundAmount,
  tranSignerRef,
  navigation,
  lockAmountStatus,
  submissionLoading,
}) => {
  const { t } = useTranslation();
  const renderFundLockContent = () => {
    if (parseInt(lockedAmount, 10) === 0)
      return <EmptyLockAmountView handleLockFund={handleLockFund} handleInfoPress={handleInfoPress} t={t} />;

    if (lockAmountStatus === FAIL)
      return (
        <ErrorView t={t} handleInfoPress={handleInfoPress} handleRetryLoadLockAmount={handleRetryLoadLockAmount} />
      );

    if (!isPendingUnlock && lockedAmount)
      return (
        <LockAmountExistView
          t={t}
          lockedAmount={lockedAmount}
          currency={currency}
          handleInfoPress={handleInfoPress}
          handleIncreaseLockFund={handleIncreaseLockFund}
          handleUnlockFund={handleUnlockFund}
          submissionLoading={submissionLoading}
        />
      );
    if (isPendingUnlock && lockedAmount)
      return (
        <PendingLockFundUnLockView
          t={t}
          lockedAmount={lockedAmount}
          currency={currency}
          handleInfoPress={handleInfoPress}
          handleCancelReleaseFundPress={handleCancelReleaseFundPress}
        />
      );
    /* lockAmount will become undefined  when server downtime */
    return null;
  };

  return (
    <>
      {renderFundLockContent()}

      <ActionModal
        t={t}
        isVisible={isCancelReleaseModalVisible}
        leftButtonType={'normal'}
        leftButtonTitle={t(`${LANG_PREFIX}buttonNotNow`)}
        rightButtonTitle={t(`${LANG_PREFIX}buttonCancelReleaseConfirm`)}
        renderContent={() => <CancelReleaseContent t={t} />}
        onDecline={handleCloseCancelReleaseModal}
        onAccept={handleConfirmCancelReleaseFund}
      />

      <FundLockInfoModal
        t={t}
        isVisible={isInfoModalVisible}
        onClose={handleCloseInfo}
        minLockedAmount={minLockFundAmount}
        onOpenUrl={handleOpenUrl}
      />

      <TranSigner
        ref={tranSignerRef}
        type={tranApiType.UNLOCK_FUND}
        navigation={navigation}
        onStartCheckSecfa={onStartCheckSecfa}
        onCancel={cancelPay}
      />
    </>
  );
};

const FundLockInfoModal = ({ isVisible, onClose, minLockedAmount, t, onOpenUrl }) => (
  <BottomDrawerModalMini isVisible={isVisible} closeModal={onClose}>
    <ScrollView>
      <View style={styles.infoView}>
        <Text bold>{t(`${LANG_PREFIX}titleFundLock`)}</Text>
        <Space height={5} />
        <ListItem>
          <Text>
            {t(`${LANG_PREFIX}descFundLock1`)}{' '}
            <LinkText
              preLinkText={t(`${LANG_PREFIX}descFunLockPreLinkText`)}
              linkText={t(`${LANG_PREFIX}descFundLockLinkText`)}
              postLinkText={t(`${LANG_PREFIX}descFundLockPostLinkText`)}
              onPress={onOpenUrl}
            />
          </Text>
        </ListItem>
        <ListItem>
          <Text>{t(`${LANG_PREFIX}descFundLock2`)}</Text>
        </ListItem>
        <ListItem>
          <Text>{t(`${LANG_PREFIX}descFundLock4`)}</Text>
        </ListItem>
        <ListItem isLast={true}>
          <Text>{t(`${LANG_PREFIX}descFundLock3`)}</Text>
        </ListItem>
        <View style={{ paddingHorizontal: 20, marginTop: 5, marginBottom: 10 }}>
          {FUND_LOCK.LIMIT_FUNCTION.map(item => (
            <ListItem key={item.id} isLast={true} style={{ minHeight: 5, marginVertical: -10 }}>
              <Text>{t(item.text)}</Text>
            </ListItem>
          ))}
        </View>
        <Divider style={{ marginLeft: 19 }} />
        <ListItem isLast={true}>
          <Text>
            {t(`${LANG_PREFIX}descFundLock5`)} <Text bold>{t(`${LANG_PREFIX}descFundLock6`)}</Text>{' '}
            {t(`${LANG_PREFIX}descFundLock7`)}
          </Text>
        </ListItem>
      </View>
    </ScrollView>
  </BottomDrawerModalMini>
);

const CancelReleaseContent = ({ t }) => (
  <View>
    <Text bold style={styles.cancelReleaseContentText}>
      {t(`${LANG_PREFIX}cancelReleaseFundLock1`)}
    </Text>
    <Text>{t(`${LANG_PREFIX}cancelReleaseFundLock2`)}</Text>
  </View>
);

const EmptyLockAmountView = ({ handleLockFund, handleInfoPress, t }) => (
  <View style={styles.emptyContainer}>
    <View style={styles.descriptionView}>
      <Text style={styles.descriptionText}>{t(`${LANG_PREFIX}descEmptyLockAmount`)}</Text>
      <TouchableOpacity style={styles.infoButtonView} onPress={handleInfoPress}>
        <Image source={HelpIcon} style={styles.infoIcon} />
      </TouchableOpacity>
    </View>
    <Divider vertical style={styles.divider} />
    <TouchableOpacity onPress={handleLockFund} style={styles.lockFundButton}>
      <Text bold style={styles.lockFundButtonText}>
        {t(`${LANG_PREFIX}buttonLockFund`)}
      </Text>
    </TouchableOpacity>
  </View>
);

const ErrorView = ({ handleRetryLoadLockAmount, handleInfoPress, t }) => (
  <View style={styles.lockAmountExistContainer}>
    <View style={styles.titleView}>
      <Text style={styles.titleText}>{t(`${LANG_PREFIX}titleLockedAmount`)}</Text>
      <TouchableOpacity style={styles.infoButtonView2} onPress={handleInfoPress}>
        <Image source={HelpIcon} style={styles.infoIcon} />
      </TouchableOpacity>
    </View>
    <ItemErrorRetry onRetry={handleRetryLoadLockAmount} />
  </View>
);

const LockAmountExistView = ({
  handleInfoPress,
  currency,
  lockedAmount,
  handleIncreaseLockFund,
  handleUnlockFund,
  submissionLoading,
  t,
}) => (
  <View style={styles.lockAmountExistContainer}>
    <View style={styles.titleContainer}>
      <View style={styles.titleView}>
        <Text style={styles.titleText}>{t(`${LANG_PREFIX}titleLockedAmount`)}</Text>
        <TouchableOpacity style={styles.infoButtonView2} onPress={handleInfoPress}>
          <Image source={HelpIcon} style={styles.infoIcon} />
        </TouchableOpacity>
      </View>
    </View>

    <View style={styles.lockAmountSectionView}>
      <View style={styles.lockAmountView}>
        <Money currency={currency} amount={lockedAmount} size={20} isBold={true} isCurrencyBold={true} />
        <TouchableOpacity style={styles.increaseButton} onPress={handleIncreaseLockFund}>
          <Image source={PlusIcon} style={styles.plusIcon} />
          <Text bold style={styles.increaseText}>
            {t(`${LANG_PREFIX}buttonIncrease`)}
          </Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        activeOpacity={0}
        disabled={submissionLoading}
        style={[styles.unlockButton, { ...(submissionLoading && { backgroundColor: colors.lightgrey }) }]}
        onPress={handleUnlockFund}
      >
        <Text bold style={styles.buttonText}>
          {t(`${LANG_PREFIX}buttonUnlock`)}
        </Text>
      </TouchableOpacity>
    </View>
  </View>
);

const PendingLockFundUnLockView = ({ handleInfoPress, currency, lockedAmount, handleCancelReleaseFundPress, t }) => (
  <View style={styles.lockAmountExistContainer}>
    <View style={styles.titleContainer}>
      <View style={styles.titleView}>
        <Text style={styles.titleText}>{t(`${LANG_PREFIX}titlePendingLockedAmount`)}</Text>
        <TouchableOpacity style={styles.infoButtonView2} onPress={handleInfoPress}>
          <Image source={HelpIcon} style={styles.infoIcon} />
        </TouchableOpacity>
      </View>
    </View>

    <View style={styles.lockAmountSectionView}>
      <View style={styles.lockAmountView}>
        <Money currency={currency} amount={lockedAmount} size={20} isBold={true} isCurrencyBold={true} />
      </View>

      <TouchableOpacity style={styles.cancelReleaseButton} onPress={handleCancelReleaseFundPress}>
        <Text bold style={styles.buttonText}>
          {t(`${LANG_PREFIX}buttonCancelRelease`)}
        </Text>
      </TouchableOpacity>
    </View>
    <View style={styles.unlockInstructionView}>
      <Text style={styles.unlockInstructionTitle}>{t(`${LANG_PREFIX}descUnlockInstruction`)}</Text>
    </View>
  </View>
);
