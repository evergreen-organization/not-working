import { createAsyncThunk } from '@reduxjs/toolkit';
import { publicClient } from 'apis/publicClient';
import { privateClient } from 'apis/privateClient';
import { apiEndpoint } from 'apis/apiUtils';
import { Demo } from 'constant';

export const loadCasa = createAsyncThunk('casaSummary', async (casa, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return Demo.Casa.Summary;
  const result = await publicClient.get(`${apiEndpoint.public}/casaSummary/v2`);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const loadCasaPrivate = createAsyncThunk('casaSummary', async (casa, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return Demo.Casa.Summary;
  const result = await privateClient.get(`${apiEndpoint.private}/casaSummary/v2`);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const loadCasaHistory = createAsyncThunk(
  'casaHistory',
  async ({ accountNo, month, childAcc }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Casa.History;
    const result = await publicClient.post(`${apiEndpoint.public}/casaHistory`, { accountNo, month, childAcc });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const loadCasaPBeHistory = createAsyncThunk(
  'casaPBeHistory',
  async ({ accountNo, pageNo, childAcc }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Casa.PBeHistory;
    const result = await publicClient.post(`${apiEndpoint.public}/pbehistory/get`, { fromAccNo: accountNo, pageNo });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const changeCasaAccountNickname = createAsyncThunk(
  'casa/changeAccountNickname',
  async ({ accountNo, nickName }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return;
    const result = await publicClient.post(`${apiEndpoint.public}/changeAccountNickname`, { accountNo, nickName });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const loadCasaUnderReview = createAsyncThunk(
  'loadCasaUnderReview',
  async (casa, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Casa.Summary;
    const result = await publicClient.get(`${apiEndpoint.public}/onhold/get`);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const cancelUnderReviewTran = createAsyncThunk(
  'cancelUnderReviewTran',
  async ({ refNo, cancelReason }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return;
    const result = await publicClient.post(`${apiEndpoint.public}/onhold/cancel`, { refNo, cancelReason });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const submitLockFund = createAsyncThunk('lockFund/submit', async ({ secfa }, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return Demo.LockFund.Submit;
  const result = await publicClient.post(`${apiEndpoint.public}/lockFund/submit`, { secfa });
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const submitUnlockFund = createAsyncThunk(
  'lockFund/unlock',
  async ({ secfa }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.LockFund.Unlock;
    const result = await publicClient.post(`${apiEndpoint.public}/lockFund/unlock`, { secfa });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const submitCancelUnlock = createAsyncThunk(
  'lockFund/cancelUnlock',
  async ({ fromAccNo }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.LockFund.CancelRelease;
    const result = await publicClient.post(`${apiEndpoint.public}/lockFund/cancelUnlock`, { fromAccNo });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const loadLockFundAmount = createAsyncThunk(
  'lockFund/inquiry',
  async ({ fromAccNo }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.LockFund.LockedAmount;
    const result = await publicClient.post(`${apiEndpoint.public}/lockFund/inquiry`, { fromAccNo });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
