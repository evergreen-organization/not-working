import { createSelector } from '@reduxjs/toolkit';

export const getCasa = createSelector(
  state => state.bankingEntities.casa,
  casa => casa,
);

export const getActiveCasa = createSelector(
  state => state.bankingEntities.casa,
  casa => {
    const accounts = casa.accounts?.filter(item => item.accountStatus === true && item.mfcAccountInfo === null);
    return { ...casa, accounts };
  },
);

export const getActiveCasaForDuitNowTagging = createSelector(
  state => state.bankingEntities.casa,
  casa => {
    const accounts = casa.accounts?.filter(
      item =>
        item.accountStatus === true &&
        item.currency === 'RM' &&
        item.productType !== 'SHARE_LINK' &&
        item.mfcAccountInfo === null,
    );
    return { ...casa, accounts };
  },
);

export const getActiveFromAccCasa = createSelector(
  state => state.bankingEntities.casa,
  casa => {
    const accounts = casa.accounts?.filter(
      item =>
        item.accountStatus === true &&
        item.currency === 'RM' &&
        item.productType !== 'SHARE_LINK' &&
        item.mfcAccountInfo === null,
    );
    return { ...casa, accounts };
  },
);

export const getActiveCasaCashAdvance = createSelector(
  state => state.bankingEntities.casa,
  casa => {
    // let validAccounts = [];
    // let invalidAccounts = [];
    // for (let item of casa.accounts) {
    //   if (item.accountStatus === true && item.productType !== "SHARE_LINK") validAccounts.push(item);
    //   else invalidAccounts.push({ ...item, disabled: true });
    // }
    // return { ...casa, accounts: [...validAccounts, ...invalidAccounts] };

    const accounts = casa.accounts?.filter(
      item => item.accountStatus === true && item.productType !== 'SHARE_LINK' && item.mfcAccountInfo === null,
    );
    return { ...casa, accounts };
  },
);

export const casaIdle = createSelector(
  state => state.bankingEntities.casa?.accountsStatus,
  status => status === 'idle',
);

export const casaAccountsStatus = createSelector(
  state => state.bankingEntities.casa?.accountsStatus,
  status => status,
);

export const getCasaDetailByAccNo = ({ accountNo }) =>
  createSelector(
    state => state.bankingEntities.casa,
    casa => {
      const account = casa.accounts?.find(item => item.accountNo === accountNo);
      return account;
    },
  );

export const getExistJourney = createSelector(
  state => state.bankingEntities.casa?.isExistJourney,
  exist => exist,
);

export const mapCasaDetailToAccounts = ({ list }) =>
  createSelector(
    state => state.bankingEntities.casa,
    casa => {
      const accounts = casa.accounts?.filter(item => list.includes(item.accountNo));
      return accounts;
    },
  );
