import React from 'react';
import { View } from 'react-native';

import { Flex } from 'atoms';
import { Text } from '../text';
import { colors } from 'configs';
import { BottomDrawerModal } from './BottomDrawerModal';
import { TnCContent } from './TnCContent';

export const TnCModal = ({ url, isVisible, title, onClose }) => {
  return (
    <BottomDrawerModal isVisible={isVisible} closeModal={onClose}>
      {title && (
        <View style={{ paddingHorizontal: 20, paddingVertical: 12 }}>
          <Text style={{ fontSize: 13, color: colors.medium }}>{title}</Text>
        </View>
      )}
      <Flex>
        <TnCContent url={url} />
      </Flex>
    </BottomDrawerModal>
  );
};

export default TnCModal;
