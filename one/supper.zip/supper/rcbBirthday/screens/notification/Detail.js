import React, { useEffect, useState } from 'react';
import { Image, Linking, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';

import { Divider, ScreenFull, SkeletonNotification, Space } from 'atoms';
import { NavBar } from 'organisms';
import { Text } from 'components';
import { colors } from 'configs';
import { displayReceiptDateTime } from 'utils';
import { getMailbox, loadMail } from 'stores';
import { LOADING } from 'apis';
import { useApi, usePreLoginApi } from 'hooks';
import { ActionModal, ItemErrorRetry, TnCModal } from 'molecules';
import { NOTIFICATION_ACTION } from 'constant';

const startOfHeader = '{{{{';
const endOfRow = '----';
const middleOfColumn = '||||';

export const Detail = ({ route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.notificationDetail.text.';

  const { item, msgId } = route.params || {};
  const [mail, setMail] = useState(item);
  const [modalVisible, setModalVisible] = useState(false);
  const [isError, setIsError] = useState(false);
  const [isPDFVisible, setIsPDFVisible] = useState(false);
  const { subject, body, date, url, imageUrl, externalLink, type } = mail || {};

  const { mailStatus } = useSelector(getMailbox);
  const loadMailApi = useApi(loadMail);
  const { callApi } = usePreLoginApi();

  useEffect(() => {
    if (msgId) loadMailDetails().then();
  }, []);

  const clickImage = () => {
    if (externalLink) return setModalVisible(true);
    openLink();
  };

  const closeModal = () => setModalVisible(false);

  const openLink = () => Linking.openURL(url);

  const loadMailDetails = async () => {
    const { userMessage } = await callApi(() => loadMailApi.request({ msgId }));
    if (userMessage) {
      setIsError(false);
      return setMail(userMessage);
    }
    setIsError(true);
  };

  const handleOpenPDF = () => setIsPDFVisible(true);

  const handleClosePDF = () => setIsPDFVisible(false);

  const renderBody = () => {
    if (mailStatus === LOADING) {
      return <SkeletonNotification.Details />;
    }

    const isTable = body?.includes('<table>');

    if (isTable) {
      const formattedBody = body
        ?.replace(/(<br \/>)/gi, '\n')
        .replace(/(<tr><th.*?>)/gi, startOfHeader)
        .replace(/(<\/th><\/tr>)|(<\/td><\/tr>)/gi, endOfRow)
        .replace(/(<\/.*?><.*?>)/gi, middleOfColumn)
        .replace(/(<.*?>)/gi, '');

      const rowList = formattedBody.split(endOfRow);

      return rowList.map((item, index) => {
        const textIndex = item.search(/[a-zA-Z0-9]/);
        if (textIndex === -1) return null;

        const rowData = item.substring(textIndex);
        const isHeader = item.includes(startOfHeader);
        return <View key={index}>{renderRow(rowData, isHeader, index === 0)}</View>;
      });
    }

    const formattedText = body?.replace(/(<br \/>)|(<br\/>)|(<br>)/gi, '\n').replace(/(<.*?>)/gi, '');

    return (
      <View style={{ paddingVertical: 15 }}>
        <Text style={{ color: colors.medium }}>{formattedText}</Text>
      </View>
    );
  };

  const renderSpecialBody = () => {
    if (!imageUrl) return null;

    return (
      <View style={styles.linkContainer}>
        <TouchableOpacity disabled={!url} style={styles.imageBtn} onPress={handleOpenPDF}>
          <Image source={{ uri: imageUrl }} style={styles.imageSpl} />
          {url && <Text style={styles.clickImageText}>{t(`${LANG_PREFIX}labelClickImageView`)}</Text>}
        </TouchableOpacity>
      </View>
    );
  };

  const renderRow = (rowData, isHeader, isFirst) => {
    const columnList = rowData.split(middleOfColumn);

    return (
      <>
        {columnList.length > 1 && !isFirst && <Divider />}
        <View style={[styles.row, isHeader && { backgroundColor: colors.bg }]}>
          {columnList.map((item, index) => (
            <Text
              key={index}
              bold={isHeader}
              style={
                index === 0
                  ? { flex: 1, color: isHeader ? colors.black : colors.medium }
                  : { minWidth: '25%', maxWidth: '75%', textAlign: 'right' }
              }
            >
              {item.trim()}
            </Text>
          ))}
        </View>
      </>
    );
  };

  const renderHeader = () => {
    if (mailStatus === LOADING) {
      return <SkeletonNotification.DetailsHeader />;
    }

    return (
      <>
        <Text bold style={{ fontSize: 15, marginBottom: 5 }}>
          {subject}
        </Text>
        <Text style={{ fontSize: 14, color: colors.medium }}>{displayReceiptDateTime(date)}</Text>
      </>
    );
  };

  const renderImageLink = () => {
    if (!imageUrl) return null;

    return (
      <View style={styles.linkContainer}>
        <TouchableOpacity disabled={!url} style={styles.imageBtn} onPress={clickImage}>
          <Image source={{ uri: imageUrl }} style={{ width: '80%', aspectRatio: 1.2, resizeMode: 'contain' }} />
          {url ? (
            <Text style={{ color: colors.medium, textAlign: 'center' }}>{t(`${LANG_PREFIX}labelClickImageView`)}</Text>
          ) : null}
        </TouchableOpacity>
      </View>
    );
  };

  const renderModalDesc = () => (
    <View>
      <Text bold style={{ fontSize: 16, color: colors.primary, paddingBottom: 20 }}>
        {t(`${LANG_PREFIX}titleWarning`)}
      </Text>
      <Text
        style={{
          fontSize: 14,
          color: colors.medium,
          paddingBottom: 20,
        }}
      >
        {t(`${LANG_PREFIX}descWarning1`)}
      </Text>
      <Text
        style={{
          fontSize: 14,
          color: colors.medium,
        }}
      >
        {t(`${LANG_PREFIX}descWarning2`)}
      </Text>
    </View>
  );

  const renderContent = () => {
    if (isError) {
      return <ItemErrorRetry onRetry={loadMailDetails} />;
    }

    if (type === NOTIFICATION_ACTION.RCB_BDAY) {
      return renderSpecialBody();
    }

    return (
      <>
        <View style={styles.contentContainer}>{renderBody()}</View>
        {renderImageLink()}
      </>
    );
  };

  return (
    <>
      <ScreenFull>
        <NavBar
          title={t(`${LANG_PREFIX}titleDetails`)}
          back
          showShadow={true}
          bottom={<View style={{ padding: 20, paddingVertical: 12 }}>{isError ? null : renderHeader()}</View>}
        />
        <ScrollView showsVerticalScrollIndicator={false}>
          {renderContent()}
          <Space height={50} />
        </ScrollView>

        <ActionModal
          isVisible={modalVisible}
          leftButtonType={'normal'}
          leftButtonTitle={t(`${LANG_PREFIX}buttonCancel`)}
          rightButtonTitle={t(`${LANG_PREFIX}buttonProceed`)}
          renderContent={renderModalDesc}
          onDecline={closeModal}
          onAccept={openLink}
        />
      </ScreenFull>

      <TnCModal url={url} isVisible={isPDFVisible} onClose={handleClosePDF} />
    </>
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    marginTop: 10,
  },
  linkContainer: {
    marginTop: 10,
  },
  imageBtn: {
    alignItems: 'center',
  },
  row: {
    flexDirection: 'row',
    paddingVertical: 12,
    borderRadius: 0,
  },
  imageSpl: {
    width: '85%',
    aspectRatio: 0.5,
    resizeMode: 'contain',
  },
  clickImageText: {
    color: colors.medium,
    textAlign: 'center',
    marginTop: 10,
  },
});
