import React, { useCallback, useRef, useState } from 'react';
import { FlatList, RefreshControl, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useFocusEffect, useScrollToTop } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';

import { colors } from 'configs';
import { Divider, Flex, InfoNotFound, SkeletonNotification, Space } from 'atoms';
import { Text } from 'components';
import { timePassed } from 'utils';
import { getMailbox, isFullAccess, loadMailbox, mailBoxHistoryReset } from 'stores';
import { IDLE, LOADING } from 'apis';
import { LoadingMore, ReachEnd } from 'molecules';
import { useApi } from 'hooks';
import usePreLoginApi from 'hooks/usePreLoginApi';
import routes from 'navigations/routes';
import { NOTIFICATION_ACTION } from 'constant';

export const NotificationTab = ({ navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.notificationTab.text.';

  const dispatch = useDispatch();
  const { callApi } = usePreLoginApi();
  const store_fullAccess = useSelector(isFullAccess);
  const { history, historyStatus, historyNextKey, endOfHistory } = useSelector(getMailbox) || {};
  const loadMailboxApi = useApi(loadMailbox);

  const [refreshing] = useState(false);

  const toTopRef = useRef(null);
  useScrollToTop(toTopRef);

  useFocusEffect(
    useCallback(() => {
      if (store_fullAccess) start();
    }, [store_fullAccess, historyStatus]),
  );

  const start = () => {
    if (historyStatus !== IDLE) return;
    if (history?.length > 0) return;
    load(0);
  };

  const load = async mailboxInd => callApi(() => loadMailboxApi.request({ mailboxInd }));

  const handleLoadHistory = () => {
    if (endOfHistory) return;
    if (historyStatus === LOADING) return;
    load(historyNextKey);
  };

  const onRefresh = () => {
    dispatch(mailBoxHistoryReset());
    load(0);
  };

  const goDetailPage = item => {
    navigation.navigate(routes.MAILBOX_DETAIL, { item });
  };

  const renderHeader = () => <Space height={10} />;
  const renderFooter = () => {
    if (historyStatus === LOADING) return <LoadingMore />;
    if (endOfHistory && history?.length > 0) return <ReachEnd />;
    return <Space height={60} />;
  };

  const renderDesc = ({ body, type }) => {
    if (!body) return;
    const isTable = body.includes('<table>');
    if (isTable)
      return <Text style={{ fontSize: 14, color: colors.primary }}>{t(`${LANG_PREFIX}labelClickViewDetails`)}</Text>;

    const formattedText = body.replace(/(<.*?>)/gi, '');
    const textColor = type === NOTIFICATION_ACTION.RCB_BDAY ? colors.primary : colors.medium;
    return (
      <Text style={{ fontSize: 14, color: textColor }} numberOfLines={4}>
        {formattedText}
      </Text>
    );
  };

  if (historyStatus === LOADING && history?.length === 0) {
    return (
      <Flex style={styles.screen}>
        <View style={{ backgroundColor: colors.white, marginTop: 10 }}>
          <SkeletonNotification loop={6} />
        </View>
      </Flex>
    );
  }
  return (
    <Flex style={styles.screen}>
      {history?.length === 0 ? (
        <InfoNotFound title={t(`${LANG_PREFIX}titleNoNotifications`)} onRefresh={onRefresh} />
      ) : (
        <FlatList
          ref={toTopRef}
          {...(store_fullAccess && {
            refreshControl: (
              <RefreshControl
                colors={[colors.black]}
                tintColor={colors.black}
                refreshing={refreshing}
                onRefresh={onRefresh}
              />
            ),
          })}
          showsVerticalScrollIndicator={false}
          keyExtractor={(item, index) => index.toString()}
          onEndReached={handleLoadHistory}
          ListHeaderComponent={renderHeader}
          ListFooterComponent={renderFooter}
          data={history}
          renderItem={({ item, index }) => (
            <View style={{ paddingHorizontal: 20, backgroundColor: colors.white }}>
              <TouchableOpacity style={styles.btn} onPress={() => goDetailPage(item)}>
                <View>
                  <View style={{ flexDirection: 'row', marginBottom: 8 }}>
                    <Text bold style={{ fontSize: 14, flex: 1, paddingRight: 10 }} numberOfLines={1}>
                      {item.subject}
                    </Text>
                    <Text style={{ fontSize: 13, color: colors.medium }}>{timePassed(item.date)}</Text>
                  </View>
                  {renderDesc(item)}
                </View>
              </TouchableOpacity>
              {index !== history.length - 1 && <Divider />}
            </View>
          )}
        />
      )}
    </Flex>
  );
};

const styles = StyleSheet.create({
  screen: {
    backgroundColor: colors.bg,
  },
  btn: {
    paddingVertical: 12,
  },
});
