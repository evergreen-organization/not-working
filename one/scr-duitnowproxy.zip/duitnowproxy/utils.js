import { duitnowIdType, validationMsg } from 'constant';

const numericRegex = /^[0-9]+$/;
const duitnowAlphaSpecialRegex = /^[A-Za-z0-9+*/#]+$/;
const LANG_PREFIX = 'screens.fundTransfer.text.';

// DuitNow ID types that allow special characters
const duitnowAllowSpecialCharTypes = [
  duitnowIdType.PASSPORT.key,
  duitnowIdType.ARMY_NO.key,
  duitnowIdType.BUSINESS_NO.key,
];

export const validateDuitnowId = ({ value, type, numericOnly }) => {
  // Required validation
  if (!value || value.length === 0) return { errorMsg: validationMsg.required };

  // Numeric only validation (Mobile No / NRIC / Loan /Card)
  if (numericOnly && !numericRegex.test(value)) return { errorMsg: validationMsg.numeric };

  // Special character validation (PSPT / ARMN / BREG only)
  if (duitnowAllowSpecialCharTypes.includes(type)) {
    if (!duitnowAlphaSpecialRegex.test(value)) return { errorMsg: `${LANG_PREFIX}errorDuitnowRegex` };
  }

  return {};
};
