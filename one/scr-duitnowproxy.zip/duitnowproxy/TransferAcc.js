import React, { useEffect, useState } from 'react';
import { Image, StyleSheet, View, TouchableOpacity } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';

import { colors } from 'configs';
import routes from 'navigations/routes';
import {
  toAccountUpdated,
  getFavouriteList,
  transferModeUpdated,
  idTypeUpdated,
  toAccountNameUpdated,
  getFundTransfer,
  favNameUpdated,
  getCasa,
} from 'stores';
import { addMYCountryCodeForMobileNo, showFailure } from 'utils';
import {
  transMode,
  selectedPBB,
  BANK_ACC,
  duitnowIdType,
  findDuitnowIcon,
  findTransferMenuTitle,
  numericKeyboard,
  transferAccType,
} from 'constant';
import { Flex, Screen } from 'atoms';
import { BottomDrawerModal, BankLogo } from 'molecules';
import { StringInput, Contacts, NavBar } from 'organisms';
import { Text } from 'components';

import { validateDuitnowId } from './utils';

//NOTE: testing account: 1408 2002 0000 037   Alliance Bank Berhad
//NOTE: testing account: 101007101544704      Al-Rajhi
//NOTE: testing account: 0182815597
//NOTE: testing account: +6 011 202 78681
//NOTE: testing account: 4330 5537 07
//NOTE: testing account: 5000 1075 09
//NOTE: testing account: 014012556198

// const validationSchema = Yup.object().shape({
//   accountNo: Yup.string().min(10).required().label("Account Number")
// })

const LANG_PREFIX = 'screens.fundTransferAcc.text.';

export const TransferAcc = ({ navigation, route }) => {
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const store_favourite = useSelector(getFavouriteList);
  const fundTransfer = useSelector(getFundTransfer);
  const casa = useSelector(getCasa);
  const { type } = route.params || {};
  const numericOnly = type === BANK_ACC.key || type === duitnowIdType.MOBILE_NO.key || type === duitnowIdType.NRIC.key;

  const { selectedBankId, selectedBankName, idType, module } = fundTransfer;

  const payLoan = module === routes.PAY_LOAN;
  const payCard = module === routes.PAY_CARD;
  const max_length = payCard ? 16 : 34;

  const [modalContactVisible, setModalContactVisible] = useState(false);

  useEffect(() => {
    start();
  }, []);

  const start = () => {
    if (type === BANK_ACC.key) return;

    dispatch(transferModeUpdated(transMode.DUITNOW.key));
    return dispatch(idTypeUpdated(type));
  };

  const onSubmit = accountNo => {
    const { errorMsg } = validateDuitnowId({ value: accountNo, type, numericOnly });
    if (errorMsg) return showFailure(t(errorMsg));

    check(accountNo);
    navigation.navigate(routes.TRANSFER_AMOUNT);
  };

  const check = value => {
    const tempAccountNo = type === duitnowIdType.MOBILE_NO.key ? addMYCountryCodeForMobileNo(value) : value;
    dispatch(toAccountUpdated(tempAccountNo));

    if (checkIfOwnAccount(tempAccountNo)) return;
    checkIfFavourite(tempAccountNo);
  };

  const checkIfOwnAccount = accountNo => {
    const found = casa.accounts.find(item => item.accountNo === accountNo);
    if (found) {
      dispatch(transferModeUpdated(transMode.OWN.key));
      dispatch(idTypeUpdated(null));
      dispatch(toAccountNameUpdated(found.accountDesc));
      return true;
    }

    if (selectedBankId === selectedPBB.id) {
      dispatch(transferModeUpdated(transMode.PBB.key));
      dispatch(idTypeUpdated(transferAccType.CASA.key));
    }
  };

  const checkIfFavourite = accountNo => {
    const found = store_favourite.find(item => item.accNo === accountNo);
    if (found) dispatch(favNameUpdated(found.name));
    else dispatch(favNameUpdated(null));
  };

  const onSelectContact = ({ num }) => {
    onSubmit(num);
    setModalContactVisible(false);
  };

  const renderNavTitle = () => {
    if (payCard) return t(LANG_PREFIX + 'titleCardNo');
    if (payLoan) return t(LANG_PREFIX + 'titleLoanNo');
    return t(findTransferMenuTitle(type));
  };

  const placeholder = () => {
    if (payCard) return '0000 0000 0000 0000';
    return '0000000000';
  };

  return (
    <Screen singlePage>
      <NavBar
        title={`${t(LANG_PREFIX + 'titleEnter')}${renderNavTitle()}`}
        back
        showShadow={true}
        bottom={
          selectedBankId !== null ? ( //PBB is 0
            <View style={styles.account}>
              <BankLogo id={selectedBankId} name={selectedBankName} size={30} />
              <Text style={styles.text}>{selectedBankName}</Text>
            </View>
          ) : (
            <View style={styles.account}>
              <Flex />
              <Image source={findDuitnowIcon(idType)} style={styles.icon} />
              <Flex style={{ alignItems: 'flex-end' }}>
                {idType === duitnowIdType.MOBILE_NO.key && (
                  <TouchableOpacity style={{ paddingVertical: 12 }} onPress={() => setModalContactVisible(true)}>
                    <Text bold style={{ fontSize: 14, color: colors.primary }}>
                      {t(LANG_PREFIX + 'buttonOpenContact')}
                    </Text>
                  </TouchableOpacity>
                )}
              </Flex>
            </View>
          )
        }
      />
      <StringInput
        maxLength={max_length}
        // errorTitle={""}
        placeholder={placeholder()}
        {...(numericOnly && { keyboardType: numericKeyboard })}
        onSubmit={onSubmit}
      />

      <BottomDrawerModal variant={BottomDrawerModal.variants.modal} isVisible={modalContactVisible} closeModal={() => setModalContactVisible(false)}>
        <Contacts onPress={item => onSelectContact(item)} />
      </BottomDrawerModal>
    </Screen>
  );
};

const styles = StyleSheet.create({
  account: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 20,
    minHeight: 65,
  },
  text: {
    fontSize: 15,
    marginLeft: 10,
  },
  icon: {
    width: 35,
    height: 35,
  },
});

export default TransferAcc;
