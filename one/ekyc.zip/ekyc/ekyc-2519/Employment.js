import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import {
  eKYCEmploymentStored,
  eKYCIncomeStored,
  formStatus,
  getCasaApplication,
  updateCurrentPageStatus,
} from 'stores';
import { occupationMASCO, sectorMSIC } from 'constant';
import { colors } from 'configs';
import { Form, FormButtonBottom, FormConditionalDisplay, FormField, FormPicker } from 'components';
import { AvoidKeyboard, Screen } from 'atoms';
import { NavBar } from 'organisms';

import {
  ekycNavigateTo,
  EMPLOYMENT,
  EMPLOYMENT_TYPE,
  employmentCode,
  employmentValidationSchema,
  INCOME,
  NUMBER_OF_PAGES,
  updateNextApplyStep,
} from './utils';
import { TitleStep } from './components';
import _ from 'lodash';
import { useTranslation } from 'react-i18next';

const maxLength_company = 40;

export const Employment = ({ navigation, route }) => {
  const LANG_PREFIX = 'screens.ekycEmployment.text.';
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const store_getCasaApplication = useSelector(getCasaApplication);
  const { viewOnly } = route?.params ?? {};
  const {
    employmentTypeCode,
    employmentSectorCode,
    employerName,
    occupationCode,
    occupationOthersCode,
    summaryItemStatus,
  } = store_getCasaApplication;
  const initialValues = {
    employmentTypeCode: employmentTypeCode ?? undefined,
    employmentSectorCode: employmentSectorCode ?? undefined,
    employerName: employerName ?? undefined,
    occupationCode: occupationCode ?? undefined,
    occupationOthersCode: occupationOthersCode ?? undefined,
  };
  const emptyInitialValues = {
    employmentTypeCode: undefined,
    employmentSectorCode: undefined,
    employerName: undefined,
    occupationCode: undefined,
    occupationOthersCode: undefined,
  };

  const sortedSector = _.sortBy(sectorMSIC, 'label');
  const filterPrivateEmployee = occupationMASCO.filter(
    item => item.type !== 2 && item.type !== 3 && item.type !== 6 && item.type !== 7,
  );
  const filterGovernmentEmployee = occupationMASCO.filter(
    item => item.type !== 3 && item.type !== 6 && item.type !== 7 && item.type !== 10,
  );
  const filterSelfEmployed = occupationMASCO.filter(
    item => item.type !== 2 && item.type !== 6 && item.type !== 7 && item.type !== 9 && item.type !== 11,
  );
  const filterUnpaidFamilyWorker = occupationMASCO.filter(item => item.type !== 6 && item.type !== 7);
  const filterOutsideLabourForce = occupationMASCO.filter(item => item.type === 6);
  const filterRetiree = occupationMASCO.filter(item => item.type !== 6 && item.type !== 7);
  const governmentEmployeeOccupations = _.sortBy(filterGovernmentEmployee, 'label');
  const privateEmployeeOccupations = _.sortBy(filterPrivateEmployee, 'label');
  const selfEmployedOccupations = _.sortBy(filterSelfEmployed, 'label');
  const unpaidFamilyWorkerOccupations = _.sortBy(filterUnpaidFamilyWorker, 'label');
  const othersOccupations = _.sortBy(filterOutsideLabourForce, 'label');
  const retireeOccupations = _.sortBy(filterRetiree, 'label');

  const handleSubmit = ({
    employmentTypeCode,
    employmentSectorCode,
    employerName,
    occupationCode,
    occupationOthersCode,
  }) => {
    if (employmentTypeCode === employmentCode.UNEMPLOYED) {
      occupationCode = '99900';
      employmentSectorCode = '88888';
    }
    if (employmentTypeCode === employmentCode.OTHERS) employmentSectorCode = '88888';
    const employmentTypeDesc = EMPLOYMENT_TYPE.find(item => item.value === employmentTypeCode)?.label;
    dispatch(
      eKYCEmploymentStored({
        employmentTypeCode,
        employmentTypeDesc,
        employmentSectorCode,
        employerName,
        occupationCode,
        occupationOthersCode,
      }),
    );

    // reset ekyc income store state as it depends on employment values
    dispatch(
      eKYCIncomeStored({
        monthlyIncome: '',
        sourceOfIncome: '',
        occupationOthersCode: '',
      }),
    );
    dispatch(updateCurrentPageStatus({ item: EMPLOYMENT, value: formStatus.pass }));
    updateNextApplyStep({ pageStatus: summaryItemStatus[INCOME], page: INCOME, dispatch });
    return ekycNavigateTo({ currentPage: EMPLOYMENT, navigation });
  };

  return (
    <Screen>
      <NavBar
        back
        showShadow={true}
        bottom={
          <TitleStep
            title={t(`${LANG_PREFIX}headerTitle`)}
            currentPage={3}
            lastPage={NUMBER_OF_PAGES}
            showPageNo={!viewOnly}
          />
        }
      />
      <AvoidKeyboard>
        <Form
          initialValues={initialValues}
          onSubmit={handleSubmit}
          validationSchema={employmentValidationSchema(t)}
          {...(!viewOnly && { button: <FormButtonBottom title={t(`${LANG_PREFIX}buttonNext`)} /> })}
        >
          <View style={styles.form}>
            <FormPicker
              disabled={viewOnly}
              name='employmentTypeCode'
              label={t(`${LANG_PREFIX}labelEmploymentType`)}
              clearOnSelect={true}
              data={EMPLOYMENT_TYPE}
              dataLabel={'langCode'}
              t={t}
              resetFormValues={emptyInitialValues}
            />
            <FormConditionalDisplay
              condition={values =>
                !!values.employmentTypeCode &&
                (values.employmentTypeCode === employmentCode.PRIVATE_EMPLOYEE ||
                  values.employmentTypeCode === employmentCode.GOVERNMENT_EMPLOYEE ||
                  values.employmentTypeCode === employmentCode.EMPLOYER ||
                  values.employmentTypeCode === employmentCode.SELF_EMPLOYED ||
                  values.employmentTypeCode === employmentCode.UNPAID_FAMILY_WORKER)
              }
            >
              <FormPicker
                disabled={viewOnly}
                name='employmentSectorCode'
                label={t(`${LANG_PREFIX}labelEmploymentSector`)}
                data={sortedSector}
                enableSearch
                dataLabel={'langCode'}
                t={t}
              />
              <FormField
                editable={!viewOnly}
                label={t(`${LANG_PREFIX}labelCompanyName`)}
                placeholder={t(`${LANG_PREFIX}placeholderCompany`)}
                name='employerName'
                maxLength={maxLength_company}
              />
            </FormConditionalDisplay>
            <FormConditionalDisplay
              condition={values =>
                values.employmentTypeCode && values.employmentTypeCode === employmentCode.PRIVATE_EMPLOYEE
              }
            >
              <FormPicker
                disabled={viewOnly}
                label={t(`${LANG_PREFIX}labelOccupation`)}
                name='occupationCode'
                data={privateEmployeeOccupations}
                enableSearch
                dataLabel={'langCode'}
                t={t}
              />
            </FormConditionalDisplay>
            <FormConditionalDisplay
              condition={values =>
                values.employmentTypeCode && values.employmentTypeCode === employmentCode.GOVERNMENT_EMPLOYEE
              }
            >
              <FormPicker
                disabled={viewOnly}
                label={t(`${LANG_PREFIX}labelOccupation`)}
                name='occupationCode'
                data={governmentEmployeeOccupations}
                enableSearch
                dataLabel={'langCode'}
                t={t}
              />
            </FormConditionalDisplay>
            <FormConditionalDisplay
              condition={values =>
                values.employmentTypeCode &&
                (values.employmentTypeCode === employmentCode.EMPLOYER ||
                  values.employmentTypeCode === employmentCode.SELF_EMPLOYED)
              }
            >
              <FormPicker
                disabled={viewOnly}
                label={t(`${LANG_PREFIX}labelOccupation`)}
                name='occupationCode'
                data={selfEmployedOccupations}
                enableSearch
                dataLabel={'langCode'}
                t={t}
              />
            </FormConditionalDisplay>
            <FormConditionalDisplay
              condition={values =>
                values.employmentTypeCode && values.employmentTypeCode === employmentCode.UNPAID_FAMILY_WORKER
              }
            >
              <FormPicker
                disabled={viewOnly}
                label={t(`${LANG_PREFIX}labelOccupation`)}
                name='occupationCode'
                data={unpaidFamilyWorkerOccupations}
                enableSearch
                dataLabel={'langCode'}
                t={t}
              />
            </FormConditionalDisplay>
            <FormConditionalDisplay
              condition={values => values.employmentTypeCode && values.employmentTypeCode === employmentCode.OTHERS}
            >
              <FormPicker
                disabled={viewOnly}
                label={t(`${LANG_PREFIX}labelOccupation`)}
                name='occupationCode'
                data={othersOccupations}
                enableSearch
                dataLabel={'langCode'}
                t={t}
              />
            </FormConditionalDisplay>
            <FormConditionalDisplay
              condition={values => values.occupationCode && values.occupationCode === employmentCode.STUDENT}
            >
              <FormField
                editable={!viewOnly}
                label={t(`${LANG_PREFIX}labelInstitutionName`)}
                placeholder={t(`${LANG_PREFIX}placeholderInstitution`)}
                name='employerName'
                maxLength={maxLength_company}
              />
            </FormConditionalDisplay>
            <FormConditionalDisplay
              condition={values => values.occupationCode && values.occupationCode === employmentCode.RETIREE}
            >
              <FormPicker
                disabled={viewOnly}
                label={t(`${LANG_PREFIX}labelPreviousOccupation`)}
                name='occupationOthersCode'
                data={retireeOccupations}
                enableSearch
                dataLabel={'langCode'}
                t={t}
              />
            </FormConditionalDisplay>
          </View>
        </Form>
      </AvoidKeyboard>
    </Screen>
  );
};

export default Employment;

const styles = StyleSheet.create({
  form: {
    backgroundColor: colors.white,
    padding: 20,
    paddingBottom: 10,
    marginTop: 10,
  },
});
