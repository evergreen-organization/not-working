import React, { useState } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import { getCasaApplication, submitIndividualCheck, getTncByTag } from 'stores';
import { useApi } from 'hooks/useApi';
import routes from 'navigations/routes';
import { showFailure } from 'utils/message';
import { tncCategory } from 'constant';
import { Form, FormButtonBottom, FormField, FormPicker } from 'components';
import { colors } from 'configs';
import { Screen, LoadingFull, LinkText } from 'atoms';
import { TnCModal } from 'molecules';
import { NavBar } from 'organisms';
import {
  getDOBFromIC,
  COUNTRY_CODE,
  fullNameInvalidMessage,
  individualCheckValidationSchema,
  handleEKYCErrorResponse,
} from './utils';
import { TitleStep } from './components';
import { useTranslation } from 'react-i18next';

export const IndividualCheck = ({ navigation, route }) => {
  const LANG_PREFIX = 'screens.ekycIndividualCheck.text.';
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const { idNo, mobileNo } = useSelector(getCasaApplication) || {};
  const { name: tncName, url: tncUrl } = useSelector(getTncByTag({ tag: tncCategory.PBE })) || {};
  const submitIndividualCheckApi = useApi(submitIndividualCheck);
  const [showTnc, setShowTnc] = useState(false);
  const countryCode = mobileNo ? mobileNo.substring(0, 3) : '';
  // const phoneNo = mobileNo ? mobileNo.substring(3) : '';
  const initialValues = {
    name: '',
    countryCode: mobileNo ? countryCode : '+60',
    phoneNo: '',
  };

  const handleSubmit = async ({ name, countryCode, phoneNo }) => {
    const dob = getDOBFromIC(idNo);
    const removeLeadingZero = phoneNo.replace(/^0+/, '');
    const mobileNo = `${countryCode}${removeLeadingZero}`;

    const result = await submitIndividualCheckApi.request({
      name: name.toUpperCase(),
      idNo,
      dob,
      mobileNo: mobileNo,
      // productCode: selectedAccount.productCode,
      phoneNo,
    });

    if (result.status === 'S') {
      return navigation.replace(routes.APPLY_SA_PAC);
    }
    return await handleEKYCErrorResponse({
      result,
      dispatch,
      navigation,
      t,
    });
  };

  return (
    <Screen>
      <NavBar back showShadow={true} bottom={<TitleStep title={t(`${LANG_PREFIX}title`)} showPageNo={false} />} />
      <Form
        enableReinitialize={true}
        initialValues={initialValues}
        onSubmit={handleSubmit}
        validationSchema={individualCheckValidationSchema(t)}
        button={
          <FormButtonBottom
            title={t(`${LANG_PREFIX}buttonNext`)}
            desc={
              <View style={{ backgroundColor: colors.white, paddingTop: 10, paddingHorizontal: 10 }}>
                <LinkText
                  preLinkText={t(`${LANG_PREFIX}preLinkText`)}
                  linkText={t(`${LANG_PREFIX}linkText`)}
                  postLinkText={t(`${LANG_PREFIX}postLinkText`)}
                  onPress={() => setShowTnc(true)}
                  style={{ fontSize: 12, textAlign: 'center' }}
                />
              </View>
            }
          />
        }
      >
        <View style={styles.form}>
          <FormField name='name' label={t(`${LANG_PREFIX}labelName`)} autoCapitalize='words' style={{ fontSize: 15 }} />
          <View style={styles.formfieldContainer}>
            <View style={{ flex: 2 }}>
              <FormPicker
                name='countryCode'
                label={t(`${LANG_PREFIX}labelCountry`)}
                data={COUNTRY_CODE}
                style={{ minHeight: Platform.OS === 'ios' ? 45 : 50 }}
              />
            </View>
            <View style={{ flex: 5, marginLeft: 10 }}>
              <FormField
                name='phoneNo'
                label={t(`${LANG_PREFIX}labelMobile`)}
                maxLength={11}
                keyboardType={'phone-pad'}
                style={{ fontSize: 15 }}
              />
            </View>
          </View>
        </View>
      </Form>

      <TnCModal url={tncUrl} title={tncName} isVisible={showTnc} onClose={() => setShowTnc(false)} />

      {submitIndividualCheckApi.loading && <LoadingFull blur />}
    </Screen>
  );
};

export default IndividualCheck;

const styles = StyleSheet.create({
  form: {
    backgroundColor: colors.white,
    padding: 20,
    paddingBottom: 10,
    marginTop: 10,
  },
  formfieldContainer: {
    flexDirection: 'row',
    marginTop: 5,
    flex: 1,
    // alignItem: 'center',
    justifyContent: 'center',
  },
  pdf: { backgroundColor: colors.bg, height: '100%' },
});
