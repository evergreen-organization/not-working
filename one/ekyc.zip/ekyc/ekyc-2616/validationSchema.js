import * as Yup from 'yup';
import { emailRegex } from 'constant';
const LANG_PREFIX_APPLY_VALIDATION_SCHEMA = 'screens.ekycValidationSchema.text.';
const LANG_PREFIX_VALIDATION = 'constant.validationMsg.';

export const maxLength_IC = 14;

// const emailRegEx = /^[A-Za-z0-9\s@\-_'‘.\/]+$/;

const accountNumberRegEx = /^[0-9]*$/;

// eslint-disable-next-line no-useless-escape
export const plpRegEx = /^[A-Za-z0-9'‘’~!@$%^*_=+\[\]|;:.\/?\s]+$/;

const answerRegEx = /^[a-zA-Z0-9\s]+$/;

// eslint-disable-next-line no-useless-escape
const fullNameRegEx = /^[aA-zZ\s@\-'‘.\/]+$/;

const phoneRegExpSG = /^(8|9)[0-9]{7}$/;

const phoneRegExpMY = /^(1)[0-46-9]-*[0-9]{7,8}$/;

export const fullNameInvalidMessage = `${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}fullNameInvalidMessage`;

export const ICValidationSchema = t =>
  Yup.object().shape({
    ic: Yup.string()
      .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}icValidationRequired`))
      .label(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}icLabel`)),
  });

Yup.addMethod(Yup.string, 'nameCount', function (errorMessage) {
  return this.test(`test-name-count`, errorMessage, function (value) {
    const { path, createError } = this;
    if (value) return value.trim().split(/\s+/).length >= 2 || createError({ path, message: errorMessage });
  });
});

export const individualCheckValidationSchema = t =>
  Yup.object().shape({
    name: Yup.string().trim()
      .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}nameValidationRequired`))
      .min(
        2,
        t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}minLength`)
          ?.replace('${min}', 2)
          ?.replace('${label}', t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}nameLabel`)),
      )
      .max(
        150,
        t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}maxLength`)
          ?.replace('${max}', 150)
          ?.replace('${label}', t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}nameLabel`)),
      )
      .label(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}nameLabel`))
      .matches(fullNameRegEx, t(fullNameInvalidMessage)),
    countryCode: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}countryCodeIsRequired`)),
    phoneNo: Yup.string()
      .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mobileNumberIsRequired`))
      .when('countryCode', {
        is: value => value === '+60',
        then: Yup.string().matches(phoneRegExpMY, t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mobileNumberIsNotValid`)),
        otherwise: Yup.string().matches(
          phoneRegExpSG,
          t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mobileNumberIsNotValid`),
        ),
      }),
  });

export const personalInfoValidationSchema = t =>
  Yup.object().shape({
    race: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}raceIsRequired`)),
    bumiStatus: Yup.boolean()
      .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}bumiStatusIsRequired`))
      .nullable(),
    email: Yup.string()
      .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}emailIsRequired`))
      .matches(emailRegex, t(`${LANG_PREFIX_VALIDATION}email`)),
    acceptTNC: Yup.boolean().required(),
    consentPDPA: Yup.boolean(),
    purpose: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}purposeIsRequired`)),
  });

export const fatcaValidationSchema = Yup.object().shape({
  fatca: Yup.boolean(),
  crs: Yup.boolean(),
  pep: Yup.boolean(),
});

export const employmentValidationSchema = t =>
  Yup.object().shape({
    employmentTypeCode: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}employmentTypeIsRequired`)),
    employmentSectorCode: Yup.string()
      .notRequired()
      .when('employmentTypeCode', {
        is: type => type === '113' || type === '112' || type === '111' || type === '115',
        then: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}employmentSectorIsRequired`)),
      }),
    employerName: Yup.string()
      .notRequired()
      .when('employmentTypeCode', {
        is: type => type === '113' || type === '112' || type === '111' || type === '115',
        then: Yup.string()
          .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}companyNameIsRequired`))
          .max(
            100,
            t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}maxLength`)
              .replace('${max}', 100)
              .replace('${label}', t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}companyNameLabel`)),
          ),
      })
      .when('occupationCode', {
        is: occupation => occupation === '99902',
        then: Yup.string()
          .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}institutionNameIsRequired`))
          .max(
            100,
            t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}maxLength`)
              .replace('${max}', 100)
              .replace('${label}', t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}institutionNameLabel`)),
          ),
      }),
    occupationCode: Yup.string()
      .notRequired()
      .when('employmentTypeCode', {
        is: type => type !== '120',
        then: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}occupationIsRequired`)),
      }),
    occupationOthersCode: Yup.string()
      .notRequired()
      .when('occupationCode', {
        is: occupation => occupation === '99903',
        then: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}previousOccupationIsRequired`)),
      }),
  });

export const financialValidationSchema = ({ employmentTypeCode, incomeList, occupationCode, t }) =>
  Yup.object().shape({
    monthlyIncome:
      employmentTypeCode === '120' || employmentTypeCode === '200'
        ? Yup.string().notRequired()
        : Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}monthlyIncomeIsRequired`)),
    sourceOfIncome: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}sourceOfIncomeIsRequired`)),
    occupationOthersCode: Yup.string()
      .notRequired()
      .when('sourceOfIncome', {
        is: sourceOfIncome => incomeList.find(item => item.value === sourceOfIncome)?.special,
        then: Yup.string().required(
          occupationCode === '99902'
            ? t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}parentIsRequired`)
            : t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}spouseIsRequired`),
        ),
      }),
  });

export const preferredBranchValidationSchema = t =>
  Yup.object().shape({
    preferredBranchStateCode: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}stateIsRequired`)),
    preferredBranchCode: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}branchIsRequired`)),
  });

export const bankValidationSchema = t =>
  Yup.object().shape({
    otherBankId: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}otherBankNameIsRequired`)),
    otherBankAccount: Yup.string()
      .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}otherBankAccountIsRequired`))
      .label(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}otherBankAccountLabel`))
      .matches(accountNumberRegEx, t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}otherBankAccountInvalid`)),
  });

export const addressValidationSchema = t =>
  Yup.object().shape({
    checked: Yup.boolean(),
    mailAddress1: Yup.mixed().when('checked', {
      is: checked => !checked,
      then: Yup.string()
        .typeError(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mailAddressTypeError`))
        .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mailAddress1IsRequired`)),
    }),
    mailAddress2: Yup.mixed().when('checked', {
      is: checked => !checked,
      then: Yup.string().typeError(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mailAddressTypeError`)),
    }),
    mailAddress3: Yup.mixed().when('checked', {
      is: checked => !checked,
      then: Yup.string().typeError(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mailAddressTypeError`)),
    }),
    postcode: Yup.mixed().when('checked', {
      is: checked => !checked,
      then: Yup.string()
        .typeError(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mailAddressTypeError`))
        .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}postCodeIsRequired`)),
    }),
    city: Yup.mixed().when('checked', {
      is: checked => !checked,
      then: Yup.string()
        .typeError(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mailAddressTypeError`))
        .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}cityIsRequired`)),
    }),
    state: Yup.mixed().when('checked', {
      is: checked => !checked,
      then: Yup.string()
        .typeError(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}mailAddressTypeError`))
        .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}userStateIsRequired`)),
    }),
  });

export const usernameValidationSchema = t =>
  Yup.object().shape({
    id: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}userIdIsRequired`)),
  });

export const passwordValidationSchema = t =>
  Yup.object().shape({
    pWord: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}pWordIsRequired`)),
    pWord2: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}confirmPWordIsRequired`)),
    plp: Yup.string()
      .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}phraseIsRequired`))
      .min(
        13,
        t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}minLength`)
          .replace('${min}', 13)
          .replace('${label}', t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}plpLabel`)),
      )
      .max(
        20,
        t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}maxLength`)
          .replace('${max}', 20)
          .replace('${label}', t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}plpLabel`)),
      )
      .matches(plpRegEx, t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}invalidPhrase`)),
  });

export const memorableQuestionValidationSchema = t =>
  Yup.object().shape({
    question: Yup.string().required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}memorableQuestionIsRequired`)),
    answer: Yup.string()
      .required(t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}memorableAnswerIsRequired`))
      .matches(answerRegEx, t(`${LANG_PREFIX_APPLY_VALIDATION_SCHEMA}invalidMemorableAnswer`)),
  });
