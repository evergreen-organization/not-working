import React, { useEffect } from 'react';
import { useFormikContext } from 'formik';
import { View, StyleSheet } from 'react-native';

import { colors } from 'configs';
import { Icon } from 'atoms';
import { Text } from '../text';
import { useTranslation } from 'react-i18next';
import { plpRegEx } from 'screens';

const USER_ID = 'id';
const PWORD = 'pWord';
const CONFIRM_PWORD = 'pWord2';
const PHRASE = 'plp';

export const PBeRegisterErrorMessage = ({ setMeetRequirements, id }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'organisms.pbeRegisterErrorMessage.';

  const { status, values } = useFormikContext();

  useEffect(() => {
    if (status === USER_ID) {
      if (idCondition1(values[USER_ID]) && idCondition2(values[USER_ID]) && idCondition3(values[USER_ID])) {
        setMeetRequirements(true);
      } else {
        setMeetRequirements(false);
      }
    }
    if (status === PWORD || status === CONFIRM_PWORD || status === PHRASE) {
      if (
        pwdCondition1(values[PWORD]) &&
        specialAlphanumeric(values[PWORD]) &&
        pwdCondition2({ pWord: values[PWORD] }) &&
        pwdCondition3({ pWord: values[PWORD], confirmPWord: values[CONFIRM_PWORD] }) &&
        phraseCondition1(values[PHRASE]) &&
        specialAlphanumeric(values[PHRASE])
      ) {
        setMeetRequirements(true);
      } else {
        setMeetRequirements(false);
      }
    }
  }, [values, status]);

  const renderMsg = (result, text) => {
    return (
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        {result ? (
          <Icon.Entypo name='check' style={{ fontSize: 18, color: colors.green }} />
        ) : (
          <Icon.Entypo name='cross' style={{ fontSize: 18, color: colors.primary }} />
        )}
        <Text style={{ fontSize: 12, flex: 1, marginLeft: 5 }}>{text}</Text>
      </View>
    );
  };

  const noSpace = val => {
    const regex = /\s/;
    return !regex.test(val);
  };

  const specialAlphanumeric = val => {
    const alphabet = /[A-Za-z]/;
    const numeric = /[0-9]/;

    const specialChar = /['‘’~!@$%^*_=+[\]|;:./?]/;

    return alphabet.test(val) && numeric.test(val) && specialChar.test(val) && plpRegEx.test(val);
  };

  const idCondition1 = userIdInput =>
    userIdInput && userIdInput.length >= 6 && userIdInput.length <= 12 && noSpace(userIdInput);

  const idCondition2 = userIdInput => userIdInput && /^[A-Za-z0-9]*$/.test(userIdInput);

  const idCondition3 = userIdInput =>
    userIdInput && userIdInput.length > 1 && /^[A-Za-z]*$/.test(userIdInput.substr(0, 2));

  const pwdCondition1 = pWordInput =>
    pWordInput && pWordInput.length >= 8 && pWordInput.length <= 12 && noSpace(pWordInput);

  const pwdCondition2 = ({ pWord }) => id !== pWord;

  const pwdCondition3 = ({ pWord, confirmPWord }) => pWord === confirmPWord;

  const phraseCondition1 = phrase => phrase && phrase.length >= 13 && phrase.length <= 20;

  if (status === USER_ID)
    return (
      <View style={{ ...styles.tableContainer, paddingBottom: 0 }}>
        <View style={styles.tableRow}>
          {renderMsg(idCondition1(values[USER_ID]), t(`${LANG_PREFIX}labelIdCondition1`))}
        </View>
        <View style={styles.tableRow}>
          {renderMsg(idCondition2(values[USER_ID]), t(`${LANG_PREFIX}labelIdCondition2`))}
        </View>
        <View style={styles.tableRow}>
          {renderMsg(idCondition3(values[USER_ID]), t(`${LANG_PREFIX}labelIdCondition3`))}
        </View>
      </View>
    );

  if (status === PWORD || status === CONFIRM_PWORD)
    return (
      <View style={styles.tableContainer}>
        <View style={styles.tableRow}>
          {renderMsg(pwdCondition1(values[PWORD]), t(`${LANG_PREFIX}labelPwdCondition1`))}
        </View>
        <View style={styles.tableRow}>
          {renderMsg(specialAlphanumeric(values[PWORD]), t(`${LANG_PREFIX}labelPwdCondition2`))}
        </View>
        <View style={styles.tableRow}>
          {renderMsg(
            pwdCondition2({ id: values[USER_ID], pWord: values[PWORD] }),
            t(`${LANG_PREFIX}labelPwdCondition3`),
          )}
        </View>
        {status === CONFIRM_PWORD && (
          <View style={styles.tableRow}>
            {renderMsg(
              pwdCondition3({ pWord: values[PWORD], confirmPWord: values[CONFIRM_PWORD] }),
              t(`${LANG_PREFIX}labelPwdCondition4`),
            )}
          </View>
        )}
      </View>
    );

  if (status === PHRASE)
    return (
      <View style={styles.tableContainer}>
        <View style={styles.tableRow}>
          {renderMsg(phraseCondition1(values[PHRASE]), t(`${LANG_PREFIX}labelPhrase1`))}
        </View>
        <View style={styles.tableRow}>
          {renderMsg(specialAlphanumeric(values[PHRASE]), t(`${LANG_PREFIX}labelPhrase2`))}
        </View>
      </View>
    );

  return null;
};

const styles = StyleSheet.create({
  tableContainer: { paddingBottom: 15 },
  tableRow: { paddingVertical: 2 },
});

export default PBeRegisterErrorMessage;
