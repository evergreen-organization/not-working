//
//  UIColor.h
//  EKYC Verification
//
//  Created by Jovial  on 23/10/2018.
//  Copyright © 2018 Xendity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (HexString)

+ (UIColor *) colorWithHexString: (NSString *) hexString;
+ (CGFloat) colorComponentFrom: (NSString *) string start: (NSUInteger) start length: (NSUInteger) length;

@end
