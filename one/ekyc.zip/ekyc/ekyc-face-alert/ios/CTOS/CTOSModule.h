//
//  CTOSModule.h
//  pbOne
//
//  Created by administrator on 10/09/2021.
//

#import "RCTEventEmitter.h"

NS_ASSUME_NONNULL_BEGIN

@interface CTOSModule : RCTEventEmitter

@end

NS_ASSUME_NONNULL_END
