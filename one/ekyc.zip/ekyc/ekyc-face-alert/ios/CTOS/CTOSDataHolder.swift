//
//  CTOSDataHolder.swift
//  MyPB
//
//  Created by Loke Yi on 06/06/2025.
//

import Foundation

class CTOSDataHolder {
    static let shared = CTOSDataHolder()
    private init() {}

    var labelDictionary: [String: Any] = [:]
  
  func getTranslatedText(_ section: String, key: String) -> String? {
    return (labelDictionary[section] as? [String: Any])?[key] as? String
  }
  
}
