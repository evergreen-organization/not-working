//
//  CameraViewController.swift
//  pbOne
//
//  Created by administrator on 10/09/2021.
//

import Foundation
import XenditySDK
import Toast_Swift

class CameraViewController: XCameraV2ViewController, PreviewListener {
  @IBOutlet weak var cameraInstructions: UILabel!
  @IBOutlet weak var cameraBorderView: UIView!
  @IBOutlet weak var cameraButton: UIButton!
  @IBOutlet weak var cameraImage: UIImageView!
  
  
  func textFrom(_ section: String, _ key: String, default defaultValue: String = "") -> String {
      return CTOSDataHolder.shared.getTranslatedText(section, key: key) ?? defaultValue
  }
  
  // Assume Protocol `PreviewListener` has this function and the Preview contains the delegate variable of `PreviewListener`
  // Below function will assume that the Preview will call the protocol function.
  func previewAction(_ isRetry: Bool) {
//    if (isRetry) {
//      self.retryCapture() // Call this function if the User wants to retry for ID Capture.
//    } else {
//      self.submitCapture() // Call this function for ID Capture confirmation.
//    }
  }
  
    override func viewDidLoad() {
      super.viewDidLoad()
      cameraInstructions.text = textFrom("cameraScreen", "labelInstruction", default: "Press the button below to start capturing")
      cameraButton.layer.cornerRadius = cameraButton.frame.height/2
      cameraButton.layer.backgroundColor = UIColor.white.cgColor
      cameraBorderView.layer.borderWidth = 1.0
      cameraBorderView.layer.borderColor = UIColor.white.cgColor
      cameraBorderView.layer.cornerRadius = 7
    }

    override func prepareForFrontCapture() {
      cameraInstructions.text = textFrom("cameraScreen", "labelFrontMyKad", default: "Front of MyKad")
    }

  override func completeFrontCapture(_ frontImage: UIImage?) {
    cameraInstructions.text = textFrom("cameraScreen", "loadingText2", default: "Loading. Please wait...")
    print("completeFrontCapture")
  }

    override func prepareForBackCapture() {
//      cameraButton.layer.backgroundColor = UIColor.white.cgColor
//      cameraButton.layer.opacity = 1
//      cameraImage.tintColor = UIColor(red: 204.0/255.0, green: 100.0/255.0, blue: 107.0/255.0, alpha: 1)
      
      cameraButton.isUserInteractionEnabled = true
      cameraButton.isHidden = false
      cameraImage.isHidden = false
      cameraBorderView.isHidden = false
      cameraInstructions.text = textFrom("cameraScreen", "labelBackMyKad", default: "Back of MyKad")
    }

    override func completeBackCapture(_ backImage: UIImage?) {
      cameraInstructions.text = textFrom("cameraScreen", "loadingText2", default: "Loading. Please wait...")
      print("completeBackCapture")
      CTOSUtil.store.hasStarted = false
    }

    override func processImageFailure(_ errorMessage: String?) {
      print("Xendity Log: %s", errorMessage ?? "")
      let fallbackMessage = "We are unable to authenticate your ID image. Please try again."
      let toastMessage = textFrom("cameraScreen", "authenticateFailure", default: fallbackMessage)
      
      self.view.makeToast(toastMessage)
    }
  

//    /** Function below is optional and only will be called if the `SetPreviewOCR` is set to `true` */
//    override func showPreview(_ previewImage: UIImage?) {
//        // Do the Preview of the Image captured here.
//    }
//
//    /** Function below is optional and only will be called if the `SetPreviewOCR` is set to `true` */
//    override func dismissPreview() {
//        // Dismiss the Preview here.
//    }

    @IBAction func startCaptureAction(_ sender: UIButton) {
        // Call 'capturePicture' function to start capture & process image.
//      cameraButton.layer.backgroundColor = UIColor.lightGray.cgColor
//      cameraButton.layer.opacity = 0.3
//      cameraImage.tintColor = UIColor.darkGray

      cameraButton.isUserInteractionEnabled = false
      cameraButton.isHidden = true
      cameraImage.isHidden = true
      cameraBorderView.isHidden = true
      CTOSUtil.store.hasStarted = true

      cameraInstructions.text = textFrom("cameraScreen", "loadingText",default: "Loading...")
      self.capturePicture()
    }
  
  @IBAction func dismissAction (_ sender: UIButton) {
    (UIApplication.shared.delegate as? AppDelegate)?.window.rootViewController?.dismiss(animated: true, completion: nil)
    let hasStarted = CTOSUtil.store.hasStarted
    let storeReuseKey = !hasStarted
    let emitterObj = [
      "function":"NoActionBack",
      "payload": ["storeReuseKey":storeReuseKey],
    ] as [String : Any]
    CTOSUtil.store.hasStarted = false
    CTOSModule.emitter.sendEvent(withName: "ctosEmitter", body:emitterObj)
  }
}


