//
//  FaceRecordViewController.swift
//  pbOne
//
//  Created by administrator on 13/09/2021.
//

import Foundation
import XenditySDK
import Toast_Swift

class FaceRecordViewController: XFaceRecordViewController {
  
  @IBOutlet weak var middleOverlay: OvalOverlayView!
  @IBOutlet weak var recordButton: UIButton!
  @IBOutlet weak var timerLabel: UILabel!
  
  @IBOutlet weak var labelFaceMatch: UILabel!
  @IBOutlet weak var labelInstruction: UILabel!
  
  func textFrom(_ section: String, _ key: String, default defaultValue: String = "") -> String {
      return CTOSDataHolder.shared.getTranslatedText(section, key: key) ?? defaultValue
  }
  
  var transparentView: UIView!
  
  var second = 3
  var timer = Timer()
  
  override func viewDidLoad() {
      super.viewDidLoad()
    labelFaceMatch.text = textFrom("faceScanScreen", "labelFaceMatch", default: "Face Match")
    labelInstruction.text = textFrom("faceScanScreen", "labelInstruction", default: "Keep your face within the oval")


      recordButton.layer.cornerRadius = recordButton.frame.height/2
      recordButton.layer.backgroundColor = UIColor.white.cgColor
  }
  
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    
    let backgroundColor:UIColor = UIColor.init(red: CGFloat(0x66)/255, green: CGFloat(0x00)/255, blue: CGFloat(0x00)/255, alpha: CGFloat(0x00)/255)
    
    let viewWidth:CGFloat = self.middleOverlay.bounds.size.width
    let viewHeight:CGFloat = self.middleOverlay.bounds.size.height
    let ovalX:CGFloat = self.middleOverlay.bounds.size.width * 0.15
    let ovalY:CGFloat = self.middleOverlay.bounds.size.height * 0.1
    let ovalWidth:CGFloat = self.middleOverlay.bounds.size.width - (ovalX * 2)
    let ovalHeight:CGFloat = self.middleOverlay.bounds.size.height - (ovalY * 2)

    transparentView = OvalOverlayView.init(frame: CGRect(x:0, y: 0, width: viewWidth, height: viewHeight), overlayColor: backgroundColor, ovalFrame: CGRect(x: ovalX, y: ovalY, width: ovalWidth, height: ovalHeight), ovalBorderWidth: 1.0, ovalBorderColor: UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1.00))
    self.middleOverlay.insertSubview(transparentView, at: 1)
    
    if let alertVC = storyboard?.instantiateViewController(withIdentifier: "faceScanAlert") as? FaceScanWarningVC {
        alertVC.modalPresentationStyle = .overCurrentContext
        alertVC.modalTransitionStyle = .crossDissolve
        self.present(alertVC, animated: true, completion: nil)
    }
  }
  
  override func viewDidLayoutSubviews() {
    super.viewDidLayoutSubviews()
  }

  override func startRecording() {
    print("Xendity Log: startRecording");
  }

  override func processingRecording() {
    print("Xendity Log: processingRecording");
  }

  override func completingProcess() {
    print("Xendity Log: completingProcess");
  }

  @IBAction func dismissAction(_ sender: UIButton) {
    (UIApplication.shared.delegate as? AppDelegate)?.window.rootViewController?.dismiss(animated: true, completion: nil)
    let emitterObj = [
      "function":"NoActionBack",
    ] as [String : Any]
    CTOSModule.emitter.sendEvent(withName: "ctosEmitter", body:emitterObj)
  }
  
  @IBAction func startRecordAction(_ sender: UIButton) {
    // Call 'startVideoRecord' function to start record & process video.
    timer.invalidate()
    self.startVideoRecord()
    timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) {
      timer in
      self.timerLabel.textColor = UIColor(red: 0.76, green: 0.36, blue: 0.36, alpha: 1.00)
      self.second -= 1
      self.timerLabel.text = "0:0\(self.second)"
      if self.second == 0 {
        timer.invalidate()
      }
    }
  }
}
