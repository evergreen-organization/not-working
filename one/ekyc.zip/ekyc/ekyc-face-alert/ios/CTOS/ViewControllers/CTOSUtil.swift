//
//  CTOSUtil.swift
//  MyPB
//
//  Created by lance on 25/06/2025.
//

class CTOSUtil {
    static let store = CTOSUtil()  // Singleton instance

    var hasStarted: Bool = false  // Your global flag

    private init() {}  // Prevent others from creating instances
}
