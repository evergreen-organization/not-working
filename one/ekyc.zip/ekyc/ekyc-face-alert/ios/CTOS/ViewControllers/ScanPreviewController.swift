//
//  ScanPreviewController.swift
//  pbOne
//
//  Created by Public Bank ITD on 17/12/2021.
//

import Foundation

protocol ScanPreviewControllerDelegate: AnyObject {
  func scanComplete()
  func onExistingScan()
}

class ScanPreviewController: UIViewController {
  
    @IBOutlet weak var FrontCard: UIImageView!
    @IBOutlet weak var BackCard: UIImageView!
    @IBOutlet weak var FullName: UILabel!
    @IBOutlet weak var MyKadNo: UILabel!
    @IBOutlet weak var ResAddress: UILabel!
    @IBOutlet weak var reviewTitle: UILabel!
    @IBOutlet weak var labelFullName: UILabel!
    @IBOutlet weak var labelResidentialAdd: UILabel!
    @IBOutlet weak var alertTitle: UILabel!
    @IBOutlet weak var alertDescription: UILabel!
  
    @IBOutlet weak var labelMyKadNo: UILabel!
    @IBOutlet weak var buttonSubmit: UIButton!
    @IBOutlet weak var buttonRescan: UIButton!
  
  func textFrom(_ section: String, _ key: String, default defaultValue: String = "") -> String {
      return CTOSDataHolder.shared.getTranslatedText(section, key: key) ?? defaultValue
  }

    var ocr: [AnyHashable: Any] = [:];
    var meta: [AnyHashable: Any] = [:];
  
    weak var delegate: ScanPreviewControllerDelegate?
  
    override func viewDidLoad() {
      
      super.viewDidLoad()
      reviewTitle.text = textFrom("previewICScreen", "title", default: "Review your details")
      labelFullName.text = textFrom("previewICScreen", "labelFullName", default: "Full Name")
      labelMyKadNo.text = textFrom("previewICScreen", "labelMyKadNo", default: "MyKad Number")
      labelResidentialAdd.text = textFrom("previewICScreen", "labelResidentialAdd", default: "Residential Address")
      alertTitle.text = textFrom("previewICScreen", "alertTitle", default: "Alert!")
      alertDescription.text = textFrom("previewICScreen", "alertDescription", default: "Please ensure the details are accurate (same as MyKad) to avoid rejection.")
      buttonSubmit.setTitle(textFrom("previewICScreen", "labelSubmit", default: "Rescan"), for: .normal)
      buttonRescan.setTitle(textFrom("previewICScreen", "labelRescan", default: "Submit"), for: .normal)

      
      FrontCard.image = meta["idFrontImage"] as! UIImage
      BackCard.image = meta["idBackImage"] as! UIImage

      let detailsObject = ocr["FrontResult"] as AnyObject?

      let name = detailsObject?.object(forKey: "fullName") as AnyObject?
      let ic = detailsObject?.object(forKey: "documentNumber") as AnyObject?
      let add = detailsObject?.object(forKey: "address") as AnyObject?

      FullName.text = name as? String ?? ""
      MyKadNo.text = ic as? String ?? ""
      ResAddress.text = add as? String ?? ""
      
    }
  
    @IBAction func handleSubmit(_ sender: UIButton) {
      self.dismiss(animated: true, completion: nil)
      delegate?.scanComplete()
    }
  
    @IBAction func handleRetry(_ sender: UIButton) {
      self.dismiss(animated: true, completion: nil)
      delegate?.onExistingScan()
    }
  
}
