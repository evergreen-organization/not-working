import UIKit
import Lottie


class FaceScanWarningVC: UIViewController {
  
  @IBOutlet weak var lottieContainer: UIView!
  @IBOutlet weak var proceedButton: UIButton!
  @IBOutlet weak var titleView: UILabel!
  @IBOutlet weak var description1View: UITextView!
  @IBOutlet weak var noteDescriptionView: UITextView!
  @IBOutlet weak var noteTitleView: UILabel!

  func textFrom(_ section: String, _ key: String, default defaultValue: String = "") -> String {
      return CTOSDataHolder.shared.getTranslatedText(section, key: key) ?? defaultValue
  }

  
  override func viewDidLoad() {
    
    super.viewDidLoad()

    titleView.text = textFrom("faceScanScreen", "title", default: "Take a Selfie")
    description1View.text = textFrom("faceScanScreen", "description1", default: "Please make sure your face is not covered by any object i.e. mask, cap etc.")
    noteTitleView.text = textFrom("faceScanScreen", "description2", default: "Note:")
    noteDescriptionView.text = textFrom("faceScanScreen", "description3", default: "Your photo may be subject to audit and review by the Bank. For your privacy, kindly ensure appropriate attire during the scan.")
    proceedButton.setTitle(textFrom("faceScanScreen", "button", default: "Proceed"), for: .normal)

    
    let animationView = LottieAnimationView(name: "scanFace") // without `.json`

    
    animationView.frame = lottieContainer.bounds
    animationView.contentMode = .scaleAspectFit
    animationView.loopMode = .loop
    animationView.play()

    lottieContainer.addSubview(animationView)
    
    }
  
  @IBAction func proceedButton(_ sender: Any) {
    dismiss(animated: true, completion: nil)
  }
}

