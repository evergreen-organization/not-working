//
//  ViewController.swift
//  pbOne
//
//  Created by administrator on 10/09/2021.
//

import Foundation
import XenditySDK
import Toast_Swift
import Lottie

enum CTOSStatus: String {
  case pass = "pass"
  case fail = "fail"
  case idle = "n/a"
}

enum CTOSMode: Int {
  case SCAN_IC = 1
  case SCAN_FACE = 2
  case ID_VERIFICATION = 3
  case KBA = 4
}

let CHANNEL_TYPE_EIV:Int = 2


class ViewController: UIViewController, XenditySDKCallback, XendityScannerCallback, XendityFaceCallback, XendityKBACallback, XendityMultifaceCallback ,ScanPreviewControllerDelegate  {
  
  var error_dict: [String: String] = [
    "300": "An unexpected error occurred. Kindly restart the app to retry.",
    "301": "An unexpected error occurred. Kindly restart the app to retry.",
    "302": "We run into some trouble while turning on your camera. Kindly restart the app to retry.",
    "303": "To continue, you'll need to allow camera access in settings.",
    "400": "An unexpected error occurred. Send a report to the developer.",
    "401": "An unexpected error occurred. Send a report to the developer.",
    "500": "Scan unsuccessful. Kindly scan with a valid new MyKad in a well-lit area.",
    "501": "An unexpected error occurred. Send a report to the developer.",
    "502": "An unexpected error occurred. Send a report to the developer.",
    "503": "An unexpected error occurred. Send a report to the developer.",
    "306": "Connection error. We're having trouble connecting to the server. Check your internet connection and restart the app to try again.",
    "307": "We are unable to authenticate your ID image. Please try again.",
    "308": "Scan unsuccessful. Kindly rescan with a valid new MyKad.",
    "310": "Scan unsuccessful. Kindly rescan with a valid new MyKad.",
    "311": "Scan unsuccessful. Kindly rescan with a valid new MyKad.",
    "411": "Scan unsuccessful. Kindly rescan with a valid new MyKad.",
    "412": "Scan unsuccessful. Kindly rescan with a valid new MyKad.",
    "413": "Scan unsuccessful. Kindly rescan with a valid new MyKad.",
    "4103": "Scan unsuccessful. Kindly scan with a valid new MyKad in a well-lit area.",
    "312": "We're having trouble verifying you. Kindly restart the app to retry.",
    "313": "We're having trouble verifying you. Kindly restart the app to retry.",
    "314": "We're having trouble verifying you. Kindly restart the app to retry.",
    "315": "We're having trouble verifying you. Kindly restart the app to retry.",
    "318": "We're having trouble connecting to the server. Please try again after 60 minutes.",
    "319": "We're having trouble connecting to the server. Please try again after 60 minutes.",
    "320": "We're having trouble connecting to the server. Please try again after 60 minutes.",
    "418": "Scan unsuccessful. Kindly rescan with a valid new MyKad.",
    "504": "Connection error. We're having trouble connecting to the server. Check your internet connection and restart the app to try again."
  ]
  
  var SDK_error_dict: [String:String] = [
    "Generic Error":"EK0000",
    ErrorCode.server_RESPONSE_INVALID_RECORD():"EK0001",
    ErrorCode.sdk_RESPONSE_TOKEN_ERROR():"EK0002",
    ErrorCode.sdk_RESPONSE_LICENSE_ERROR() :"EK0003",
    ErrorCode.sdk_RESPONSE_NO_AUTO_FOCUS() :"EK0004",
    ErrorCode.sdk_RESPONSE_NO_CAMERA_SUPPORT() :"EK0005",
    ErrorCode.sdk_RESPONSE_UNKNOWN_ERROR() :"EK0006",
    ErrorCode.sdk_RESPONSE_PRE_DEPLOY_ERROR() :"EK0007",
    ErrorCode.sdk_RESPONSE_IMAGE_CREATION() :"EK0008",
    ErrorCode.sdk_RESPONSE_IMAGE_MISSING() :"EK0009",
    ErrorCode.sdk_RESPONSE_LANDMARK_ERROR() :"EK0010",
    ErrorCode.sdk_RESPONSE_IC_NUMBER_MISSING() :"EK0011",
    ErrorCode.sdk_RESPONSE_SCANNER_RESULTS_ERROR() :"EK0012",
    ErrorCode.sdk_RESPONSE_SAVE_DATA_ERROR() :"EK0013",
    ErrorCode.sdk_RESPONSE_FACE_REFERENCE_MISSING() :"EK0014",
    ErrorCode.sdk_RESPONSE_FACE_MATCH_ERROR() :"EK0015",
    ErrorCode.sdk_RESPONSE_FACE_LIVENESS_ERROR() :"EK0016",
    ErrorCode.sdk_RESPONSE_SAVE_FACE_ERROR() :"EK0017",
    ErrorCode.sdk_RESPONSE_BARCODE_ERROR() :"EK0018",
    ErrorCode.sdk_RESPONSE_SIGNATURE_ERROR() :"EK0019",
    ErrorCode.sdk_RESPONSE_VERIFY_ID_ERROR() :"EK0020",
    ErrorCode.sdk_RESPONSE_KBA_REQUEST_ERROR():"EK0021",
    ErrorCode.sdk_RESPONSE_KBA_VERIFY_ERROR():"EK0022",
    ErrorCode.sdk_RESPONSE_CAMERA_NOT_READY():"EK0023",
    //check this ouit post deploy
    ErrorCode.sdk_RESPONSE_OCR_RECTIFICATION_ERROR():"EK0024",
    ErrorCode.sdk_RESPONSE_CLASS_ERROR():"EK0025",
    ErrorCode.sdk_RESPONSE_NO_ACCESS():"EK0026",
    ErrorCode.sdk_RESPONSE_LICENSE_EXPIRY():"EK0027",
    ErrorCode.sdk_RESPONSE_RETRY_REACHED():"EK0028",
    ErrorCode.server_RESPONSE_HOLOGRAM_MISMATCHED():"EK0029",
    ErrorCode.sdk_RESPONSE_BILLING_ERROR():"EK0030",
    ErrorCode.server_RESPONSE_HOLOGRAM_EXPIRED():"EK0031",
    ErrorCode.server_RESPONSE_HOLOGRAM_UNKNOWN_ERROR():"EK0032",
    ErrorCode.sdk_RESPONSE_HOLOGRAM_ERROR():"EK0033",
    ErrorCode.sdk_RESPONSE_POSSIBLE_OLD():"EK0034",
    ErrorCode.sdk_RESPONSE_FACE_NOT_COMPARABLE():"EK0035",
    ErrorCode.sdk_RESPONSE_MYKAD_VERSION_UNKNOWN():"EK0036",
    ErrorCode.sdk_RESPONSE_MYKAD_VERSION_ERROR():"EK0037",
    ErrorCode.server_RESPONSE_ID_CARD_TAMPERED():"EK0038",
    ErrorCode.sdk_RESPONSE_MYKAD_INVALID():"EK0039",
    ErrorCode.server_RESPONSE_ID_CARD_LABELLED():"EK0040",
    ErrorCode.server_RESPONSE_NETWORK_FAIL():"EK0041",
    ErrorCode.server_RESPONSE_FAIL_MESSAGE():"EK0042",
    ErrorCode.server_RESPONSE_FAIL_JSON():"EK0043",
    ErrorCode.server_REQUEST_FAIL_JSON():"EK0044",
    ErrorCode.server_ACCESS_TOKEN_EXPIRED():"EK0045",
    ErrorCode.sdk_RESPONSE_POSSIBLE_ROOT():"EK0046",
    ErrorCode.server_RESPONSE_NULL_OCR():"EK0047",
    ErrorCode.server_RESPONSE_MULTIFRAME_FAIL():"EK0048",
    ErrorCode.server_RESPONSE_SINGLEFRAME_FAIL():"EK0049",
  ]
  
  var apiKey:String = ""
  var apiURL:String = ""
  var type:OCRType = ID_MYS_MYKAD_FRONT_BACK_LANDMARK
  var fullName:String = ""
  var idNo:String = ""
  var onBoardingID:String = ""
  var referenceID:String = ""
  var initialized = false
  var rawOCRResults: [AnyHashable: Any] = [:]
  var metaResults: [AnyHashable: Any] = [:]
  var inputDetails: [AnyHashable: Any] = [:]
  var referenceNo:String = ""
  var kbaAnswer:[[AnyHashable: Any]] = []
  var errorDict:[NSDictionary] = []
  var passLandmark = false
  var mNameIsSimilar = false
  var mDocumentNoIsSimilar = false
  var mFrontBackIsSimilar  = false
  var faceMatch = false
  var channel:Int = 1
  
  var requiredFeature:Int = 0
  var stageList:[Int] = []
  var timerOn = true
  
  var animationView: LottieAnimationView?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    print("XenditySDK Version: \(XenditySDK.sdkVersion())")
    print("apiKey: \(apiKey)")
    print("apiURL: \(apiURL)")
    print("type: \(type)")
    print("fullName: \(fullName)")
    print("idNo: \(idNo)")
    print("onBoardingID: \(onBoardingID)")
    print("referenceID: \(referenceID)")
    print("rawOCRResults: \(rawOCRResults)")
    print("referenceNo: \(referenceNo)")
    print("kbaAnswer: \(kbaAnswer)")
    print("errorDict: \(errorDict)")
    NSLog("start")

    stageList = convertIntToArray(requiredFeature)
    
    let customLoadingView = CustomLoadingView(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
    renderLoadingView()
    XenditySDK.setLoading(customLoadingView)
    initializeSDK()
  }
  
  func startTimeOutTimer (funcName: String, code: String){
    Timer.scheduledTimer(withTimeInterval: 120.0, repeats: false) { [self] timer in
      if(timerOn){
        exitNative(funcName, [:], code);
      }
    }
  }
  
  func initializeSDK () {
    print("initializeSDK")
    if (!initialized) {
      NSLog("Start initSDK")
      XenditySDK.initSDK(self.apiKey, apiURL: self.apiURL, completionHandler: self)
      initialized = true
    }
  }
  
  func initSDKStatus(_ status: Bool, message: String!) {
    NSLog("Stop initSDK")
    print("initSDKStatus")
    print("status: \(status)")
    print("message: \(message ?? "no message")")
    
    if (status) {
      startCTOSProcess()
    }
    else {
      initialized = false
      showErrorMessage(message)
      let map = ["initStatus":status] as [String:Any]
      exitNative("InitSDKStatus", map, getErrorCode(message))
      return
    }
  }
  
  func startCTOSProcess (){
    if (onBoardingID.isEmpty) {
      onNewScan()
    } else {
      onExistingScan()
    }
  }
  
  func runCTOSFeatures (){
    if(stageList.contains(CTOSMode.SCAN_IC.rawValue)){
      deployICScanner()
    }
    else if(stageList.contains(CTOSMode.SCAN_FACE.rawValue)){
      if(onBoardingID.isEmpty){
        showErrorMessage("Information is missing")
        exitNative("runCTOSFeatures",[:],"EK0000")
        return
      }
        deployFaceCamera()
    }
    else if(stageList.contains(CTOSMode.ID_VERIFICATION.rawValue)){
      if(onBoardingID.isEmpty){
        showErrorMessage("Information is missing")
        exitNative("runCTOSFeatures",[:],"EK0000")
        return
      }
      requestIdVerification()
    }
    else if(stageList.contains(CTOSMode.KBA.rawValue)){
      if(onBoardingID.isEmpty || referenceNo.isEmpty){
        showErrorMessage("Information is missing")
        exitNative("runCTOSFeatures",[:],"EK0000")
        return
      }
      if(kbaAnswer.isEmpty){
        requestKBA()
      }else{
        answerKBAQuestion()
      }
    }
    else{
      exitNative("Completed",[:],"S")
      return
    }
  }
  
  func deployICScanner(){
    NSLog("Start deployScanner")
    XenditySDK.deployScannerV2(type, inputController: self, extendedController: self.storyboard?.instantiateViewController(withIdentifier: "CameraViewController") as! CameraViewController, completionHandler: self)
    // callback =>
    // scanSimilarityResults
    // scanMetaDocFrontResults
    // scanMetaDocBackResults
    // scanMetaDocFaceResults
    // scanResults
  }
  
  func deployFaceCamera(){
    var idTest = self.onBoardingID
    XenditySDK.deployFaceRecord(self.onBoardingID, inputController: self, extendedController: self.storyboard?.instantiateViewController(withIdentifier: "FaceRecordViewController") as? XFaceRecordViewController, completionHandler:self)
    // callback => faceMatchResult
  }
  
  func requestIdVerification(){
    startTimeOutTimer(funcName:"requestIdVerification",code:"EK0055")
    XenditySDK.idVerificationFor(onBoarding: onBoardingID, completionHandler: self)
    // callback => idVerificationStatus
  }
  
  func requestKBA(){
    startTimeOutTimer(funcName:"requestKBA",code:"EK0056")
    XenditySDK.requestArrayKBAFor(onBoarding: onBoardingID, referenceNo: referenceNo, completionHandler: self)
    // callback => kbaRequestArrayStatus
  }
  
  
  func scanResults(_ rawOCRResults: [AnyHashable : Any]?, referenceID: String!, onBoardingID: String!, errorMessage: String!) {
    if(errorMessage.isEmpty){
      self.referenceID = referenceID
      self.rawOCRResults = rawOCRResults ?? ["error": "error"]
      self.onBoardingID = onBoardingID
      let detailsObject = rawOCRResults?["FrontResult"] as AnyObject?
      
      if(channel == CHANNEL_TYPE_EIV){
        sendUserIdentifiers(onBoardingID,referenceID)
      }
      
      let name = detailsObject?.object(forKey: "fullName") as AnyObject?
      if(name == nil || name as! String == "") {
        self.view.makeToast("Scan unsuccessful. Kindly rescan with a valid new MyKad.")
        startCTOSProcess()
      } else {
        showPreview()
      }
    }else{
      showErrorMessage(errorMessage)
      startCTOSProcess()
    }
  }
  
  func scanMetaDocFrontResults(_ frontdocImage: UIImage!, refFrontDocImage: String!, errorMessage: String!) {
    print("scanMetaDocFrontResults")
    if(errorMessage.isEmpty){
      metaResults["idFrontImage"] = frontdocImage
      metaResults["refFrontID"] = refFrontDocImage
    }else{
      showErrorMessage(errorMessage)
    }
  }
  
  func scanMetaDocBackResults(_ backDocImage: UIImage!, refBackDocImage: String!, errorMessage: String!) {
    print("scanMetaDocBackResults")
    if(errorMessage.isEmpty){
    metaResults["idBackImage"] = backDocImage
    metaResults["refBackID"] = refBackDocImage
    }else{
      showErrorMessage(errorMessage)
      startCTOSProcess()
    }
  }
  
  func scanMetaDocFaceResults(_ idFaceImage: UIImage!, refFaceImage: String!, errorMessage: String!) {
    print("scanMetaDocFaceResults")
    if(errorMessage.isEmpty){
    metaResults["idFaceImage"] = idFaceImage
    metaResults["refFace"] = refFaceImage
    }else{
      showErrorMessage(errorMessage)
      startCTOSProcess()
    }
  }
  
  func scanSimilarityResults(_ nameIsSimilar: Bool, documentNoIsSimilar: Bool, frontBackIsSimilar: Bool) {
    print("scanSimilarityResults")
    print("nameIsSimilar: \(nameIsSimilar)")
    print("documentNoIsSimilar: \(documentNoIsSimilar)")
    print("frontBackIsSimilar: \(frontBackIsSimilar)")
  
    mNameIsSimilar = nameIsSimilar
    mDocumentNoIsSimilar = documentNoIsSimilar
    mFrontBackIsSimilar  = frontBackIsSimilar
  }
  
  func scanLandmarkInformation(_ landmarkScores: [AnyHashable : Any]!) {
    print("scanLandmarkInformation")
    if (landmarkScores != nil) {
      let passLandmarkResult = landmarkScores["is_original"] as! AnyHashable
      if (passLandmarkResult != "true" as! AnyHashable) {
        print("passCTOS = false: scanLandmarkInformation")
        passLandmark = false
      }else{
        passLandmark = true
      }
    }
  }
  
  func completePostDeploymentResults(_ nameIsSimilarScore: Double, nameIsSimilar: Bool, documentNoIsSimilarScore: Double, documentNoIsSimilar: Bool, frontBackIsSimilarScore: Double, frontBackIsSimilar: Bool, errorMessage: String!) {
    //This function is not used but required by SDK confirmed by vendor
    print("completePostDeploymentResults")
    print("nameIsSimilarScore: \(nameIsSimilarScore)")
    print("documentNoIsSimilarScore: \(documentNoIsSimilarScore)")
    print("frontBackIsSimilarScore: \(frontBackIsSimilarScore)")

    if(errorMessage.count > 0) {
      showErrorMessage(errorMessage)
    }
  }
  
  func scanCompleteDeployment(_ status: Bool, errorMessage: String!) {
    
    NSLog("Stop completeScanDeployment")
    print("scanCompleteDeployment")
    
    if (errorMessage.count > 0) {
      showErrorMessage(errorMessage)
      exitNative("scanCompleteDeployment",[:],getErrorCode(errorMessage))
      return
    }
    else{
      requiredFeature = removeFromStageList(CTOSMode.SCAN_IC.rawValue)
      let map = [
        "referenceID":referenceID,
        "onBoardingID":onBoardingID,
        "rawOCRResults":rawOCRResults,
        "nameIsSimilar":mNameIsSimilar,
        "documentNoIsSimilar":mDocumentNoIsSimilar,
        "frontBackIsSimilar":mFrontBackIsSimilar,
        "passLandmark":passLandmark,
        "scanComplete":status,
      ] as [String : Any]
      exitNative("scanCompleteDeployment", map, "S")
      return
    }
//    self.rawOCRResults = [:]
//    self.metaResults = [:]
  }
  
  func faceMatchResult(_ isMatched: Bool, percentMatched: Double, error: String!) {
    NSLog("Stop deployFaceRecord")
    print("faceMatchResult")
    print("isMatched: \(isMatched)")
    print("percentMatched: \(percentMatched)")
    print("faceMatchError: \(error)")
    
    let map = ["isMatched":isMatched] as [String:Any]
    faceMatch = isMatched
    requiredFeature = removeFromStageList(CTOSMode.SCAN_FACE.rawValue);

    if (error.count > 0) {
      showErrorMessage(error)
      exitNative("faceMatchResult", [:], getErrorCode(error))
      return
    }
    else if (!isMatched) {
      exitNative("faceMatchResult", map, "EK0052");
      return
    }
    else {
      exitNative("faceMatchResult", map, "S");
      return
    }
  }
  
  func faceMatchMetaResult(_ outputImage: UIImage!, outputRef: String!) {
    print("faceMatchMetaResult")
  }
  
  func multifaceVerificationStatus(_ status: Int32, profileObject: [AnyHashable : Any]!, errorMessage: String!) {
    print("multifaceVerificationStatus")
  }

  
  func idVerificationStatus(_ status: Int32, profileObject: [AnyHashable : Any]!, errorMessage: String!) {
    NSLog("Stop idVerificationFor")
    print("idVerificationStatus")
    print("status: \(status)")
    print("errorMessage: \(String(describing: errorMessage))")
    print("profileObject: \(profileObject)")
    timerOn = false;

    if (errorMessage.count > 0) {
      showErrorMessage(errorMessage)
      exitNative("IDVerificationStatus", [:], getErrorCode(errorMessage));
      return
    }

    // status 300 valid user, status 500 clean user
    if ( profileObject.isEmpty) {
      exitNative("IDVerificationStatus", [:], "EK0054");
      return
    }

    if (status == 109) {
      exitNative("IDVerificationStatus", [:], "EK0041");
      return
    }
    
    requiredFeature = removeFromStageList(CTOSMode.SCAN_FACE.rawValue);

      let isReferenceNoExist = profileObject["ref_no"] != nil
      if(!isReferenceNoExist){
        exitNative("IDVerificationStatus", [:], "EK0000");
        return
      }
       if (status == 400) {
         exitNative("IDVerificationStatus", [:], "EK0050");
         return
      }
      else {
        referenceNo = profileObject["ref_no"] as! String
        let map = ["referenceNo":referenceNo] as [String:Any]
        if(status == 300){
          exitNative("IDVerificationStatus", map, "S");
          return
        }else{
          exitNative("IDVerificationStatus", map, "EK0051");
          return
        }
      }
  }
  
  func kbaRequestStatus(_ questionObjects: [AnyHashable : Any]!, errorMessage: String!) {
    //This function is not used but required by confirmed SDK by vendor
    print("kbaRequestStatus")
    print("errorMessage: \(errorMessage)")
    print("questionObjects \(questionObjects)")
    timerOn = false;

    if (errorMessage.count > 0) {
      showErrorMessage(errorMessage)
    }

    if ((questionObjects) != nil) {
      questionObjects.forEach({
        print("\($0)")
        print("\($1)")
      })
    }
  }
  
  func kbaRequestArrayStatus(_ questionObjects: [Any]!, errorMessage: String!) {
    NSLog("Stop requestArrayKBAFor")
    print("kbaRequestArrayStatus")
    print("errorMessage: \(errorMessage)")
    print("questionObjects \(questionObjects)")
    
    if (errorMessage.count > 0) {
      exitNative("kbaRequestArrayStatus",[:],getErrorCode(errorMessage))
      return
    }
    
    requiredFeature = removeFromStageList(CTOSMode.KBA.rawValue);
    let map = ["kbaQuestion":questionObjects as Any] as [String:Any]
    exitNative("kbaRequestArrayStatus",map,"S")
    return
  }
  
  func answerKBAQuestion() {
    print("answerKBAQuestion")
    var mAnswer:[AnswerKBA] = [];
    for item in kbaAnswer {
      let temp = AnswerKBA.init()
      temp.setQuestionID(item["id"] as! String)
      temp.setAnswer((item["answer"] as! Bool))
      print("id: \(temp.getQuestionID())\tanswer: \(temp.getAnswer())")
      mAnswer.append(temp)
    }
    NSLog("Start verifyKBAFor")
    XenditySDK.verifyKBAFor(onBoarding: onBoardingID, referenceNo: referenceNo, answers: mAnswer, completionHandler: self)
    // callback => kbaVerificationStatus
  }
  
  func kbaVerificationStatus(_ totalCorrect: Int32, errorMessage: String!) {
    NSLog("Stop verifyKBAFor")
    print("kbaVerificationStatus")
    print("errorMessage: \(errorMessage)")
    print("totalCorrect: \(totalCorrect)")
    
    if (errorMessage.count > 0) {
      exitNative("kbaVerificationStatus", [:], getErrorCode(errorMessage));
      return
    }else{
      let map = ["totalCorrect":totalCorrect] as [String:Any]
      exitNative("kbaVerificationStatus",map,"S")
      return
    }
  }
  
  func onNewScan () {
    print("onNewScan")
    
    if(channel == CHANNEL_TYPE_EIV){
      setupSDK()
      runCTOSFeatures()
    }else{
      inputDetails = [
        "fullName": fullName,
        "documentNumber": idNo
      ]
      NSLog("Start setPreDeployment")
      XenditySDK.setPreDeployment("", inputDetails: inputDetails, inputOCRType: type, completionHandler: { [self] (resReferenceID, resOnBoardingID, error) in
      completePreDeployment(resReferenceID, resOnBoardingID, error)
      })
    }
    
  }
  
  func completePreDeployment (_ resReferenceID: String?,_ resOnBoardingID:String?,_ error:String?){
    
    if (error!.count>0) {
      showErrorMessage(error ?? "")
      print(error as Any)
      exitNative("completePreDeployment", [:], getErrorCode("blaa"));
      return
    }
    
    onBoardingID = resOnBoardingID!
    referenceID = resReferenceID!
    
    NSLog("Stop setPreDeployment")
    
    XenditySDK.setReferenceID(referenceID)
    XenditySDK.setOnBoardingID(onBoardingID)
    
    sendUserIdentifiers(onBoardingID,referenceID)
  
    setupSDK()
    runCTOSFeatures()

  }
  
  func onExistingScan() {
    XenditySDK.setReferenceID(self.referenceID)
    XenditySDK.setOnBoardingID(self.onBoardingID)
    setupSDK()
    runCTOSFeatures()
  }
  
  func setupSDK() {
    XenditySDK.setPreviewOCR(false)
    XenditySDK.setCHECK_ID_FACE_COMPARE(true) 
    XenditySDK.setIDVersionChecks(REJECT_MODE)
    XenditySDK.setMATERIAL_CHECK_DETECTION(true)
    XenditySDK.setLABEL_CHECK_DETECTION(true)
    XenditySDK.setMULTI_FRAME_DETECTION(false)
    XenditySDK.setRemarks(Int32(channel))
    XenditySDK.setSHOW_SDK_LOADING(true)
  }
  
  
  func showPreview() {
    performSegue(withIdentifier: "showDetail", sender: nil)
  }
  
  func scanComplete() {
    if(channel == CHANNEL_TYPE_EIV){
      callBackRN("onIcSubmit")
    }
    XenditySDK.completeScanDeploymentV2(self.onBoardingID, metaCardResult: self.metaResults, cardResult: self.rawOCRResults, inputOCRType: self.type, completionHandler: self)
    // callback => scanCompleteDeployment
  }
  
  
  func createMetaObject() -> [String:Any] {
    let metaObj = [
      "fullName":fullName,
      "idNo":idNo ,
      "onBoardingID":onBoardingID,
      "referenceID":referenceID ,
      "rawOCRResults":rawOCRResults,
      "referenceNo":referenceNo ,
      "passLandmark":passLandmark ,
      "nameIsSimilar":mNameIsSimilar,
      "documentNoIsSimilar":mDocumentNoIsSimilar,
      "frontBackIsSimilar":mFrontBackIsSimilar,
      "isMatched":faceMatch,
      "requiredFeature":requiredFeature
    ] as [String : Any]
    return metaObj
  }
  
  
  func exitNative(_ function:String, _ payload:[String: Any], _ status:String) {
    let meta = createMetaObject()
    
    var emitterObj = [
      "function":function,
      "payload": payload,
      "status":status,
      "meta":meta
    ] as [String : Any]
    
    if (payload.count<1){
      emitterObj.removeValue(forKey: "payload")
    }
    
    (UIApplication.shared.delegate as? AppDelegate)?.window.rootViewController?.dismiss(animated: true, completion: nil)
    CTOSModule.emitter.sendEvent(withName: "ctosEmitter", body: emitterObj)
  }
  
  func convertIntToArray(_ feature: Int) -> [Int] {
    var temp = feature
    var stageList = [Int]()
    stageList.append(temp%10)
    while temp >= 10 {
      temp = temp/10
      stageList.insert(temp%10, at: 0)
    }
    return stageList
  }
  
  func removeFromStageList(_ currentStep: Int) -> Int {
    var result = 0
    if(stageList.contains(currentStep)){
      stageList = stageList.filter {$0 != currentStep}
      if(stageList.count>0){
        var newSteps = ""
        for counter in stageList {
          newSteps += String(counter)
        }
        result = Int(newSteps) ?? 0
      }
    }
    return result
  }
  
  
  func sendUserIdentifiers(_ onBoardingID: String,_ referenceID: String) {
    let emitterObj = [
      "function":"storeBoardingID",
      "payload": ["onBoardingID":onBoardingID,"referenceID":referenceID],
      "status":"S",
    ] as [String : Any]
        
    CTOSModule.emitter.sendEvent(withName: "ctosEmitter", body:emitterObj)
  }
    
  func callBackRN(_ functionName: String) {
    let emitterObj = [
      "function":functionName,
      "status":"S",
    ] as [String : Any]
        
    CTOSModule.emitter.sendEvent(withName: "ctosEmitter", body:emitterObj)
  }
  
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if let destinationVC = segue.destination as? ScanPreviewController {
      destinationVC.delegate = self
      destinationVC.ocr = self.rawOCRResults
      destinationVC.meta = self.metaResults
    }
  }
  
  func showErrorMessage(_ message: String) {
    let errCode = message.components(separatedBy: "-")
    let errorCodeString = String(errCode[0])
    if let errMsg = error_dict[errCode[0]] {
      self.view.makeToast(errMsg+"("+errorCodeString+")")
    }else{
      self.view.makeToast("An unexpected error occurred. Kindly restart the app to retry."+"("+errorCodeString+")")
    }
  }

  func getErrorCode(_ errorMessage: String) -> String {
    let errorArray = errorMessage.components(separatedBy: "\n")
    if let errMsg = SDK_error_dict[errorArray[0]] {
      return errMsg
    }else{
      return SDK_error_dict["Generic Error"]!
    }
  }
  
  func renderLoadingView() {
    let screenSize: CGRect = UIScreen.main.bounds

    let myView = UIView(frame: CGRect(x: 0, y: 0, width: screenSize.width, height: screenSize.height))
    myView.backgroundColor = UIColor.white
    
    animationView = .init(name: "kyc")
    animationView!.frame = CGRect(x: 0, y: 0, width: 200, height: 200)
    animationView!.center = CGPoint(x: myView.frame.size.width / 2, y: myView.frame.size.height / 2 )
    animationView!.contentMode = .scaleAspectFit
    animationView!.loopMode = .loop
    animationView!.animationSpeed = 0.5
    myView.addSubview(animationView!)
    animationView!.play()
    
    let myLabel = UILabel()
    myLabel.text = "Loading..."
    myLabel.textColor = .black
    myLabel.font = UIFont(name: "Nunito-Bold", size: 18)
    myLabel.textAlignment = .center

    myLabel.frame = CGRect(x: 0, y: 0, width: 200, height: 50)
    myLabel.center = CGPoint(x: myView.frame.size.width / 2, y: myView.frame.size.height / 2 + 130 )
    
    myView.addSubview(myLabel)
    self.view.addSubview(myView)
  }
}
