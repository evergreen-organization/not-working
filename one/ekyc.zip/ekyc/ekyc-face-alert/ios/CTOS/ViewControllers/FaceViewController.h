//
//  FaceViewController.h
//  DemoProject
//
//  Created by Jovial  on 31/1/2020.
//  Copyright © 2020 Xendity. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XenditySDK/XenditySDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface FaceViewController : XendityFaceViewController

@property (weak, nonatomic) IBOutlet UILabel *instructionLabel;

@end

NS_ASSUME_NONNULL_END
