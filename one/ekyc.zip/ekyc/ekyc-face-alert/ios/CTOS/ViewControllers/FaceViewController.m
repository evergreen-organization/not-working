//
//  FaceViewController.m
//  DemoProject
//
//  Created by Jovial  on 31/1/2020.
//  Copyright © 2020 Xendity. All rights reserved.
//

#import "FaceViewController.h"

@implementation FaceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    [self startFaceMatch];
}

- (void)preSmileDetection {
    [self.instructionLabel setText:@"Please Smile At The Camera."];
    NSLog(@"Xendity Log: PreSmileDetection");
}

- (void)smileDetected {
    [self.instructionLabel setText:@"Smile Detected."];
    NSLog(@"Xendity Log: SmileDetection");
}

- (void)processingSmile {
    [self.instructionLabel setText:@"Processing Smile. Please wait."];
    NSLog(@"Xendity Log: ProcessingSmile");
}

- (void)preBlinkDetection {
    [self.instructionLabel setText:@"Please Blink Your Eye."];
    NSLog(@"Xendity Log: PreBlinkDetection");
}

- (void)blinkDetected {
    [self.instructionLabel setText:@"Eye Blink Detected."];
    NSLog(@"Xendity Log: BlinkDetection");
}

- (void)processingBlink {
    [self.instructionLabel setText:@"Processing Eye Blink."];
    NSLog(@"Xendity Log: ProcessingBlink");
}

- (void)completingFaceMatchProcess {
    [self.instructionLabel setText:@"Completing Face Match process. Please wait."];
    NSLog(@"Xendity Log: CompletingFaceMatchProcess");
}

@end
