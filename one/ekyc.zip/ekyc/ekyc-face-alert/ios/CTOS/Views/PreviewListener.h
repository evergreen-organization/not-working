//
//  PreviewListener.h
//  XendityPrototype
//
//  Created by Jovial  on 15/1/2020.
//  Copyright © 2020 Xenchain. All rights reserved.
//

#ifndef PreviewListener_h
#define PreviewListener_h

@protocol PreviewListener

-(void) PreviewAction:(bool)isRetry;

@end

#endif /* PreviewListener_h */
