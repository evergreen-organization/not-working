//
//  PartialTransparentView.h
//  
//
//  Created by Jovial  on 5/8/2019.
//  Copyright © 2019 Xenchain. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

NS_ASSUME_NONNULL_BEGIN

@interface OvalOverlayView : UIView

@property (nonatomic, retain) UIColor *overlayColor;
@property (nonatomic, assign) CGRect ovalFrame;
@property (nonatomic, assign) CGFloat ovalBorderWidth;
@property (nonatomic, retain) UIColor *ovalBorderColor;

- (id)initWithFrame:(CGRect)frame overlayColor:(UIColor * _Nonnull)overlayColor ovalFrame:(CGRect)ovalFrame ovalBorderWidth:(CGFloat)ovalBorderWidth ovalBorderColor:(UIColor * _Nonnull)ovalBorderColor;

@end

NS_ASSUME_NONNULL_END
