//
//  LoadingScreenV2.swift
//  pbOne
//
//  Created by Public Bank ITD on 08/12/2021.
//

import UIKit
// import Lottie

class LoadingScreenV2: UIView {

//  @IBOutlet var animationView: LottieAnimationView!
  
  required init? (coder: NSCoder) {
    super.init(coder: coder)
    commonInit(for: "LoadingScreenV2")
  }
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    commonInit(for: "LoadingScreenV2")
//   animationView.contentMode = .scaleAspectFit
//   animationView.loopMode = .loop
//   animationView.animationSpeed = 0.5
//   animationView.play()
  }
 
  func commonInit(for customViewName: String) {
    let viewFromXib = Bundle.main.loadNibNamed(customViewName, owner: self, options: nil)![0] as! UIView
    viewFromXib.frame = self.bounds
    addSubview(viewFromXib)
  }
  
}
