//
//  OCRPreview.h
//  XendityPrototype
//
//  Created by Jovial  on 15/1/2020.
//  Copyright © 2020 Xenchain. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PreviewListener.h"

NS_ASSUME_NONNULL_BEGIN

@interface OCRPreview : UIView

@property (weak, nonatomic) IBOutlet UIImageView *mImagePreview;

@property (weak, nonatomic) IBOutlet UIButton *retryButton;
@property (weak, nonatomic) IBOutlet UIButton *continueButton;

@property (weak, nonatomic) id<PreviewListener> delegate;

+ (void)show:(UIImage *)inputImage delegate:(id<PreviewListener>)delegate;
+ (void)dismiss;

@end

NS_ASSUME_NONNULL_END
