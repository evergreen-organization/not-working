//
//  OCRPreview.m
//  XendityPrototype
//
//  Created by Jovial  on 15/1/2020.
//  Copyright © 2020 Xenchain. All rights reserved.
//

#import "OCRPreview.h"

@implementation OCRPreview

static OCRPreview *ocrPreview;

UIView *preView;

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self xibSetup];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [self xibSetup];
    }
    return self;
}

-(void) xibSetup {
    NSBundle *bundle = [NSBundle bundleForClass:[self class]];
    preView = [self loadViewFromNib:bundle];
    preView.frame = [self bounds];
    [self addSubview:preView];
}

-(UIView *) loadViewFromNib:(NSBundle *)bundle {
    UINib *nib = [UINib nibWithNibName:@"OCRPreview" bundle:bundle];
    UIView *view = (UIView *)([nib instantiateWithOwner:self options:nil][0]);
    return view;
}

+ (void)show:(UIImage *)inputImage delegate:(id<PreviewListener>)delegate {
    if (ocrPreview == nil) {
        UIWindow *containerView = UIApplication.sharedApplication.keyWindow;
        if (containerView == nil) {
            [NSException raise:@"KeyWindowNil" format:@"\n`UIApplication.keyWindow` is `nil`. If you're trying to show a loadingView from your view controller's `viewDidLoad` method, do that from `viewWillAppear` instead. Alternatively use `useContainerView` to set a view where the Loading View should show"];
            return;
        }
        
        ocrPreview = [[OCRPreview alloc] initWithFrame:containerView.bounds];
        ocrPreview.mImagePreview.image = inputImage;
        ocrPreview.delegate = delegate;
        [containerView addSubview:ocrPreview];
    }
}

+ (void)dismiss {
    if (ocrPreview != nil) {
        [ocrPreview removeFromSuperview];
        ocrPreview = nil;
    }
}

- (IBAction)buttonAction:(UIButton *)sender {
    [self.delegate PreviewAction:sender == self.retryButton];
}

@end
