import UIKit
import Lottie

class CustomLoadingView: UIView {
  
    func textFrom(_ section: String, _ key: String, default defaultValue: String = "") -> String {
        return CTOSDataHolder.shared.getTranslatedText(section, key: key) ?? defaultValue
    }
  
    private lazy var loadingLabel: UILabel = {
        let label = UILabel()
        label.text = textFrom("previewICScreen", "labelLoading", default: "Loading...")

        label.textColor = .black
        label.font = UIFont(name: "Nunito-Bold", size: 18)
        label.textAlignment = .center
        label.numberOfLines = 0 // Allow multiple lines
        label.adjustsFontSizeToFitWidth = true // Adjust font size if needed
        label.minimumScaleFactor = 0.5 // Allow scaling down to 50% of original size
        return label
    }()
    
    var animationView: LottieAnimationView?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }

    private func setupView() {
        backgroundColor = UIColor.white
        addSubview(loadingLabel)
      
        animationView = .init(name: "kyc")
        animationView!.contentMode = .scaleAspectFit
        animationView!.loopMode = .loop
        animationView!.animationSpeed = 0.5
        addSubview(animationView!)
        animationView!.play()

        // Set up constraints
        animationView!.translatesAutoresizingMaskIntoConstraints = false
        loadingLabel.translatesAutoresizingMaskIntoConstraints = false
      
        NSLayoutConstraint.activate([
            animationView!.centerXAnchor.constraint(equalTo: centerXAnchor),
            animationView!.centerYAnchor.constraint(equalTo: centerYAnchor),
            animationView!.widthAnchor.constraint(equalToConstant: 200),
            animationView!.heightAnchor.constraint(equalToConstant: 200),
            
            loadingLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            loadingLabel.topAnchor.constraint(equalTo: animationView!.bottomAnchor, constant: 30),
            loadingLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            loadingLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20)
        ])
    }
}
