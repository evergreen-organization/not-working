//
//  OvalOverlayView.m
//  
//
//  Created by Jovial  on 5/8/2019.
//  Copyright © 2019 Xenchain. All rights reserved.
//

#import "OvalOverlayView.h"

@implementation OvalOverlayView

- (id)initWithFrame:(CGRect)frame overlayColor:(UIColor *)overlayColor ovalFrame:(CGRect)ovalFrame ovalBorderWidth:(CGFloat)ovalBorderWidth ovalBorderColor:(UIColor *)ovalBorderColor {
    self = [super initWithFrame:frame];
    if (self) {
        self.overlayColor = overlayColor;
        self.ovalFrame = ovalFrame;
        self.ovalBorderWidth = ovalBorderWidth;
        self.ovalBorderColor = ovalBorderColor;
        self.opaque = NO;
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    [self.overlayColor setFill];
    UIRectFill(rect);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGRect holeRectIntersection = CGRectIntersection(self.ovalFrame, rect);
    if(CGRectIntersectsRect(holeRectIntersection, rect)) {
        CGContextAddEllipseInRect(context, holeRectIntersection);
        CGContextClip(context);
        CGContextClearRect(context, holeRectIntersection);
        CGContextSetFillColorWithColor(context, [UIColor clearColor].CGColor);
        CGContextFillRect(context, holeRectIntersection);
        
        CGContextSetLineWidth(context, self.ovalBorderWidth);
        CGContextSetStrokeColorWithColor(context, self.ovalBorderColor.CGColor);
        CGContextStrokeEllipseInRect(context, self.ovalFrame);
    }
}

@end
