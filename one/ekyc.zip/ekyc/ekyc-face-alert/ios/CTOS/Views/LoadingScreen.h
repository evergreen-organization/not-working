//
//  LoadingScreen.h
//  demo
//
//  Created by Jovial  on 25/3/2020.
//  Copyright © 2020 Xenchain. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoadingScreen : UIView

@property (weak, nonatomic) IBOutlet UIView *rootView;
@property (weak, nonatomic) IBOutlet UIImageView *loadingImage;
@property (weak, nonatomic) IBOutlet UILabel *loadingText;

@property (strong, nonatomic) CABasicAnimation *rotationAnimation;

@end

NS_ASSUME_NONNULL_END
