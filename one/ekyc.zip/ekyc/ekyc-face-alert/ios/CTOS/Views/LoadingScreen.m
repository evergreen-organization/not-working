//
//  LoadingScreen.m
//  demo
//
//  Created by Jovial  on 25/3/2020.
//  Copyright © 2020 Xenchain. All rights reserved.
//

#import "LoadingScreen.h"

#import <QuartzCore/QuartzCore.h>

@implementation LoadingScreen

UIView *loadingScreenView;

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self xibSetup];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [self xibSetup];
    }
    return self;
}

-(void) xibSetup {
    
    if (![self.subviews containsObject:loadingScreenView]){
        NSBundle *bundle = [NSBundle bundleForClass:[self class]];
        loadingScreenView = [self loadViewFromNib:bundle];
        loadingScreenView.frame = [self bounds];
        [self addSubview:loadingScreenView];
        
        [self.rootView.layer setCornerRadius:10.0];
        [self.rootView.layer setBorderWidth:10.0];
        [self.rootView.layer setBorderColor:UIColor.whiteColor.CGColor];
        [self.rootView.layer setMasksToBounds:true];
        
        self.rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
        self.rotationAnimation.fromValue = [NSNumber numberWithFloat:0];
        self.rotationAnimation.toValue = [NSNumber numberWithFloat:M_PI*2];
        self.rotationAnimation.duration = 1.0;
        self.rotationAnimation.repeatCount = HUGE_VALF;
        [self.rotationAnimation setRemovedOnCompletion:false];
        [self.loadingImage.layer addAnimation:self.rotationAnimation forKey:@"rotationAnimation"];
    }
    
   
}

-(UIView *) loadViewFromNib:(NSBundle *)bundle {
    UINib *nib = [UINib nibWithNibName:@"LoadingScreen" bundle:bundle];
    UIView *view = (UIView *)([nib instantiateWithOwner:self options:nil][0]);
    return view;
}

- (void)removeFromSuperview {
    [loadingScreenView removeFromSuperview];
    [super removeFromSuperview];
}

@end
