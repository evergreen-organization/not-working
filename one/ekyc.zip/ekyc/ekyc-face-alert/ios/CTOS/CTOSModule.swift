//
//  Xendity.swift
//  pbOne
//
//  Created by administrator on 24/08/2021.
//

import Foundation
import React

@objc (CTOSModule)
class CTOSModule : RCTEventEmitter {
  
  public static var emitter: RCTEventEmitter!
  
  override init() {
    super.init()
    CTOSModule.emitter = self
  }

  override func supportedEvents() -> [String]! {
    return ["ctosResponse", "ctosScanResults", "ctosSimilarResults", "ctosLandmarkInformation", "ctosFaceMatchResult", "ctosReference", "ctosKBAQuestion", "ctosKBAResult", "ctosExitNative","ctosEmitter"]
  }
  
  @objc
  override static func requiresMainQueueSetup() -> Bool {
    return false
  }
  
  @objc
  func navigateToCTOS (_ key: String, url: String, type: Int, name: String, idNo: String, onBoardingID: String, referenceID: String, rawOCRResults: [AnyHashable: Any], referenceNo: String, kbaAnswer: [[AnyHashable: Any]], requiredFeature: Int, channel: Int, labelDict: NSDictionary) -> Void {
    print("navigateTOCTOS: \(name) \(idNo)");
    let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
    let ctosMain = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
    
    ctosMain.apiKey = key
    ctosMain.apiURL = url
    ctosMain.type = OCRType(rawValue: Int32(type))
    ctosMain.fullName = name
    ctosMain.idNo = idNo
    ctosMain.onBoardingID = onBoardingID
    ctosMain.referenceID = referenceID
    ctosMain.rawOCRResults = rawOCRResults
    ctosMain.referenceNo = referenceNo
    ctosMain.kbaAnswer = kbaAnswer
    ctosMain.requiredFeature = requiredFeature
    ctosMain.channel = channel
    
    if let labelDict = labelDict as? [String: Any] {
      CTOSDataHolder.shared.labelDictionary = labelDict
     }

    DispatchQueue.main.async {
      (UIApplication.shared.delegate as? AppDelegate)?.window.rootViewController?.present(ctosMain, animated: false, completion: nil);
    }
  }
}
