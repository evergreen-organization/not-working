/*
 This is the React Native Bridge Module to
 */

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
#import <React/RCTViewManager.h>

@interface RCT_EXTERN_MODULE(CTOSModule, RCTEventEmitter)

RCT_EXTERN_METHOD(navigateToCTOS :
                  (NSString *)key
                  url: (NSString *)url
                  type: (NSInteger *)type
                  name: (NSString *)name
                  idNo: (NSString *)idNo
                  onBoardingID: (NSString *)onBoardingID
                  referenceID: (NSString *)referenceID
                  rawOCRResults: (NSDictionary *)rawOCRResults
                  referenceNo: (NSString *)referenceNo
                  kbaAnswer: (NSArray *)kbaAnswer
                  requiredFeature: (NSInteger *) requiredFeature
                  channel: (NSInteger *)channel
                  labelDict: (NSDictionary *) labelDict)
@end
