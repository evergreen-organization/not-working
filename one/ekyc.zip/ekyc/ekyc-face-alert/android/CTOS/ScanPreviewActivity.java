package com.pbb.mypb.CTOS;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.react.ReactActivity;
import com.pbb.mypb.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;

public class ScanPreviewActivity extends ReactActivity implements View.OnClickListener {

  private ImageView frontIcView;
  private ImageView backIcView;
  private TextView fullName;
  private TextView icNumber;
  private TextView address;

  String nameString;
  String icString;
  String addressString;

  private JSONObject labelDictJSON;

  private TextView titlePreview;
  private TextView textFullName;
  private TextView textMyKad;
  private TextView textResidentialAdd;
  private TextView titleAlert;
  private TextView textAlertDesc;
  private Button textRescan;
  private Button textSubmit;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (getIntent() != null) {
      nameString = getIntent().getStringExtra("fullName");
      icString = getIntent().getStringExtra("icNumber");
      addressString = getIntent().getStringExtra("address");
    }

    LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View v = vi.inflate(R.layout.activity_scan_preview, null);

    frontIcView = v.findViewById(R.id.preview_ic_front);
    Bitmap frontIcImage = null;
    try {
      frontIcImage = BitmapFactory.decodeStream(this.openFileInput("frontIcImage"));
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    frontIcView.setImageBitmap(frontIcImage);

    backIcView = v.findViewById(R.id.preview_ic_back);
    Bitmap backIcImage = null;
    try {
      backIcImage = BitmapFactory.decodeStream(this.openFileInput("backIcImage"));
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    backIcView.setImageBitmap(backIcImage);

    fullName = v.findViewById(R.id.preview_full_name);
    fullName.setText(nameString);
    icNumber = v.findViewById(R.id.preview_ic_number);
    icNumber.setText(icString);
    address = v.findViewById(R.id.preview_address);
    address.setText(addressString);

    titlePreview = v.findViewById(R.id.textView);
    textFullName = v.findViewById(R.id.textView2);
    textMyKad = v.findViewById(R.id.textView7);
    textResidentialAdd = v.findViewById(R.id.textView4);
    titleAlert = v.findViewById(R.id.textView5);
    textAlertDesc = v.findViewById(R.id.textView6);
    textRescan = v.findViewById(R.id.preview_retry_button);
    textSubmit = v.findViewById(R.id.preview_submit_button);

    v.findViewById(R.id.preview_retry_button).setOnClickListener(this);
    v.findViewById(R.id.preview_submit_button).setOnClickListener(this);
    setContentView(v);


    // Load label dictionary
    String labelDict = CTOSDataHolder.getInstance().getLabelDictionary();
    try {
      JSONObject outerObject = new JSONObject(labelDict);  // your full JSON string
      labelDictJSON = outerObject.getJSONObject("previewICScreen");
    } catch (JSONException e) {
      //
    }

    if (labelDictJSON != null) {
      try {
        titlePreview.setText(labelDictJSON.getString("title"));
        textFullName.setText(labelDictJSON.getString("labelFullName"));
        textMyKad.setText(labelDictJSON.getString("labelMyKadNo"));
        textResidentialAdd.setText(labelDictJSON.getString("labelResidentialAdd"));
        titleAlert.setText(labelDictJSON.getString("alertTitle"));
        textAlertDesc.setText(labelDictJSON.getString("alertDescription"));
        textRescan.setText(labelDictJSON.getString("labelRescan"));
        textSubmit.setText(labelDictJSON.getString("labelSubmit"));

      } catch (JSONException e) {
        setDefaultValue();
      }
    }

  }

  private void setDefaultValue() {
    titlePreview.setText("Review your details");
    textFullName.setText("Full Name");
    textMyKad.setText("MyKad Number");
    textResidentialAdd.setText("Residential Address");
    titleAlert.setText("Alert!");
    textAlertDesc.setText("Please ensure the details are accurate (same as MyKad) to avoid rejection.");
    textRescan.setText("Rescan");
    textSubmit.setText("Submit");
  }

  @Override
  public void onClick(View v) {
    int id = v.getId();

    if (id == R.id.preview_retry_button) {
      CTOSUtil.setSelection("retry");
      finish();
    } else if (id == R.id.preview_submit_button) {
      CTOSUtil.setSelection("submit");
      finish();
    }
  }

  @Override
  public void onBackPressed() {
    Intent intent = new Intent(this, ExitEmitterActivity.class);
    startActivity(intent);
    finish();
  }
}
