package com.pbb.mypb.CTOS;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.pbb.mypb.R;
import com.xendity.reader.Activity.XCameraV2Activity;

import org.json.JSONException;
import org.json.JSONObject;

public class CameraActivity extends XCameraV2Activity implements View.OnClickListener {

  private static final String TAG = "CTOSCamera";

  private OCRPreview mDialogPreview;

  private JSONObject labelDictJSON;

  private TextView mTextInstruction;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View v = vi.inflate(R.layout.activity_camera, null);
    mTextInstruction = v.findViewById(R.id.camera_text_instruction);

    v.findViewById(R.id.camera_back_button).setOnClickListener(this);
    v.findViewById(R.id.camera_start_capture).setOnClickListener(this);
    setupCustomScanner(v);

    mDialogPreview = new OCRPreview(this, this);

    String labelDict = CTOSDataHolder.getInstance().getLabelDictionary();
    try {
      JSONObject outerObject = new JSONObject(labelDict);
      labelDictJSON = outerObject.getJSONObject("cameraScreen");
    } catch (JSONException e) {
      e.printStackTrace();
    }

  }

  @Override
  protected void prepareForFrontCapture() {
    Log.d(TAG, "prepareForFrontCapture: ");
    if (labelDictJSON != null) {
        try {
        mTextInstruction.setText(labelDictJSON.getString("labelFrontMyKad"));
      } catch (JSONException e) {
        mTextInstruction.setText("Front of MyKad");
      }
    }

  }

  @Override
  protected void captureFrameInProgress() {
    if (labelDictJSON != null) {
        try {
        mTextInstruction.setText(labelDictJSON.getString("captureImage"));
      } catch (JSONException e) {
        mTextInstruction.setText("Capturing images. Please Hold on.");
      }
    }    
  }

  @Override
  protected void askForMoreFrame() {
    if (labelDictJSON != null) {
        try {
        mTextInstruction.setText(labelDictJSON.getString("captureFailure"));
      } catch (JSONException e) {
        mTextInstruction.setText("Capture error. Press the button below to capture Front IC again.");
      }
    }
  }

  @Override
  protected void completeFrontCapture(Bitmap frontBitmap) {
    Log.d(TAG, "completeFrontCapture: ");
  }

  @Override
  protected void prepareForBackCapture() {
    Log.d(TAG, "prepareForBackCapture: ");
    if (labelDictJSON != null) {
        try {
        mTextInstruction.setText(labelDictJSON.getString("labelBackMyKad"));
      } catch (JSONException e) {
        mTextInstruction.setText("Back of MyKad");
      }
    }
  }

  @Override
  protected void completeBackCapture(Bitmap backBitmap) {
    Log.d(TAG, "completeBackCapture: ");
    CTOSUtil.setHasStarted(false);
  }

  @Override
  protected void processImageFailure(String errorMessage) {
    Log.d(TAG, "processImageFailure: " + errorMessage);
    String message = "";

    if (labelDictJSON != null) {
        try {
            message = labelDictJSON.getString("authenticateFailure");
        } catch (JSONException e) {
          e.printStackTrace();
          message = "We are unable to authenticate your ID image. Please try again.";
        }
    }

    Toast.makeText(CameraActivity.this, message, Toast.LENGTH_LONG).show();
}


  @Override
  public void onClick(View v) {
    int id = v.getId();

    if (id == R.id.camera_back_button) {
      onClose();
    } else if (id == R.id.camera_start_capture) {
      CTOSUtil.setHasStarted(true);
      capturePicture();
    }
  }

  @Override
  public void onBackPressed() {
    onClose();
  }

  public void onClose() {
    Log.d(TAG, "onClose: Back to React Native");
    Intent intent = new Intent(this, ExitEmitterActivity.class);
    boolean storeReuseKey = !CTOSUtil.getHasStarted();
    intent.putExtra("storeReuseKey", storeReuseKey);
    
    CTOSUtil.setHasStarted(false);
    startActivity(intent);
    finish();
  }
}
