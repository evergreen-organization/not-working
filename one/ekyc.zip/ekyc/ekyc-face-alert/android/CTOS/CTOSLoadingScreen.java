package com.pbb.mypb.CTOS;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.util.Log;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.pbb.mypb.R;
import com.xendity.reader.Dialog.XCustomDialog;

import org.json.JSONException;
import org.json.JSONObject;

public class CTOSLoadingScreen extends XCustomDialog {

  private Dialog mLoadingDialog;
  private JSONObject labelDictJSON;


  private Dialog createDialog(Context mContext) {
    mLoadingDialog = new Dialog(mContext, android.R.style.Theme_Light);
    mLoadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
    mLoadingDialog.setCancelable(false);
    mLoadingDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    // if (mLoadingDialog.getWindow() != null)
    // mLoadingDialog.getWindow().setBackgroundDrawable(new
    // ColorDrawable(Color.WHITE));

    LinearLayout.LayoutParams outerLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT);

    LinearLayout outerLayout = new LinearLayout(mContext);
    outerLayout.setLayoutParams(outerLayoutParams);
    outerLayout.setBackgroundColor(Color.WHITE);

    LinearLayout.LayoutParams innerLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT);

    LinearLayout innerLayout = new LinearLayout(mContext);
    innerLayout.setOrientation(LinearLayout.VERTICAL);
    innerLayout.setLayoutParams(innerLayoutParams);
    innerLayout.setGravity(Gravity.CENTER);
    innerLayout.setBackgroundColor(Color.WHITE);
    outerLayout.addView(innerLayout);

    LinearLayout.LayoutParams animationLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT);

    LottieAnimationView loadingAnimationView = new LottieAnimationView(mContext);
    animationLayoutParams.height = 500;
    animationLayoutParams.width = 500;
    loadingAnimationView.setLayoutParams(animationLayoutParams);
    loadingAnimationView.setAnimation(R.raw.kyc);
    loadingAnimationView.setRepeatCount(LottieDrawable.INFINITE);
    loadingAnimationView.playAnimation();
    innerLayout.addView(loadingAnimationView);

    LinearLayout.LayoutParams textLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT);

    TextView loadingTextView = new TextView(mContext);
    loadingTextView.setLayoutParams(textLayoutParams);
    loadingTextView.setBackgroundColor(Color.TRANSPARENT);
//    loadingTextView.setText(mContext.getResources().getIdentifier("loading_text", "string", mContext.getPackageName()));
    loadingTextView.setTextColor(Color.BLACK);
    loadingTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
    loadingTextView.setTypeface(ResourcesCompat.getFont(mContext, R.font.nunito_bold));

    String labelDict = CTOSDataHolder.getInstance().getLabelDictionary();
    try {
      JSONObject outerObject = new JSONObject(labelDict);
      labelDictJSON = outerObject.getJSONObject("previewICScreen");
    } catch (JSONException e) {
      //
    }
    if (labelDictJSON != null) {
      try {
        loadingTextView.setText(labelDictJSON.getString("labelLoading"));
      } catch (JSONException e) {
    loadingTextView.setText(mContext.getResources().getIdentifier("loading_text", "string", mContext.getPackageName()));
      }
    }

    innerLayout.addView(loadingTextView);

    mLoadingDialog.setContentView(outerLayout);
    return mLoadingDialog;
  }

  @Override
  public void showDialog(Activity activity) {
    try {
      if (mLoadingDialog != null && mLoadingDialog.isShowing())
        dismissDialog();

      mLoadingDialog = createDialog(activity);

      if (!activity.isFinishing())
        mLoadingDialog.show();
    } catch (Exception ex) {
      ex.printStackTrace();
      mLoadingDialog.dismiss();
      mLoadingDialog = null;
    }
  }

  @Override
  public void dismissDialog() {
    try {
      if (mLoadingDialog != null) {
        mLoadingDialog.dismiss();
        mLoadingDialog = null;
      }
    } catch (Exception ex) {
      ex.printStackTrace();
      mLoadingDialog = null;
    }
  }
}
