package com.pbb.mypb.CTOS;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import com.pbb.mypb.MainActivity;
import com.pbb.mypb.R;
import com.xendity.reader.Activity.XFaceRecordActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class FaceRecordActivity extends XFaceRecordActivity implements View.OnClickListener {

  private static final String TAG = "CTOSFaceActivity";

  private TextView faceInstructionText;
  private TextView faceInstructionText2;
  private TextView faceMatchText;

  private JSONObject labelDictJSON;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    Log.d(TAG, "onCreate");
    super.onCreate(savedInstanceState);

    LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View v = vi.inflate(R.layout.activity_face_record, null);
    faceInstructionText = v.findViewById(R.id.face_record_instruction_text3);
    faceInstructionText2 = v.findViewById(R.id.face_record_instruction_text2);
    faceMatchText = v.findViewById(R.id.face_record_instruction_text);

    v.findViewById(R.id.video_back_button).setOnClickListener(this);
    v.findViewById(R.id.video_start_capture).setOnClickListener(this);

    setupCustomScanner(v);

    String labelDict = CTOSDataHolder.getInstance().getLabelDictionary();
    try {
      JSONObject outerObject = new JSONObject(labelDict);
      labelDictJSON = outerObject.getJSONObject("faceScanScreen");
    } catch (JSONException e) {
      //
    }
    if (labelDictJSON != null) {
      try {
        faceInstructionText2.setText(labelDictJSON.getString("labelInstruction"));
        faceMatchText.setText(labelDictJSON.getString("labelFaceMatch"));
      } catch (JSONException e) {
        setDefaultValue();
      }
    }

    Handler handler = new Handler(Looper.getMainLooper());
    handler.post(new Runnable() {
      @Override
      public void run() {
        displayPopUp();
      }
    });
  }

  private void setDefaultValue() {
    faceInstructionText2.setText("Keep your face within the oval");
    faceMatchText.setText("Face Match");
  }

  private void displayPopUp(){
    FaceScanWaringDialog warningDialog = new FaceScanWaringDialog();
    warningDialog.setOnClickProceedListener(()->{
      if(warningDialog != null){
        warningDialog.dismissAllowingStateLoss();
      }
    });
    FragmentManager fragmentManager= getSupportFragmentManager();
    if(fragmentManager.findFragmentByTag("WARNING_DIALOG")==null){
      warningDialog.setStyle(DialogFragment.STYLE_NORMAL, R.style.MaterialDialog);
      fragmentManager.beginTransaction().add(warningDialog, "WARNING_DIALOG").commitNowAllowingStateLoss();

    }
  }

  @Override
  public void onBackPressed() {
    super.onBackPressed();
    Intent intent = new Intent(this, ExitEmitterActivity.class);
    startActivity(intent);
    finish();
  }

  @Override
  public void onClick(View v) {
    int id = v.getId();

    if (id == R.id.video_back_button) {
      onClose();
    } else if (id == R.id.video_start_capture) {
      startTimer();
      startVideoRecord();
    }
  }

  @Override
  protected void preBlinkDetection() {

  }

  @Override
  protected void blinkDetected() {

  }

  @Override
  protected void smileDetected() {

  }

  @Override
  protected void startRecording() {
    Log.d(TAG, "startRecording: ");
  }

  @Override
  protected void processingRecording() {
    Log.d(TAG, "processingRecording: ");
  }

  @Override
  protected void completingProcess() {
    Log.d(TAG, "completingProcess: ");
  }

  public void onClose() {
    Log.d(TAG, "onClose: Back to React Native");
    Intent intent = new Intent(this, ExitEmitterActivity.class);
    startActivity(intent);
    finish();
  }

  CountDownTimer cTimer = null;

  void startTimer() {
    faceInstructionText.setTextColor(Color.RED);
    faceInstructionText.setText("0:03");
    cTimer = new CountDownTimer(3000, 1000) {
      public void onTick(long millisUntilFinished) {
        long sec = (millisUntilFinished / 1000) % 60;
        faceInstructionText.setText("0:0" + sec);
      }

      public void onFinish() {
        faceInstructionText.setText("0:00");
      }
    };
    cTimer.start();
  }

  void cancelTimer() {
    if (cTimer != null)
      cTimer.cancel();
  }
}
