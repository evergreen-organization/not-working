package com.pbb.mypb.CTOS;

import static com.pbb.mypb.util.ReactNativeJson.*;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Objects;

public class CTOSModule extends ReactContextBaseJavaModule {
    final String moduleName = "CTOSModule";

    CTOSModule(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return moduleName;
    }

    @ReactMethod
    void navigateToCTOS(String key, String url, int type, String name, String id, String onBoardingID, String referenceID, ReadableMap rawOCRResults, String referenceNo, ReadableArray kbaAnswer, int requiredFeature, int channel,  ReadableMap labelDict) throws JSONException {
        Activity activity = getCurrentActivity();
        String resultString = null;
        String lableDictString = null;

        if (!Objects.isNull(rawOCRResults))
            resultString = rawOCRResults.toString();

        if (!Objects.isNull(labelDict))
            lableDictString = labelDict.toString();

        if (activity != null) {
            Intent intent = new Intent(activity, CTOSMainActivity.class);
            intent.putExtra("apiKey", key);
            intent.putExtra("apiURL", url);
            intent.putExtra("scanningType", type);
            intent.putExtra("fullName", name);
            intent.putExtra("idNo", id);
            intent.putExtra("rawOCRResults", resultString);
            intent.putExtra("onBoardingID", onBoardingID);
            intent.putExtra("referenceID", referenceID);
            intent.putExtra("referenceNo", referenceNo);
            intent.putExtra("requiredFeature",requiredFeature );
            intent.putExtra("channel",channel );
            intent.putExtra("labelDict", lableDictString);


            try {
                intent.putExtra("kbaAnswer", convertArrayToJson(kbaAnswer).toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            activity.startActivity(intent);
        }
    }
}
