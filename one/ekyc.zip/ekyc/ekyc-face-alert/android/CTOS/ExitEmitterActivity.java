package com.pbb.mypb.CTOS;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;

import com.facebook.react.ReactActivity;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.pbb.mypb.MainActivity;

import java.util.Objects;


public class ExitEmitterActivity extends ReactActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WritableMap map = Arguments.createMap();
        if (getIntent() != null) {
            boolean storeReuseKey = getIntent().getBooleanExtra("storeReuseKey",false);
                WritableMap payload = Arguments.createMap();
                payload.putBoolean("storeReuseKey", storeReuseKey);
                map.putMap("payload", payload);
            }
        map.putString("function", "NoActionBack");
        sendEventToRNExit("ctosEmitter", map);
    }

    protected void sendEventToRNExit(String name, @Nullable WritableMap params) {
        Objects.requireNonNull(getReactInstanceManager().getCurrentReactContext()).getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(name, params);
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}