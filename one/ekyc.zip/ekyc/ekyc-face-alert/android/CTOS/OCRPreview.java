package com.pbb.mypb.CTOS;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;

import com.pbb.mypb.R;

public class OCRPreview {

  private Dialog mDialog;
  private ImageView mPreImageView;

  public OCRPreview(Context context, View.OnClickListener onClickListener) {
    mDialog = initComponent(context, onClickListener);
  }

  private Dialog initComponent(Context context, View.OnClickListener onClickListener) {
    Dialog dialog = new Dialog(context);
    dialog.setContentView(R.layout.dialog_ocr_preview);
    dialog.setCancelable(true);
    dialog.setCanceledOnTouchOutside(true);

    mPreImageView = dialog.findViewById(R.id.ocr_preview_image);
    dialog.findViewById(R.id.ocr_preview_retry_button).setOnClickListener(onClickListener);
    dialog.findViewById(R.id.ocr_preview_continue_button).setOnClickListener(onClickListener);

    return dialog;
  }

  public void setImageInput(Bitmap previewBitmap) {
    if (mPreImageView != null)
      mPreImageView.setImageBitmap(previewBitmap);
  }

  public void showDialog(final Activity inputActivity) {
    inputActivity.runOnUiThread(new Runnable() {
      @Override
      public void run() {
        try {
          if (!inputActivity.isFinishing() && mDialog != null && !mDialog.isShowing())
            mDialog.show();
        } catch (Exception ignore) {
        }
      }
    });
  }

  public void dismissDialog() {
    try {
      if (mDialog != null) {
        mDialog.dismiss();
      }
    } catch (Exception ignore) {
    }
  }
}
