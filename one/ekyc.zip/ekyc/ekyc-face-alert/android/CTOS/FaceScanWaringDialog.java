package com.pbb.mypb.CTOS;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;

import com.pbb.mypb.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

public class FaceScanWaringDialog extends DialogFragment {

    //Views
    private AppCompatButton proceedButton;
    private AppCompatTextView titleTextView;
    private AppCompatTextView description1TextView;
    private AppCompatTextView dialogNoteTextView;
    private AppCompatTextView dialogNote2TextView;

    //logic
    private JSONObject labelDictJSON;
    private OnClickProceedListener onClickProceedListener;

    public interface OnClickProceedListener {
        void onClickProceed();
    }

    public void setOnClickProceedListener(OnClickProceedListener onClickProceedListener) {
        this.onClickProceedListener = onClickProceedListener;
    }

    @Override
    public void onStart() {


        super.onStart();
        if (getDialog() != null && getDialog().getWindow() != null) {
            int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.85);
            getDialog().getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_face_scan_warning, container, false);
        if (getDialog() != null) {
            WindowManager.LayoutParams params = Objects.requireNonNull(getDialog().getWindow()).getAttributes();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            requireActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            getDialog().getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getDialog().getWindow().setStatusBarColor(ContextCompat.getColor(requireActivity(), R.color.colorTransparent));
            getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
            getDialog().getWindow().setAttributes(params);
            getDialog().setCancelable(true);
            getDialog().setCanceledOnTouchOutside(true);

            getDialog().getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        }

        proceedButton = view.findViewById(R.id.dialogDismissButton);
        titleTextView = view.findViewById(R.id.dialogTitle);
        description1TextView = view.findViewById(R.id.dialogDescription);
        dialogNoteTextView = view.findViewById(R.id.dialogNote);
        dialogNote2TextView = view.findViewById(R.id.dialogNote2);

        String labelDict = CTOSDataHolder.getInstance().getLabelDictionary();
        try {
            JSONObject outerObject = new JSONObject(labelDict);  // your full JSON string
            labelDictJSON = outerObject.getJSONObject("faceScanScreen");
        } catch (JSONException e) {
            //
        }

        if (labelDictJSON != null) {
            try {
                titleTextView.setText(labelDictJSON.getString("title"));
                description1TextView.setText(labelDictJSON.getString("description1"));
                dialogNoteTextView.setText(labelDictJSON.getString("description2"));
                dialogNote2TextView.setText(labelDictJSON.getString("description3"));
                proceedButton.setText(labelDictJSON.getString("button"));

            } catch (JSONException e) {
                setDefaultValue();
            }
        }

        proceedButton.setOnClickListener(v -> {
            if (onClickProceedListener != null) {
                onClickProceedListener.onClickProceed();
            }
        });

        return view;
    }

    private void setDefaultValue() {
        titleTextView.setText("Take a Selfie");
        description1TextView.setText("Please make sure your face is not covered by any object i.e. mask, cap etc.");
        dialogNoteTextView.setText("Note:");
        dialogNote2TextView.setText("Your photo may be subject to audit and review by the Bank. For your privacy, kindly ensure appropriate attire during the scan.");
        proceedButton.setText("Proceed");
    }
}
