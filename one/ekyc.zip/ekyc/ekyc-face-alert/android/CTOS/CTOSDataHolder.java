package com.pbb.mypb.CTOS;

import com.google.android.gms.common.data.DataHolder;

public class CTOSDataHolder {

    private static final CTOSDataHolder instance = new CTOSDataHolder();
    private String labelDictionary;

    public static CTOSDataHolder getInstance() {
        return instance;
    }

    public String getLabelDictionary() {
        return labelDictionary;
    }

    public void setLabelDictionary(String labelDictionary) {
        this.labelDictionary = labelDictionary;
    }
}
