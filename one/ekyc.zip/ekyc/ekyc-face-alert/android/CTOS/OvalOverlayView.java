package com.pbb.mypb.CTOS;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

import com.pbb.mypb.R;

public class OvalOverlayView extends View {
    private float mLeftMargin;
    private float mRightMargin;
    private float mTopMargin;
    private float mBottomMargin;

    private float mBorderSize;
    private int mBorderColor;

    private Bitmap mBitmap;

    public OvalOverlayView(Context context) {
        super(context);
    }

    public OvalOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray attributes = context.obtainStyledAttributes(attrs, R.styleable.OvalOverlayView);
        mLeftMargin = attributes.getDimension(R.styleable.OvalOverlayView_Left_Margin, 25);
        mRightMargin = attributes.getDimension(R.styleable.OvalOverlayView_Right_Margin, 25);
        mTopMargin = attributes.getDimension(R.styleable.OvalOverlayView_Top_Margin, 25);
        mBottomMargin = attributes.getDimension(R.styleable.OvalOverlayView_Bottom_Margin, 25);

        mBorderSize = attributes.getDimension(R.styleable.OvalOverlayView_Border_Size, 5);
        mBorderColor = attributes.getColor(R.styleable.OvalOverlayView_Border_Color, Color.BLACK);
        attributes.recycle();
    }

    public OvalOverlayView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public OvalOverlayView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);

        if (mBitmap == null) {
            createWindowFrame();
        }
        canvas.drawBitmap(mBitmap, 0, 0, null);
    }

    protected void createWindowFrame() {
        mBitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
        Canvas osCanvas = new Canvas(mBitmap);

        RectF outerRectangle = new RectF(0, 0, getWidth(), getHeight());

        Paint outerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        outerPaint.setColor(Color.TRANSPARENT);
        osCanvas.drawRect(outerRectangle, outerPaint);

        Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setColor(mBorderColor);
        borderPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
        RectF borderOvalRect = new RectF(mLeftMargin - mBorderSize, mTopMargin - mBorderSize, getWidth() - mRightMargin + mBorderSize, getHeight() - mBottomMargin + mBorderSize);
        osCanvas.drawOval(borderOvalRect, borderPaint);

        Paint innerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        innerPaint.setColor(Color.TRANSPARENT);
        innerPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
        RectF innerOvalRect = new RectF(mLeftMargin, mTopMargin, getWidth() - mRightMargin, getHeight() - mBottomMargin);
        osCanvas.drawOval(innerOvalRect, innerPaint);
    }

    @Override
    public boolean isInEditMode() {
        return true;
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        mBitmap = null;
    }
}
