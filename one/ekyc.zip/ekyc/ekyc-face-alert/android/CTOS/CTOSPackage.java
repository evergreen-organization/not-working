package com.pbb.mypb.CTOS;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;

import java.util.ArrayList;
import java.util.List;

public class CTOSPackage implements ReactPackage {

  @Override
  public List<ViewManager> createViewManagers(ReactApplicationContext reactContext) {
    List<ViewManager> modules = new ArrayList<>();
// Add native UI components here
//    modules.add(new MyReactNativeModule(reactContext));
    return modules;
  }

  @Override
  public List<NativeModule> createNativeModules(ReactApplicationContext reactContext) {
    List<NativeModule> modules = new ArrayList<>();
// Add native modules here
//    modules.add(new MyReactNativeModule(reactContext));
    modules.add(new CTOSModule(reactContext));
    return modules;
  }
}
