package com.pbb.mypb.CTOS;

import static com.pbb.mypb.util.ReactNativeJson.convertJsonToArray;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.facebook.react.ReactActivity;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.xendity.reader.Callback.XendityFaceCallback;
import com.xendity.reader.Callback.XendityKBACallback;
import com.xendity.reader.Callback.XendityPreDeployCallback;
import com.xendity.reader.Callback.XenditySDKCallback;
import com.xendity.reader.Callback.XendityScannerCallback;
import com.xendity.reader.Dialog.XLoadingDialog;
import com.xendity.reader.Model.AnswerKBA;
import com.xendity.reader.Model.Enum.CheckIDVersion;
import com.xendity.reader.Model.Enum.ErrorCode;
import com.xendity.reader.Model.Enum.OCRType;
import com.xendity.reader.XenditySDK;
import com.xendity.reader.Callback.XendityMultifaceCallback;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;

public class CTOSMainActivity extends ReactActivity implements XenditySDKCallback, XendityScannerCallback, XendityFaceCallback, XendityKBACallback, XendityPreDeployCallback, XendityMultifaceCallback {
    HashMap<String, String> TOAST_ERROR_CODE = new HashMap<String, String>();
    HashMap<String, String> SDK_ERROR_CODE = new HashMap<String, String>();


    public static final String TAG = "CTOSMainActivity";

    public static final int PERMISSION_REQUEST_ID = 100;

    public static final int SCAN_IC = 1;
    public static final int SCAN_FACE = 2;
    public static final int ID_VERIFICATION = 3;
    public static final int KBA = 4;
    public static final int CHANNEL_TYPE_EIV = 2;

    private JSONObject mOCRCardResults = null;
    private JSONObject mMetaCardResults = null;
    private JSONObject inputObject = new JSONObject();

    private boolean initialized = false;

    private String mFaceImageRef = "";
    private String fullName;
    private String idNo;
    private String apiKey;
    private String apiURL;
    private int scanningType;
    private String mReferenceID;
    private String mOnBoardingID;
    private String rawOCRResults;
    private String referenceNo;
    private String kbaAnswer;
    private int channel;

    private boolean passLandmark;
    private boolean mNameIsSimilar;
    private boolean mDocumentNoIsSimilar;
    private boolean mFrontBackIsSimilar;
    private WritableMap mOCResult;
    private boolean faceMatch;

    private int requiredFeature;
    private boolean timerOn = true;

    private ArrayList<Integer> stageList;

    public String labelDict;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        initErrorDict();
        super.onCreate(savedInstanceState);
        if (getIntent() != null) {
            apiKey = getIntent().getStringExtra("apiKey");
            apiURL = getIntent().getStringExtra("apiURL");
            scanningType = getIntent().getIntExtra("scanningType", OCRType.ID_MYS_MYKAD_FRONT_BACK_LANDMARK);
            fullName = getIntent().getStringExtra("fullName");
            idNo = getIntent().getStringExtra("idNo");
            mOnBoardingID = getIntent().getStringExtra("onBoardingID");
            mReferenceID = getIntent().getStringExtra("referenceID");
            rawOCRResults = getIntent().getStringExtra("rawOCRResults");
            referenceNo = getIntent().getStringExtra("referenceNo");
            kbaAnswer = getIntent().getStringExtra("kbaAnswer");
            channel = getIntent().getIntExtra("channel", 1);
            requiredFeature = getIntent().getIntExtra("requiredFeature", 0);
            stageList = CTOSUtil.convertIntToArray(requiredFeature);
            labelDict = getIntent().getStringExtra("labelDict");
            CTOSDataHolder.getInstance().setLabelDictionary(labelDict);
        }
        Log.d(TAG, "fullName: " + fullName);
        Log.d(TAG, "XenditySDK Version: " + XenditySDK.getSDKVersion());
        XenditySDK.SDKLoadingDialog = new CTOSLoadingScreen();

    }

    @Override
    protected void onStart() {
        super.onStart();
        initializeSDK();
    }


    @Override
    protected void onResume() {
        super.onResume();

        if (mOCRCardResults != null) {
            if (CTOSUtil.getSelection().equalsIgnoreCase("submit")) {
                if (channel == CHANNEL_TYPE_EIV) {
                    callBackRN("onIcSubmit");
                }
                scanComplete();
            } else {
                startCTOSProcess();
            }
        } else {
            initializeSDK();
        }
    }

    public void startTimeOutTimer(String funcName, String code) {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (timerOn) {
                    exitNative(funcName, null, code);
                    Toast.makeText(CTOSMainActivity.this, "Timeout. Please exit and try again.", Toast.LENGTH_LONG).show();
                }
            }
        }, 120000);
    }

    // method to emit event to ReactNative
    protected void sendEventToRN(String name, @Nullable WritableMap params) {
        Objects.requireNonNull(getReactInstanceManager().getCurrentReactContext()).getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(name, params);
    }

    public void initializeSDK() {
        if ((!stageList.contains(KBA)) || (stageList.contains(KBA) && !kbaAnswer.equals("[]"))) {
            XLoadingDialog.showDialog(this);
        }
        if (!initialized) {
            initialized = true;
            try {
                XenditySDK.initSDK(apiKey, apiURL, this, this);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void startCTOSProcess() {
        if (mOnBoardingID.isEmpty()) {
            onNewScan();
        } else {
            onExistingScan();
        }
    }

    public void runCTOSFeatures() {
        if (stageList.contains(SCAN_IC)) {
            deployICScanner();
        } else if (stageList.contains(SCAN_FACE)) {
            if (mOnBoardingID.isEmpty()) {
                showErrorMessage("Information is missing");
                exitNative("runCTOSFeatures", null, "EK0000");
                return;
            }
            deployFaceCamera();
        } else if (stageList.contains(ID_VERIFICATION)) {
            if (mOnBoardingID.isEmpty()) {
                showErrorMessage("Information is missing");
                exitNative("runCTOSFeatures", null, "EK0000");
                return;
            }
            requestIdVerification();
        } else if (stageList.contains(KBA)) {
            if (mOnBoardingID.isEmpty() || referenceNo.isEmpty()) {
                showErrorMessage("Information is missing");
                exitNative("runCTOSFeatures", null, "EK0000");
                return;
            }
            if (kbaAnswer.equals("[]")) {
                requestKBA();
            } else {
                answerKBAQuestion();
            }
        } else {
            exitNative("Completed", null, "S");
        }
    }

    public void deployICScanner() {
        try {
            XenditySDK.deployScannerV2(scanningType, CTOSMainActivity.this, CameraActivity.class, this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // callback =>
        // scanSimilarityResults
        // scanMetaDocFrontResults
        // scanMetaDocBackResults
        // scanMetaDocFaceResults
        // scanResults
        // After this will navigate to preview screen, so will resume at onResume
    }

    public void deployFaceCamera() {
        try {
            XenditySDK.deployFaceRecord(mOnBoardingID, this, FaceRecordActivity.class, this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // callback => faceMatchResult
        // After this will navigate to FaceRecord Screen, so will resume at onResume
    }

    public void requestIdVerification() {
        try {
            startTimeOutTimer("requestIdVerification", "EK0055");

            XenditySDK.IDVerificationForOnBoarding(mOnBoardingID, CTOSMainActivity.this, CTOSMainActivity.this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // callback => IDVerificationStatus
        // After this will requestKBA
    }

    public void requestKBA() {
        try {
            startTimeOutTimer("requestKBA", "EK0056");
            XenditySDK.RequestKBAForOnBoarding(mOnBoardingID, referenceNo, CTOSMainActivity.this, this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // callback => KBARequestStatus
        // After this will navigate to React Native screen, so will resume at onResume
    }

    public void setupSDK() {
        XenditySDK.setPreviewOCR(false);
        XenditySDK.setCheckIDFaceCompare(true);
        XenditySDK.setIDVersionChecks(CheckIDVersion.REJECT_MODE);
        XenditySDK.setMaterialCheckDetection(true);
        XenditySDK.setLabelCheckDetection(true);
        XenditySDK.setIsMultiFrameDetection(false);
        XenditySDK.setRemarks(channel);

    }

    public void onNewScan() {
        Log.d(TAG, "onNewScan");
        XLoadingDialog.showDialog(this);
        try {
            if (channel == CHANNEL_TYPE_EIV) {
                setupSDK();
                runCTOSFeatures();
            } else {
                inputObject.put("fullName", fullName);
                inputObject.put("documentNumber", idNo);
                XenditySDK.setPreDeployment("", inputObject, scanningType, CTOSMainActivity.this, this);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        // callback => completePreDeployment - to get onBoardingID and referenceID
    }


    public void onExistingScan() {
        Log.d(TAG, "onExistingScan");
        XenditySDK.setReferenceID(mReferenceID);
        XenditySDK.setOnBoardingID(mOnBoardingID);
        setupSDK();
        runCTOSFeatures();
    }

    public void answerKBAQuestion() {
        Log.d(TAG, "answerKBAQuestion");
        try {
            JSONArray array = new JSONArray(kbaAnswer);
            JSONObject jsonObject = null;
            String questionId = null;
            boolean answer;
            AnswerKBA[] answerArray = new AnswerKBA[array.length()];
            for (int i = 0; i < array.length(); i++) {
                jsonObject = array.getJSONObject(i);
                questionId = jsonObject.get("id").toString();
                answer = (boolean) jsonObject.get("answer");

                AnswerKBA answerKBA = new AnswerKBA();
                answerKBA.setQuestionID(questionId);
                answerKBA.setAnswer(answer);

                answerArray[i] = answerKBA;
            }
            XenditySDK.VerifyKBAForOnBoarding(mOnBoardingID, referenceNo, answerArray, CTOSMainActivity.this, this);
            // callback => KBAVerificationStatus
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showPreview() {
        try {
            JSONObject frontIc = mOCRCardResults.getJSONObject("FrontResult");
            String fullName = frontIc.getString("fullName");
            String icNumber = frontIc.getString("documentNumber");
            String address = frontIc.getString("address");
            Bitmap frontIcImage = (Bitmap) mMetaCardResults.get("idFrontImage");
            createImageFromBitmap(frontIcImage, "frontIcImage");
            Bitmap backIcImage = (Bitmap) mMetaCardResults.get("idBackImage");
            createImageFromBitmap(backIcImage, "backIcImage");
            Intent intent = new Intent(CTOSMainActivity.this, ScanPreviewActivity.class);
            intent.putExtra("fullName", fullName);
            intent.putExtra("icNumber", icNumber);
            intent.putExtra("address", address);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void scanComplete() {
        try {
            XenditySDK.completeScanDeploymentV2(mOnBoardingID, mMetaCardResults, mOCRCardResults, scanningType, CTOSMainActivity.this, CTOSMainActivity.this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // callback => scanCompleteDeployment
    }


    @Override
    public void InitSDKStatus(boolean status, String message) {
        XLoadingDialog.dismissDialog();
        if (status) {
            startCTOSProcess();
        } else {
            initialized = false;
            showErrorMessage(message);
            WritableMap map = Arguments.createMap();
            map.putBoolean("initStatus", status);
            exitNative("InitSDKStatus", map, getErrorCode(message));
        }
    }


    @Override
    public void completePreDeployment(String referenceID, String onBoardingID, String error) {
        if (error.isEmpty()) {
            XLoadingDialog.dismissDialog();

            mReferenceID = referenceID;
            XenditySDK.setReferenceID(referenceID);

            mOnBoardingID = onBoardingID;
            XenditySDK.setOnBoardingID(onBoardingID);

            sendUserIdentifiers(onBoardingID, referenceID);

            setupSDK();
            runCTOSFeatures();
            return;
        }
        showErrorMessage(error);
        exitNative("completePreDeployment", null, getErrorCode(error));
    }


    @Override
    public void scanMetaDocFrontResults(Bitmap frontDocBitmap, String refFrontDocBitmap, String errorMessage) {
        Log.d(TAG, "scanMetaDocFrontResults");
        if (errorMessage.isEmpty()) {
            if (mMetaCardResults == null)
                mMetaCardResults = new JSONObject();

            try {
                mMetaCardResults.put("idFrontImage", frontDocBitmap);
                mMetaCardResults.put("refFrontID", refFrontDocBitmap);
            } catch (Exception ignore) {
            }

            return;
        } else {
            //carl added - Error 4103-MyKad's Photo image is not clear.
            showErrorMessage(errorMessage);
        }
        Log.d(TAG, "scanMetaDocFrontResults: " + errorMessage);
    }

    @Override
    public void scanMetaDocBackResults(Bitmap backDocBitmap, String refBackDocBitmap, String errorMessage) {
        Log.d(TAG, "scanMetaDocBackResults");
        if (errorMessage.isEmpty()) {
            if (mMetaCardResults == null)
                mMetaCardResults = new JSONObject();
            try {
                mMetaCardResults.put("idBackImage", backDocBitmap);
                mMetaCardResults.put("refBackID", refBackDocBitmap);
            } catch (Exception ignore) {

            }
            return;
        } else {
            //carl added - Error back result incorrect
            showErrorMessage(errorMessage);
            startCTOSProcess();
        }
        Log.d(TAG, "scanMetaDocBackResults: " + errorMessage);
    }

    @Override
    public void scanMetaDocFaceResults(Bitmap faceBitmap, String refFaceBitmap, String errorMessage) {
        Log.d(TAG, "scanMetaDocFaceResults");
        if (errorMessage.isEmpty()) {
            mFaceImageRef = refFaceBitmap;

            if (mMetaCardResults == null)
                mMetaCardResults = new JSONObject();

            try {
                mMetaCardResults.put("idFaceImage", faceBitmap);
                mMetaCardResults.put("refFace", refFaceBitmap);
            } catch (Exception ignore) {
            }

            return;
        } else {
            //carl added - Error 4103-MyKad's Photo image is not clear.
            showErrorMessage(errorMessage);
            startCTOSProcess();
        }

        Log.d(TAG, "scanMetaDocFaceResults: " + errorMessage);
    }

    @Override
    public void scanSimilarityResults(boolean nameIsSimilar, boolean documentNoIsSimilar, boolean frontBackIsSimilar) {
        Log.d(TAG, "scanSimilarityResults");
        Log.d(TAG, "nameIsSimilar: " + (nameIsSimilar ? "true" : "false"));
        Log.d(TAG, "documentNoIsSimilar: " + (documentNoIsSimilar ? "true" : "false"));
        Log.d(TAG, "frontBackIsSimilar: " + (frontBackIsSimilar ? "true" : "false"));

        mNameIsSimilar = nameIsSimilar;
        mDocumentNoIsSimilar = documentNoIsSimilar;
        mFrontBackIsSimilar = frontBackIsSimilar;
    }

    @Override
    public void scanLandmarkInformation(JSONObject landmarkScores) {
        Log.d(TAG, "scanLandmarkInformation: " + landmarkScores.toString());
        try {
            passLandmark = landmarkScores.getBoolean("is_original");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void scanCompleteDeployment(boolean status, String errorMessage) {
        Log.d(TAG, "scanCompleteDeployment: " + Boolean.toString(status));
        if (!errorMessage.isEmpty()) {
            showErrorMessage(errorMessage);
            exitNative("scanCompleteDeployment", null, getErrorCode(errorMessage));
        } else {
            requiredFeature = removeFromStageList(SCAN_IC);
            WritableMap map = Arguments.createMap();

            map.putString("referenceID", mReferenceID);
            map.putString("onBoardingID", mOnBoardingID);
            map.putMap("rawOCRResults", mOCResult);
            map.putBoolean("nameIsSimilar", mNameIsSimilar);
            map.putBoolean("documentNoIsSimilar", mDocumentNoIsSimilar);
            map.putBoolean("frontBackIsSimilar", mFrontBackIsSimilar);
            map.putBoolean("passLandmark", passLandmark);
            map.putBoolean("scanComplete", status);

            exitNative("scanCompleteDeployment", map, "S");
        }
    }

    @Override
    public void faceMatchResult(boolean isMatched, double percentMatched, String error) {
        Log.d(TAG, "faceMatchResult");
        Log.d(TAG, "faceMatchResult: IsMatched => " + (isMatched ? "True" : "False"));
        Log.d(TAG, "faceMatchResult: PercentMatched => " + percentMatched);
        Log.d(TAG, "faceMatchResult: Error => " + error);

        WritableMap map = Arguments.createMap();
        map.putBoolean("isMatched", isMatched);

        faceMatch = isMatched;
        requiredFeature = removeFromStageList(SCAN_FACE);

        if (!error.isEmpty()) {
            showErrorMessage(error);
            exitNative("faceMatchResult", null, getErrorCode(error));
        } else if (!isMatched) {
            exitNative("faceMatchResult", map, "EK0052");
        } else {
            exitNative("faceMatchResult", map, "S");
        }
    }

    @Override
    public void faceMatchMetaResult(Bitmap outputBitmap, String outputRef) {
        //This function is not used but required by SDK confirmed by vendor
    }

    @Override
    public void IDVerificationStatus(int status, JSONObject profileObject, String errorMessage) {
        Log.d(TAG, "IDVerificationStatus: " + errorMessage);
        Log.d(TAG, "status: " + status);
        timerOn = false;

        if (!errorMessage.isEmpty()) {
            showErrorMessage(errorMessage);
            exitNative("IDVerificationStatus", null, getErrorCode(errorMessage));
            return;
        }

        if (status == 109) {
            exitNative("IDVerificationStatus", null, "EK0041");
            return;
        }

        try {
            referenceNo = profileObject.getString("ref_no");
        } catch (Exception e) {
            exitNative("IDVerificationStatus", null, "EK0054");
            e.printStackTrace();
            return;

        }

        WritableMap map = Arguments.createMap();
        requiredFeature = removeFromStageList(ID_VERIFICATION);

        if (referenceNo.isEmpty()) {
            exitNative("IDVerificationStatus", null, "EK0000");
        }
        // status 300 valid user, status 500 clean user
        if (status == 400) {
            exitNative("IDVerificationStatus", null, "EK0050");
        } else {
            map.putString("referenceNo", referenceNo);
            if (status == 300) {
                exitNative("IDVerificationStatus", map, "S");
            } else {
                exitNative("IDVerificationStatus", map, "EK0051");
            }
        }
    }

    @Override
    public void MultifaceVerificationStatus(int i, JSONObject jsonObject, String s) {
        //This function is not used but required by SDK confirmed by vendor
    }


    @Override
    public void KBARequestStatus(JSONArray jsonArray, String errorMessage) {
        Log.d(TAG, "KBARequestStatus: " + errorMessage);
        Log.d(TAG, "jsonArray: " + jsonArray.toString());
        timerOn = false;

        if (!errorMessage.isEmpty()) {
            exitNative("KBARequestStatus", null, getErrorCode(errorMessage));
        }
        if (jsonArray.length() != 0) {
            WritableMap map = Arguments.createMap();
            try {
                map.putArray("kbaQuestion", convertJsonToArray(jsonArray));
            } catch (Exception e) {
                e.printStackTrace();
            }
            requiredFeature = removeFromStageList(KBA);
            exitNative("KBARequestStatus", map, "S");
        }
    }

    @Override
    public void KBAVerificationStatus(int totalCorrect, String errorMessage) {
        Log.d(TAG, "KBAVerificationStatus: " + errorMessage);
        Log.d(TAG, "totalCorrect " + totalCorrect);
        if (!errorMessage.isEmpty()) {
            exitNative("kbaVerificationStatus", null, getErrorCode(errorMessage));
        } else {
            WritableMap map = Arguments.createMap();
            map.putInt("totalCorrect", totalCorrect);
            requiredFeature = removeFromStageList(KBA);
            exitNative("kbaVerificationStatus", map, "S");
        }
    }

    @Override
    public void scanResults(JSONObject rawOCRResults, String referenceID, String onBoardingID, String errorMessage) {
        Log.d(TAG, "scanResults");
        if (errorMessage.isEmpty()) {
            WritableMap ocrResults = Arguments.createMap();
            try {
                Iterator<String> lists = rawOCRResults.keys();
                Log.d(TAG, "lists:" + lists);
                while (lists.hasNext()) {
                    String key = lists.next();
                    String value = rawOCRResults.getString(key);
                    ocrResults.putString(key, value);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (channel == CHANNEL_TYPE_EIV) {
                sendUserIdentifiers(onBoardingID, referenceID);
            }

            mReferenceID = referenceID;
            mOnBoardingID = onBoardingID;
            mOCRCardResults = rawOCRResults;
            Log.d(TAG, "rawOCRResults" + rawOCRResults);
            mOCResult = ocrResults;

            JSONObject frontIc;
            try {
                frontIc = rawOCRResults.getJSONObject("FrontResult");
                String fullName = frontIc.getString("fullName");
                if (fullName.isEmpty() || fullName == null) {
                    Toast.makeText(CTOSMainActivity.this, "Scan unsuccessful. Kindly rescan with a valid new MyKad.", Toast.LENGTH_LONG).show();
                    startCTOSProcess();
                } else {
                    showPreview();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            showErrorMessage(errorMessage);
            // Carl added - restart scanning when error else will stuck at loading dialog
            startCTOSProcess();
        }
    }

    public int removeFromStageList(int currentStep) {
        int result = 0;
        if (stageList.contains(currentStep)) {
            stageList.remove(Integer.valueOf(currentStep));
            if (stageList.size() > 0) {
                StringBuilder newSteps = new StringBuilder();
                for (int counter = 0; counter < stageList.size(); counter++) {
                    int current = stageList.get(counter);
                    newSteps.append(current);
                }
                result = Integer.parseInt(String.valueOf(newSteps));
            }
        }
        return result;
    }

    public void sendUserIdentifiers(String onBoardingID, String referenceID) {
        WritableMap map = Arguments.createMap();
        WritableMap payload = Arguments.createMap();
        payload.putString("onBoardingID", onBoardingID);
        payload.putString("referenceID", referenceID);
        map.putMap("payload", payload);
        map.putString("function", "storeBoardingID");
        map.putString("status", "S");
        sendEventToRN("ctosEmitter", map);
    }

    public void callBackRN(String functionName) {
        WritableMap map = Arguments.createMap();
        map.putString("function", functionName);
        map.putString("status", "S");
        sendEventToRN("ctosEmitter", map);
    }

    public String createImageFromBitmap(Bitmap bitmap, String name) {
        String fileName = name;
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            FileOutputStream fo = openFileOutput(fileName, Context.MODE_PRIVATE);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (Exception e) {
            e.printStackTrace();
            fileName = null;
        }
        return fileName;
    }

    public void exitNative(String function, WritableMap payload, String status) {
        XLoadingDialog.dismissDialog();
        WritableMap map = Arguments.createMap();
        map.putString("function", function);
        map.putString("status", status);
        map.putMap("payload", payload);

        WritableMap meta = createMetaObject();
        map.putMap("meta", meta);

        sendEventToRN("ctosEmitter", map);
        finish();
    }


    public WritableMap createMetaObject() {
        WritableMap meta = Arguments.createMap();
        meta.putString("fullName", fullName);
        meta.putString("idNo", idNo);
        meta.putString("onBoardingID", mOnBoardingID);
        meta.putString("referenceID", mReferenceID);

        if (mOCRCardResults != null) {
            WritableMap ocrResults = Arguments.createMap();
            try {
                Iterator<String> lists = mOCRCardResults.keys();
                Log.d(TAG, "lists:" + lists);
                while (lists.hasNext()) {
                    String key = lists.next();
                    String value = mOCRCardResults.getString(key);
                    ocrResults.putString(key, value);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            meta.putMap("rawOCRResults", ocrResults);
        }

        meta.putString("referenceNo", referenceNo);
        meta.putInt("requiredFeature", requiredFeature);
        meta.putBoolean("passLandmark", passLandmark);
        meta.putBoolean("nameIsSimilar", mNameIsSimilar);
        meta.putBoolean("documentNoIsSimilar", mDocumentNoIsSimilar);
        meta.putBoolean("frontBackIsSimilar", mFrontBackIsSimilar);
        meta.putBoolean("isMatched", faceMatch);
        meta.putInt("channel", channel);

        return meta;
    }

    public String getErrorCode(String errorMessage) {
        String[] errorArray = errorMessage.split("\n");
        String sdkError = SDK_ERROR_CODE.get(errorArray[0]);
        if (sdkError == null) {
            sdkError = SDK_ERROR_CODE.get("Generic Error");
        }
        return sdkError;
    }

    public void showErrorMessage(String message) {
        XLoadingDialog.dismissDialog();
        String[] errCode = message.split("-");
        try {
            String errMsg = (String) TOAST_ERROR_CODE.get(errCode[0]);
            Toast.makeText(CTOSMainActivity.this, errMsg + " (" + errCode[0] + ")", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(CTOSMainActivity.this, "An unexpected error occurred. Kindly restart the app to retry." + " (" + errCode[0] + ")", Toast.LENGTH_LONG).show();
        }
    }

    public void initErrorDict() {
        TOAST_ERROR_CODE.put("300", "An unexpected error occurred. Kindly restart the app to retry.");
        TOAST_ERROR_CODE.put("301", "An unexpected error occurred. Kindly restart the app to retry.");
        TOAST_ERROR_CODE.put("302", "We run into some trouble while turning on your camera. Kindly restart the app to retry.");
        TOAST_ERROR_CODE.put("303", "To continue, you'll need to allow camera access in settings.");
        TOAST_ERROR_CODE.put("400", "An unexpected error occurred. Send a report to ed. Send a report to the develthe developer.");
        TOAST_ERROR_CODE.put("401", "An unexpected error occurred.");
        TOAST_ERROR_CODE.put("501", "An unexpected error occurred. Send a report to the developer.");
        TOAST_ERROR_CODE.put("502", "An unexpected error occurred. Send a report to the developer.");
        TOAST_ERROR_CODE.put("503", "An unexpected error occurred. Send a report to the developer.");
        TOAST_ERROR_CODE.put("306", "Connection error. We're having trouble connecting to the server. Check your internet connection and restart the app to try again.");
        TOAST_ERROR_CODE.put("307", "We are unable to authenticate your ID image. Please try again.");
        TOAST_ERROR_CODE.put("308", "Scan unsuccessful. Kindly rescan with a valid new MyKad.");
        TOAST_ERROR_CODE.put("310", "Scan unsuccessful. Kindly rescan with a valid new MyKad.");
        TOAST_ERROR_CODE.put("311", "Scan unsuccessful. Kindly rescan with a valid new MyKad.");
        TOAST_ERROR_CODE.put("411", "Scan unsuccessful. Kindly rescan with a valid new MyKad.");
        TOAST_ERROR_CODE.put("412", "Scan unsuccessful. Kindly rescan with a valid new MyKad.");
        TOAST_ERROR_CODE.put("413", "Scan unsuccessful. Kindly rescan with a valid new MyKad.");
        TOAST_ERROR_CODE.put("4103", "Scan unsuccessful. Kindly scan with a valid new MyKad in a well-lit area.");
        TOAST_ERROR_CODE.put("312", "We're having trouble verifying you. Kindly restart the app to retry.");
        TOAST_ERROR_CODE.put("313", "We're having trouble verifying you. Kindly restart the app to retry.");
        TOAST_ERROR_CODE.put("314", "We're having trouble verifying you. Kindly restart the app to retry.");
        TOAST_ERROR_CODE.put("315", "We're having trouble verifying you. Kindly restart the app to retry.");
        TOAST_ERROR_CODE.put("318", "We're having trouble connecting to the server. Please try again after 60 minutes.");
        TOAST_ERROR_CODE.put("319", "We're having trouble connecting to the server. Please try again after 60 minutes.");
        TOAST_ERROR_CODE.put("320", "We're having trouble connecting to the server. Please try again after 60 minutes.");
        TOAST_ERROR_CODE.put("418", "Scan unsuccessful. Kindly rescan with a valid new MyKad.");
        TOAST_ERROR_CODE.put("504", "Connection error. We're having trouble connecting to the server. Check your internet connection and restart the app to try again.");


        SDK_ERROR_CODE.put("Generic Error", "EK0000");

        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_INVALID_RECORD, "EK0001");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_TOKEN_ERROR, "EK0002");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_LICENSE_ERROR, "EK0003");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_NO_AUTO_FOCUS, "EK0004");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_NO_CAMERA_SUPPORT, "EK0005");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_UNKNOWN_ERROR, "EK0006");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_PRE_DEPLOY_ERROR, "EK0007");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_IMAGE_CREATION, "EK0008");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_IMAGE_MISSING, "EK0009");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_LANDMARK_ERROR, "EK0010");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_IC_NUMBER_MISSING, "EK0011");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_SCANNER_RESULTS_ERROR, "EK0012");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_SAVE_DATA_ERROR, "EK0013");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_FACE_REFERENCE_MISSING, "EK0014");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_FACE_MATCH_ERROR, "EK0015");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_FACE_LIVENESS_ERROR, "EK0016");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_SAVE_FACE_ERROR, "EK0017");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_BARCODE_ERROR, "EK0018");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_SIGNATURE_ERROR, "EK0019");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_VERIFY_ID_ERROR, "EK0020");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_KBA_REQUEST_ERROR, "EK0021");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_KBA_VERIFY_ERROR, "EK0022");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_CAMERA_NOT_READY, "EK0023");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_POST_DEPLOY_ERROR, "EK0024");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_CLASS_ERROR, "EK0025");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_NO_ACCESS, "EK0026");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_LICENSE_EXPIRY, "EK0027");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_RETRY_REACHED, "EK0028");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_HOLOGRAM_MISMATCHED, "EK0029");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_BILLING_ERROR, "EK0030");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_HOLOGRAM_EXPIRED, "EK0031");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_HOLOGRAM_UNKNOWN_ERROR, "EK0032");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_HOLOGRAM_ERROR, "EK0033");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_POSSIBLE_OLD, "EK0034");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_FACE_NOT_COMPARABLE, "EK0035");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_MYKAD_VERSION_UNKNOWN, "EK0036");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_MYKAD_VERSION_ERROR, "EK0037");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_ID_CARD_TAMPERED, "EK0038");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_MYKAD_INVALID, "EK0039");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_ID_CARD_LABELLED, "EK0040");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_NETWORK_FAIL, "EK0041");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_FAIL_MESSAGE, "EK0042");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_FAIL_JSON, "EK0043");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_REQUEST_FAIL_JSON, "EK0044");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_ACCESS_TOKEN_EXPIRED, "EK0045");
        SDK_ERROR_CODE.put(ErrorCode.SDK_RESPONSE_POSSIBLE_ROOT, "EK0046");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_NULL_OCR, "EK0047");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_MULTIFRAME_FAIL, "EK0048");
        SDK_ERROR_CODE.put(ErrorCode.SERVER_RESPONSE_SINGLEFRAME_FAIL, "EK0049");
    }
}
