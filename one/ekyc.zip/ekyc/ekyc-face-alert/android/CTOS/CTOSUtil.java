package com.pbb.mypb.CTOS;

import androidx.annotation.Nullable;

import com.facebook.react.ReactActivity;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;

import java.util.ArrayList;
import java.util.Objects;



public class CTOSUtil extends ReactActivity {

    public static String selection;

    public static String getSelection() {
        return selection;
    }

    public static void setSelection(String selection) {
        CTOSUtil.selection = selection;
    }

    public static boolean hasStarted;

    public static boolean getHasStarted() {
        return hasStarted;
    }

    public static void setHasStarted(boolean hasStarted) {
        CTOSUtil.hasStarted = hasStarted;
    }

    public static ArrayList<Integer> convertIntToArray(int feature) {
        int temp = feature;
        ArrayList<Integer> stageList = new ArrayList<Integer>();
        do {
            stageList.add(temp % 10);
            temp /= 10;
        } while (temp > 0);
        return stageList;
    }

    protected void sendEventToRN(String name, @Nullable WritableMap params) {
        Objects.requireNonNull(getReactInstanceManager().getCurrentReactContext()).getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(name, params);
    }
}
