export const apiKey = {
  android: 'RMxJ97a0GWiA8Jsv2zS3pmrm_7Ws2fQ-',
  ios: 'hzAxfXhCCovnXrW2zyGRRsh9ArbALrzl',
};
export const apiURL = 'https://uat-kyc.pbebank.com:8443';
export const idType = 4;
export const CTOS_CHANNEL = {
  EKYC: 1,
  EIV: 2,
};
