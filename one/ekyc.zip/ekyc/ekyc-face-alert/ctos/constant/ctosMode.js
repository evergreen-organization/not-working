export const CTOS_SCAN_IC = 1;
export const CTOS_SCAN_FACE = 2;
export const CTOS_ID_VERIFICATION = 3;
export const CTOS_KBA = 4;
export const CTOS_IC_FACE_SCAN = 12;
