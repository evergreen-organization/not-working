import { errorCode } from '../constant/error';

const LANG_PREFIX = 'utils.ekycError.';

export const getErrorMessage = (error, t) => {
  let code = error.status;
  const meta = error.meta;
  const functionName = error.function;
  let status;
  const errorList = errorCode.EN.errorList;
  const errorMessage = errorList.find(x => x.errorCode === code)?.langCode;
  if (errorMessage) {
    status = {
      error: code,
      message: t(errorMessage),
    };
    return { meta, status, function: functionName };
  } else {
    status = {
      error: 'EKM005',
      message: t(`${LANG_PREFIX}msgUnexpectedError`),
    };
    return { meta, status, function: functionName };
  }
};
