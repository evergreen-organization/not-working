import { Platform } from 'react-native';
import {
  requestAndroidAudioPermission,
  requestCameraPermission,
  requestGalleryPermission
} from 'utils';

export const checkEKYCPermissions = async(t) => {
  const cameraPermission = await requestCameraPermission(t);
  if (!cameraPermission) return false;
  if (Platform.OS === 'ios') return cameraPermission;

  if (Platform.Version < 33) {
    const galleryPermission = await requestGalleryPermission(t);
    if (!galleryPermission) return false;
  }
  return await requestAndroidAudioPermission(t);
};






