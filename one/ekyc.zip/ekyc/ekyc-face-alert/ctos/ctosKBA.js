import { DeviceEventEmitter, NativeEventEmitter, NativeModules, Platform } from 'react-native';
import { CTOS_CHANNEL, apiKey as apiKeyConfig, apiURL, idType } from './constant/config';
import { CTOS_KBA } from './constant/ctosMode';

const apiKey = Platform.OS === 'android' ? apiKeyConfig.android : apiKeyConfig.ios;

export const ctosKBA = ({
  name,
  idNo,
  onBoardingID,
  referenceID,
  rawOCRResults = {},
  reference,
  kbaAnswer = [],
  channel = CTOS_CHANNEL.EKYC,
  translatedText = {},
}) =>
  new Promise((resolve, reject) => {
    if (!name || !idNo || !onBoardingID || !referenceID || !reference) {
      return reject({ status: 'EKM003', meta: {}, function: null });
    }
    const CTOSModule = NativeModules.CTOSModule;
    const emitter = Platform.OS === 'android' ? DeviceEventEmitter : new NativeEventEmitter(CTOSModule);

    const ctosListener = emitter.addListener('ctosEmitter', function (e) {
      if (e.status !== 'S') {
        const status = e.status;
        const meta = e.meta;
        const functionName = e.function;
        ctosListener.remove();
        return reject({ status, meta, function: functionName });
      }
      ctosListener.remove();
      return resolve(e);
    });

    CTOSModule.navigateToCTOS(
      apiKey,
      apiURL,
      idType,
      name,
      idNo,
      onBoardingID,
      referenceID,
      rawOCRResults,
      reference,
      kbaAnswer,
      CTOS_KBA,
      channel,
      translatedText,
    );
  });
