# CTOS-PBB Framework

## Background
This framework is a bridge build to connect both iOS & Android SDKs to the main react native application.
<br/>
<br/>

## Structure
This framework consist of two layers: Middleware layer & Subroutine Layer.
<br/>

### 1. Middleware layer
First layer is the middleware layer consist of ctosController. This layer is used for connect the application to the Subroutine layer.
<br/>

### 2. Subroutine layer
The second layer consist of multiple subroutines, used for specify the features that will be execute by the SDK. Also act as a bridge to connect middleware to the native module.
<br/>
<br/>

# How to use
Start by using this function:
```
let ctosObject = {
    variant: CTOS_IC_FACE_SCAN,
    data: {
      name: name,
      idNo: idNo,
      onBoardingID: onBoardingID,
      referenceID: referenceID,
      rawOCRResults: rawOCRResults,
      reference: referenceNo,
      kbaAnswer: kbaAnswer,
    }
  };

let result = await startCTOS(ctosObject);
```
The variant key in the ctosObject is use to choose the defined subroutine.
<br/>


# How to add a new subroutine
Steps:
1. Add the new subroutine name into ctosMode constant file. The value of the key is should be made up of the available feature from the Xendity SDK.
```
IC scan = 1
Face liveliness test = 2
KBA questions = 3
```
2. Add the subroutine to the middleware as an option.
3. Add the new subroutine file into the module.
<br/>
-The main use of the subroutine layer is to activated the SDK and handle the returning data.
<br/>
-The logic on how to process the returning data from the sdk should be contained in the Listener.
<br/>
-The name of the Emitter by default should be: **"ctosEmitter"**.

# Subroutine Structure
1. The whole subroutine should be warp in a promise in order to use it as an asynchronus function. Thus, desired result should be either reject or resolved in order to return to the application layer.
```
resolve(e);
or
reject({ status, meta, function: functionName });
```
2. Listener 
```
const ctosListener = emitter.addListener('ctosEmitter', function (e) {});
```
- Used for listen for returning signal which contains the result from the native layer.
<br/>
<br/>

3. Native navigator
```
CTOSModule.navigateToCTOS(apiKey, apiURL, idType, name, idNo, onBoardingID, referenceID, rawOCRResults, reference kbaAnswer, CTOS_SCAN_IC);
```
- Used for trigger the native screens.

# Precaution
When using multiple feature in a single subroutine, the flow will always go in order, ***example 1 > 2 >3***. If, the need for custom flow arise, calling each single feature subroutine individually maybe a solution. Another option is to make changes in the ***runCTOSFeatures()*** function in both iOS & Android native module. 
<br/>
<br/>

#### This Framework was developed by MyPB Team, if any issue can refer to us instead of vendor. 