import PropTypes from 'prop-types';
import { CTOS_IC_FACE_SCAN, CTOS_ID_VERIFICATION, CTOS_KBA, CTOS_SCAN_FACE, CTOS_SCAN_IC } from './constant/ctosMode';
import { ctosIdVerification } from './ctosIdVerification';
import { ctosKBA } from './ctosKBA';
import { ctosScanFace } from './ctosScanFace';
import { ctosScanIC } from './ctosScanIC';
import { ctosScanICFace } from './ctosScanICFace';
import { getErrorMessage } from './utils/errorHandler';
import { checkEKYCPermissions } from './utils/permission';
import { getCTOSLocalizedText } from './utils/localization';

export const startCTOS = async ({ variant, data }, t) => {
  let result;
  let havePermissions = await checkEKYCPermissions(t);
  if (!havePermissions) {
    return getErrorMessage({ meta: {}, status: 'EK0053' }, t);
  }
  if (!data) {
    return getErrorMessage({ meta: {}, status: 'EKM001' }, t);
  }

  const translatedText = getCTOSLocalizedText(t);

  try {
    if (havePermissions) {
      switch (variant) {
        case CTOS_SCAN_IC:
          result = await ctosScanIC({ ...data, translatedText });
          break;
        case CTOS_SCAN_FACE:
          result = await ctosScanFace({ ...data, translatedText });
          break;
        case CTOS_ID_VERIFICATION:
          result = await ctosIdVerification({ ...data, translatedText });
          break;
        case CTOS_KBA:
          result = await ctosKBA({ ...data, translatedText });
          break;
        case CTOS_IC_FACE_SCAN:
          result = await ctosScanICFace({ ...data, translatedText });
          break;
        default:
          result = getErrorMessage({ status: 'EKM002' }, t);
      }
    }
  } catch (err) {
    return getErrorMessage(err, t);
  }
  return result;
};

startCTOS.PropTypes = {
  variant: PropTypes.number,
  data: PropTypes.shape({
    name: PropTypes.string,
    idNo: PropTypes.string,
    onBoardingID: PropTypes.string,
    referenceID: PropTypes.string,
    rawOCRResults: PropTypes.object,
    reference: PropTypes.string,
    kbaAnswer: PropTypes.array,
  }),
};
