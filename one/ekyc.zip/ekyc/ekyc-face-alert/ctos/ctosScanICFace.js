import { DeviceEventEmitter, NativeEventEmitter, NativeModules, Platform } from 'react-native';
import { apiKey as apiKeyConfig, apiURL, CTOS_CHANNEL, idType } from './constant/config';
import { CTOS_IC_FACE_SCAN, CTOS_SCAN_FACE } from './constant/ctosMode';

const apiKey = Platform.OS === 'android' ? apiKeyConfig.android : apiKeyConfig.ios;

export const ctosScanICFace = ({
  name,
  idNo,
  onBoardingID,
  referenceID,
  rawOCRResults = {},
  reference,
  kbaAnswer = [],
  channel = CTOS_CHANNEL.EKYC,
  onSubmitReport,
  translatedText = {},
}) =>
  new Promise((resolve, reject) => {
    if (channel !== CTOS_CHANNEL.EIV && (!name || !idNo)) {
      return reject({ status: 'EKM003', meta: {}, function: null });
    }

    const CTOSModule = NativeModules.CTOSModule;
    const emitter = Platform.OS === 'android' ? DeviceEventEmitter : new NativeEventEmitter(CTOSModule);

    let icResult = {};
    let faceResult = {};
    let meta = {};
    let boardID = null;
    let refID = null;
    let nextStep;

    const ctosListener = emitter.addListener('ctosEmitter', function (e) {
      let completeProcess = false;
      let status = {};
      let functionName = null;

      if (e.function === 'storeBoardingID') {
        boardID = e.payload.onBoardingID;
        refID = e.payload.referenceID;
      }

      if (e.function === 'onIcSubmit') {
        completeProcess = false;
        if (onSubmitReport && boardID && refID) {
          onSubmitReport({ onBoardingID: boardID, referenceID: refID });
        }
        return;
      }

      if (e.function === 'NoActionBack') {
        let storeReuseKey = e?.payload?.storeReuseKey;
        meta = { onBoardingID: boardID, referenceID: refID, storeReuseKey };
        ctosListener.remove();
        return reject({ status: 'EK0053', meta, function: 'NoActionBack' });
      }

      if (e.status !== 'S' && e.status !== 'EK0053') {
        status = e.status;
        functionName = e.function;
        if (functionName === 'faceMatchResult') {
          meta.isMatched = false;
        } else {
          meta = e.meta;
        }
        ctosListener.remove();
        return reject({ status, meta, function: functionName });
      }

      if (e.meta) {
        meta = e.meta;
        nextStep = meta.requiredFeature;
      }

      if (nextStep === CTOS_SCAN_FACE) {
        if (meta.nameIsSimilar && meta.documentNoIsSimilar && meta.frontBackIsSimilar && meta.passLandmark) {
          //Do not remove this due to iOS not able to proceed need buffer to allow next native call
          setTimeout(() => {
            CTOSModule.navigateToCTOS(
              apiKey,
              apiURL,
              idType,
              name,
              idNo,
              meta.onBoardingID,
              meta.referenceID,
              {},
              meta.referenceNo,
              [],
              meta.requiredFeature,
              channel,
              translatedText,
            );
          }, 500);
        } else {
          ctosListener.remove();
          return reject({ status: 'EKM004', meta });
        }
      }

      if (e.function === 'scanCompleteDeployment') {
        icResult = e.payload;
      }

      if (e.function === 'faceMatchResult') {
        faceResult = e.payload;
        status = e.status;
        completeProcess = true;
        functionName = e.function;
      }

      if (completeProcess) {
        let finalResult = { payload: { icResult, faceResult }, meta, status, functionName };
        ctosListener.remove();
        return resolve(finalResult);
      }
    });

    CTOSModule.navigateToCTOS(
      apiKey,
      apiURL,
      idType,
      name,
      idNo,
      onBoardingID,
      referenceID,
      rawOCRResults,
      reference,
      kbaAnswer,
      CTOS_IC_FACE_SCAN,
      channel,
      translatedText,
    );
  });
