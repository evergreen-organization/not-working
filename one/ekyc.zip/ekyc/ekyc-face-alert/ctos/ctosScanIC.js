import { DeviceEventEmitter, NativeEventEmitter, NativeModules, Platform } from 'react-native';
import { CTOS_CHANNEL, apiKey as apiKeyConfig, apiURL, idType } from './constant/config';
import { CTOS_SCAN_IC } from './constant/ctosMode';

const apiKey = Platform.OS === 'android' ? apiKeyConfig.android : apiKeyConfig.ios;

export const ctosScanIC = ({
  name,
  idNo,
  onBoardingID,
  referenceID,
  rawOCRResults = {},
  reference,
  kbaAnswer = [],
  channel = CTOS_CHANNEL.EKYC,
  onSubmitReport,
  translatedText = {},
}) =>
  new Promise((resolve, reject) => {
    if (channel !== CTOS_CHANNEL.EIV && (!name || !idNo)) {
      return reject({ status: 'EKM003', meta: {}, function: null });
    }

    const CTOSModule = NativeModules.CTOSModule;
    const emitter = Platform.OS === 'android' ? DeviceEventEmitter : new NativeEventEmitter(CTOSModule);
    let icResult = {};
    let meta = {};
    let boardID = null;
    let refID = null;

    const ctosListener = emitter.addListener('ctosEmitter', function (e) {
      let completeProcess = false;
      let status = {};
      let functionName = e.function;

      if (e.function === 'storeBoardingID') {
        boardID = e.payload.onBoardingID;
        refID = e.payload.referenceID;
      }

      if (e.function === 'onIcSubmit') {
        completeProcess = false;
        if (onSubmitReport && boardID && refID) {
          onSubmitReport({ onBoardingID: boardID, referenceID: refID });
        }
        return;
      }

      if (e.function === 'NoActionBack') {
        meta = { onBoardingID: boardID, referenceID: refID };
        ctosListener.remove();
        return reject({ status: 'EK0053', meta, function: 'NoActionBack' });
      }

      if (e.meta) {
        meta = e.meta;
      }

      if (e.status !== 'S') {
        status = e.status;
        functionName = e.function;
        ctosListener.remove();
        return reject({ status, meta, function: functionName });
      }

      if (e.function === 'scanCompleteDeployment') {
        if (
          !e.payload.nameIsSimilar ||
          !e.payload.documentNoIsSimilar ||
          !e.payload.frontBackIsSimilar ||
          !e.payload.passLandmark
        ) {
          ctosListener.remove();
          return reject({ status: 'EKM004', meta });
        }
        status = e.status;
        icResult = e.payload;
        completeProcess = true;
      }

      if (completeProcess) {
        let finalResult = { payload: { icResult }, meta, status, functionName };
        ctosListener.remove();
        return resolve(finalResult);
      }
    });

    CTOSModule.navigateToCTOS(
      apiKey,
      apiURL,
      idType,
      name,
      idNo,
      onBoardingID,
      referenceID,
      rawOCRResults,
      reference,
      kbaAnswer,
      CTOS_SCAN_IC,
      channel,
      translatedText,
    );
  });
