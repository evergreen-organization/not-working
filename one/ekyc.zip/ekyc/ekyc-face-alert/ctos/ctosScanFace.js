import { DeviceEventEmitter, NativeEventEmitter, NativeModules, Platform } from 'react-native';
import { CTOS_CHANNEL, apiKey as apiKeyConfig, apiURL, idType } from './constant/config';
import { CTOS_SCAN_FACE } from './constant/ctosMode';

const apiKey = Platform.OS === 'android' ? apiKeyConfig.android : apiKeyConfig.ios;

export const ctosScanFace = ({
  name,
  idNo,
  onBoardingID,
  referenceID,
  rawOCRResults = {},
  reference,
  kbaAnswer = [],
  channel = CTOS_CHANNEL.EKYC,
  translatedText = {},
}) =>
  new Promise((resolve, reject) => {
    if (channel !== CTOS_CHANNEL.EIV && (!name || !idNo || !onBoardingID)) {
      return reject({ status: 'EKM003', meta: {}, function: null });
    }

    const CTOSModule = NativeModules.CTOSModule;
    const emitter = Platform.OS === 'android' ? DeviceEventEmitter : new NativeEventEmitter(CTOSModule);

    let faceResult = {};
    let meta = {};

    const ctosListener = emitter.addListener('ctosEmitter', function (e) {
      let completeProcess = false;
      let status = {};
      let functionName = null;

      if (e.function === 'NoActionBack') {
        ctosListener.remove();
        return reject({ status: 'EK0053', meta, function: 'NoActionBack' });
      }

      if (e.status !== 'S') {
        status = e.status;
        functionName = e.function;
        meta = e.meta;
        if (functionName === 'faceMatchResult') {
          meta.isMatched = false;
        }
        ctosListener.remove();
        return reject({ status, meta, function: functionName });
      }

      if (e.meta) {
        meta = e.meta;
      }

      if (e.function === 'faceMatchResult') {
        faceResult = e.payload;
        status = e.status;
        completeProcess = true;
        functionName = e.function;
      }

      if (completeProcess) {
        let finalResult = { payload: { faceResult }, meta, status, functionName };
        ctosListener.remove();
        return resolve(finalResult);
      }
    });

    CTOSModule.navigateToCTOS(
      apiKey,
      apiURL,
      idType,
      name,
      idNo,
      onBoardingID,
      referenceID,
      rawOCRResults,
      reference,
      kbaAnswer,
      CTOS_SCAN_FACE,
      channel,
      translatedText,
    );
  });
