import JompayIcon from 'assets/images/corporation/jompay.png';

const LANG_CONSTANT = 'constant.bill.';
export const BILL_GIRO_CODE = {
  EPF: '7370',
};

export const BILL_MODULES = {
  BILL: { key: 'BILL_PAYMENT', name: `${LANG_CONSTANT}labelBillPayment` },
  JOMPAY: { key: 'JOMPAY', name: `${LANG_CONSTANT}labelJomPAY`, icon: JompayIcon },
};

export const billFieldType = {
  TEXT_BOX: 1,
  DROP_DOWN: 2,
  TEXT_BOX_SPECIAL: 3,
  CALENDAR: 4,
};

export const BILL_FIELD_DYNAMIC_IND = {
  DYNAMIC: 'D',
  FIXED: 'F',
};
