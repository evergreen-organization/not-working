import React, { useEffect, useRef, useState } from 'react';
import _ from 'lodash';
import { useSelector, useDispatch } from 'react-redux';

import { tagColors } from 'configs';
import routes from 'navigations/routes';
import { useApi, useAppRating } from 'hooks';
import { authStorage } from 'auth/storage';
import { CustomScrollView, Screen } from 'atoms';
import { TableItemTag } from 'molecules';
import { Receipt as TranReceipt, DoneButton, ReceiptLinks, Recurring, SaveFavourite } from 'components';
import { displayReceiptDateTime, displayReceiptDate, isToday, maskAccount, showFailure, showSuccess } from 'utils';
import {
  ApiDateFormat,
  backendDatetimeFormat,
  billFieldType,
  BILL_MODULES,
  recurringFailedMsg,
  APP_RATING_MODULE,
  displayDateFormat,
} from 'constant';
import {
  getActiveFromAccCasa,
  billInit,
  convertTrailerDropDown,
  getBillerDetailById,
  getNewBill,
  getRecentBill,
  getTrailersById,
  billRecentUpdated,
  getSecfaAuth,
  getActiveCard,
  getBillFavouriteList,
  addBillFavouriteStatus,
  addBillFavourite,
  delBillFavouriteById,
  getSoftToken,
} from 'stores';
import { LOADING } from 'apis';
import { findFavouriteBill, getBillReceiptDisplayRefs, getBillRefs, getUnmatchedRecentBills } from '../utils';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';

const maxLength = 50;

const LANG_PREFIX = 'screens.billReceipt.text.';

export const Receipt = ({ navigation, route }) => {
  useAppRating({ method: APP_RATING_MODULE.PAY_BILL });
  const { t } = useTranslation();

  const { secfaInfo, additionalRefs, additionalInfo } = route.params || {};
  const formattedAdditionalRefs = getBillReceiptDisplayRefs(additionalRefs);
  const formattedAdditionalInfo = getBillReceiptDisplayRefs(additionalInfo);

  const dispatch = useDispatch();
  const { preferredAccountNo, preferredAccountName } = useSelector(getSoftToken) || {};
  const newBill = useSelector(getNewBill) || {};
  const { billerCode, billerId, amount, currency, tranDateTime, referenceNo, isESISuccess, availableBalance } = newBill;
  const { name, isFavAllowed, serviceCharge, serviceChargeType } = useSelector(getBillerDetailById({ billerId })) || {};
  const trailers = useSelector(getTrailersById({ billerId }));
  const secfaAuth = useSelector(getSecfaAuth);
  const recent = useSelector(getRecentBill);
  const casa = useSelector(getActiveFromAccCasa);
  const card = useSelector(getActiveCard);
  const store_favourite = useSelector(getBillFavouriteList);
  const addStatus = useSelector(addBillFavouriteStatus);
  const addFavouriteApi = useApi(addBillFavourite);
  const delFavouriteApi = useApi(delBillFavouriteById);

  const fromAcc = secfaInfo.fromAccNo;
  const interval = secfaInfo.occurence;
  const frequency = secfaInfo.frequency;
  const actualDate = secfaInfo.tranDate;

  const isTodayTransaction = isToday(tranDateTime, backendDatetimeFormat, actualDate, ApiDateFormat);
  const isESICreated = frequency && isESISuccess;
  const found =
    preferredAccountNo === fromAcc
      ? { accountDesc: preferredAccountName, availableBalance }
      : [...casa.accounts, ...card.accounts].find(item => item.accountNo === fromAcc);

  const [refs, setRefs] = useState({});
  const [fixedRefs, setFixedRefs] = useState({});
  const [isFavourite, setIsFavourite] = useState(false);
  const [favId, setFavId] = useState(null);
  const saveFavRef = useRef();

  useEffect(() => {
    if (frequency && !isESISuccess) showFailure(t(recurringFailedMsg));
    return () => dispatch(billInit());
  }, []);

  useEffect(() => {
    if (_.isEmpty(refs)) createRefs();
    else handleFav();
  }, [store_favourite]);

  useEffect(() => {
    if (!_.isEmpty(refs)) {
      updateRecent();
      handleFav();
    }
  }, [refs]);

  const createRefs = () => {
    const { refs, fixedRefs } =
      getBillRefs({
        obj: newBill,
        trailers,
      }) || {};

    setRefs(refs);
    setFixedRefs(fixedRefs);
    //0327782778
  };

  const handleFav = () => {
    const found = findFavouriteBill({
      list: store_favourite,
      type: BILL_MODULES.BILL.key,
      billerCode,
      refs: fixedRefs,
    });

    const isFav = !!found;
    setTimeout(() => setIsFavourite(isFav), 300);
    if (found) setFavId(found.id);
  };

  const createFavItem = favName => {
    return {
      type: BILL_MODULES.BILL.key,
      name: favName ?? name,
      billerCode,
      ...fixedRefs,
    };
  };

  const updateRecent = () => {
    const tempRecent = getUnmatchedRecentBills({
      list: recent,
      type: BILL_MODULES.BILL.key,
      billerCode,
      refs: fixedRefs,
    });

    let list = [...tempRecent];
    if (list.length >= 5) list.shift();
    list.push(createFavItem());
    dispatch(billRecentUpdated(list));
    authStorage.storeRecentBillBene(JSON.stringify(list)).then();
  };

  const onOKPress = () => navigation.navigate(routes.MAIN_TAB);

  const onFavouriteConfirm = async val => {
    const item = createFavItem(val);
    const result = await addFavouriteApi.request({ isPublic: secfaAuth.isPublic, ...item });
    if (result.problem) return showFailure(result.problem);
    showSuccess(t(LANG_PREFIX + 'messageFavAdded'), '', 100);
    saveFavRef.current.closeModal();
  };

  const onFavouriteRemove = async () => {
    const result = await delFavouriteApi.request({
      isPublic: secfaAuth.isPublic,
      type: BILL_MODULES.BILL.key,
      id: favId,
    });
    if (result.problem) return showFailure(result.problem);
    showSuccess(t(LANG_PREFIX + 'messageFavRemoved'));
  };

  const renderServiceCharge = () => {
    if (serviceCharge) {
      if (serviceChargeType === 'P')
        return <TableItemTag title={t(LANG_PREFIX + 'itemServiceCharge')} value={`${serviceCharge}%`} />;
      return <TableItemTag title={t(LANG_PREFIX + 'itemServiceCharge')} value={serviceCharge} currency={'RM'} />;
    }
  };

  const renderRefs = () => {
    return Object.entries(refs).map(([key, item], index) => {
      const trailer = trailers.find(a => a.sequence.toString() === key.substring(3, key.length));
      let value = item;
      if (trailer?.format === billFieldType.DROP_DOWN) {
        const data = convertTrailerDropDown(trailer.inputFormat);
        value = data.find(x => x.id === item)?.name;
      } else if (trailer?.format === billFieldType.CALENDAR) {
        value = trailer?.dateFormat ? dayjs(item, trailer?.dateFormat).format(displayDateFormat) : item;
      }

      return <TableItemTag key={`ref${index}`} title={trailer?.name} value={value} />;
    });
  };

  const renderAdditionalRefs = () => {
    return formattedAdditionalRefs.map((item, index) => {
      const trailer = trailers.find(a => a.trailerId === item.trailerId);
      let value = item.value;
      if (trailer?.format === billFieldType.DROP_DOWN) {
        const data = convertTrailerDropDown(trailer.inputFormat);
        value = data.find(x => x.id === item.value)?.name;
      } else if (trailer?.format === billFieldType.CALENDAR) {
        value = trailer?.dateFormat ? dayjs(item.value, trailer?.dateFormat).format(displayDateFormat) : item.value;
      }

      return <TableItemTag key={`addRefs${index}`} title={trailer?.name} value={value} />;
    });
  };

  const renderAdditionalInfo = () => {
    return formattedAdditionalInfo.map((item, index) => (
      <TableItemTag key={`info${index}`} title={item.title} value={item.value} />
    ));
  };

  const Content = () => (
    <>
      <TableItemTag title={t(LANG_PREFIX + 'itemRefNo')} value={referenceNo} />
      <TableItemTag title={t(LANG_PREFIX + 'itemDateTime')} value={displayReceiptDateTime(tranDateTime)} />
      {!isTodayTransaction && (
        <TableItemTag title={t(LANG_PREFIX + 'itemTransferDate')} value={displayReceiptDate(actualDate)} />
      )}
      <TableItemTag title={t(LANG_PREFIX + 'itemPaymentMethod')} value={t(LANG_PREFIX + 'labelBillPayment')} />
      <TableItemTag
        title={t(LANG_PREFIX + 'itemBillerName')}
        value={name}
        tagList={[{ title: billerCode, color: tagColors.grey, style: { marginTop: 3 }, fontStyle: { fontSize: 14 } }]}
      />
      {renderServiceCharge()}
      {renderRefs()}
      {renderAdditionalRefs()}
      {renderAdditionalInfo()}
    </>
  );

  return (
    <Screen singlePage>
      <CustomScrollView showsVerticalScrollIndicator={false}>
        <TranReceipt
          animation
          amount={amount}
          currency={currency}
          title={isTodayTransaction ? t(LANG_PREFIX + 'titlePaid') : t(LANG_PREFIX + 'titleAccepted')}
          desc={
            <>
              <Content />
              <TableItemTag
                title={t(LANG_PREFIX + 'itemFromAccount')}
                value={found?.accountDesc}
                tagList={[
                  { title: fromAcc, color: tagColors.grey, style: { marginTop: 3 }, fontStyle: { fontSize: 14 } },
                ]}
              />
              <TableItemTag
                title={t(LANG_PREFIX + 'itemNewBal')}
                value={found?.availableBalance}
                currency={currency}
                isLast={true}
              />
            </>
          }
        />
        {isESICreated && <Recurring date={actualDate} interval={interval} frequency={frequency} />}
      </CustomScrollView>

      <ReceiptLinks
        extraButton={
          isFavAllowed && (
            <SaveFavourite
              ref={saveFavRef}
              name={name}
              maxLength={maxLength}
              isFavourite={!!isFavourite}
              onAdd={onFavouriteConfirm}
              onRemove={onFavouriteRemove}
              isDisabled={addStatus === LOADING}
            />
          )
        }
        content={
          <TranReceipt
            amount={amount}
            currency={currency}
            title={isTodayTransaction ? t(LANG_PREFIX + 'titlePaid') : t(LANG_PREFIX + 'titleAccepted')}
            desc={
              <>
                <Content />
                <TableItemTag title={t(LANG_PREFIX + 'itemFromAccount')} value={maskAccount(fromAcc)} isLast={true} />
              </>
            }
          />
        }
      />
      <DoneButton onPress={onOKPress} />
    </Screen>
  );
};

export default Receipt;
