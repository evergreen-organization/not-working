import React, { useEffect, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';

import {
  convertTrailerDropDown,
  getBillerDetailById,
  getNewBill,
  getTrailersById,
  updateNewBillObject,
  getSoftToken,
  getBillFavouriteList,
  getBillEnquiry,
  billEnquiryUpdated,
  enquireBill,
} from 'stores';
import { showFailure, utc8DateTime } from 'utils';
import { TranSigner } from 'softToken';
import { colors, tagColors } from 'configs';
import {
  esiFrequency,
  getKeyByValue,
  billFieldType,
  tranApiType,
  validationMsg,
  ApiDateFormat,
  displayDateFormat,
  BILL_MODULES,
  BILL_GIRO_CODE,
} from 'constant';
import { Text, Money, Form, FormPaymentBtn, Tag, FormDateCalendarPicker } from 'components';
import { Screen, Divider, Space, AvoidKeyboard, SkeletonBar } from 'atoms';
import {
  TableItemTag,
  TableItemButton,
  MoreLess,
  FormCheckBoxWithReturn,
  ModalListSelect,
  BottomDrawerModal,
} from 'molecules';
import { FormFieldInterval, FromAccTab, NavBar, Notes } from 'organisms';
import { findFavouriteBill, getBillRefs } from '../utils';
import { useTranslation } from 'react-i18next';
import { useHandleDispatch } from 'hooks';
import { FAIL, IDLE, LOADING, SUCCESS } from 'apis';
import dayjs from 'dayjs';

const LANG_PREFIX_FREQUENCY = 'constant.ESI_FREQUENCY.';
const LANG_PREFIX = 'screens.billConfirmation.text.';
const LANG_PREFIX_VALIDATION = 'constant.validationMsg.';

const esiFrequencyArr = Object.entries(esiFrequency).filter(a => a[1] !== esiFrequency.ONE);

let secfaInfo;

export const Confirmation = ({ navigation }) => {
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const today = utc8DateTime().format(displayDateFormat);
  const softToken = useSelector(getSoftToken);
  const store_favourite = useSelector(getBillFavouriteList);
  const newBill = useSelector(getNewBill) || {};
  const { fromAcc, billerId, billerCode, amount } = newBill;
  const {
    name,
    mopCasa,
    isNameConsentRequired,
    isEsiAllowed,
    isFutureDate,
    isInquiryRequired,
    zakat,
    serviceCharge,
    serviceChargeType,
  } = useSelector(getBillerDetailById({ billerId })) || {};
  const trailers = useSelector(getTrailersById({ billerId }));
  const { status: billEnquiryStatus } = useSelector(getBillEnquiry) || {};
  const [othersVisible, setOthersVisible] = useState(false);
  const [isRecurring, setIsRecurring] = useState(false);
  const [frequency, setFrequency] = useState(getKeyByValue(esiFrequency, esiFrequency.DAILY));
  const [modalFrequencyVisible, setModalFrequencyVisible] = useState(false);
  const [fromAccModalVisible, setFromAccModalVisible] = useState(false);
  const [submissionLoading, setSubmissionLoading] = useState(false);
  const [refs, setRefs] = useState({});
  const [isFavourite, setIsFavourite] = useState(false);
  const [favId, setFavId] = useState(null);
  const [additionalInfo, setAdditionalInfo] = useState([]);

  const tranSignerRef = useRef();
  const enteredRefs = useRef({});
  const additionalRefs = useRef([]);

  const validationSchema = Yup.object().shape({
    isRecurring: Yup.boolean().notRequired(),
    interval: Yup.number()
      .typeError(t(`${LANG_PREFIX_VALIDATION}numberOnly`))
      .notRequired()
      .nullable()
      .label(t(`${LANG_PREFIX}itemNumOccurrences`))
      .when('isRecurring', {
        is: true,
        then: Yup.number()
          .typeError(t(`${LANG_PREFIX_VALIDATION}numberOnly`))
          .min(
            1,
            t(`${LANG_PREFIX_VALIDATION}minAmount`)
              ?.replace('${label}', t(`${LANG_PREFIX}itemNumOccurrences`))
              ?.replace('${minAmount}', 1),
          )
          .required(t(validationMsg.required)),
      }),
  });

  const initialValues = {
    date: today,
    interval: null,
    endDate: null,
  };

  useEffect(() => {
    start();
  }, []);

  const start = () => {
    if (softToken.preferredAccountActive && mopCasa !== 2)
      dispatch(updateNewBillObject({ fromAcc: softToken.preferredAccountNo }));

    const { refs, fixedRefs } =
      getBillRefs({
        obj: newBill,
        trailers,
      }) || {};

    setRefs(refs);
    enteredRefs.current = refs;

    const found = findFavouriteBill({
      list: store_favourite,
      type: BILL_MODULES.BILL.key,
      billerCode,
      refs: fixedRefs,
    });

    const isFav = !!found;
    setIsFavourite(isFav);
    if (found) setFavId(found.id);

    if (billEnquiryStatus === IDLE || billEnquiryStatus === FAIL) handleBillEnquiry(refs);
  };

  const handleBillEnquiry = async refs => {
    if (!isInquiryRequired) return dispatch(billEnquiryUpdated({ status: SUCCESS }));

    const info = {
      billerCode,
      ...refs,
    };
    const result = await handleDispatch(enquireBill(info));
    if (result.problem) return showFailure(result.problem);

    if (result.amount) {
      dispatch(updateNewBillObject({ amount: result.amount }));
    }

    if (result.trailers) {
      let moreRefs = {};
      for (const data of result.trailers) {
        const trailer = trailers.find(a => a.trailerId === data.trailerId);
        if (trailer) moreRefs[`rrn${trailer.sequence}`] = data.value;
      }

      additionalRefs.current = result.trailers;
      setRefs({ ...refs, ...moreRefs });
    }

    if (result.info) {
      setAdditionalInfo(result.info);
    }
  };

  const onStartCheckSecfa = () => setSubmissionLoading(true);
  const cancelPay = () => setSubmissionLoading(false);

  const onSubmit = async ({ interval, date }) => {
    const intervalInt = parseInt(interval);
    secfaInfo = {
      tranType: 'BILL_PAYMENT',
      billPaymentType: BILL_MODULES.BILL.key,
      isFavourite,
      favId,
      amount,
      tranDate: dayjs(date, displayDateFormat).format(ApiDateFormat),
      fromAccNo: fromAcc,
      billerCode,
      ...enteredRefs.current, //refs may contain values from enquiry API, take refs entered by user only
    };

    if (!fromAcc) return showFailure(t(LANG_PREFIX + 'errorFromAccRequired'));

    setSubmissionLoading(true);

    if (isRecurring && intervalInt > 0) {
      if (intervalInt > 60) return setSubmissionLoading(false);

      // Future dated transfer is calculated as 1 occurence, therefore occurence input must be at least 2
      const todayTran = dayjs(date, displayDateFormat).isSame(utc8DateTime(), 'day');
      if (!todayTran && intervalInt === 1) return setSubmissionLoading(false);

      secfaInfo = {
        ...secfaInfo,
        frequency,
        occurence: intervalInt,
      };
    }

    tranSignerRef.current.checkSecfa({
      secfaInfo,
      onSubmitParam: { fromAcc },
      onSuccessParam: {
        secfaInfo,
        additionalRefs: additionalRefs.current,
        additionalInfo,
      },
    });
  };

  const renderHeaderTag = () => {
    if (isFavourite)
      return <Tag title={t(LANG_PREFIX + 'tagFavourite')} color={tagColors.grey} style={{ marginRight: 0 }} />;
  };

  const renderServiceCharge = () => {
    if (serviceCharge) {
      if (serviceChargeType === 'P')
        return <TableItemTag title={t(LANG_PREFIX + 'itemServiceCharge')} value={`${serviceCharge}%`} />;
      return <TableItemTag title={t(LANG_PREFIX + 'itemServiceCharge')} value={serviceCharge} currency={'RM'} />;
    }
  };

  const renderRefs = () => {
    return Object.entries(refs).map(([key, item], index) => {
      const trailer = trailers.find(a => a.sequence.toString() === key.substring(3, key.length));
      let value = item;
      if (trailer?.format === billFieldType.DROP_DOWN) {
        const data = convertTrailerDropDown(trailer.inputFormat);
        value = data.find(x => x.id === item)?.name;
      } else if (trailer?.format === billFieldType.CALENDAR) {
        value = trailer?.dateFormat ? dayjs(item, trailer?.dateFormat).format(displayDateFormat) : item;
      }

      return (
        <TableItemTag
          key={`ref${index}`}
          title={trailer?.name}
          value={value}
          isLast={index === Object.keys(refs).length - 1 && additionalInfo.length === 0}
        />
      );
    });
  };

  const renderAdditionalInfo = () => {
    return additionalInfo.map((item, index) => (
      <TableItemTag
        key={`info${index}`}
        title={item.title}
        value={item.value}
        isLast={index === additionalInfo.length - 1}
      />
    ));
  };

  const isPaymentDisabled = () => {
    if (submissionLoading) return true;
    if (billEnquiryStatus !== SUCCESS) return true;
    return false;
  };

  const onAccountChange = ({ accountNo }) => {
    dispatch(updateNewBillObject({ fromAcc: accountNo }));
    setFromAccModalVisible(false);
  };

  const renderName = () => {
    if (billEnquiryStatus === IDLE) return;
    if (billEnquiryStatus === LOADING)
      return (
        <View style={{ marginLeft: -8 }}>
          <SkeletonBar title={true} height={20} color={colors.lightgrey} />
        </View>
      );

    if (billEnquiryStatus === FAIL)
      return <Text style={{ color: colors.primary, marginBottom: 5 }}>{t(`${LANG_PREFIX}errorGettingData`)}</Text>;

    return (
      <Text bold style={{ marginBottom: 5 }}>
        {name}
      </Text>
    );
  };

  const additionalNotesForEpf = () => {
    if (billerCode === BILL_GIRO_CODE.EPF) {
      return [
        {
          title: t(`${LANG_PREFIX}epfNoteDesc1`),
        },
        {
          title: t(`${LANG_PREFIX}epfNoteDesc2`),
        },
        {
          title: t(`${LANG_PREFIX}epfNoteDesc3`),
        },
      ];
    }

    return [];
  };

  const additionalFooterForEpf = () => {
    if (billerCode === BILL_GIRO_CODE.EPF) {
      return t(`${LANG_PREFIX}epfNote1`);
    }

    return null;
  };

  return (
    <>
      <Screen>
        <NavBar
          title={t(LANG_PREFIX + 'title')}
          back
          showShadow={true}
          bottom={
            <View style={{ marginHorizontal: 20, paddingVertical: 12, flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ flex: 1 }}>
                {renderName()}
                <Text style={{ color: colors.medium }}>{billerCode}</Text>
              </View>
              {renderHeaderTag()}
            </View>
          }
        />

        <AvoidKeyboard>
          <Form
            initialValues={initialValues}
            onSubmit={onSubmit}
            validationSchema={validationSchema}
            button={
              <FormPaymentBtn
                disabled={isPaymentDisabled()}
                loading={submissionLoading}
                title={t(LANG_PREFIX + 'buttonPay')}
                amount={<Money amount={amount} currency={'RM'} size={18} color={colors.primary} />}
                desc={
                  zakat && (
                    <>
                      <Divider />
                      <View style={{ backgroundColor: colors.white, padding: 10 }}>
                        <Text style={{ fontSize: 12, textAlign: 'center' }}>{t(LANG_PREFIX + 'labelZakatDesc')}</Text>
                      </View>
                    </>
                  )
                }
              />
            }>
            <View style={styles.mandatory}>
              <TableItemButton
                title={t(LANG_PREFIX + 'itemFromAccount')}
                value={fromAcc}
                onPress={() => setFromAccModalVisible(true)}
              />
              <Divider />
              {isFutureDate ? (
                <>
                  <View style={styles.detailBlock}>
                    <Text numberOfLines={1} style={{ color: colors.medium }}>
                      {t(LANG_PREFIX + 'itemTransferDate')}
                    </Text>
                    <FormDateCalendarPicker
                      name={'date'}
                      showRightIcon={true}
                      style={{ borderBottomWidth: 0, marginBottom: 0 }}
                    />
                  </View>
                  <Divider />
                </>
              ) : (
                <TableItemTag title={t(LANG_PREFIX + 'itemTransferDate')} value={today} />
              )}
              {renderServiceCharge()}
              {renderRefs()}
              {renderAdditionalInfo()}
            </View>

            {isEsiAllowed && (
              <>
                <Space height={10} />
                <MoreLess status={othersVisible} onPress={() => setOthersVisible(!othersVisible)} />
                {othersVisible && (
                  <View style={styles.optional}>
                    <Divider style={{ marginHorizontal: -20 }} />
                    <View style={styles.detailBlock}>
                      <Text numberOfLines={1} style={{ fontSize: 14, color: colors.medium }}>
                        {t(LANG_PREFIX + 'itemSetRecurring')}
                      </Text>
                      <FormCheckBoxWithReturn name='isRecurring' onReturn={val => setIsRecurring(val)} />
                    </View>

                    {isRecurring && (
                      <View style={{ backgroundColor: colors.bg, paddingHorizontal: 12, marginBottom: 10 }}>
                        <TableItemButton
                          title={t(LANG_PREFIX + 'itemFrequency')}
                          value={t(LANG_PREFIX_FREQUENCY + frequency)}
                          onPress={() => setModalFrequencyVisible(true)}
                        />
                        <Divider />
                        <FormFieldInterval
                          label={t(LANG_PREFIX + 'itemNumOccurrences')}
                          name='interval'
                          placeholder={t(LANG_PREFIX + 'placeholderNumOccurrences')}
                          frequency={frequency}
                          dateFormat={displayDateFormat}
                          keyboardType='numeric'
                          maxLength={2}
                        />
                      </View>
                    )}
                  </View>
                )}
              </>
            )}

            <Notes
              data={[
                {
                  title: t(`${LANG_PREFIX}labelNote`),
                  list: [
                    {
                      title: t(LANG_PREFIX + 'labelNoteDesc1'),
                    },
                    {
                      title: t(LANG_PREFIX + 'labelNoteDesc2'),
                    },
                    ...additionalNotesForEpf(),
                  ],
                  footer: additionalFooterForEpf(),
                },
                {
                  title: t(`${LANG_PREFIX}labelDisclaimer`),
                  list: [
                    {
                      title: isNameConsentRequired
                        ? t(`${LANG_PREFIX}labelDisclaimerDescConsent`)
                        : t(`${LANG_PREFIX}labelDisclaimerDesc`),
                    },
                  ],
                },
              ]}
            />
          </Form>
        </AvoidKeyboard>
      </Screen>

      <BottomDrawerModal
        variant={BottomDrawerModal.variants.modalize}
        isVisible={fromAccModalVisible}
        closeModal={() => setFromAccModalVisible(false)}>
        <FromAccTab
          casaDisabled={mopCasa === 2}
          cardDisabled={mopCasa === 1}
          onAccountChange={onAccountChange}
          fromAcc={fromAcc}
        />
      </BottomDrawerModal>

      <ModalListSelect
        isVisible={modalFrequencyVisible}
        closeModal={() => setModalFrequencyVisible(false)}
        title={t(LANG_PREFIX + 'modalLabelFrequency')}
        data={esiFrequencyArr}
        value={frequency}
        onSelect={val => {
          setFrequency(val);
          setModalFrequencyVisible(false);
        }}
      />

      <TranSigner
        ref={tranSignerRef}
        type={tranApiType.BILL_PAYMENT}
        navigation={navigation}
        onStartCheckSecfa={onStartCheckSecfa}
        onCancel={cancelPay}
      />
    </>
  );
};

const styles = StyleSheet.create({
  icon: {
    width: 30,
    height: 30,
  },
  mandatory: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    marginTop: 10,
  },
  optional: {
    paddingHorizontal: 20,
    backgroundColor: colors.white,
  },
  detailBlock: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    minHeight: 45,
  },
});

export default Confirmation;
