import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import routes from 'navigations/routes';
import { billEnquiryInit, getBillerDetailByCode, getBillers, getNewBill, updateNewBillObject } from 'stores';
import { showFailure } from 'utils';
import { colors, tagColors } from 'configs';
import { max_length_amount } from 'constant';
import { Tag, Text } from 'components';
import { NavBar, NumberInput } from 'organisms';
import { Info, Screen, SkeletonItem } from 'atoms';
import { LOADING, SUCCESS } from 'apis';
import { useTranslation } from 'react-i18next';

const LANG_PREFIX = 'screens.billAmount.text.';

export const TransferAmount = ({ navigation }) => {
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const billerStatus = useSelector(getBillers).status;
  const { billerCode, currency } = useSelector(getNewBill) || {};
  const { billerId, name, minAmt, maxAmt, amtCentNotAllowed } =
    useSelector(getBillerDetailByCode({ billerCode })) || {};

  const onSubmit = ({ amount }) => {
    if (amount === 0) return showFailure(t(LANG_PREFIX + 'errorMoreThanZero'));
    if (amount < minAmt) return showFailure(`${t(LANG_PREFIX + 'errorMinAmount')}${minAmt}`);
    if (amount > maxAmt) return showFailure(`${t(LANG_PREFIX + 'errorMaxAmount')}${maxAmt}`);
    dispatch(updateNewBillObject({ amount }));
    dispatch(billEnquiryInit());

    navigation.navigate(routes.BILL_CONFIRMATION);
  };

  const renderMax = () => {
    if (maxAmt?.length < 10) {
      return (
        <Tag
          title={`${t(LANG_PREFIX + 'tagMax')}: ${currency}${maxAmt}`}
          color={tagColors.red}
          style={{ marginTop: 10 }}
          isBold={false}
        />
      );
    }
  };

  const renderNoCent = () => {
    if (amtCentNotAllowed) {
      return (
        <Tag title={t(`${LANG_PREFIX}noCentAllowed`)} color={tagColors.grey} style={{ marginTop: 10 }} isBold={false} />
      );
    }
  };

  return (
    <Screen singlePage>
      {!billerId && billerStatus === SUCCESS ? (
        <>
          <NavBar title={t(LANG_PREFIX + 'emptyTitle')} back />
          <Info title={t(LANG_PREFIX + 'emptyDesc')} style={{ backgroundColor: colors.white }} />
        </>
      ) : (
        <>
          <NavBar
            title={t(LANG_PREFIX + 'title')}
            back
            showShadow={true}
            bottom={
              <View style={styles.account}>
                {billerStatus === LOADING ? (
                  <SkeletonItem title={true} subtitle={true} color={colors.lightgrey} />
                ) : (
                  <View>
                    <Text bold style={styles.text}>{`${billerCode} - ${name}`}</Text>
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
                      {minAmt > 0 && (
                        <Tag
                          title={`${t(LANG_PREFIX + 'tagMin')}: ${currency}${minAmt}`}
                          color={tagColors.red}
                          style={{ marginTop: 10 }}
                          isBold={false}
                        />
                      )}
                      {renderMax()}
                      {renderNoCent()}
                    </View>
                  </View>
                )}
              </View>
            }
          />
          <NumberInput
            maxLength={max_length_amount}
            onSubmit={onSubmit}
            loading={billerStatus === LOADING}
            showDecimal={!amtCentNotAllowed}
          />
        </>
      )}
    </Screen>
  );
};

const styles = StyleSheet.create({
  account: {
    justifyContent: 'center',
    minHeight: 85,
    marginHorizontal: 20,
    paddingVertical: 12,
  },
  text: {
    fontSize: 15,
  },
});

export default TransferAmount;
