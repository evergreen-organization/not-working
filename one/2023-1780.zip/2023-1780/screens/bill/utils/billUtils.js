import { BILL_FIELD_DYNAMIC_IND } from "constant";
import { isEqual } from "utils";

export const findFavouriteBill = (
  {
    list,
    type,
    billerCode,
    refs
  }
) => (
  list?.find(x => {
    if (x.type === type && x.billerCode === billerCode) {
      const restRRN = Object.keys(x)
        .filter((key) => key.startsWith('rrn'))
        .reduce((obj, key) => Object.assign(obj, { [key]: x[key] }), {});

      if (isEqual(restRRN, refs)) return true;
    }
  })
);

export const getBillRefs = (
  {
    obj,
    trailers
  }
) => {
  let refs = {};
  let fixedRefs = {};
  for (var field in obj) {
    const fieldStr = field.toString();
    if (fieldStr.startsWith('rrn')) {
      refs[field] = obj[field];

      const trailer = trailers.find(a => a.sequence.toString() === fieldStr.substring(3, fieldStr.length));
      if (trailer?.dynamicInd === BILL_FIELD_DYNAMIC_IND.FIXED) {
        fixedRefs[field] = obj[field];
      }
    }
  }
  return { refs, fixedRefs };
};

export const getUnmatchedRecentBills = (
  {
    list,
    type,
    billerCode,
    refs
  }
) => (
  list?.filter(x => {
    if (x.type === type && x.billerCode === billerCode) {
      const restRRN = Object.keys(x)
        .filter((key) => key.startsWith('rrn'))
        .reduce((obj, key) => Object.assign(obj, { [key]: x[key] }), {});

      if (isEqual(restRRN, refs)) return false;
    }
    return true;
  })
);

export const removeDynamicBillRefs = (
  {
    obj,
    trailers
  }
) => {
  let refs = {};
  for (var field in obj) {
    const fieldStr = field.toString();
    if (fieldStr.startsWith('rrn')) {
      const trailer = trailers.find(a => a.sequence.toString() === fieldStr.substring(3, fieldStr.length));
      if (trailer?.dynamicInd === BILL_FIELD_DYNAMIC_IND.FIXED) refs[field] = obj[field];
      else refs[field] = undefined;
    }
    else refs[field] = obj[field];
  }
  return refs;
};

export const removeBillsRefsFromNewBill = (obj) => (
  Object.fromEntries(
    Object.entries(obj).filter(
      ([key, v]) => !(key.startsWith('rrn'))
    )
  )
);

export const removeEmptyBillRefs = (obj) => (
  Object.fromEntries(Object.entries(obj).filter(([_, v]) => v))
);

export const getBillReceiptDisplayRefs = list => {
  if (!list) return [];
  return list?.filter(x => x.displayInReceipt);
};
