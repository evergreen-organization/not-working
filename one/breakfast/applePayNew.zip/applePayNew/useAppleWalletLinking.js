import { useNavigation } from '@react-navigation/native';
import routes from 'navigations/routes';
import { useEffect, useRef } from 'react';
import { Linking } from 'react-native';
import { useAccessControl } from 'utils';
import useAppState from './useAppState';

export const useAppleWalletLinking = () => {
  const navigation = useNavigation();
  const accessControl = useAccessControl({ navigation });
  const isBackground = useAppState();

  const handledUrlRef = useRef(null);

  const parseUrl = url => {
    // Return null early if no URL is provided
    if (!url) return null;

    try {
      let rest;

      // case 1: standard URLs with "://"
      // example: "mypb://callback?x=1"
      if (url.includes('://')) {
        // split into ["mypb", "callback?x=1"]
        // ignore scheme, keep the rest
        [, rest] = url.split('://');

        // case 2: Non-standard URLs with just ":"
        // example: "mypb:callback?x=1"
      } else if (url.includes(':')) {
        // split into ["mypb", "callback?x=1"]
        [, rest] = url.split(':');
      } else {
        // if neither format matches, it's invalid for our use case
        return null;
      }

      // if for some reason nothing exists after scheme, exit
      if (!rest) return null;

      // split the remaining string into:
      // - type/path (before "?")
      // - query string (after "?")
      // example:
      // "callback?x=1&y=2" → ["callback", "x=1&y=2"]
      const [type, queryString] = rest.split('?');

      // object to store parsed query parameters
      const params = {};

      // if query string exists, parse it
      if (queryString) {
        // split into key-value pairs: ["x=1", "y=2"]
        queryString.split('&').forEach(pair => {
          // split each pair into key and value
          const [key, value] = pair.split('=');

          // only add if key exists
          if (key) {
            // decode value (handles %20, etc.)
            params[key] = decodeURIComponent(value || '');
          }
        });
      }

      console.log({ params });

      // return structured result
      return { type, params };
    } catch (e) {
      // Catch any unexpected parsing errors
      return null;
    }
  };

  //centralized route config
  const routeMap = {
    //deeplink scheme is mypb://wallet

    //checks for 'wallet' segmen
    wallet: params => {
      accessControl.navigate(routes.APPLE_CARD_LIST_LOADING, {
        ...params,
      });
    },
  };

  const handleDeepLink = url => {
    if (!url) return;

    // if (handledUrlRef.current === url) return;
    // handledUrlRef.current = url;

    const result = parseUrl(url);
    if (!result) return;

    const { type, params } = result;

    // Dynamic handler
    const handler = routeMap[type];

    if (handler) {
      //navigate based on routeMap
      handler(params);
    }
  };

  useEffect(() => {
    //to handle cold start
    const init = async () => {
      const url = await Linking.getInitialURL();
      if (url) {
        handleDeepLink(url);
      }
    };

    init();

    //to handle foreground
    const sub = Linking.addEventListener('url', ({ url }) => {
      handleDeepLink(url);
    });

    return () => sub.remove();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
};
