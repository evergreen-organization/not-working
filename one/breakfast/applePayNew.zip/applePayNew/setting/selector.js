import { createSelector } from '@reduxjs/toolkit';

export const getPublicKeys = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.publicKeys,
);

export const getAlertList = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.alertList,
);

export const getAppInfo = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.app,
);

export const checkFirstTime = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.firstTimeUser,
);

export const getOtherUrlList = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.otherUrl,
);

export const getOtherUrlByTag = ({ tag }) =>
  createSelector(
    state => state.environmentEntities.setting?.otherUrl,
    list => {
      const found = list.find(item => item.tag === tag);
      return found;
    },
  );

export const getOnHoldCancellationReason = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.onHoldCancellationReason,
);

export const getSettingSecurity = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.security,
);

export const getValidMyPBSourceList = createSelector(
  state => state.environmentEntities.setting?.validMyPBSourceList,
  list => {
    return Array.isArray(list) ? list : [];
  },
);

export const getValidAppSourceList = createSelector(
  state => state.environmentEntities.setting?.validSourceList,
  list => {
    return Array.isArray(list) ? list : [];
  },
);

export const getValidAppSignatureList = createSelector(
  state => state.environmentEntities.setting?.validSignatureList,
  list => {
    return Array.isArray(list) ? list : [];
  },
);

export const getSettingFestive = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.festive,
);

export const getSettingAccessibility = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.importantForAccessibility,
);

export const getSettingAppRating = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.appRating,
);

export const getSettingPostureStatus = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.postureStatus,
);

export const getLastInitAppDate = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.lastInitAppDate,
);

export const getApplePayAvailable = createSelector(
  state => state.environmentEntities.setting,
  setting => setting?.applePayAvailable,
);
