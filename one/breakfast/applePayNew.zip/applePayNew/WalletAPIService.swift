
import Foundation
import PassKit

class WalletAPIService {

    static let shared = WalletAPIService()

    private init() {}

    func login(
        encryptedPin: String,
        credentials: StoredCredentials,
        completion: @escaping (Result<String, WalletError>) -> Void
    ) {
        let client = APIConfig.constructAPIClient(
            forPost: true,
            forPrivate: false,
            apiPath: APIConfig.API_PATH.WALLET_LOGIN
        )

        let requestBody: NSDictionary = [
            "pin": encryptedPin,
            "deviceId": credentials.deviceId,
            "encryptedId": credentials.encryptedId,
            "publicKey": credentials.publicKeys
        ]

        APIConfig.useAPI(client: client, requestBody: requestBody) { data, response, error in
          
            guard let data = data as? Data else {
                print("❌ Invalid Data from backend")
                completion(.failure(.invalidData))
                return
            }
          
          // Convert Data to String
          if let jsonString = String(data: data, encoding: .utf8) {
              print("📄 Response as String:", jsonString)
          } else {
              print("❌ Failed to convert data to string")
          }

            guard let dataDict = APIConfig.parseResponse(data: data) else {
                print("❌ Invalid Data Parsing to NSDict")
                completion(.failure(.parsingError))
                return
            }

            // Check for access key (successful login)
            if let accessKey = dataDict["accessKey"] as? String {
                print("[Access Key]:", accessKey)
                appGroupSharedDefaults.set(accessKey, forKey: ACCESS_KEY)
                completion(.success(accessKey))
                return
            }

          // Check for error response with message
              if let status = dataDict["status"] as? String {
                  print("[status]:", status)
                  
                  // Extract error message from API response
                let errorParam = dataDict["errorParam"] as? NSDictionary
                let errorMessage = errorParam?["message"] as? String
                    ?? errorParam?["errorMessage"] as? String
                    ?? errorParam?["error"] as? String
                let pinAttempts = dataDict["pinAttempts"] as? Int
                  
                  // Check for public key update requirement
                  if let publicKey = dataDict["publicKey"] as? String {
                      print("[publicKey]:", publicKey)
                      
                      if status == "E00xxx" { // TODO: Apple Wallet Check Error Status
                          if CredentialsManager.shared.updatePublicKey(publicKey) {
                              completion(.failure(.publicKeyUpdateRequired))
                          } else {
                              completion(.failure(.credentialUpdateFailed))
                          }
                      } else {
                        completion(.failure(.apiErrorWithMessage(status, errorMessage, pinAttempts)))
                      }
                      return
                  }
                  
                completion(.failure(.apiErrorWithMessage(status, errorMessage, pinAttempts)))
                  return
              }
            print("❌ Unexpected Response:", dataDict)
            completion(.failure(.unexpectedResponse))
        }
    }
  
  func isVisaMaster(accountType: String) -> Bool {
    return (accountType == "V" || accountType == "P" || accountType == "M")
  }
  
  func isCardPinCreated(cardStatus: String) -> Bool {
    return cardStatus == "Y"
  }
  
  func isCardLost(cancelReason: String) -> Bool {
    return cancelReason == "L"
  }
  
  func checkApplePayEligibleCreditCard(_ card: Dictionary<String, Any>) -> Bool {
    let accStatus = card["accountStatus"] as? Bool ?? false
    let accType = card["accountType"] as? String ?? "" //credit card returns m,v,p in accountType
    let cardStatus = card["cardStatus"] as? String ?? ""
    let cancelReason = card["cancelReason"] as? String ?? ""
    let comCard = card["comCard"] as? Bool ?? false
    
    return accStatus &&
    isVisaMaster(accountType: accType) &&
    !comCard &&
    isCardPinCreated(cardStatus: cardStatus) &&
    !isCardLost(cancelReason: cancelReason)
  }
  
  func checkApplePayEligibleDebitCard(_ card: Dictionary<String, Any>) -> Bool {
    let accStatus = card["accountStatus"] as? Bool ?? false
    let accType = card["debitCardType"] as? String ?? "" //debit card returns m,v,p in debitCardType
    
    return accStatus && isVisaMaster(accountType: accType)
  }

  func getCardList(completion: @escaping (Result<[String: APIConfig.ProvisioningCredential], WalletError>) -> Void) {
        let client = APIConfig.constructAPIClient(
            forPost: false,
            forPrivate: false,
            apiPath: APIConfig.API_PATH.WALLET_CARDLIST
        )

        APIConfig.useAPI(client: client) { data, response, error in
            guard let data = data as? Data else {
                print("❌ Invalid Data from backend")
                completion(.failure(.invalidData))
                return
            }
          // Convert Data to String
          if let jsonString = String(data: data, encoding: .utf8) {
              print("📄 Response as String:", jsonString)
          } else {
              print("❌ Failed to convert data to string")
          }
            guard let dataDict = APIConfig.parseResponse(data: data) else {
                print("❌ Invalid Data Parsing to NSDict")
                completion(.failure(.parsingError))
                return
            }

          let credentials: [String: APIConfig.ProvisioningCredential] = Dictionary(uniqueKeysWithValues:
          (dataDict["accountSummary"] as? [[String: Any]])?.compactMap { card in
            
            var network: String? = ""
            let cardCategory = card["cardCategory"] as? String
            switch (cardCategory){
            case APIConfig.CARD_CATEGORY.CREDIT:
              if !self.checkApplePayEligibleCreditCard(card) {
                return nil
              }
              network = card["accountType"] as? String
              break
              
            case APIConfig.CARD_CATEGORY.DEBIT:
              if !self.checkApplePayEligibleDebitCard(card) {
                return nil
              }
              network = card["debitCardType"] as? String
              break
              
            default: return nil
            }

            let primaryAccountIdentifier = card["primaryAccountIdentifier"] as? String
            let cardholderName = card["cardholderName"] as? String
            let identifier = card["identifier"] as? String ?? ""
            let accountDesc = card["accountDesc"] as? String
            let expiryDate = card["expiryDate"] as? String
            let accountSuffix = card["accountSuffix"] as? String
            let binNo = card["binNo"] as? String
            
            let credential = APIConfig.ProvisioningCredential(
              primaryAccountIdentifier: primaryAccountIdentifier,
              cardholderName: cardholderName,
              primaryAccountSuffix: accountSuffix,
              network: network,
              localizedDescription: accountDesc,
              expiration: expiryDate,
              assetName: binNo,
              identifier: identifier,
            )
            
            return (identifier, credential)
          } ?? [] )

            print("[credentials]:", credentials)

            do {
                let encodedData = try JSONEncoder().encode(credentials)
                appGroupSharedDefaults.set(encodedData, forKey: "PaymentPassCredentials")
                completion(.success(credentials))
            } catch {
                print("❌ Failed to encode credentials:", error)
                completion(.failure(.encodingError))
            }
        }
    }
}

enum WalletError: Error {
    case invalidData
    case parsingError
    case publicKeyUpdateRequired
    case credentialUpdateFailed
    case apiError(String)
    case apiErrorWithMessage(String, String?, Int?) // status, message, pinAttempts
    case unexpectedResponse
    case encodingError
    case missingCredentials
    case encryptionFailed
    case biometricFailed

    var localizedDescription: String {
        switch self {
        case .invalidData:
            return "Invalid data received from server"
        case .parsingError:
            return "Failed to parse server response"
        case .publicKeyUpdateRequired:
            return "Public key update required. Please try again."
        case .credentialUpdateFailed:
            return "Failed to update credentials"
        case .apiError(let status):
            return "API error: \(status)"
        case .apiErrorWithMessage(let status, let message, let pinAttempts):
              // Always use the message from API if available
              if let message = message, !message.isEmpty {
                  // Replace ${count} placeholder with pinAttempts if available
                  if let attempts = pinAttempts, message.contains("${count}") {
                      return message.replacingOccurrences(of: "${count}", with: "\(attempts)")
                  }
                  return message
              }
              // If no message, show generic error with status code
              return "An error occurred (\(status)). Please try again."
        case .unexpectedResponse:
            return "Unexpected response from server"
        case .encodingError:
            return "Failed to encode data"
        case .missingCredentials:
            return "Missing credentials. Please log in again."
        case .encryptionFailed:
            return "Failed to encrypt PIN"
        case .biometricFailed:
            return "Unable to retrieve PIN. Please try again."
        }
    }
}
