//
//  InAppProvisioningModule.swift
//  MyPB
//
//  Created by Administrator on 18/03/2026.
//

import Foundation
import PassKit
import UIKit
import React

@objc(InAppProvisioningModule)
class InAppProvisioningModule : RCTEventEmitter, PKAddPaymentPassViewControllerDelegate {
  
  var clientObj: APIConfig.clientCodable?
  var typedCardInfo: [String: String] = [:]
  var errorObj: [String: String] = [:]
  
  override func supportedEvents() -> [String]! {
    return ["provisionListener"]
  }
  
  /**
   Delegate Function
   */
  func addPaymentPassViewController(_ controller: PKAddPaymentPassViewController, generateRequestWithCertificateChain certificates: [Data], nonce: Data, nonceSignature: Data, completionHandler handler: @escaping  (PKAddPaymentPassRequest) -> Void) {
    
    // Convert to base64
    let certsBase64 = certificates.map { $0.base64EncodedString() }
    let nonceBase64 = nonce.base64EncodedString()
    let nonceSignatureBase64 = nonceSignature.base64EncodedString()
    
    let request = APIConfig.RequestAddPaymentPass(certificates: certsBase64,
                                                  nonce: nonceBase64,
                                                  nonceSignature: nonceSignatureBase64,
                                                  identifier: typedCardInfo["identifier"],
                                                  expiryDate: typedCardInfo["expiryDate"],
                                                  cardType: APIConfig.mapNetworkToCardType(typedCardInfo["cardType"]))
    
    do {
      let data = try JSONEncoder().encode(request)
      guard let requestBody = try JSONSerialization.jsonObject(with: data) as? NSDictionary else {
          throw NSError(domain: "Invalid JSON", code: -1)
      }
      
      APIConfig.useAPI(client: clientObj!, requestBody: requestBody) { data, response, error in
        guard let jsonData = data as? Data else {
          print("❌ Invalid data format")
          self.errorObj = ["code": "PK005",
                           "status": "E"]
          return handler(PKAddPaymentPassRequest())
        }
        
        do {
          let dataValue = try JSONDecoder().decode(APIConfig.AddPaymentPassResponse.self, from: jsonData)
          guard
            let activationData = Data(base64Encoded: dataValue.activationData),
            let encryptedPassData = Data(base64Encoded: dataValue.encryptedPassData),
            let ephemeralPublicKey = Data(base64Encoded: dataValue.ephemeralPublicKey)
          else {
            print("❌ Invalid Base64 from backend")
            self.errorObj = ["code": "PK006",
                             "status": "E"]
            return handler(PKAddPaymentPassRequest())
          }
          
          let request = PKAddPaymentPassRequest()
          request.activationData = activationData
          request.encryptedPassData = encryptedPassData
          request.ephemeralPublicKey = ephemeralPublicKey
          
          handler(request)
          
        } catch {
          do {
            let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String:Any]
            
            print("[Response Doesnt have activationData, encryptedPassData, ephemeralPublicKey]====")
            print(json as Any)
            
            self.errorObj = ["code": "PK007",
                             "status": "E"]
            
            handler(PKAddPaymentPassRequest())
            
          } catch{
            print("[Response Error. Fail to decode]====")
            self.errorObj = ["code": "PK008",
                             "status": "E"]
            handler(PKAddPaymentPassRequest())
          }
        }
      }
    } catch {
      self.errorObj = ["code": "PK009",
                       "status": "E"]
      return handler(PKAddPaymentPassRequest())
    }
  }
  
  func addPaymentPassViewController(_ controller: PKAddPaymentPassViewController, didFinishAdding pass: PKPaymentPass?, error: (any Error)?) {
    // This method will be called when enroll process ends (with success / error)
    
    var data: Any?
    var status: String?
    
    if errorObj.count == 0 {
      if let error = error {
        print("❌ Failed to add payment pass:")
        print("Error: \(error.localizedDescription)")
        print("Full error: \(error)")
        status = "E"
        data = error.localizedDescription
      }
      
      if let pass = pass {
        print("✅ Successfully added payment pass")
        print("ActivationState: \(pass.activationState)")
        print("Card Identifier: \(pass.primaryAccountIdentifier)")
        status = "S"
        data = pass.primaryAccountIdentifier
      }
      sendEvent(withName: "provisionListener", body: ["code": "PK010",
                                                      "status": status,
                                                      "data": data])
    } else {
      sendEvent(withName: "provisionListener", body: errorObj)
    }
    
    controller.dismiss(animated: false)
  }
  
  struct PKAddPaymentPassRequestData {
    var activationData: String
    var encryptedPassData: String
    var ephemeralPublicKey: String
  }
  
  /**
   Init enrollment process
   */
  @objc(initInAppProvisioning:client:requestBody:resolver:rejecter:)
  func initInAppProvisioning(cardInfo: NSDictionary,
                             client: NSDictionary,
                             requestBody: NSDictionary?,
                             resolver resolve: RCTPromiseResolveBlock,
                             rejecter reject: RCTPromiseRejectBlock) {
    
    errorObj = [:]
    
    do {
      let data = try JSONSerialization.data(withJSONObject: client)
      self.clientObj = try JSONDecoder().decode(APIConfig.clientCodable.self, from: data)

    } catch {
      // Decode failed
      errorObj = ["code": "PK001",
                  "status": "E"]
      resolve(errorObj)
    }
    
    guard let typedCardInfo = cardInfo as? [String: String] else {
      errorObj = ["code": "PK002",
                  "status": "E"]
      return resolve(errorObj)
    }
    let cardHolderName: String = typedCardInfo["cardHolderName"] ?? ""
    let cardSuffix: String = typedCardInfo["cardSuffix"] ?? ""
    self.typedCardInfo = typedCardInfo

    guard let configuration = PKAddPaymentPassRequestConfiguration(encryptionScheme: .ECC_V2) else {
      // PKAddPaymentPassRequestConfiguration failed
      errorObj = ["code": "PK003",
                  "status": "E"]
      resolve(errorObj)
      return
    }
    configuration.cardholderName = cardHolderName
    configuration.primaryAccountSuffix = cardSuffix
    
    guard let enrollViewController = PKAddPaymentPassViewController(requestConfiguration: configuration, delegate: self) else {
      // PKAddPaymentPassViewController failed
      errorObj = ["code": "PK004",
                  "status": "E"]
      resolve(errorObj)
      return
    }
    
    // Present Native Apple Wallet In-App Provisioning View
    DispatchQueue.main.async {
      RCTPresentedViewController()?.present(enrollViewController, animated: true, completion: nil)
    }
  }
  
}

