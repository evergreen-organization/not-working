import { StyleSheet } from 'react-native';
import { colors, tagColors } from 'configs';

export const styles = StyleSheet.create({
  scrollContent: {
    marginHorizontal: 10,
    paddingBottom: 40,
  },
  cardContainer: {
    marginBottom: 10,
  },
  cardImage: {
    width: 120,
    aspectRatio: 1.6,
    borderRadius: 10,
    overflow: 'hidden',
  },
  cardContent: {
    backgroundColor: colors.white,
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingTop: 15,
    paddingBottom: 5,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardContentDisabled: {
    opacity: 0.5,
  },
  cardTypeLabel: {
    position: 'absolute',
    right: 8,
    top: 5,
    fontStyle: 'italic',
    color: colors.grey,
    fontSize: 11,
  },
  cardDetailsRow: {
    flexDirection: 'row',
  },
  cardInfoContainer: {
    flex: 1,
    justifyContent: 'center',
    marginLeft: 15,
  },
  cardTitle: {
    fontSize: 15,
  },
  cardNumber: {
    marginTop: 4,
    color: colors.medium,
  },
  reportedLostTag: {
    marginTop: 5,
    backgroundColor: tagColors.red.secondary,
    alignSelf: 'flex-start',
    borderRadius: 5,
    paddingVertical: 3,
    paddingHorizontal: 8,
  },
  reportedLostText: {
    fontSize: 12,
    color: tagColors.red.primary,
  },
  actionsContainer: {
    marginHorizontal: 5,
    marginTop: 8,
  },
  buttonRow: {
    flexDirection: 'row',
    marginTop: 12,
    gap: 10,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 0.3,
  },
  reportButton: {
    backgroundColor: colors.black,
    borderColor: colors.black,
  },
  reportButtonDisabled: {
    backgroundColor: colors.lightgrey,
    borderColor: colors.lightgrey,
  },
  reportButtonText: {
    color: colors.white,
  },
  reportButtonTextDisabled: {
    color: colors.grey,
  },
  pinButton: {
    backgroundColor: '#F7FBFF',
    borderColor: '#2779CA',
  },
  pinButtonText: {
    color: '#2779CA',
  },
  loaderContainer: {
    alignSelf: 'center',
  },
  applePayDivider: {
    paddingBottom: 10,
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  actionText: {
    fontSize: 15,
  },
  walletButtonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 12,
  },
  walletButtonRowNoPadding: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 12,
    paddingBottom: 0,
  },
  walletButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  applePayIcon: {
    width: 35,
    height: undefined,
    aspectRatio: 1.5,
  },
  walletButtonTextActivated: {
    color: colors.blue,
    fontSize: 15,
  },
  walletButtonText: {
    color: colors.blue,
    fontSize: 15,
  },
  rightIcon: {
    width: 10,
    height: 10,
    tintColor: colors.medium,
  },
  learnMoreText: {
    color: '#8E8E93',
    fontSize: 13,
    paddingTop: 12,
  },
  learnMoreTextNoBottom: {
    paddingBottom: 0,
  },
  learnMoreTextWithBottom: {
    paddingBottom: 10,
  },
  applePayListContainer: {
    marginTop: 12,
  },
  applePayListHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  applePayListTitle: {
    fontSize: 13,
    color: colors.grey,
    marginBottom: 5,
  },
  deviceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  deviceRowWatch: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 12,
    paddingBottom: 0,
  },
  deviceRowWatchWithBottom: {
    paddingBottom: 10,
  },
  deviceName: {
    fontSize: 15,
  },
  activatedText: {
    fontSize: 15,
  },
  deviceStatus: {
    fontSize: 13,
    color: colors.grey,
  },
  divider: {
    marginVertical: 0,
  },
  addToWalletBadge: {
    height: 28,
    margin: 0,
  },
  howToUseButton: {
    marginTop: 0,
    margin: 0,
  },
  howToUseText: {
    color: colors.blue,
    fontSize: 13,
    padding: 0,
  },
  cardPinWarningView:{
    backgroundColor: colors.lightestRed, padding: 5, borderRadius: 5, marginBottom: 12, marginHorizontal: -4
  },
  cardPinWarningText:{
    color: colors.red, fontSize: 12
  }
});
