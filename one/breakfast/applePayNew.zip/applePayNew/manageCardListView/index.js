import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  cardInitialInfoUpdated,
  getActiveCasaDebitCards,
  getApplePayAvailable,
  getCasa,
  getCreditCard,
  getErrorMessage,
  getOtherUrlByTag,
  getValidCreditCardList,
  lostCardSelected,
  searchMastercardByTur,
} from 'stores';
import {
  checkApplePayEligibleCreditCard,
  checkApplePayEligibleDebitCard,
  formatApplePayCardList,
  handleLostCardPress,
  handleUpdatePinPress,
  isCardLost,
  isCardPinCreated,
} from '../utils';
import { showFailure, useAccessControl } from 'utils';
import routes from '../../../../navigations/routes';
import { LOADING, SUCCESS } from 'apis';
import { ManageCardListViewComp } from './components';
import { NativeEventEmitter, NativeModules, Platform } from 'react-native';
import { APPLE_PAY_CONSTANT, APPLE_PAY_EDUCATION_SCREENS } from '../../../applePay/constant';
import { useInAppProvisioning } from 'hooks/useInAppProvisioning';
import { CARD_CATEGORY } from '../constant';
import { otherUrlTag } from '../../../../constant';
import { useApplePayAccount } from '../../../../hooks/useApplePayAccount';
import { useHandleDispatch } from 'hooks';
import { getAppleWalletTokenizationSelector } from '../../../../stores/banking/appleWalletTokenization/selector';

const { AppleWalletModule, InAppProvisioningModule } = NativeModules;

export const ManageCardListView = ({ navigation, route }) => {
  useApplePayAccount();

  const accessControl = useAccessControl({ navigation });
  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const { accounts: creditCardList } = useSelector(getValidCreditCardList);
  const { accounts: casaList } = useSelector(getActiveCasaDebitCards);
  const { applePayAccountStatus: store_applePayAccount_casa, accountsStatus: storeCasaStatus } =
    useSelector(getCasa) || {};
  const { applePayAccountStatus: store_applePayAccount_card, accountsStatus: storeCardStatus } =
    useSelector(getCreditCard) || {};
  const { status: searchStatus } = useSelector(getAppleWalletTokenizationSelector);
  const [educationPopupContent, setEducationPopupContent] = useState('');
  const genericErrorMessage = useSelector(getErrorMessage('E00001'));

  const howToUseApplePayURL = useSelector(getOtherUrlByTag({ tag: otherUrlTag.APPLE_PAY_HOW_TO_USE }));
  const learnMoreApplePayURL = useSelector(getOtherUrlByTag({ tag: otherUrlTag.APPLE_PAY_LEARN_MORE }));

  const mergedCardList = useMemo(
    () => formatApplePayCardList({ casa: casaList, card: creditCardList }),
    [casaList, creditCardList],
  );

  const mergedCardListRef= useRef(mergedCardList)

  const applePayAvailable = useSelector(getApplePayAvailable);
  const isApplePayAvailable = applePayAvailable && Platform.OS === 'ios';

  // State to store Apple Pay activation statuses
  const [appleWalletStatuses, setAppleWalletStatuses] = useState({});
  const [isCheckingStatuses, setIsCheckingStatuses] = useState(false);
  const [isEducationPopUpVisible, setIsVisiblePopUpVisible] = useState(false);
  const [passMap, setPassMap] = useState({});

  const isCardActive = cardStatus => isCardPinCreated(cardStatus);
  const isCardReportedLost = cancelReason => isCardLost(cancelReason);

  const appleWalletProvisioning = useInAppProvisioning();
  const nativeEventEmitter = new NativeEventEmitter(InAppProvisioningModule);


  useEffect(() => {
    mergedCardListRef.current = mergedCardList;
  }, [mergedCardList]);

  // Check all cards' Apple Pay status when account statuses or card list changes
  useEffect(() => {
    if (isApplePayAvailable && store_applePayAccount_casa === SUCCESS && store_applePayAccount_card === SUCCESS) {
      checkAllCardsStatus();
    }
  }, [store_applePayAccount_casa, store_applePayAccount_card, mergedCardList]);

  useEffect(() => {
    const provisionProcessListener = nativeEventEmitter.addListener('provisionListener', event => {
      handleProvisionListener(event);
    });
    return () => provisionProcessListener.remove();
  }, []);

  const handleProvisionListener = event => {
    console.log('[provisionListener]:', event);

    if (event.code === 'PK010' && event.status === 'S') {
      handleEducationPopUpVisible(APPLE_PAY_EDUCATION_SCREENS.ADDED_SUCCESS);
      checkAllCardsStatus()
      return;
    }

    if (event.status === 'E') {
      if (event.code !== 'PK010') {
        showFailure(genericErrorMessage + ` (ErrorCode: ${event.code})`);
      }
    }
  };

  const checkAllCardsStatus = async () => {
    setIsCheckingStatuses(true);

    try {
      const { localPasses, remotePasses, isWatchPaired } = await AppleWalletModule.getWalletAndWatchStatus();

      const localPassMap = Object.fromEntries(localPasses.map(pass => [pass.primaryAccountIdentifier, pass]));

      const remotePassMap = Object.fromEntries(remotePasses.map(pass => [pass.primaryAccountIdentifier, pass]));

      const cardPassMap = {};

      for (const pass of [...localPasses, ...remotePasses]) {
        if (!pass) continue;

        // Direct PAI match
        const paiCard = mergedCardListRef?.current.find(card => card.primaryAccountIdentifier === pass.primaryAccountIdentifier);

        if (paiCard) {
          cardPassMap[paiCard.cardNo] = pass;
          continue;
        }

        // Mastercard fallback
        const candidateCards = mergedCardListRef?.current.filter(
          card => card.cardType === 'M' && card.cardSuffix === pass.primaryAccountNumberSuffix,
        );

        if (candidateCards.length === 1) {
          cardPassMap[candidateCards[0].cardNo] = pass;
          continue;
        }

        if (candidateCards.length > 1) {
          const result = await handleDispatch(
            searchMastercardByTur({
              uniqueKey: pass.deviceAccountIdentifier,
            }),
          );

          const exactCard = candidateCards.find(card => card.cardNo === result?.pan);

          if (exactCard) {
            cardPassMap[exactCard.cardNo] = pass;
          }
        }
      }

      const statuses = Object.fromEntries(
        mergedCardListRef?.current.map(card => {
          const pass = cardPassMap[card.cardNo];

          const localPass = pass ? localPassMap[pass.primaryAccountIdentifier] : null;

          const remotePass = pass ? remotePassMap[pass.primaryAccountIdentifier] : null;

          const isPhoneActivated = localPass?.activationState === APPLE_PAY_CONSTANT.ACTIVATION_STATUS.ACTIVATED;

          const isWatchActivated = remotePass?.activationState === APPLE_PAY_CONSTANT.ACTIVATION_STATUS.ACTIVATED;

          return [
            card.cardNo,
            {
              isPhoneActivated,
              isWatchActivated,
              pendingActivation: localPass?.activationState === APPLE_PAY_CONSTANT.ACTIVATION_STATUS.REQUIRE_ACTIVATION,
              watchPendingActivation:
                remotePass?.activationState === APPLE_PAY_CONSTANT.ACTIVATION_STATUS.REQUIRE_ACTIVATION,
              canAddToWatch: isPhoneActivated && isWatchPaired && !isWatchActivated,
              canAddToAppleWallet:
                card.cardCategory === CARD_CATEGORY.CREDIT
                  ? checkApplePayEligibleCreditCard(card)
                  : checkApplePayEligibleDebitCard(card),
            },
          ];
        }),
      );

      setPassMap(cardPassMap);
      setAppleWalletStatuses(statuses);
    } catch (error) {
      console.error('Error checking Apple Pay statuses:', error);
    } finally {
      setIsCheckingStatuses(false);
    }
  };

  const onReportCardPress = item => {
    mergedCardList?.length === 1
      ? handleOneLostCardPress(item)
      : handleLostCardPress({
          navigation,
          dispatch,
          route,
          selectedCardNo: item.cardNo,
          selectedCardDesc: item.cardDesc,
        });
  };

  const handleOneLostCardPress = item => {
    const { cardNo, cardDesc, cardType } = item || {};
    dispatch(
      cardInitialInfoUpdated({
        route: { route: route.name, params: { accountNo: cardNo } },
        selectedCards: [{ cardNo, cardDesc }],
      }),
    );
    const cards = [
      {
        cardNo,
        cardDesc,
        cardType,
      },
    ];
    dispatch(lostCardSelected({ cards }));

    navigation.navigate(routes.LOST_CARD_REPLACEMENT);
  };

  const onUpdatePinPress = item =>
    handleUpdatePinPress({
      accessControl,
      route,
      selectedCardNo: item.cardNo,
      selectedCardDesc: item.cardDesc,
    });

  const handleAddToWalletButtonPress = async item => {
    console.log('[card]: ', item);
    const ind = await accessControl.isSoftTokenFullyActivated(routes.MANAGE_CARD_LIST);
    if (!ind) return;
    appleWalletProvisioning.initProvisioning(item);
  };

  const handleVerifyPendingCard = item => {
    const currentPass = passMap[item.cardNo];
    const currentCard = {
      ...item,
      deviceAccountIdentifier: currentPass?.deviceAccountIdentifier,
      primaryAccountNumberSuffix: currentPass?.primaryAccountNumberSuffix,
      primaryAccountIdentifier: currentPass?.primaryAccountIdentifier,
    };
    //navigation.navigate(routes.MAIN_TAB);
    return accessControl.navigate(routes.SYNCHRONOUS_TOKENIZATION, { currentCard });
  };

  const handleEducationPopUpVisible = content => {
    setEducationPopupContent(content);
    setIsVisiblePopUpVisible(!isEducationPopUpVisible);
  };

  const handleCloseEducationPopUp = () => {
    setIsVisiblePopUpVisible(false);
  };

  const handleEducationPopUpLearnMorePress = () => {
    navigation.navigate(routes.OPEN_WEBVIEW, { url: howToUseApplePayURL?.url });
    setIsVisiblePopUpVisible(false);
  };

  const handleOpenLearnMoreUrl = () => navigation.navigate(routes.OPEN_WEBVIEW, { url: learnMoreApplePayURL?.url });

  const props = {
    mergedCardList,
    onReportCardPress,
    onUpdatePinPress,
    isCardReportedLost,
    isCardActive,
    isLoading:
      storeCardStatus === LOADING ||
      storeCasaStatus === LOADING ||
      store_applePayAccount_casa === LOADING ||
      store_applePayAccount_card === LOADING ||
      searchStatus === LOADING,
    isEmpty: mergedCardList.length === 0,
    appleWalletStatuses,
    isCheckingStatuses,
    isEducationPopUpVisible,
    handleAddToWalletButtonPress,
    handleEducationPopUpVisible,
    handleCloseEducationPopUp,
    handleOpenLearnMoreUrl,
    handleEducationPopUpLearnMorePress,
    handleVerifyPendingCard,
    educationPopupContent,
    isApplePayAvailable,
  };

  return <ManageCardListViewComp {...props} />;
};
