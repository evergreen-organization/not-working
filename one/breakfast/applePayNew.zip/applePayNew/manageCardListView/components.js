import React from 'react';
import { Divider, Screen, InfoNotFound, Space } from 'atoms';
import { AddToWalletButton as AppleAddToWalletButton, NavBar } from 'organisms';
import { Image, ScrollView, TouchableOpacity, useWindowDimensions, View } from 'react-native';
import { CardArtMapping } from '../../../../constant/cardArtMapping';
import { colors, skeletonColors, tagColors } from 'configs';
import { Text } from 'components';
import ContentLoader, { Rect } from 'react-content-loader/native';
import { formatCardNumber } from 'utils';
import { useTranslation } from 'react-i18next';
import RightIcon from 'assets/images/icon/right.png';
import ApplePayMark from 'assets/images/corporation/applePayMark.png';

import { styles } from './styles';
import { ApplePayEducationPopUp } from 'screens';
import { APPLE_PAY_EDUCATION_SCREENS } from '../../../applePay/constant';
import { CARD_CATEGORY } from '../constant';
import { isSchemedDebitCard } from '../utils';

const LANG_PREFIX = 'screens.cardManagementList.text.';

export const ManageCardListViewComp = ({
  mergedCardList,
  onReportCardPress,
  onUpdatePinPress,
  isCardReportedLost,
  isCardActive,
  isLoading,
  isEmpty,
  appleWalletStatuses,
  handleAddToWalletButtonPress,
  isEducationPopUpVisible,
  handleEducationPopUpVisible,
  handleCloseEducationPopUp,
  handleOpenLearnMoreUrl,
  handleEducationPopUpLearnMorePress,
  handleVerifyPendingCard,
  educationPopupContent,
  isApplePayAvailable,
}) => {
  const { t } = useTranslation();
  const { width, height } = useWindowDimensions();

  const cardCategoryDescription = card => {
    if (card.cardCategory === CARD_CATEGORY.DEBIT) return t(`${LANG_PREFIX}debit`);
    if (isSchemedDebitCard(card.cardNo)) return t(`${LANG_PREFIX}debit`);
    return t(`${LANG_PREFIX}credit`);
  };

  return (
    <Screen>
      <NavBar title={t(`${LANG_PREFIX}titleManageCards`)} back />

      {isLoading ? (
        <CardLoading height={height} width={width} />
      ) : isEmpty ? (
        <InfoNotFound title={t(`${LANG_PREFIX}emptyNoCards`)} />
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {mergedCardList.map((card, index) => (
            <View key={index} style={styles.cardContainer}>
              <View>
                <View
                  style={[styles.cardContent, isCardReportedLost(card?.cancelReason) && styles.cardContentDisabled]}
                >
                  <Text style={styles.cardTypeLabel}>{cardCategoryDescription(card)}</Text>

                  {/* Card Details */}
                  <View style={styles.cardDetailsRow}>
                    <Image source={CardArtMapping[card.cardNo?.substring(0, 6)]} style={styles.cardImage} />
                    <View style={styles.cardInfoContainer}>
                      <Text bold style={styles.cardTitle}>
                        {card.cardDesc}
                      </Text>

                      <Text style={styles.cardNumber}>{formatCardNumber(card.cardNo)}</Text>

                      {isCardReportedLost(card?.cancelReason) && (
                        <View style={styles.reportedLostTag}>
                          <Text style={styles.reportedLostText}>{t(`${LANG_PREFIX}reportedLost`)}</Text>
                        </View>
                      )}
                    </View>
                  </View>

                  <View style={styles.actionsContainer}>
                    {/* Apple Pay section for iOS only */}
                    {isApplePayAvailable && appleWalletStatuses[card.cardNo]?.canAddToAppleWallet && (
                      <>
                        {appleWalletStatuses[card.cardNo]?.canAddToWatch ? (
                          <ApplePayList
                            card={card}
                            onAddToAppleWallet={handleAddToWalletButtonPress}
                            onLearnMore={handleOpenLearnMoreUrl}
                            cardActivationStatus={appleWalletStatuses[card.cardNo]}
                            t={t}
                          />
                        ) : (
                          <AddToWalletButton
                            cardActivationStatus={appleWalletStatuses[card.cardNo]}
                            card={card}
                            onAddToAppleWallet={handleAddToWalletButtonPress}
                            onPendingVerify={handleVerifyPendingCard}
                            onHowToUseApplePay={() =>
                              handleEducationPopUpVisible(APPLE_PAY_EDUCATION_SCREENS.HOW_TO_USEE)
                            }
                            onLearnMore={handleOpenLearnMoreUrl}
                            t={t}
                          />
                        )}
                      </>
                    )}

                    {appleWalletStatuses[card.cardNo]?.canAddToAppleWallet &&
                      card.cardCategory === CARD_CATEGORY.CREDIT && <Divider style={styles.applePayDivider} />}

                    {card.cardCategory === CARD_CATEGORY.CREDIT && !isCardReportedLost(card?.cancelReason) && (
                      <>
                        <TouchableOpacity onPress={() => onReportCardPress(card)} style={styles.actionRow}>
                          <View style={styles.walletButtonContent}>
                            <Text style={styles.actionText}>{t(`${LANG_PREFIX}reportLostCard`)}</Text>
                          </View>
                          <Image source={RightIcon} style={styles.rightIcon} />
                        </TouchableOpacity>

                        <Divider />

                        <TouchableOpacity onPress={() => onUpdatePinPress(card)} style={styles.actionRow}>
                          <View style={styles.walletButtonContent}>
                            <Text style={styles.actionText}>
                              {isCardActive(card?.cardStatus)
                                ? t(`${LANG_PREFIX}changeCardPin`)
                                : t(`${LANG_PREFIX}createCardPin`)}
                            </Text>
                          </View>
                          <Image source={RightIcon} style={styles.rightIcon} />
                        </TouchableOpacity>

                        {isApplePayAvailable && !isCardActive(card?.cardStatus) && (
                          <View style={styles.cardPinWarningView}>
                            <Text style={styles.cardPinWarningText}>{t(`${LANG_PREFIX}createCardPinWarning`)}</Text>
                          </View>
                        )}
                      </>
                    )}
                  </View>
                </View>
              </View>
            </View>
          ))}
        </ScrollView>
      )}

      <ApplePayEducationPopUp
        isVisible={isEducationPopUpVisible}
        onModalHide={handleCloseEducationPopUp}
        onPressPrimary={handleEducationPopUpLearnMorePress}
        content={educationPopupContent}
      />
    </Screen>
  );
};

const CardLoading = ({ height, width }) => (
  <ContentLoader
    width={width - 20}
    height={height}
    speed={1}
    backgroundColor={skeletonColors.bone}
    foregroundColor={skeletonColors.highlight}
    style={styles.loaderContainer}
  >
    <Rect x='0' y='2' rx='5' ry='5' width='100%' height={'25%'} />
    <Rect x='0' y={height * 0.3} rx='5' ry='5' width='100%' height={'25%'} />
  </ContentLoader>
);

const AddToWalletButton = ({
  cardActivationStatus,
  card,
  onAddToAppleWallet,
  onHowToUseApplePay,
  onLearnMore,
  t,
  onPendingVerify,
}) => {
  const { isPhoneActivated, pendingActivation } = cardActivationStatus || {};
  const onButtonPress = card => {
    if (pendingActivation) return onPendingVerify(card);
    if (!isPhoneActivated) return onAddToAppleWallet(card);
    onHowToUseApplePay();
  };

  return (
    <View>
      <TouchableOpacity onPress={() => onButtonPress(card)} style={styles.walletButtonRowNoPadding}>
        <View style={styles.walletButtonContent}>
          <Image source={ApplePayMark} style={styles.applePayIcon} resizeMode='contain' />
          {!isPhoneActivated ? (
            pendingActivation ? (
              <Text style={styles.walletButtonText}>{t(`${LANG_PREFIX}verifyCard`)}</Text>
            ) : (
              <Text style={styles.walletButtonText}>{t(`${LANG_PREFIX}addToAppleWallet`)}</Text>
            )
          ) : (
            <Text style={[styles.walletButtonTextActivated]}>{t(`${LANG_PREFIX}howToUseApplePay`)}</Text>
          )}
        </View>
        <Image source={RightIcon} style={styles.rightIcon} />
      </TouchableOpacity>

      {!isPhoneActivated && (
        <TouchableOpacity onPress={onLearnMore}>
          <Text
            style={[
              styles.learnMoreText,
              card.cardCategory === CARD_CATEGORY.CREDIT
                ? styles.learnMoreTextNoBottom
                : styles.learnMoreTextWithBottom,
            ]}
          >
            {t(`${LANG_PREFIX}learnMoreApplePay`)}
          </Text>
        </TouchableOpacity>
      )}
      {isPhoneActivated && card.cardCategory === CARD_CATEGORY.DEBIT && <Space height={10} />}
    </View>
  );
};

const ApplePayList = ({ cardActivationStatus, card, onAddToAppleWallet, onLearnMore, t }) => {
  const { watchPendingActivation } = cardActivationStatus || {};

  return (
    <View style={styles.applePayListContainer}>
      <View style={styles.applePayListHeader}>
        <Text style={styles.applePayListTitle}>{t(`${LANG_PREFIX}applePayTitle`)}</Text>

        <TouchableOpacity onPress={onLearnMore} style={styles.howToUseButton}>
          <Text style={styles.howToUseText}>{t(`${LANG_PREFIX}learnMoreApplePay`)}</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.deviceRow}>
        <View style={styles.walletButtonContent}>
          <Text style={styles.deviceName}>{t(`${LANG_PREFIX}iphone`)}</Text>
        </View>
        <Text style={styles.activatedText}>{t(`${LANG_PREFIX}activated`)}</Text>
      </View>

      <Divider />

      <View
        style={[styles.deviceRowWatch, card.cardCategory === CARD_CATEGORY.DEBIT && styles.deviceRowWatchWithBottom]}
      >
        <Text style={styles.deviceName}>{t(`${LANG_PREFIX}appleWatch`)}</Text>
        {watchPendingActivation ? (
          <TouchableOpacity
            style={{
              backgroundColor: tagColors.blue.secondary,
              paddingHorizontal: 10,
              paddingVertical: 4,
              borderRadius: 5,
              borderColor: colors.blue,
              borderWidth: 1,
            }}
          >
            <Text style={{ color: colors.blue, fontSize: 14 }}>{t(`${LANG_PREFIX}verifyCard`)}</Text>
          </TouchableOpacity>
        ) : (
          <AppleAddToWalletButton
            buttonType='badge'
            style={styles.addToWalletBadge}
            onPress={() => onAddToAppleWallet(card)}
          />
        )}
      </View>
    </View>
  );
};
