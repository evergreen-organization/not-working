import { useNavigation } from '@react-navigation/native';
import { useRef, useState } from 'react';
import routes from 'navigations/routes';
import { getAppleWalletTokenizationSelector } from 'stores/banking/appleWalletTokenization/selector';
import { useSelector } from 'react-redux';
import { LOADING } from 'apis';
import { Linking } from 'react-native';
import { useTranslation } from 'react-i18next';
import { showSuccess } from 'utils';

const LANG_PREFIX = 'screens.applePayConstant.text.';

export const useAppleWalletTokenization = () => {
  const navigation = useNavigation();
  const { t } = useTranslation();

  const tranSignerRef = useRef();
  const urlRef = useRef(null);

  const [submissionLoading, setSubmissionLoading] = useState(false);
  const { status } = useSelector(getAppleWalletTokenizationSelector) || {};

  const onStartCheckSecfa = () => setSubmissionLoading(true);
  const cancelPay = () => setSubmissionLoading(false);

  // const loadSearchProvisioningInfo = async ({ uniqueKey, cardType }) => {
  //   const result = await handleDispatch(searchProvisioningInfo({ uniqueKey, cardType }));
  //   if (result.problem) {
  //     //search provisioning error
  //     return navigateToErrorScreen({ errorMessage: result.problem });
  //   }
  //   setPan(result.pan);
  // };

  const navigateToErrorScreen = ({ errorMessage, onPress }) => {
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.APPLE_WALLET_TOKENIZATION_FAIL, { errorMessage, onPress });
  };

  const handleApproveProvisioning = async ({ cardType, uniqueKey, walletType, pan, primaryAccountIdentifier }) => {
    const secfaInfo = {
      tranType: 'WALLET_TOKENIZATION',
      cardType,
      walletType,
      pan,
      uniqueKey,
    };

    tranSignerRef.current.checkSecfa({
      secfaInfo,
      onSubmitParam: { pan, primaryAccountIdentifier },
      onSuccessParam: { secfaInfo, pan, primaryAccountIdentifier },
    });
  };

  const handleReject = async () => {
    //to go error screen with reject
    //to check if require to call API and pass status to Apple
    return navigateToErrorScreen({ errorMessage: t(`${LANG_PREFIX}rejectMessage`) });
  };

  //handle wallet success
  const handleRedirectToAppleWalletSuccess = async () => {
    //launch wallet
    //check with Apple if required to pass in params to the URL
    const url = urlRef.current;
    if (!url) {
      //currently unable to confirm URL path
      showSuccess(t(`${LANG_PREFIX}msgAddCardSuccessful`));
      return navigation.navigate(routes.MAIN_TAB);
    }

    try {
      await Linking.openURL(url);
    } catch (e) {
      navigateToErrorScreen({ errorMessage: t(`${LANG_PREFIX}urlRedirectFail`) });
    } finally {
      //clear ref after use
      urlRef.current = null;
    }
  };

  //handle wallet failed
  const handleRedirectToAppleWalletFailure = async ({ errorMessage }) => {
    //unused secfa info
    return navigateToErrorScreen({ errorMessage: errorMessage });
  };

  return {
    handleApproveProvisioning,
    handleReject,
    handleRedirectToAppleWalletSuccess,
    handleRedirectToAppleWalletFailure,
    onStartCheckSecfa,
    cancelPay,
    navigateToErrorScreen,
    tranSignerRef,
    isLoading: status === LOADING,
    submissionLoading,
  };
};
