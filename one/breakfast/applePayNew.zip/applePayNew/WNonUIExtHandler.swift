import PassKit
import JavaScriptCore
import os
import WatchConnectivity

public class WNonUIExtHandler: PKIssuerProvisioningExtensionHandler , WCSessionDelegate{
  
  private let logger = Logger(subsystem: "com.pbb.mypb", category: "IssuerExtension")
  private let passLibrary = PKPassLibrary()

  
  override init() {
         super.init()

         if WCSession.isSupported() {
             let session = WCSession.default
             session.delegate = self
             session.activate()
         }
     }
  
  let session = WCSession.default
  
  // MARK: - WCSessionDelegate

  public func session(_ session: WCSession,
               activationDidCompleteWith activationState: WCSessionActivationState,
               error: Error?) {
      print("WCSession activated")
  }

  public func sessionDidBecomeInactive(_ session: WCSession) {}

  public func sessionDidDeactivate(_ session: WCSession) {
      WCSession.default.activate()
  }
  
  // MARK: - Constants
  private enum Constants {
    static let userCredentialsKey = "UserCredentials"
    static let paymentPassCredentialsKey = "PaymentPassCredentials"
  }
  
  // MARK: - Data Models
  struct StoredCredentials: Codable {
    let deviceId: String
    let encryptedId: String
    let publicKeys: String
  }
  
  
  struct PaymentPassCredentials: Codable {
    let identifier: String
    let primaryAccountIdentifier: String?
  }

  
  // MARK: - Helper Methods
  
  private func mapToPaymentNetwork(_ network: String?) -> PKPaymentNetwork? {
    guard let network = network else { return nil }
    
    switch network.uppercased() {
    case "V", "P":
      return .visa
    case "M":
      return .masterCard
    default:
      return nil
    }
  }
  
  private func getExistingPassIdentifiers() -> Set<String> {
    let passes = passLibrary.passes(of: .secureElement)
    var identifiers = Set<String>()
    
    for pass in passes {
      if let identifier = pass.secureElementPass?.primaryAccountIdentifier {
        logger.log("Existing Wallet Pass Identifier: \(identifier)")
        identifiers.insert(identifier)
      }
    }
    
    return identifiers
  }
  
  private func getRemotePassIdentifiers() -> Set<String> {
    let remotePasses = passLibrary.remoteSecureElementPasses
    var identifiers = Set<String>()
    
    for pass in remotePasses {
      if let identifier = pass.secureElementPass?.primaryAccountIdentifier {
        identifiers.insert(identifier)
      }
    }
    
    return identifiers
  }
  
  private func loadCachedCredentials() -> [String: PaymentPassCredentials]? {
    guard let cachedData = appGroupSharedDefaults.data(forKey: Constants.paymentPassCredentialsKey) else {
      logger.log("No cached credentials found")
      return nil
    }
    
    if let jsonString = String(data: cachedData, encoding: .utf8) {
      logger.log("Cached credentials JSON: \(jsonString)")
    }
    
    do {
      let decoded = try JSONDecoder().decode([String: PaymentPassCredentials].self, from: cachedData)
      logger.log("Cached credentials decoded: \(decoded)")
      return decoded
    } catch {
      logger.error("Failed to decode cached credentials: \(String(describing: error))")
      return nil
    }
  }
  
  private func loadProvisioningCredentials() -> [String: APIConfig.ProvisioningCredential]? {
    guard let cachedData = appGroupSharedDefaults.data(forKey: Constants.paymentPassCredentialsKey) else {
      logger.log("No provisioning credentials found")
      return nil
    }
    
    do {
      let decoded = try JSONDecoder().decode([String: APIConfig.ProvisioningCredential].self, from: cachedData)
      return decoded
    } catch {
      logger.error("Failed to decode provisioning credentials: \(String(describing: error))")
      return nil
    }
  }
  
  // MARK: - Override Methods
  
  public override func status(completion: @escaping (PKIssuerProvisioningExtensionStatus) -> Void) {
    logger.log("Issuer provisioning extension status() called")
    
    let status = PKIssuerProvisioningExtensionStatus()

    
    let passIdentifiers = getExistingPassIdentifiers()
    let remotePassIdentifiers = getRemotePassIdentifiers()
    
    var availablePassesForIphone = 0
    var availableRemotePassesForAppleWatch = 0
    
    guard let credentials = loadCachedCredentials() else {
      logger.log("Unable to find credentials of passes available to add to Apple Pay.")
      status.passEntriesAvailable = false
      status.requiresAuthentication = true
      completion(status)
      return
    }
    
    for (_, credential) in credentials {
      let identifier = credential.primaryAccountIdentifier ?? ""
      
      if !identifier.isEmpty {
        if !passIdentifiers.contains(identifier) {
          availablePassesForIphone += 1
        }
        
        if !remotePassIdentifiers.contains(identifier) {
          availableRemotePassesForAppleWatch += 1
        }
      } else {
        // Fallback: card exists but no identifier yet
        availablePassesForIphone += 1
        availableRemotePassesForAppleWatch += 1
      }
    }
    
    logger.log("Available passes for iPhone: \(availablePassesForIphone)")
    logger.log("Available passes for Apple Watch: \(availableRemotePassesForAppleWatch)")
    
    status.passEntriesAvailable = availablePassesForIphone > 0
    status.remotePassEntriesAvailable = session.isPaired && availableRemotePassesForAppleWatch > 0

    status.requiresAuthentication = true
    
    completion(status)
  }
  
  public override func passEntries(completion: @escaping ([PKIssuerProvisioningExtensionPassEntry]) -> Void) {
    var passEntries: [PKIssuerProvisioningExtensionPassEntry] = []
    
    let passLibraryIdentifiers = getExistingPassIdentifiers()
    
    guard let credentials = loadProvisioningCredentials() else {
      logger.log("Unable to find credentials of passes available to add to Apple Pay on iPhone.")
      completion(passEntries)
      return
    }
    
    for (_, credential) in credentials {
      let identifier = credential.primaryAccountIdentifier ?? ""
      
      if identifier.isEmpty || !passLibraryIdentifiers.contains(identifier) {
        let entry = getPaymentPassEntry(provisioningCredential: credential)
        passEntries.append(entry)
      }
    }
    logger.log("Generated \(passEntries.count) pass entries")
    completion(passEntries)
  }
  
  private func getPaymentPassEntry(provisioningCredential: APIConfig.ProvisioningCredential) -> PKIssuerProvisioningExtensionPaymentPassEntry {
    let identifier = generateRequestIdentifier(identifier: provisioningCredential.identifier ?? "", expiryDate: provisioningCredential.expiration ?? "", cardType: APIConfig.mapNetworkToCardType(provisioningCredential.network))
    let label = provisioningCredential.localizedDescription ?? "Payment Card"
    let paymentNetwork = mapToPaymentNetwork(provisioningCredential.network)
    
    guard let requestConfig = PKAddPaymentPassRequestConfiguration(encryptionScheme: .ECC_V2) else {
      fatalError("Failed to create PKAddPaymentPassRequestConfiguration")
    }
    
    requestConfig.primaryAccountIdentifier = provisioningCredential.primaryAccountIdentifier
    requestConfig.paymentNetwork = paymentNetwork
    requestConfig.cardholderName = provisioningCredential.cardholderName
    requestConfig.localizedDescription = provisioningCredential.localizedDescription
    requestConfig.primaryAccountSuffix = provisioningCredential.primaryAccountSuffix
    requestConfig.style = .payment
    
    if let expiration = provisioningCredential.expiration {
      requestConfig.cardDetails.append(PKLabeledValue(label: "Expiry Date", value: expiration))
    }
    
    let artImage = getArtImage(assetName: provisioningCredential.assetName)
    
    guard let entry = PKIssuerProvisioningExtensionPaymentPassEntry(
      identifier: identifier,
      title: label,
      art: getEntryArt(image: artImage),
      addRequestConfiguration: requestConfig
    ) else {
      fatalError("Failed to create PKIssuerProvisioningExtensionPaymentPassEntry")
    }
    
    return entry
  }
  
  private func getArtImage(assetName: String?) -> UIImage {
    guard let assetName = assetName,
          let image = UIImage(named: assetName) else {
      return #imageLiteral(resourceName: "myPBlogo")
    }
    return image
  }
  
  private func getEntryArt(image: UIImage) -> CGImage {
    guard let ciImage = CIImage(image: image) else {
      fatalError("Failed to create CIImage from UIImage")
    }
    
    let ciContext = CIContext(options: nil)
    
    guard let cgImage = ciContext.createCGImage(ciImage, from: ciImage.extent) else {
      fatalError("Failed to create CGImage from CIImage")
    }
    
    return cgImage
  }
  
  public override func generateAddPaymentPassRequestForPassEntryWithIdentifier(
    _ identifier: String,
    configuration: PKAddPaymentPassRequestConfiguration,
    certificateChain certificates: [Data],
    nonce: Data,
    nonceSignature: Data,
    completionHandler completion: @escaping (PKAddPaymentPassRequest?) -> Void
  ) {
    
    logRequestDetails(
      identifier: identifier,
      configuration: configuration,
      certificates: certificates,
      nonce: nonce,
      nonceSignature: nonceSignature
    )
    
    guard let sharedDefaults = UserDefaults(suiteName: appGroupID),
          let storedToken = sharedDefaults.string(forKey: ACCESS_KEY) else {
      logger.error("No Access Key found in shared defaults")
      completion(nil)
      return
    }
    
    let client = APIConfig.constructAPIClient(
      forPost: true,
      forPrivate: false,
      apiPath: APIConfig.API_PATH.GET_ADD_PAYMENT_PASS_REQUEST_DATA,
      accessToken: storedToken
    )
    
    let (identifier, expiryDate, cardType) = parseRequestIdentifier(jsonString: identifier)
    var request = APIConfig.RequestAddPaymentPass(certificates: certificates.map { $0.base64EncodedString() },
                                                  nonce: nonce.base64EncodedString(),
                                                  nonceSignature: nonceSignature.base64EncodedString(),
                                                  identifier: identifier,
                                                  expiryDate: expiryDate,
                                                  cardType: cardType)
    
    do {
      let data = try JSONEncoder().encode(request)
      guard let requestBody = try JSONSerialization.jsonObject(with: data) as? NSDictionary else {
          throw NSError(domain: "Invalid JSON", code: -1)
      }
      
      APIConfig.useAPI(client: client, requestBody: requestBody) { [weak self] data, response, error in
        guard let self = self else {
          completion(nil)
          return
        }
        
        if let error = error {
          self.logger.error("API Error: \(String(describing: error))")
          completion(nil)
          return
        }
        
        guard let jsonData = data as? Data else {
          self.logger.error("Invalid data format from API")
          completion(nil)
          return
        }
        
        self.handleAPIResponse(jsonData: jsonData, completion: completion)
      }
    } catch {
      self.logger.error("Encoding error: \(String(describing: error))")
      completion(nil)
      return
    }
  }
  
  private func logRequestDetails(
    identifier: String,
    configuration: PKAddPaymentPassRequestConfiguration,
    certificates: [Data],
    nonce: Data,
    nonceSignature: Data
  ) {
    logger.log("--- Apple Wallet Request Started ---")
    logger.log("Identifier: \(identifier)")
    logger.log("Cardholder Name: \(configuration.cardholderName ?? "nil")")
    logger.log("Suffix: \(configuration.primaryAccountSuffix ?? "nil")")
    logger.log("Nonce (Base64): \(nonce.base64EncodedString())")
    logger.log("Nonce Signature (Base64): \(nonceSignature.base64EncodedString())")
    logger.log("Certificate Count: \(certificates.count)")
    
    for (index, certData) in certificates.enumerated() {
      logger.log("Certificate [\(index)] (Base64): \(certData.base64EncodedString())")
    }
  }
  
  private func handleAPIResponse(jsonData: Data, completion: @escaping (PKAddPaymentPassRequest?) -> Void) {
    do {
      let dataValue = try JSONDecoder().decode(APIConfig.AddPaymentPassResponse.self, from: jsonData)
      guard
        let activationData = Data(base64Encoded: dataValue.activationData),
        let encryptedPassData = Data(base64Encoded: dataValue.encryptedPassData),
        let ephemeralPublicKey = Data(base64Encoded: dataValue.ephemeralPublicKey)
      else {
        print("❌ Invalid Base64 from backend")
        completion(nil)
        return
      }
      
      let request = PKAddPaymentPassRequest()
      request.activationData = activationData
      request.encryptedPassData = encryptedPassData
      request.ephemeralPublicKey = ephemeralPublicKey
      
      logger.log("Successfully created PKAddPaymentPassRequest")
      completion(request)
      
    } catch {
      logger.error("Failed to decode API response: \(error.localizedDescription)")
      
      if let json = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
        logger.error("Response JSON: \(json)")
      }
      
      completion(nil)
    }
  }
  
  private func generateRequestIdentifier(identifier: String, expiryDate: String, cardType: String) -> String {
    let dict: [String: String] = ["identifier": identifier,
                                   "expiryDate": expiryDate,
                                   "cardType": cardType]
    
    if let jsonData = try? JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted),
       let jsonString = String(data: jsonData, encoding: .utf8) {
      return jsonString
    }
    return ""
  }
  
  private func parseRequestIdentifier(jsonString: String) -> (String, String, String) {
    if let data = jsonString.data(using: .utf8),
       let dict = try? JSONSerialization.jsonObject(with: data) as? [String: String] {
      
      if let identifier = dict["identifier"],
         let expiryDate = dict["expiryDate"],
         let cardType = dict["cardType"]{
        return (identifier, expiryDate, cardType)
      }
    }
    return ("", "", "")
  }
}
