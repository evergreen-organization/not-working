import { createSlice } from '@reduxjs/toolkit';
import { REHYDRATE } from 'redux-persist';
import { getKeychain, hasSensor, setKeychain } from 'utils/keychain';
import { updateBiometric } from './thunk';
import { BIOMETRIC_KEYCHAIN_STATE } from 'utils/biometric';
import { NativeModules, Platform } from 'react-native';

const { AppSharedInfoModule } = NativeModules;

export const BIOMETRIC_TYPE = {
  ALL: 'ALL',
  LOGIN: 'LOGIN',
  SOFT_TOKEN: 'SOFT_TOKEN',
};

const initialState = {
  isStored: false,
  isLocked: false,
  isLoginEnabled: false,
  isTranApprovalEnabled: false,
  keyChainState: BIOMETRIC_KEYCHAIN_STATE.NON_SECURE,
};

const slice = createSlice({
  name: 'biometric',
  initialState,
  reducers: {
    biometricReset: _ => initialState,
    updateBiometricObject: (biometric, { payload }) => {
      for (const key in payload) {
        biometric[key] = payload[key];
      }

      if (Platform.OS === 'ios') {
        const hasIsStored = 'isStored' in payload;
        const hasIsLocked = 'isLocked' in payload;
        const hasIsLoginEnabled = 'isLoginEnabled' in payload;

        const shouldDisable =
          (hasIsLocked && payload.isLocked) ||
          (hasIsStored && !payload.isStored) ||
          (hasIsLoginEnabled && !payload.isLoginEnabled);

        if (shouldDisable) {
          AppSharedInfoModule.setBiometricEnabled(false);
          return;
        }

        if (hasIsLoginEnabled && payload.isLoginEnabled) {
          AppSharedInfoModule.setBiometricEnabled(true);
        }
      }
    },
    disableBiometric: biometric => {
      biometric.isLocked = false;
      biometric.isLoginEnabled = false;
      biometric.isTranApprovalEnabled = false;
    },
  },
  extraReducers: builder => {
    builder.addCase(REHYDRATE, (biometric, { payload }) => {
      if (payload?.biometric !== undefined) {
        biometric = payload.biometric;
      }
    });
  },
});

export const { biometricReset, updateBiometricObject, disableBiometric } = slice.actions;
export default slice.reducer;

export const storeBiometric =
  ({ pin, isStored = false, type = BIOMETRIC_TYPE.LOGIN }) =>
  async dispatch => {
    try {
      await setKeychain(pin);
      if (isStored) return { status: 'S' }; //If previously stored, no need to update anything
      return await enableBiometric(dispatch, type);
    } catch (error) {
      dispatch(
        updateBiometricObject({
          isStored: false,
          keyChainState: BIOMETRIC_KEYCHAIN_STATE.SHOWN_RE_ENROLL,
          isLoginEnabled: false,
          isTranApprovalEnabled: false,
        }),
      );
      return { status: 'E', problem: 'Set keychain fail' };
    }
  };

const enableBiometric = async (dispatch, type) => {
  const sensor = await hasSensor();
  if (!sensor) {
    dispatch(updateBiometricObject({ isStored: false }));
    if (Platform.OS === 'ios') await AppSharedInfoModule.setBiometricEnabled(false);
    return { status: 'E', problem: 'No Sensor found' };
  }
  if (sensor === 'Touch ID' || sensor === true) {
    if (Platform.OS === 'ios') await AppSharedInfoModule.setBiometricEnabled(true);
    dispatch(updateBiometric({ isBiometricOn: true, type }));
    dispatch(
      updateBiometricObject({
        isStored: true,
        keyChainState: BIOMETRIC_KEYCHAIN_STATE.SECURE,
        isLoginEnabled: true,
        isTranApprovalEnabled: true,
      }),
    );
    return { status: 'S' };
  }
  if (sensor === 'Face ID') {
    try {
      const { data } = await getKeychain('Face ID authorization for first time');
      if (!data) {
        dispatch(
          updateBiometricObject({
            isStored: true,
            keyChainState: BIOMETRIC_KEYCHAIN_STATE.SECURE,
            isLoginEnabled: false,
            isTranApprovalEnabled: false,
          }),
        );
        if (Platform.OS === 'ios') await AppSharedInfoModule.setBiometricEnabled(false);
        return { status: 'E', problem: 'No Keychain found' };
      }
      if (Platform.OS === 'ios') await AppSharedInfoModule.setBiometricEnabled(true);
      dispatch(updateBiometric({ isBiometricOn: true, type }));
      dispatch(
        updateBiometricObject({
          isStored: true,
          keyChainState: BIOMETRIC_KEYCHAIN_STATE.SECURE,
          isLoginEnabled: true,
          isTranApprovalEnabled: true,
        }),
      );
      return { status: 'S' };
    } catch (e) {
      dispatch(
        updateBiometricObject({
          isStored: true,
          keyChainState: BIOMETRIC_KEYCHAIN_STATE.SECURE,
          isLoginEnabled: false,
          isTranApprovalEnabled: false,
        }),
      );
      if (Platform.OS === 'ios') await AppSharedInfoModule.setBiometricEnabled(false);
      return { status: 'E', problem: 'Get keychain fail' };
    }
  }
};
