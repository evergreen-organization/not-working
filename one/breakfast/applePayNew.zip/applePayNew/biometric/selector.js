import { createSelector } from "@reduxjs/toolkit";

export const getBiometric = createSelector(
  state => state.lifestyleEntities.biometric,
  (biometric) => biometric
);

export const isBiometricLocked = createSelector(
  state => state.lifestyleEntities.biometric,
  (user) => user.isLocked
);