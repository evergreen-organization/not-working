import { createAsyncThunk } from '@reduxjs/toolkit';
import { publicClient } from 'apis/publicClient';
import { apiEndpoint } from 'apis/apiUtils';
import { Demo } from 'constant';
import { client } from 'apis/client';

export const updateBiometric = createAsyncThunk(
  'updateBiometric',
  async ({ type, isBiometricOn }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return;
    const result = await publicClient.post(`${apiEndpoint.public}/updateBiometric`, { type, isBiometricOn });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const submitDisableBiometric = createAsyncThunk(
  'submitDisableBiometric',
  async (params, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return;
    const result = await client.get(`${apiEndpoint.public}/disableBiometric`);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
