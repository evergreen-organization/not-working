import React, { useEffect, useState } from 'react';
import { NativeModules } from 'react-native';
import { useSelector } from 'react-redux';
import {
  getCasa,
  getCreditCard,
  getOtherUrlByTag,
  getValidApplePayCreditCardList,
  getValidApplePayDebitCardList,
} from 'stores';
import { otherUrlTag } from '../../../constant';
import routes from '../../../navigations/routes';
import { APPLE_PAY_EDUCATION_SCREENS } from '../constant';
import { formatApplePayCardList, hasAppleInAppVerificationPending } from '../../accounts/cardManagement/utils';
import { FAIL, SUCCESS } from 'apis';
import { ApplePayEducationComp } from './component';
import { countActivatedCards, createActivatedPassMap } from '../utils';
import { useStoredCardsToAppGroup } from '../../walletTokenization/hooks/useStoredCardsToAppGroup';
import { useApplePayAccount } from '../../../hooks/useApplePayAccount';
import { showFailure } from 'utils';
import { useTranslation } from 'react-i18next';

const { AppleWalletModule } = NativeModules;
let hasHandledPendingPasses = false;

const LANG_PREFIX = 'screens.applePayConstant.text.';

export const ApplePayEducation = ({ navigation }) => {
  useApplePayAccount();
  useStoredCardsToAppGroup();
  const { t } = useTranslation();
  const applePayURL = useSelector(getOtherUrlByTag({ tag: otherUrlTag.APPLE_PAY_HOW_TO_USE }));
  const { accounts: creditCardList } = useSelector(getValidApplePayCreditCardList);
  const { accounts: debitCardList } = useSelector(getValidApplePayDebitCardList);
  const { applePayAccountStatus: storeCardStatus } = useSelector(getCasa) || {};
  const { applePayAccountStatus: storeCasaStatus } = useSelector(getCreditCard) || {};

  const [isFirstTime, setIsFirstTime] = useState(true);
  const [currentItem, setCurrentItem] = useState({
    screen: APPLE_PAY_EDUCATION_SCREENS.EDUCATION_SCREEN_3,
    action: () => {},
  });

  const mergedCardList = formatApplePayCardList({ casa: debitCardList, card: creditCardList });

  const handleOpenUrl = () => {
    navigation.navigate(routes.OPEN_WEBVIEW, { url: applePayURL?.url });
  };

  const handleLearnHowToUse = () => {
    return setCurrentItem({
      screen: APPLE_PAY_EDUCATION_SCREENS.EDUCATION_SCREEN_2,
      action: handleOpenUrl,
    });
  };

  const handleNavigateManageCards = () => {
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.MANAGE_CARD_LIST);
  };

  const handleNavigateAsynchronousFlow = () => {
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.APPLE_CARD_LIST_LOADING);
  };

  useEffect(() => {
    setIsFirstTime(false);
    if ((storeCardStatus === FAIL || storeCasaStatus === FAIL) && !isFirstTime)
      return showFailure(t(`${LANG_PREFIX}failedGetData`));
    if (storeCardStatus === SUCCESS && storeCasaStatus === SUCCESS) determineNavigation().then();
  }, [storeCardStatus, storeCasaStatus]);

  const determineNavigation = async () => {
    try {
      const passkitPasses = await AppleWalletModule.getAllUniqueSecureElementPasses();

      const passActivationMap = createActivatedPassMap(passkitPasses);
      const activatedCardsCount = countActivatedCards(mergedCardList, passActivationMap);

      //Rule 0 - Asynchronous - pending passes requires activation
      if (
        hasAppleInAppVerificationPending({ cardList: mergedCardList, passList: passkitPasses }) &&
        !hasHandledPendingPasses
      ) {
        hasHandledPendingPasses = true;
        return handleNavigateAsynchronousFlow();
      }

      // Rule 1: No eligible cards  or no passes in wallet OR no activated cards
      if (mergedCardList.length === 0 || passkitPasses?.length === 0 || activatedCardsCount === 0) {
        return setCurrentItem({
          screen: APPLE_PAY_EDUCATION_SCREENS.EDUCATION_SCREEN_1,
          action: handleNavigateManageCards,
        });
      }

      // Count activated cards
      const eligibleCount = mergedCardList.length === 0;
      const allEligibleCardsActivated = activatedCardsCount === eligibleCount;

      // Rule 2: All eligible cards are activated
      if (allEligibleCardsActivated) {
        return setCurrentItem({
          screen: APPLE_PAY_EDUCATION_SCREENS.EDUCATION_SCREEN_2,
          action: handleOpenUrl,
        });
      }

      // Rule 3: Some cards activated, but not all eligible cards are activated
      return setCurrentItem({
        screen: APPLE_PAY_EDUCATION_SCREENS.EDUCATION_SCREEN_3,
        action: handleNavigateManageCards,
      });
    } catch (error) {
      console.error('Error determining navigation:', error);
      // Fallback to default screen
      setCurrentItem({
        screen: APPLE_PAY_EDUCATION_SCREENS.EDUCATION_SCREEN_1,
        action: handleNavigateManageCards,
      });
    }
  };

  const props = {
    currentItem,
    handleOpenUrl,
    handleLearnHowToUse,
    isLoading: storeCardStatus !== SUCCESS || storeCasaStatus !== SUCCESS,
  };

  return <ApplePayEducationComp {...props} />;
};
