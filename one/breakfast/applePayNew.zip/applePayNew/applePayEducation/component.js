import React from 'react';
import { BottomView, Screen } from 'atoms';
import { NavBar } from 'organisms';
import { Image, ScrollView, StyleSheet, TouchableOpacity, useWindowDimensions, View } from 'react-native';
import { colors } from 'configs';
import { Text } from 'components';
import LottieView from 'lottie-react-native';
import loadingLottie from '../../../assets/lottie/loading-qrcode.json';
import { useTranslation } from 'react-i18next';

export const ApplePayEducationComp = ({ currentItem, handleOpenUrl, handleLearnHowToUse, isLoading }) => {
  const { height } = useWindowDimensions();

  const { t } = useTranslation();

  if (isLoading)
    return (
      <Screen singlePage>
        <LottieView source={loadingLottie} autoPlay loop style={styles.flex} />
      </Screen>
    );
  return (
    <Screen>
      <NavBar back />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={[styles.contentContainer, { minHeight: height * 0.3 }]}>
          <Text bold style={styles.title}>
            {t(currentItem.screen.title)}
          </Text>
          <Image source={currentItem.screen.centerImg} style={styles.centerImage} resizeMode='contain' />

          <Text style={styles.description}>{t(currentItem.screen.description)}</Text>

          {currentItem.screen?.bottomImg && <Image source={currentItem.screen?.bottomImg} style={styles.bottomImage} />}
        </View>
      </ScrollView>

      <BottomView>
        <TouchableOpacity onPress={currentItem.action} style={styles.primaryButton}>
          <Text bold style={styles.primaryButtonText}>
            {t(currentItem.screen.buttonText)}
          </Text>
        </TouchableOpacity>

        {currentItem.screen?.hyperLinkText && (
          <TouchableOpacity onPress={handleLearnHowToUse} style={styles.linkContainer}>
            <Text style={styles.linkText}>{t(currentItem.screen?.hyperLinkText)}</Text>
          </TouchableOpacity>
        )}
      </BottomView>
    </Screen>
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    backgroundColor: colors.white,
    borderRadius: 10,
    marginHorizontal: 10,
    padding: 10,
  },
  title: {
    textAlign: 'center',
    fontSize: 16,
  },
  centerImage: {
    width: undefined,
    height: 300,
    aspectRatio: 1.2,
    marginVertical: 20,
  },
  description: {
    textAlign: 'center',
    paddingHorizontal: 10,
    marginBottom: 12,
  },
  bottomImage: {
    width: 120,
    height: undefined,
    aspectRatio: 3.1,
    marginVertical: 12,
  },
  primaryButton: {
    backgroundColor: colors.primary,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    height: 45,
    marginHorizontal: 30,
    marginTop: 10,
  },
  primaryButtonText: {
    color: colors.white,
  },
  linkContainer: {
    alignItems: 'center',
    marginBottom: 10,
    marginTop: 10,
  },
  linkText: {
    color: colors.blue,
    textDecorationLine: 'underline',
  },
  flex: {
    flex: 1,
  },
});
