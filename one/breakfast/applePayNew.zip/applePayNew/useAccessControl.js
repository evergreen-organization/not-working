import { useDispatch, useSelector } from 'react-redux';

import routes from 'navigations/routes';
import { useSoftToken } from 'hooks/useSoftToken';
import { FAIL, SUCCESS } from 'apis/data';
import {
  checkProfileType,
  getActiveFromAccCasa,
  getSoftToken,
  isBound,
  isFullAccess,
  isQuickPayment,
  routeSelected,
} from 'stores';

import { showFailure, showSuccess, showViewOnly } from './message';
import { useRetry } from 'contexts';
import { CQ_ACTIVATION_STATUS, PROFILE_TYPE, SOFT_TOKEN_ACTIVATION_STATUS } from 'constant';
import { useTranslation } from 'react-i18next';
import { AUTH_TYPE } from 'hooks';
import { InteractionManager } from 'react-native';

// Types of access checking
const bound = true;
const fullAccess = true;
const preferredAccount = true;
const secureSign = true;
const challengeQuestion = true;
const quickPayment = true;
const loggedIn = true;
const allowCardOnly = true;

// Configure access rights by navigation routes
const access = {
  //Challenge Question
  [routes.CQ_ENROLMENT]: {
    bound,
    fullAccess,
    preferredAccount,
    allowCardOnly,
    loggedIn,
    secureSign,
    challengeQuestion,
  },

  //Financial
  [routes.CASH_ADVANCE_FROM]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.CASH_ADVANCE_TO]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },

  [routes.PAY_LOAN]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.PAY_LOAN_AMOUNT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },

  [routes.PAY_CARD]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.PAY_CARD_AMOUNT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },

  [routes.JOURNEY]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.APPOINTMENT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.TRANSFER_TO]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.CARDLESS_SELECTION]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },

  [routes.REMITTANCE]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },

  [routes.DUITNOW_REGISTER]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.DUITNOW_UPDATE]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },

  [routes.DEPOSIT_OPEN_ACCOUNT_TYPE]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.DEPOSIT_PLACEMENT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.DEPOSIT_WITHDRAW_AMOUNT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.DEPOSIT_WITHDRAW_CONFIRMATION]: {
    bound,
    fullAccess,
    preferredAccount,
    loggedIn,
    secureSign,
    challengeQuestion,
  },
  [routes.DEPOSIT_PLACEMENT_TENURE]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.FUND_LOCK_AMOUNT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.GOLD_LANDING]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.GOLD_CLOSE_ACC]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },
  [routes.GOLD_AMOUNT]: { bound, fullAccess, preferredAccount, loggedIn, secureSign, challengeQuestion },

  [routes.INSURANCE]: { bound, fullAccess, loggedIn, secureSign, challengeQuestion },
  [routes.SYNCHRONOUS_TOKENIZATION]: { bound, loggedIn, fullAccess, secureSign, challengeQuestion },

  //Financial Card Only
  [routes.TOP_UP]: { bound, fullAccess, preferredAccount, allowCardOnly, loggedIn, secureSign, challengeQuestion },
  [routes.BILL]: { bound, fullAccess, preferredAccount, allowCardOnly, loggedIn, secureSign, challengeQuestion },
  [routes.QR_PAYMENT]: {
    bound,
    fullAccess,
    preferredAccount,
    allowCardOnly,
    secureSign,
    challengeQuestion,
    quickPayment,
  },
  [routes.QR_PAYMENT_RECEIVE]: {
    bound,
    fullAccess,
    preferredAccount,
  },
  [routes.CARBON_TRACKER]: { bound, fullAccess, allowCardOnly, loggedIn, secureSign, challengeQuestion },
  [routes.CARD_PIN_UPDATE_SELECT]: { bound, fullAccess, allowCardOnly, loggedIn, secureSign, challengeQuestion },
  [routes.CARD_PIN_UPDATE]: { bound, fullAccess, allowCardOnly, loggedIn, secureSign, challengeQuestion },

  //Financial no login
  [routes.SOFT_TOKEN_PENDING_TRAN]: { bound, fullAccess, secureSign }, //CQ not required to access module
  [routes.PENDING_TOKENIZATION]: { bound, fullAccess, secureSign }, //CQ not required to access module
  [routes.QUICK_PAYMENT]: { bound, fullAccess, secureSign, challengeQuestion },
  [routes.ACCOUNT_UPDATE_EMAIL]: { bound, loggedIn, fullAccess, secureSign, challengeQuestion },

  //Require Login
  [routes.ESI]: { bound, loggedIn },
  [routes.PFM_SUMMARY]: { bound, loggedIn },
  [routes.LOYALTY]: { bound, loggedIn },
  [routes.EXPENSE_TRACKER_MAIN]: { bound, fullAccess, loggedIn },
  [routes.CUSTOMER_FEEDBACK]: { bound, loggedIn },
  [routes.DEVICE_MANAGEMENT]: { bound, loggedIn },
  [routes.ACCOUNT_UPDATE_PROFILE]: { bound, loggedIn },
  [routes.CASA_DETAIL]: { bound, loggedIn },
  [routes.APPLE_PAY_EDUCATION]: { bound, loggedIn },
  [routes.MANAGE_CARD_LIST]: { bound, loggedIn },
  [routes.ASYNCHRONOUS_TOKENIZATION]: { bound, loggedIn },
  [routes.APPLE_CARD_LIST_LOADING]: { bound, loggedIn },

  //No authentication
  [routes.OPEN_WEBVIEW]: {},
};

export const useAccessControl = ({ navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'utils.accessControl.';
  const dispatch = useDispatch();
  const { globalLoggedIn } = useRetry();
  const softToken = useSoftToken({ navigation });
  const store_isBound = useSelector(isBound);
  const store_fullAccess = useSelector(isFullAccess);
  const hasQuickPayment = useSelector(isQuickPayment);
  const casaStore = useSelector(getActiveFromAccCasa);
  const softTokenStore = useSelector(getSoftToken);
  const {
    selectedRoute,
    preferredAccountActive,
    isLicenseAvailable,
    isActivated,
    softTokenActivationStatus,
    cqActivationStatus,
  } = softTokenStore || {};
  const viewOnly = useSelector(checkProfileType(PROFILE_TYPE.VIEW));

  const requireBind = path => (access[path]?.bound ? !store_isBound : false);
  const requireFullAccess = path => (access[path]?.fullAccess ? !store_fullAccess : false);
  const requireQuickPayment = path => (access[path]?.quickPayment ? !hasQuickPayment : false);
  const requireLogin = path => (access[path]?.loggedIn ? !globalLoggedIn.current : false);
  const requirePreferredAccount = path => (access[path]?.preferredAccount ? !preferredAccountActive : false);
  const requireSecureSign = path => access[path]?.secureSign;
  const canAllowCardOnly = path => access[path]?.allowCardOnly;
  const checkSoftTokenAndCQ = path =>
    access[path]?.challengeQuestion
      ? softTokenActivationStatus === SOFT_TOKEN_ACTIVATION_STATUS.ACTIVE &&
        (cqActivationStatus === CQ_ACTIVATION_STATUS.ACTIVE || cqActivationStatus === CQ_ACTIVATION_STATUS.INACTIVE)
      : softTokenActivationStatus === SOFT_TOKEN_ACTIVATION_STATUS.ACTIVE;

  const routeParams = path => ({
    flow: AUTH_TYPE.QUICK_LOGIN,
    newRoute: path,
  });

  const navigate = (path, param) => {
    dispatch(routeSelected(path));

    if (requireBind(path)) return navigation.navigate(routes.LOGIN_PBE_OLD);

    if (requireFullAccess(path)) {
      const allowCard = canAllowCardOnly(path);
      return { requireFullAccess: true, allowCard };
    }

    if (requireSecureSign(path) && viewOnly) {
      return showViewOnly(navigation, globalLoggedIn.current);
    }

    if (requirePreferredAccount(path)) {
      const allowCardOnly = canAllowCardOnly(path);
      if (globalLoggedIn.current)
        return navigation.navigate(routes.PREFERRED_ACCOUNT, { allowCardOnly, extraParam: param });
      return navigation.navigate(routes.LOGIN_PIN, {
        ...routeParams(routes.PREFERRED_ACCOUNT),
        params: { allowCardOnly, extraParam: param },
      });
    }

    lastCheck(path, param);
  };

  const lastCheck = (path, param, toValidateSecureSign = true) => {
    if (requireSecureSign(path) && toValidateSecureSign) {
      if (isActivated) {
        if (checkSoftTokenAndCQ(path)) {
          //Fully activated - proceed to next checking
        } else {
          return navigation.navigate(routes.HOME_LOADING, { action: 'checkSoftTokenStatus', params: param });
        }
      } else {
        return activateSoftToken();
      }
    }

    if (requireQuickPayment(path)) {
      if (globalLoggedIn.current) return navigation.navigate(routes.QUICK_PAYMENT, { tranType: 'UPDATE_QUICKPAYMENT' });
      return navigation.navigate(routes.LOGIN_PIN, {
        ...routeParams(routes.QUICK_PAYMENT),
        params: { tranType: 'UPDATE_QUICKPAYMENT' },
      });
    }

    if (requireLogin(path)) {
      return navigation.navigate(routes.LOGIN_PIN, {
        ...routeParams(path),
        params: param,
      });
    }

    navigation.navigate(path, param);
  };

  const activateSoftToken = () => {
    if (viewOnly) return showViewOnly(navigation, globalLoggedIn.current);

    const activationInd = globalLoggedIn.current ? softToken.activate() : softToken.activateAfterPinLogin(routeParams);

    if (activationInd) return;

    return showFailure(t(`${LANG_PREFIX}pbssUnavailable`), t(`${LANG_PREFIX}pbssUnavailableDesc`));
  };

  const isSoftTokenFullyActivated = (currentPath, params) => {
    if (viewOnly) return showViewOnly(navigation, globalLoggedIn.current);

    dispatch(routeSelected(currentPath));

    if (isActivated) {
      if (checkSoftTokenAndCQ(currentPath)) return true;
      navigation.navigate(routes.HOME_LOADING, { action: 'checkSoftTokenStatus', params });
    } else activateSoftToken();

    return false;
  };

  const handleViewOnlyFlow = () => {
    navigation.navigate(routes.MAIN_TAB);
    return showSuccess(t(`${LANG_PREFIX}titleWelcome`), t(`${LANG_PREFIX}descriptionWelcomeViewOnly`));
  };

  const fromAccountCheck = () => {
    const isCardOnlyUser = casaStore.accountsStatus === SUCCESS && casaStore.accounts.length === 0;
    const shouldCheckIC = casaStore.accountsStatus === FAIL || isCardOnlyUser;

    if (shouldCheckIC && viewOnly) return handleViewOnlyFlow();
    if (shouldCheckIC) return checkIC();
    if (casaStore.accountsStatus === SUCCESS) {
      InteractionManager.runAfterInteractions(() => {
        navigation.replace(routes.PREFERRED_ACCOUNT, { isFromBinding: true });
      });
    }
  };

  const softTokenStatusActivated = params => {
    lastCheck(selectedRoute, params, false);
  };

  const checkIC = () => {
    navigation.navigate(routes.MAIN_TAB);
    if (isLicenseAvailable && !isActivated)
      navigation.navigate(routes.SOFT_TOKEN_CHECKIC, {
        isFromBinding: true,
        disableBack: true,
      });
  };

  return {
    navigate,
    isSoftTokenFullyActivated,
    fromAccountCheck,
    softTokenStatusActivated,
    activateSoftToken,
    lastCheck,
  };
};
