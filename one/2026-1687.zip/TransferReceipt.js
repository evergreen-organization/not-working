import React, { useEffect, useState, useRef } from 'react';
import { ScrollView } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';

import { tagColors } from 'configs';
import { useApi, useAppRating, useHandleDispatch, usePostGuard } from 'hooks';
import { showFailure, showSuccess, displayReceiptDateTime, displayReceiptDate, isToday, maskAccount } from 'utils';
import routes from 'navigations/routes';
import {
  checkTransModeDuitNow,
  checkTransModeDuitNowTransfer,
  checkTransModeIBG,
  checkTransModeOwn,
  checkTransModePBB,
  duitnowIdType,
  favouriteType,
  findDuitnowIdTypeName,
  findTransferModeName,
  recurringFailedMsg,
  ApiDateFormat,
  backendDatetimeFormat,
  transferAccType,
  wordsSpacesRegex,
  APP_RATING_MODULE,
  ibgIdType,
  duitnowTransIdType,
} from 'constant';
import {
  addFavourite,
  addFavouriteStatus,
  getFundTransfer,
  getRecentFundTransfer,
  fundTransferRecentUpdated,
  fundTransferInit,
  getActiveFromAccCasa,
  getSecfaAuth,
  getCountryNameByCode,
  getRecentCardPayment,
  getRecentLoanPayment,
  cardPaymentRecentUpdated,
  loanPaymentRecentUpdated,
  getFestiveFundTransfer,
  delFavouriteById,
  getFavouriteByAccNo,
  submitOnHoldPurpose,
} from 'stores';
import { CustomScrollView, Screen } from 'atoms';
import { BottomDrawerModalMini, TableItemTag, IBGTime, QuickLinkItem } from 'molecules';
import { Recurring, Receipt as TranReceipt, ReceiptLinks, DoneButton, IBG, SaveFavourite, Text } from 'components';
import { authStorage } from 'auth/storage';
import DuitNowIcon from 'assets/images/corporation/duitnowfull.png';
import GiftCardIcon from 'assets/images/basiccolor/shareECard.png';
import { LOADING } from 'apis';
import { GiftCardModal, OnHoldPopUp } from './components';

import { useTranslation } from 'react-i18next';

const maxLength = 40;

const LANG_PREFIX = 'screens.fundTransferReceipt.text.';

export const TransferReceipt = ({ navigation, route }) => {
  useAppRating({ method: APP_RATING_MODULE.SEND_MONEY });
  const { clearUUID } = usePostGuard(false);
  const { t } = useTranslation();

  const { secfaInfo } = route.params || {};
  const transferMode = secfaInfo.sendMoneyType;

  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const fundTransfer = useSelector(getFundTransfer);
  const secfaAuth = useSelector(getSecfaAuth);
  const recent = useSelector(getRecentFundTransfer);
  const recentCard = useSelector(getRecentCardPayment);
  const recentLoan = useSelector(getRecentLoanPayment);
  const addStatus = useSelector(addFavouriteStatus);
  const casa = useSelector(getActiveFromAccCasa);
  const addFavouriteApi = useApi(addFavourite);
  const delFavouriteApi = useApi(delFavouriteById);

  const {
    name,
    favName: tranFavName,
    selectedBankId,
    selectedBankName,
    currency,
    tranDateTime,
    referenceNo,
    country,
    module,
    isESISuccess,
    isTrxOnHold,
    duitNowBizMsgId,
    rppStatusCode,
    tranPurpose,
    isSenderWhiteListed,
  } = fundTransfer || {};

  const payLoan = module === routes.PAY_LOAN;
  const payCard = module === routes.PAY_CARD;
  const countryName = useSelector(getCountryNameByCode(country));
  const { eGiftCardUrl } = useSelector(getFestiveFundTransfer) || {};
  const isDuitNowMode = checkTransModeDuitNow(transferMode);
  const isDuitNowTransferMode = checkTransModeDuitNowTransfer(transferMode);
  const isIBGMode = checkTransModeIBG(transferMode);
  const isOwnMode = checkTransModeOwn(transferMode);
  const isPBBMode = checkTransModePBB(transferMode);
  const beneName = secfaInfo.beneName ?? name ?? tranFavName;
  const fromAcc = secfaInfo.fromAccNo;
  const toAcc = isDuitNowMode ? secfaInfo.proxyValue : secfaInfo.beneAccNo;
  const idType = isDuitNowMode ? secfaInfo.proxyType : secfaInfo.beneAccType;
  const amount = secfaInfo.amount;
  const reference = secfaInfo.recipientRef;
  const paymentDetail = secfaInfo.otherPaymentDetails;
  const interval = secfaInfo.occurence;
  const frequency = secfaInfo.frequency;
  const ibgBeneId = secfaInfo.ibgBeneficiaryId;
  const ibgBeneIdType = secfaInfo.ibgBeneficiaryType;
  const actualDate = secfaInfo.tranDate;

  const isTodayTransaction = isToday(tranDateTime, backendDatetimeFormat, actualDate, ApiDateFormat);
  const isESICreated = frequency && isESISuccess;
  const showCardLoanFavMsg =
    idType === transferAccType.CARD.key ||
    idType === transferAccType.LOAN.key ||
    idType === transferAccType.HIRE_PURCHASE.key;

  const found = casa.accounts.find(item => item.accountNo === fromAcc);

  const [modalIBGVisible, setModalIBGVisible] = useState(false);
  const [isECardModalVisible, setIsECardModalVisible] = useState(false);
  const [onHoldPurposeVisible, setOnHoldPurposeVisible] = useState(tranPurpose?.length > 0);

  const saveFavRef = useRef();

  //to check if the recipient account is favorited
  const favAcc = useSelector(getFavouriteByAccNo({ accountNo: toAcc }));

  useEffect(() => {
    if (frequency && !isESISuccess) showFailure(t(recurringFailedMsg));

    return () => {
      updateRecent();
      dispatch(fundTransferInit());
      clearUUID().then();
      //TODO: show rating depends on indicator pass from backend
      // showAppRatingToast();
    };
  }, []);

  const handleSubmitPurpose = ({ id, tranPurpose }) => {
    handleDispatch(submitOnHoldPurpose({ isPublic: secfaAuth.isPublic, id, tranPurpose })).then();
    setOnHoldPurposeVisible(false);
  };

  const createFavItem = favName => {
    const type = getFavType();
    const item = { type, name: favName ?? beneName, beneName, accNo: toAcc, ibgBeneId, ibgBeneIdType };

    if (type === favouriteType.DUITNOW) {
      return {
        ...item,
        proxyType: fundTransfer?.idType,
        proxyCountry: country,
      };
    } else {
      const bankId = type === favouriteType.PBB ? 0 : selectedBankId;

      return {
        ...item,
        accCategory: fundTransfer?.idType,
        accType: null,
        bankId,
      };
    }
  };

  const updateRecent = () => {
    if (isOwnMode) return;

    if ((isDuitNowTransferMode || isIBGMode) && idType !== transferAccType.CASA.key) {
      if (idType === transferAccType.CARD.key) {
        const tempRecent = recentCard.filter(x => x.accNo !== toAcc);

        let list = [...tempRecent];
        if (list.length >= 5) list.shift();
        list.push(createFavItem());
        dispatch(cardPaymentRecentUpdated(list));
        authStorage.storeRecentCardPaymentBene(JSON.stringify(list)).then();
      } else {
        const tempRecent = recentLoan.filter(x => x.accNo !== toAcc);

        let list = [...tempRecent];
        if (list.length >= 5) list.shift();
        list.push(createFavItem());
        dispatch(loanPaymentRecentUpdated(list));
        authStorage.storeRecentLoanPaymentBene(JSON.stringify(list)).then();
      }
      return;
    }

    const tempRecent = recent.filter(x => x.accNo !== toAcc);

    let list = [...tempRecent];
    if (list.length >= 5) list.shift();
    list.push(createFavItem());
    dispatch(fundTransferRecentUpdated(list));
    authStorage.storeRecentTranBene(JSON.stringify(list)).then();
  };

  const onOKPress = () => {
    navigation.navigate(routes.MAIN_TAB);
  };

  const getFavType = () => {
    if (isPBBMode) return favouriteType.PBB;
    if (isDuitNowMode) return favouriteType.DUITNOW;
    if (isDuitNowTransferMode || isIBGMode) return favouriteType.OTHER;
    return null;
  };

  const onFavouriteConfirm = async val => {
    if (!wordsSpacesRegex.test(val)) return showFailure(t(LANG_PREFIX + 'failureMsgFavNameRegex'));
    const item = createFavItem(val);
    const result = await addFavouriteApi.request({ isPublic: secfaAuth.isPublic, ...item });
    if (result.problem) return showFailure(result.problem);
    const successMessage = showCardLoanFavMsg
      ? t(LANG_PREFIX + 'successMsgAddedFavCardLoan')
      : t(LANG_PREFIX + 'successMsgAddedFav');
    showSuccess(successMessage, '', 100);
    saveFavRef.current.closeModal();
  };

  const onFavouriteRemove = async () => {
    const result = await delFavouriteApi.request({
      isPublic: secfaAuth.isPublic,
      id: favAcc?.id,
    });
    if (result.problem) return showFailure(result.problem);
    showSuccess(t(LANG_PREFIX + 'successMsgRemovedFav'));
  };

  const handleOpenECardsModal = () => setIsECardModalVisible(true);
  const handleCloseECardsModal = () => setIsECardModalVisible(false);

  const Content = () => (
    <>
      <TableItemTag title={t(LANG_PREFIX + 'itemRefNo')} value={referenceNo} />
      <TableItemTag title={t(LANG_PREFIX + 'itemDateTime')} value={displayReceiptDateTime(tranDateTime)} />
      {!isTodayTransaction && (
        <TableItemTag title={t(LANG_PREFIX + 'itemTransferDate')} value={displayReceiptDate(actualDate)} />
      )}
      {!!duitNowBizMsgId && <TableItemTag title={t(LANG_PREFIX + 'itemDuitNowReferenceNo')} value={duitNowBizMsgId} />}
      {!!rppStatusCode && <TableItemTag title={t(LANG_PREFIX + 'itemDuitNowStatusCode')} value={rppStatusCode} />}
      <TableItemTag
        title={t(LANG_PREFIX + 'itemTransferMethod')}
        value={t(findTransferModeName(transferMode))}
        {...((isDuitNowMode || isDuitNowTransferMode) && { icon: DuitNowIcon })}
      />
      {reference && <TableItemTag title={t(LANG_PREFIX + 'itemRecipientReference')} value={reference} />}
      {paymentDetail && <TableItemTag title={t(LANG_PREFIX + 'itemPaymentDetail')} value={paymentDetail} />}
      {isDuitNowMode ? (
        <>
          <TableItemTag title={t(LANG_PREFIX + 'itemIDType')} value={t(findDuitnowIdTypeName(idType))} />
          {idType === duitnowIdType.PASSPORT.key && (
            <TableItemTag title={t(LANG_PREFIX + 'itemCountry')} value={countryName} />
          )}
          <TableItemTag
            title={t(LANG_PREFIX + 'itemRecipientID')}
            value={beneName}
            tagList={[{ title: toAcc, color: tagColors.red, style: { marginTop: 3 }, fontStyle: { fontSize: 14 } }]}
          />
        </>
      ) : (
        <>
          <TableItemTag title={t(LANG_PREFIX + 'itemRecipientBank')} value={selectedBankName} />
          <TableItemTag
            title={t(LANG_PREFIX + 'itemRecipientAcc')}
            value={beneName}
            tagList={[{ title: toAcc, color: tagColors.red, style: { marginTop: 3 }, fontStyle: { fontSize: 14 } }]}
          />
        </>
      )}
    </>
  );

  const title = () => {
    if (isTodayTransaction) {
      if (payCard) return t(LANG_PREFIX + 'titleCardPaid');
      if (payLoan) return t(LANG_PREFIX + 'titleLoanPaid');
      return t(LANG_PREFIX + 'titleMoneySent');
    }
    return t(LANG_PREFIX + 'titleAccepted');
  };

  const getIdTypeName = key => {
    if (isIBGMode) return t(ibgIdType[key]?.langCode);
    if (isDuitNowTransferMode) return t(duitnowTransIdType[key]?.langCode);
  };

  return (
    <Screen singlePage>
      <CustomScrollView showsVerticalScrollIndicator={false}>
        <TranReceipt
          animation
          amount={amount}
          currency={currency}
          {...(isTrxOnHold
            ? {
                type: 'pending',
                title: t(LANG_PREFIX + 'titleOnHold'),
                titleDesc: (
                  <Text style={{ fontSize: 13, paddingTop: 10, textAlign: 'center' }}>
                    {t(LANG_PREFIX + 'titleOnHoldCancelDesc')}
                  </Text>
                ),
              }
            : {
                title: title(),
              })}
          desc={
            <>
              <Content />

              {ibgBeneIdType && (
                <>
                  <TableItemTag title={t(LANG_PREFIX + 'itemBeneIDType')} value={getIdTypeName(ibgBeneIdType)} />

                  <TableItemTag title={t(LANG_PREFIX + 'itemBeneID')} value={ibgBeneId} />
                </>
              )}

              <TableItemTag
                title={t(LANG_PREFIX + 'itemFromAcc')}
                value={found?.accountDesc}
                tagList={[
                  { title: fromAcc, color: tagColors.grey, style: { marginTop: 3 }, fontStyle: { fontSize: 14 } },
                ]}
              />
              <TableItemTag
                title={t(LANG_PREFIX + 'itemNewBal')}
                value={found?.availableBalance}
                currency={currency}
                isLast={true}
              />
            </>
          }
        />

        {isESICreated && <Recurring date={actualDate} interval={interval} frequency={frequency} />}
        {isIBGMode && <IBG />}
      </CustomScrollView>

      {!isTrxOnHold && (
        <ReceiptLinks
          {...(!isOwnMode && {
            extraButton: (
              <SaveFavourite
                ref={saveFavRef}
                name={beneName}
                maxLength={maxLength}
                isFavourite={!!favAcc?.accNo}
                onAdd={onFavouriteConfirm}
                onRemove={onFavouriteRemove}
                isDisabled={addStatus === LOADING}
                {...(showCardLoanFavMsg && { info: t(`${LANG_PREFIX}infoCardLoanFav`) })}
              />
            ),
          })}
          {...(eGiftCardUrl?.length > 0 && {
            centerButton: (
              <QuickLinkItem
                style={{ flex: 0.5 }}
                icon={GiftCardIcon}
                label={t(`${LANG_PREFIX}buttonShareGiftCard`)}
                onPress={handleOpenECardsModal}
                iconStyle={{ width: 28, height: 28 }}
              />
            ),
          })}
          content={
            <TranReceipt
              amount={amount}
              currency={currency}
              title={title()}
              desc={
                <>
                  <Content />
                  {ibgBeneIdType && (
                    <>
                      <TableItemTag title={t(LANG_PREFIX + 'itemBeneIDType')} value={getIdTypeName(ibgBeneIdType)} />
                      <TableItemTag title={t(LANG_PREFIX + 'itemBeneID')} value={maskAccount(ibgBeneId)} />
                    </>
                  )}
                  <TableItemTag title={t(LANG_PREFIX + 'itemFromAcc')} value={maskAccount(fromAcc)} isLast={true} />
                </>
              }
            />
          }
        />
      )}
      <DoneButton onPress={onOKPress} />

      <BottomDrawerModalMini isVisible={modalIBGVisible} closeModal={() => setModalIBGVisible(false)}>
        <ScrollView>
          <IBGTime />
        </ScrollView>
      </BottomDrawerModalMini>

      {eGiftCardUrl?.length > 0 && <GiftCardModal isVisible={isECardModalVisible} onClose={handleCloseECardsModal} />}
      {tranPurpose?.length > 0 && (
        <BottomDrawerModalMini
          variant={BottomDrawerModalMini.variants.modalize}
          isVisible={onHoldPurposeVisible}
          closeModal={() => {}}
          showCancel={false}
          closeOnOverlayTap={false}
        >
          <OnHoldPopUp handleSubmit={handleSubmitPurpose} data={tranPurpose} isWhiteListed={isSenderWhiteListed} />
        </BottomDrawerModalMini>
      )}
    </Screen>
  );
};

export default TransferReceipt;
