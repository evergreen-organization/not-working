import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { authStorage } from 'auth/storage';
import routes from 'navigations/routes';
import { usePostGuard, useTranApiSubmit } from 'hooks';
import { CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MSG, proxyManageType, tranApiType } from 'constant';
import {
  duitNowIdAvailableItemAdded,
  duitNowIdAvailableItemRemoved,
  duitNowIdRegisteredItemAccountUpdated,
  duitNowIdRegisteredItemAdded,
  duitNowIdRegisteredItemRemoved,
  duitNowIdRegisteredItemStatusUpdated,
  referenceNoUpdated,
  tranDateTimeUpdated,
  updateAccountBalance,
  updateCardBalance,
  updateNewBillObject,
  updateNewJompayObject,
  updateSuccessTransaction,
  updateCardlessWithdrawObject,
  fundTransferESISuccessUpdated,
  updateNewBakongObject,
  fundTransferTrxOnHoldUpdated,
  updateNewAlipayPlusObject,
  storeBiometric,
  carbonPaymentChallengeCompleted,
  updateGoldReceiptData,
  updateGoldNewBalance,
  updateInvestBalance,
  updateSoftTokenObject,
  updateNewTopUpObject,
  duitNowBizMsgIdUpdated,
  duitNowStatusCodeUpdated,
  logout,
  getErrorMessage,
  updateAuthObject,
  updateCashAdvanceObject,
  updateCardAccount,
} from 'stores';

import { Challenge } from './component';
import { useTranslation } from 'react-i18next';
import { showFailure } from 'utils';

export const AAOPChallenge = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.aaopChallenge.text.';
  usePostGuard();

  const dispatch = useDispatch();
  const { type, onSubmitParam, onSuccessParam } = route?.params || {};
  const tranApiUtils = useTranApiSubmit({ type, navigation });
  const junction = tranApiUtils.checkJunction();
  const isPublic = tranApiUtils.isPublicJunction(junction);
  const cqLockedMessage = useSelector(getErrorMessage('L00007'));

  const onChallengeSuccess = async result => {
    const { deviceTokenCookie } = result;
    if (deviceTokenCookie) authStorage.storeDeviceTokenCookie(deviceTokenCookie).then();

    if (type === tranApiType.FUND_TRANSFER) {
      //CASA only
      dispatch(referenceNoUpdated(result.refNo));
      dispatch(tranDateTimeUpdated(result.tranDateTime));
      dispatch(fundTransferESISuccessUpdated(result.isESISuccess));
      dispatch(fundTransferTrxOnHoldUpdated({ isTrxOnHold: result.isTrxOnHold, tranPurpose: result.tranPurpose, isSenderWhiteListed: result?.isSenderWhiteListed }));
      dispatch(duitNowBizMsgIdUpdated(result?.duitNowBizMsgId));
      dispatch(duitNowStatusCodeUpdated(result?.rppStatusCode));
      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
          currentBalance: result.currentBalance,
        }),
      );
    } else if (type === tranApiType.LOCK_FUND || type === tranApiType.LOCK_FUND_INCREASE) {
      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
          currentBalance: result.currentBalance,
          lockedAmount: result.lockedAmount,
          holdAmount: result.holdAmount,
        }),
      );
    } else if (type === tranApiType.DUITNOW_MANAGEMENT) {
      if (onSubmitParam.duitNowManageType === proxyManageType.DEREGISTER) {
        dispatch(duitNowIdRegisteredItemRemoved(onSubmitParam));
        dispatch(duitNowIdAvailableItemAdded(onSubmitParam));
      } else if (
        onSubmitParam.duitNowManageType === proxyManageType.ACTIVATE ||
        onSubmitParam.duitNowManageType === proxyManageType.DEACTIVATE
      ) {
        dispatch(duitNowIdRegisteredItemStatusUpdated(onSubmitParam));
      } else {
        dispatch(duitNowIdRegisteredItemAccountUpdated(onSubmitParam));
      }
    } else if (type === tranApiType.DUITNOW_REGISTRATION) {
      dispatch(duitNowIdAvailableItemRemoved(onSubmitParam));
      dispatch(duitNowIdRegisteredItemAdded(result.updatedProxy));
    } else if (type === tranApiType.QR_PAYMENT) {
      // CASA and card
      dispatch(updateSuccessTransaction(result));
      if (result.outstandingBalance)
        dispatch(
          updateCardBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            outstandingBalance: result.outstandingBalance,
          }),
        );
      else
        dispatch(
          updateAccountBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            currentBalance: result.currentBalance,
          }),
        );
    } else if (type === tranApiType.BILL_PAYMENT) {
      // CASA and card
      dispatch(
        updateNewBillObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
          isESISuccess: result.isESISuccess,
          availableBalance: result.availableBalance,
        }),
      );
      if (result.outstandingBalance)
        dispatch(
          updateCardBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            outstandingBalance: result.outstandingBalance,
          }),
        );
      else
        dispatch(
          updateAccountBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            currentBalance: result.currentBalance,
          }),
        );
    } else if (type === tranApiType.JOMPAY_PAYMENT) {
      // CASA and card
      dispatch(
        updateNewJompayObject({
          referenceNo: result.refNo,
          jompayReferenceNo: result.nbpsRefNo,
          tranDateTime: result.tranDateTime,
          isESISuccess: result.isESISuccess,
          availableBalance: result.availableBalance,
        }),
      );
      if (result.outstandingBalance)
        dispatch(
          updateCardBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            outstandingBalance: result.outstandingBalance,
          }),
        );
      else
        dispatch(
          updateAccountBalance({
            fromAcc: onSubmitParam?.fromAcc,
            availableBalance: result.availableBalance,
            currentBalance: result.currentBalance,
          }),
        );
    } else if (type === tranApiType.CARDLESS_WITHDRAW) {
      dispatch(
        updateCardlessWithdrawObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
          tCode: result.tCode,
          availableBalance: result.availableBalance,
        }),
      );
      if (result.currentBalance && result.availableBalance)
        dispatch(
          updateAccountBalance({
            fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
            availableBalance: result.availableBalance,
            currentBalance: result.currentBalance,
          }),
        );
    } else if (type === tranApiType.BAKONG_TRANSFER) {
      dispatch(
        updateNewBakongObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
          bakongRefNo: result.bakongRefNo,
          availableBalance: result.availableBalance,
        }),
      );

      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
          currentBalance: result.currentBalance,
        }),
      );
    } else if (type === tranApiType.ALIPAY_PLUS) {
      dispatch(
        updateNewAlipayPlusObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
          aplusRefNo: result.aplusRefNo,
          aplusRefOrderId: result.aplusRefOrderId,
          customerId: result.customerId,
          availableBalance: result.availableBalance,
        }),
      );

      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
          currentBalance: result.currentBalance,
        }),
      );
    } else if (type === tranApiType.CARBON_OFFSET) {
      dispatch(carbonPaymentChallengeCompleted(result));
      dispatch(
        updateAccountBalance({
          fromAcc: onSuccessParam?.secfaInfo.fromAccNo,
          availableBalance: result.availableBalance,
        }),
      );
    } else if (type === tranApiType.GOLD_SELL) {
      dispatch(updateGoldNewBalance({ currentBalance: result.currentBalance }));
      dispatch(
        updateInvestBalance({
          fromAccNo: onSuccessParam.secfaInfo.fromAccNo,
          currentBalance: result.currentBalance,
          availableBalance: result.availableBalance,
        }),
      );
      dispatch(
        updateGoldReceiptData({
          refNo: result.refNo,
          tranDateTime: result.tranDateTime,
          totalAmount: result?.totalAmount,
        }),
      );
    } else if (type === tranApiType.GOLD_CLOSE_ACC) {
      dispatch(
        updateGoldReceiptData({
          refNo: result.refNo,
          tranDateTime: result.tranDateTime,
          totalAmount: result?.totalAmount,
        }),
      );
    } else if (type === tranApiType.RESET_PIN || type === tranApiType.CHANGE_PIN) {
      if (onSubmitParam?.isBioStored) dispatch(storeBiometric(onSubmitParam?.pin, true));
    } else if (type === tranApiType.CQ_ENROLMENT || type === tranApiType.CQ_CHANGE) {
      dispatch(
        updateSoftTokenObject({
          processedTime: result.processedTime,
          coolingOffHour: result.coolingOffHour,
          cqActivationStatus: result.cqActivationStatus,
        }),
      );
    } else if (type === tranApiType.QUICK_PAYMENT_LIMIT) {
      dispatch(
        updateSoftTokenObject({
          quickLimit: onSubmitParam?.quickLimit,
        }),
      );
    } else if (type === tranApiType.TOP_UP) {
      dispatch(
        updateNewTopUpObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
          availableBalance: result.availableBalance,
        }),
      );
    } else if (type === tranApiType.CASH_ADVANCE) {
      dispatch(
        updateCashAdvanceObject({
          referenceNo: result.refNo,
          tranDateTime: result.tranDateTime,
        }),
      );
      dispatch(
        updateCardBalance({
          fromAcc: onSubmitParam?.fromAcc,
          availableBalance: result.availableBalance,
          outstandingBalance: result.outstandingBalance,
        }),
      );
    } else if (type === tranApiType.PASSWORD_LOGIN || type === tranApiType.PASSWORD_LOGIN_MODAL) {
      dispatch(
        updateAuthObject({
          isPBeUser: result.isPBORegistered,
          secfaType: result.secfaType,
          email: result.email,
          pbeEmail: result.pbeEmail,
        }),
      );
    } else if (type === tranApiType.UPDATE_CARD_PIN) {
      dispatch(updateCardAccount({ fromAcc: onSuccessParam?.secfaInfo.fromAccNo }));
    }

    tranApiUtils.onSuccess({ extraParam: onSuccessParam, apiResponse: result });
  };

  const onChallengeFailure = result => {
    const { deviceTokenCookie } = result;
    if (deviceTokenCookie) authStorage.storeDeviceTokenCookie(deviceTokenCookie).then();

    if (result.status === CONNECTION_TIMEOUT) {
      tranApiUtils.onFailure({
        title: t(CONNECTION_TIMEOUT_MSG),
        message: t(`${LANG_PREFIX}timeoutDesc`),
      });
    } else {
      tranApiUtils.onFailure({
        title: tranApiUtils.failureTitle(result?.status),
        message: result.problem,
        extraParam: onSuccessParam,
        data: result?.data,
        status: result?.status,
      });
    }
  };

  //When backend returns cqRemainingAttempt: 1, failing to answer will lock id.
  //If user quits without answering, the ID will be locked on subsequent login, the current login session will still be active.
  //App to force logout if user quits without answering to end the login session.

  //When backend returns cqRemainingAttempt: 1, app to depend on failed attempt counter.
  //Note: Only AIFPS to force logout with logic above, AAOP not applicable.
  const onCancelChallenge = ({ attemptCount, cqRemainingAttempt, message }) => {
    navigation.navigate(routes.MAIN_TAB);

    if (type === tranApiType.CQ_ENROLMENT || type === tranApiType.PBSS_CQ_ENROLMENT_VALIDATE_PAC) {
      dispatch(logout());
      return;
    }

    if (cqRemainingAttempt === 1 || attemptCount === 0) {
      showFailure(cqLockedMessage);
      dispatch(logout());
      return;
    }

    navigation.navigate(routes.SOFT_TOKEN_FAIL, { message });
  };

  return (
    <Challenge
      fullScreen={true}
      type={type}
      isPublic={isPublic}
      onSuccess={onChallengeSuccess}
      onFailure={onChallengeFailure}
      onCancelChallenge={onCancelChallenge}
    />
  );
};

export default AAOPChallenge;
