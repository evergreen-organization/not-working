import { createSlice, isAnyOf } from '@reduxjs/toolkit';
import {
  addFavourite,
  delFavourite,
  getFavourite,
  getFestive,
  nameInquiry,
  submitFundTransfer,
  delFavouriteById,
} from './thunk';
import { IDLE } from 'apis';

const initialState = {
  newTransfer: {
    fromAcc: null,
    toAcc: null,
    name: null,
    idType: null, //NOTE: accType for DuitNow Transfer / IBG; idType for DuitNow
    transferMode: null,
    selectedBankId: null,
    selectedBankName: null,
    currency: null,
    amount: 0,
    reference: null,
    favName: null,
    tranDateTime: null,
    ibgBeneIdType: null,
    ibgFav: false,
    duitNowBizMsgId: null,
    rppStatusCode: null,
    tranPurpose: [],
    isSenderWhiteListed: false,
  },
  nameInquiryStatus: {
    status: 'idle',
    errMsg: null,
  },
  recent: [],
  favourite: {
    addStatus: 'idle',
    favouriteStatus: 'idle',
    list: [],
  },
  festive: {
    recipientRefs: [],
    eGiftCardUrl: [],
    festiveStatus: IDLE,
  },
};

const slice = createSlice({
  name: 'fundTransfer',
  initialState,
  reducers: {
    fundTransferReset: _ => initialState,
    fundTransferInit: state => {
      state.newTransfer = initialState.newTransfer;
      state.nameInquiryStatus = initialState.nameInquiryStatus;
    },
    fromAccountUpdated: (state, { payload }) => {
      state.newTransfer.fromAcc = payload;
    },
    toAccountUpdated: (state, { payload }) => {
      state.newTransfer.toAcc = payload;
    },
    toAccountNameUpdated: (state, { payload }) => {
      state.newTransfer.name = payload;
    },
    moduleUpdated: (state, { payload }) => {
      state.newTransfer.module = payload;
    },
    idTypeUpdated: (state, { payload }) => {
      state.newTransfer.idType = payload;
    },
    transferModeUpdated: (state, { payload }) => {
      state.newTransfer.transferMode = payload;
    },
    selectedBankUpdated: (state, { payload }) => {
      state.newTransfer.selectedBankId = payload.id;
      state.newTransfer.selectedBankName = payload.name;
    },
    currencyUpdated: (state, { payload }) => {
      state.newTransfer.currency = payload;
    },
    amountUpdated: (state, { payload }) => {
      state.newTransfer.amount = payload;
    },
    nameInquiryStatusUpdated: (state, { payload }) => {
      state.nameInquiryStatus.status = payload.status;
      state.nameInquiryStatus.errMsg = payload.errMsg;
    },
    referenceUpdated: (state, { payload }) => {
      state.newTransfer.reference = payload;
    },
    referenceNoUpdated: (state, { payload }) => {
      state.newTransfer.referenceNo = payload;
    },
    fundTransferESISuccessUpdated: (state, { payload }) => {
      state.newTransfer.isESISuccess = payload;
    },
    fundTransferTrxOnHoldUpdated: (state, { payload }) => {
      state.newTransfer.isTrxOnHold = payload.isTrxOnHold;
      if (payload.tranPurpose) state.newTransfer.tranPurpose = payload.tranPurpose;
      if (payload.isSenderWhiteListed) state.newTransfer.isSenderWhiteListed = payload.isSenderWhiteListed;
    },
    tranDateTimeUpdated: (state, { payload }) => {
      state.newTransfer.tranDateTime = payload;
    },
    countryUpdated: (state, { payload }) => {
      state.newTransfer.country = payload;
    },
    ibgBeneIdUpdated: (state, { payload }) => {
      state.newTransfer.ibgBeneId = payload;
    },
    ibgBeneIdTypeUpdated: (state, { payload }) => {
      state.newTransfer.ibgBeneIdType = payload;
    },
    favNameUpdated: (state, { payload }) => {
      state.newTransfer.favName = payload;
    },
    fundTransferRecentUpdated: (state, { payload }) => {
      state.recent = payload;
    },
    isIbgFavUpdated: (state, { payload }) => {
      state.newTransfer.ibgFav = payload;
    },
    duitNowBizMsgIdUpdated: (state, { payload }) => {
      state.newTransfer.duitNowBizMsgId = payload;
    },
    duitNowStatusCodeUpdated: (state, { payload }) => {
      state.newTransfer.rppStatusCode = payload;
    },
  },
  extraReducers: builder => {
    builder.addCase(getFavourite.fulfilled, (state, { payload }) => {
      state.favourite.favouriteStatus = 'succeeded';
      state.favourite.list = payload.favourites;
    });
    builder.addCase(getFavourite.pending, state => {
      state.favourite.favouriteStatus = 'loading';
    });
    builder.addCase(getFavourite.rejected, state => {
      state.favourite.favouriteStatus = 'failed';
    });
    builder.addCase(getFestive.fulfilled, (state, { payload }) => {
      state.festive.festiveStatus = 'succeeded';
      if (payload.recipientRefs && payload.recipientRefs.length > 0)
        state.festive.recipientRefs = payload.recipientRefs;
      if (payload.eGiftCardUrl && payload.eGiftCardUrl.length > 0) state.festive.eGiftCardUrl = payload.eGiftCardUrl;
    });
    builder.addCase(getFestive.pending, state => {
      state.festive.festiveStatus = 'loading';
    });
    builder.addCase(getFestive.rejected, state => {
      state.festive.festiveStatus = 'failed';
    });
    builder.addCase(nameInquiry.fulfilled, (state, { payload }) => {
      const { beneName, isDuitNowOnUs } = payload;
      state.nameInquiryStatus.status = 'succeeded';
      state.newTransfer.name = beneName;
      state.newTransfer.isDuitNowOnUs = isDuitNowOnUs;
      state.nameInquiryStatus.errMsg = payload?.status + ': ' + payload.data?.message;
    });
    // Already update loading before ping api
    // [nameInquiry.pending]: (state) => {
    //   state.nameInquiryStatus.status = "loading"
    // },
    builder.addCase(nameInquiry.rejected, (state, { payload }) => {
      state.nameInquiryStatus.status = 'failed';
      state.nameInquiryStatus.errMsg = payload?.status + ': ' + payload.data?.message;
    });
    builder.addCase(submitFundTransfer.fulfilled, (state, { payload }) => {
      state.newTransfer.referenceNo = payload.refNo;
      state.newTransfer.tranDateTime = payload.tranDateTime;
      state.newTransfer.isESISuccess = payload.isESISuccess;
      state.newTransfer.isTrxOnHold = payload.isTrxOnHold;
      state.newTransfer.duitNowBizMsgId = payload.duitNowBizMsgId;
      state.newTransfer.rppStatusCode = payload.rppStatusCode;
      if (payload?.tranPurpose) state.newTransfer.tranPurpose = payload?.tranPurpose;
      if (payload?.isSenderWhiteListed) state.newTransfer.isSenderWhiteListed = payload?.isSenderWhiteListed;
    });
    builder.addCase(addFavourite.fulfilled, (state, { payload, meta }) => {
      state.favourite.addStatus = 'succeeded';
      const { isPublic, ...rest } = meta.arg;
      const item = { id: payload.id, ...rest };
      state.favourite.list.push(item);
    });
    builder.addCase(delFavourite.fulfilled, (state, { meta }) => {
      state.favourite.addStatus = 'succeeded';
      const newList = state.favourite.list.filter(item => item.accNo !== meta.arg.toAcc);
      state.favourite.list = newList;
    });
    builder.addCase(delFavouriteById.fulfilled, (state, { meta }) => {
      state.favourite.addStatus = 'succeeded';
      const { id } = meta.arg;
      const newList = state.favourite.list.filter(item => !(item.id === id));
      state.favourite.list = newList;
    });
    builder.addMatcher(isAnyOf(addFavourite.pending, delFavourite.pending), state => {
      state.favourite.addStatus = 'loading';
    });
    builder.addMatcher(isAnyOf(addFavourite.rejected, delFavourite.rejected), state => {
      state.favourite.addStatus = 'failed';
    });
    builder.addMatcher(isAnyOf(addFavourite.pending, delFavouriteById.pending), state => {
      state.favourite.addStatus = 'loading';
    });
    builder.addMatcher(isAnyOf(addFavourite.rejected, delFavouriteById.rejected), state => {
      state.favourite.addStatus = 'failed';
    });
  },
});

export const {
  fundTransferInit,
  fundTransferReset,
  fromAccountUpdated,
  toAccountUpdated,
  toAccountNameUpdated,
  moduleUpdated,
  idTypeUpdated,
  transferModeUpdated,
  selectedBankUpdated,
  currencyUpdated,
  amountUpdated,
  nameInquiryStatusUpdated,
  referenceUpdated,
  referenceNoUpdated,
  fundTransferESISuccessUpdated,
  fundTransferTrxOnHoldUpdated,
  tranDateTimeUpdated,
  countryUpdated,
  fundTransferRecentUpdated,
  ibgBeneIdUpdated,
  ibgBeneIdTypeUpdated,
  favNameUpdated,
  isIbgFavUpdated,
  duitNowBizMsgIdUpdated,
  duitNowStatusCodeUpdated,
} = slice.actions;

export default slice.reducer;
