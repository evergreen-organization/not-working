import React, { useEffect, useState } from 'react';
import { BackHandler, View } from 'react-native';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';

import { Divider, Text } from 'atoms';
import { Form, FormButtonBottom, FormConditionalDisplay, FormField, FormSelectMany } from 'components/forms';
import { alphanumericSpaceRegex } from 'constant';
import { styles } from './styles';

export const OnHoldPopUp = ({ handleSubmit, data, isWhiteListed = false }) => {
  const { t } = useTranslation();
  const LANG_PREFIX_ONHOLD = 'screens.fundTransferOnHold.text.';

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      return true;
    });
    return () => {
      backHandler.remove();
    };
  }, []);

  const validationSchema = Yup.object().shape({
    purposes: Yup.array()
      .min(1, t(`${LANG_PREFIX_ONHOLD}failureMsgTransPurpose`))
      .required(t(`${LANG_PREFIX_ONHOLD}failureMsgTransPurpose`)),
    otherPurpose: Yup.string()
      .test('not-empty-or-spaces', t(`${LANG_PREFIX_ONHOLD}validationMsgFieldRequired`), value => {
        if (typeof value !== 'string') return true;
        return value.trim().length > 0;
      })
      .matches(alphanumericSpaceRegex, t(`${LANG_PREFIX_ONHOLD}regexMsg`))
      .max(20, t(`${LANG_PREFIX_ONHOLD}validationMsgCharsLimit`))
      .when('purposes', {
        is: (purposes = []) => {
          const selected = data.find(p => purposes.includes(p.id));
          return selected?.isFreeTextRequired === true;
        },
        then: schema => schema.required(t(`${LANG_PREFIX_ONHOLD}validationMsgFieldRequired`)),
        otherwise: schema => schema.notRequired(),
      }),
  });

  const renderHeader = () => (
    <View style={styles.container}>
      {isWhiteListed ? (
        <Text as={Text.type.H6} bold style={styles.titleText}>
          {t(`${LANG_PREFIX_ONHOLD}titleOnHoldWhitelist`)}
        </Text>
      ) : (
        <Text as={Text.type.H6} bold style={styles.titleText}>
          {t(`${LANG_PREFIX_ONHOLD}titleOnHold2`)}{' '}
          <Text as={Text.type.H6} bold style={styles.redText}>
            {t(`${LANG_PREFIX_ONHOLD}titleOnHold`)}
          </Text>
          .
        </Text>
      )}
      <View style={styles.subtitleView}>
        <Text style={styles.subtitleText}>
          {t(`${LANG_PREFIX_ONHOLD}${isWhiteListed ? 'titleOnHoldWhitelistDesc' : 'titleOnHoldDesc'}`)}
        </Text>
        <Text style={styles.subtitleText2}>{t(`${LANG_PREFIX_ONHOLD}itemPurposeSelection`)}</Text>
        <Divider style={styles.divider} />
      </View>
    </View>
  );

  const onSubmit = async values => {
    setLoading(true);
    const { purposes, otherPurpose } = values || {};
    if (!purposes || purposes?.length === 0) {
      return setLoading(false);
    }

    const selectedPurpose = data.find(item => item.id === purposes[0]);

    handleSubmit({
      id: selectedPurpose.id,
      ...(selectedPurpose?.isFreeTextRequired && { tranPurpose: otherPurpose ?? '' }),
    });
    setLoading(false);
  };

  return (
    <Form
      initialValues={{ purposes: [], otherPurpose: '' }}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
      header={renderHeader()}
      button={
        <FormButtonBottom
          loading={loading}
          buttonStyle={styles.buttonSubmit}
          title={t(`${LANG_PREFIX_ONHOLD}titleSubmit`)}
        />
      }
    >
      <FormSelectMany
        name='purposes'
        data={data?.map(item => ({ id: item.id, name: item.purpose }))}
        t={t}
        multiple={false}
        showError={true}
      />
      <FormConditionalDisplay
        condition={({ purposes }) => purposes?.some(id => data?.find(p => p.id === id)?.isFreeTextRequired)}
      >
        <View style={styles.otherPurpose}>
          <FormField
            name='otherPurpose'
            placeholder={t(`${LANG_PREFIX_ONHOLD}itemSpecifyPurpose`)}
            autoCapitalize='none'
            maxLength={20}
            showCounter
            style={styles.otherInput}
          />
        </View>
      </FormConditionalDisplay>
    </Form>
  );
};
