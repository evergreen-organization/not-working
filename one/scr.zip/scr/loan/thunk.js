import { createAsyncThunk } from '@reduxjs/toolkit';
import { apiEndpoint } from 'apis/apiUtils';
import { client } from 'apis/client';
import { Demo } from 'constant';
import { privateClient } from 'apis/privateClient';

export const getLanguageData = createAsyncThunk(
  'updateLanguage',
  async (
    { isPublic, deviceId, encryptedId, languageCode, languageVersion, appLanguageVersion },
    { getState, rejectWithValue },
  ) => {
    if (Demo.User.Check(getState)) return Demo.Language.Update({ languageCode, languageVersion, appLanguageVersion });
    const request = {
      deviceId,
      encryptedId,
      languageCode,
      languageVersion,
      appLanguageVersion,
    };
    let result;
    if (isPublic) result = await client.post(`${apiEndpoint.public}/updateLanguage`, request);
    else result = await privateClient.post(`${apiEndpoint.private}/updateLanguage`, request);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
