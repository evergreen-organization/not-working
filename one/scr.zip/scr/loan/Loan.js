import React, { useEffect } from 'react';
import { ScrollView, TouchableOpacity, Image } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import routes from 'navigations/routes';
import { displayDateTime, useAccessControl } from 'utils';
import { colors, newTagColor, tagColors } from 'configs';
import { getLoan, loadLoanHistory, resetLoanHistory, updateNewLoanPaymentObject } from 'stores';

import { ScreenFull, Space } from 'atoms';
import { NavBar } from 'organisms';

import HistoryIcon from 'assets/images/basiccolor/history.png';
import LoanIcon from 'assets/images/basiccolor/loan.png';

import {
  AccountDetailsTable,
  BalanceAmount,
  InstallmentDetails,
  OthersQuickLinkSection,
  ProductDetailsTable,
} from './components';
import { useTranslation } from 'react-i18next';
import { balanceAmountColorSets } from 'screens/accounts/utils';
import CustomerServiceIcon from 'assets/images/icon/customerService.png';
import { HIRE_PURCHASE_ACC_TYPE, LOAN_COMPANY_TYPE } from 'screens/accounts/constant/loan';

export const Loan = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.loanDetails.text.';

  const dispatch = useDispatch();
  const store_loan = useSelector(getLoan);
  const accountIndex = store_loan.accounts.findIndex(
    item => item.accountNo === route.params?.accountNo && item.noteNo === route.params?.noteNo,
  );
  const accessControl = useAccessControl({ navigation });

  useEffect(() => {
    return () => dispatch(resetLoanHistory());
  }, []);

  const {
    accountNo,
    noteNo,
    accountDesc,
    accountStatus,
    statusType,
    nickName,
    outstandingBalance,
    currency,
    installment,
    interestRate,
    term,
    overdueAmount,
    nextDueDate,
    lastPaymentAmount,
    lastTranDate,
    vehicleInfo,
    siStatus,
    siAccNo,
    accountType,
    company,
    branch,
    commencementDate,
    maturityDate,
    loanAmount,
    originalTerm,
    staffAcc,
  } = store_loan.accounts[accountIndex] || {};

  const handleShowHPInfo = () => navigation.navigate(routes.HIRE_PURCHASE_INFO);

  const showHistory = () => {
    navigation.navigate(routes.TRAN_HISTORY, {
      item: getLoan,
      load: loadLoanHistory,
      loadParam: { accountNo, noteNo },
      currency,
    });
  };

  const payLoan = () => {
    dispatch(updateNewLoanPaymentObject({ toAcc: accountNo, favName: accountDesc, noteNo }));
    accessControl.navigate(routes.PAY_LOAN_AMOUNT);
  };

  const vehicleInfoTagList = [
    { title: vehicleInfo?.carRegNo, color: newTagColor.grey, style: { borderColor: newTagColor.red.secondary } },
    { title: vehicleInfo?.carYear, color: newTagColor.grey, style: { borderColor: newTagColor.red.secondary } },
  ];

  const tableItems = [
    ...(accountType === HIRE_PURCHASE_ACC_TYPE
      ? [
        {
          title: t(`${LANG_PREFIX}itemVehicleInfo`),
          value: vehicleInfo?.carModel,
          tagList: vehicleInfo?.carRegNo ? vehicleInfoTagList : [],
        },
      ]
      : []),
    {
      title: t(`${LANG_PREFIX}itemAccountName`),
      value: accountDesc,
    },
    { title: t(`${LANG_PREFIX}itemAccountNo`), value: accountNo, copyable: true },
    { title: t(`${LANG_PREFIX}itemNoteNo`), value: noteNo },
    {
      title:
        accountType === HIRE_PURCHASE_ACC_TYPE
          ? company === LOAN_COMPANY_TYPE.PBB
            ? t(`${LANG_PREFIX}itemInstalmentOverdue`)
            : t(`${LANG_PREFIX}itemPaymentDue`)
          : t(`${LANG_PREFIX}itemOverdueBalance`),
      value: overdueAmount,
      currency: currency,
    },
  ];

  const productDescriptionList = [
    { title: t(`${LANG_PREFIX}accountHoldingBranch`), value: branch },
    { title: t(`${LANG_PREFIX}commencementDate`), value: displayDateTime(commencementDate) },
    { title: t(`${LANG_PREFIX}maturityDate`), value: displayDateTime(maturityDate) },
    { title: t(`${LANG_PREFIX}loanAmount`), value: loanAmount, currency: currency },
    { title: t(`${LANG_PREFIX}originalLoanTerm`), value: originalTerm },
    { title: t(`${LANG_PREFIX}revisedLoanTerm`), value: term },
  ];

  const quickLinList = [{ label: t(`${LANG_PREFIX}itemHistory`), icon: HistoryIcon, action: showHistory }];
  const quickLinList_Action = [{ label: t(`${LANG_PREFIX}itemPayLoan`), icon: LoanIcon, action: payLoan }];

  return (
    <ScreenFull>
      <NavBar
        title={t(`${LANG_PREFIX}titleLoan`)}
        back
        renderRightButton={
          accountType === HIRE_PURCHASE_ACC_TYPE && (
            <TouchableOpacity
              style={{
                height: 44,
                width: 42,
                alignItems: 'center',
                justifyContent: 'center',
              }}
              onPress={handleShowHPInfo}>
              <Image
                source={CustomerServiceIcon}
                style={{ width: 24, height: 24, tintColor: colors.black, marginRight: 12 }}
              />
            </TouchableOpacity>
          )
        }
      />
      <ScrollView showsVerticalScrollIndicator={false}>
        <BalanceAmount
          title={t(`${LANG_PREFIX}titleBalanceAmount`)}
          amount={outstandingBalance}
          currency={currency}
          colorSets={balanceAmountColorSets.positiveRed}
        />
        <AccountDetailsTable
          isActive={accountStatus}
          statusType={statusType}
          nickName={nickName}
          nickNameColour={tagColors.grey}
          tableItems={tableItems}
        />

        {accountType === HIRE_PURCHASE_ACC_TYPE && <ProductDetailsTable tableItems={productDescriptionList} />}

        <InstallmentDetails
          currency={currency}
          installment={installment}
          term={term}
          interestRate={interestRate}
          lastTranDate={lastTranDate}
          lastPaymentAmount={lastPaymentAmount}
          nextDueDate={nextDueDate}
          siStatus={siStatus}
          siAccNo={siAccNo}
          accountType={accountType}
          company={company}
        />

        <OthersQuickLinkSection quickLinksList={quickLinList} />
        {accountStatus && !staffAcc && (
          <OthersQuickLinkSection quickLinksList={quickLinList_Action} title={t(`${LANG_PREFIX}labelQuickAccess`)} />
        )}
        <Space height={50} />
      </ScrollView>
    </ScreenFull>
  );
};

export default Loan;
