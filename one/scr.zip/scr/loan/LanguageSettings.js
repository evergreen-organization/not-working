import React, { useEffect, useState } from 'react';
import { FlatList, TouchableOpacity, View, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';

import { NavBar } from 'organisms';
import { Divider, Flex, LoadingFull, Screen, Text } from 'atoms';
import { SettingItem } from 'molecules';
import { colors } from 'configs';
import {
  changeAppLanguage,
  getAppLanguageCode,
  getAppLanguagePack,
  getBundledLanguagePack,
  newAppLanguageRetrieved,
} from 'localization/utils';
import {
  getAllLanguages,
  getLanguageData,
  getLanguageStatus,
  getSecfaAuth,
  getUser,
  updateLanguageObject,
} from 'stores';
import { FAIL, LOADING, SUCCESS } from 'apis';
import { APP_LANGUAGES } from 'localization/constant';
import { showFailure, showSuccess } from 'utils';
import { useHandleDispatch } from 'hooks';

export const LanguageSettings = () => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.languageSetting.text.';

  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const status = useSelector(getLanguageStatus);
  const sLanguages = useSelector(getAllLanguages);
  const { deviceId, encryptedId } = useSelector(getUser) || {};
  const { isPublic } = useSelector(getSecfaAuth) || {};

  const [currentLanguage, setCurrentLanguage] = useState('');
  const [fileVersion, setFileVersion] = useState({});

  useEffect(() => {
    start();
  }, []);

  const start = async () => {
    const result = await getAppLanguageCode();
    setCurrentLanguage(result);
    checkCurrentAppLanguageVersion(result);
  };

  const checkCurrentAppLanguageVersion = async code => {
    const file = await getAppLanguagePack(code);

    setFileVersion({
      version: file?.version ?? getBundledLanguagePack(code)?.version,
      isFromApi: file?.isFromApi,
    });
  };

  const handleFailure = msg => {
    showFailure(msg);
    dispatch(updateLanguageObject({ status: FAIL }));
  };

  const changeLanguage = async code => {
    if (code === currentLanguage) return;

    dispatch(updateLanguageObject({ status: LOADING }));

    const upperCasedCode = code.toUpperCase();
    const result = await handleDispatch(
      getLanguageData({
        isPublic,
        deviceId,
        encryptedId,
        languageCode: upperCasedCode,
        languageVersion: sLanguages[upperCasedCode]?.languageVersion,
        appLanguageVersion: sLanguages[upperCasedCode]?.appLanguageVersion,
      }),
    );
    if (result.problem) return handleFailure(t(`${LANG_PREFIX}labelError`));

    const { languageFile, appLanguageVersion } = result.language || {};

    //Update language json file
    await newAppLanguageRetrieved(code, languageFile, appLanguageVersion);

    await changeAppLanguage(code);
    setCurrentLanguage(code);
    checkCurrentAppLanguageVersion(code);

    dispatch(updateLanguageObject({ status: SUCCESS }));
    showSuccess(t(`${LANG_PREFIX}msgLanguageChanged`));
  };

  const renderHeader = () => {
    return (
      <View style={styles.subtitleView}>
        <Text style={styles.subtitleText}>{`${t(`${LANG_PREFIX}labelChangeLanguage`)}`}</Text>
        <Divider style={styles.divider} />
      </View>
    );
  };

  const renderFooter = () => {
    return (
      <Text style={styles.footer}>
        {t(`${LANG_PREFIX}labelVersion`)?.replace('${currentLanguageVersion}', fileVersion?.version)}
        {fileVersion?.isFromApi ? '/B' : '/F'}
      </Text>
    );
  };

  return (
    <Screen>
      <NavBar title={t(`${LANG_PREFIX}titleLanguage`)} back />

      <Flex>
        <FlatList
          showsVerticalScrollIndicator={false}
          keyExtractor={(item, index) => index.toString()}
          ListHeaderComponent={renderHeader}
          ListFooterComponent={renderFooter}
          data={APP_LANGUAGES}
          renderItem={({ item, index }) => (
            <View style={styles.langItemView}>
              <TouchableOpacity onPress={() => changeLanguage(item.code)}>
                <SettingItem
                  variant={SettingItem.variants.checkbox}
                  onPress={() => changeLanguage(item.code)}
                  title={item.title}
                  status={currentLanguage === item.code}
                  containerStyle={styles.langItemContainer}
                  bold={false}
                  fixedHeight={false}
                />
              </TouchableOpacity>
              {index !== APP_LANGUAGES.length - 1 && <Divider style={styles.langItemDivider} />}
            </View>
          )}
        />

        {status === LOADING && <LoadingFull blur />}
      </Flex>
    </Screen>
  );
};

const styles = StyleSheet.create({
  subtitleView: {
    backgroundColor: colors.white,
    paddingLeft: 20,
    paddingTop: 12,
  },
  subtitleText: {
    color: colors.medium,
  },
  divider: {
    marginLeft: -20,
    paddingTop: 12,
  },
  langItemView: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
  },
  langItemContainer: {
    marginHorizontal: 0,
    paddingVertical: 20,
  },
  langItemDivider: {
    marginRight: 36,
  },
  footer: {
    fontSize: 13,
    color: colors.medium,
    textAlign: 'center',
    marginTop: 10,
  },
});
