import React, { useMemo } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import { colors } from 'configs';
import { useHandleDispatch, useLoan } from 'hooks';
import routes from 'navigations/routes';
import { Flex, InfoNotFound, SkeletonItem, Space } from 'atoms';
import { AccountItem, ItemErrorRetry } from 'molecules';
import { getActiveLoan, loadLoan, updateNewLoanPaymentObject } from 'stores';
import { LOADING, SUCCESS } from 'apis';
import { useTranslation } from 'react-i18next';

const LANG_PREFIX = 'screens.loan.text.';
const filterOutStaffAccount = accounts => accounts?.filter(acc => !acc.staffAcc);

export const SelfTab = ({ navigation }) => {
  const { t } = useTranslation();

  useLoan({});
  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const loans = useSelector(getActiveLoan);
  const filteredLoanAcc = filterOutStaffAccount(loans?.accounts);

  const renderHeader = useMemo(() => <Space height={10} />);
  const renderFooter = useMemo(() => <Space height={50} />);

  const onSelect = ({ accountNo, accountDesc, noteNo }) => {
    dispatch(updateNewLoanPaymentObject({ toAcc: accountNo, favName: accountDesc, noteNo }));
    navigation.navigate(routes.PAY_LOAN_AMOUNT);
  };

  const renderContent = () => {
    if (filteredLoanAcc?.length === 0) {
      return (
        <InfoNotFound title={t(LANG_PREFIX + 'emptyNoOtherLoan')} desc={t(LANG_PREFIX + 'emptyNoOtherLoanDesc')} />
      );
    }

    return (
      <FlatList
        showsVerticalScrollIndicator={false}
        keyExtractor={(item, index) => index.toString()}
        ListHeaderComponent={renderHeader}
        ListFooterComponent={renderFooter}
        data={filteredLoanAcc}
        renderItem={({ item, index }) => (
          <View style={{ backgroundColor: colors.white }}>
            <AccountItem
              key={index}
              status={item.accountStatus}
              icon={item.accountType}
              nickname={item.nickName}
              name={item.accountDesc}
              accNo={item.accountNo}
              bal={item.outstandingBalance}
              currency={item.currency}
              isLast={index === filteredLoanAcc.length - 1}
              onPress={() => onSelect(item)}
            />
          </View>
        )}
      />
    );
  };

  return (
    <Flex style={styles.screen}>
      {loans.accountsStatus === SUCCESS ? (
        renderContent()
      ) : (
        <View style={styles.container}>
          {loans.accountsStatus === LOADING ? (
            <SkeletonItem loop={2} title={true} subtitle={true} amount={true} />
          ) : (
            <ItemErrorRetry onRetry={() => handleDispatch(loadLoan())} />
          )}
        </View>
      )}
    </Flex>
  );
};

const styles = StyleSheet.create({
  screen: {
    backgroundColor: colors.bg,
  },
  info: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
  },
  container: { backgroundColor: colors.white, marginTop: 10, alignItems: 'center' },
});
