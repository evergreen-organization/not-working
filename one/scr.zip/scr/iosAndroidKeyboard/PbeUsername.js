import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import {
  getCasaApplication,
  submitPBeUsernameCheck,
  eKYCPBeUsernameStored,
  getEncryptedEKYCApplyKey,
  updateCurrentPageStatus,
  formStatus,
} from 'stores';
import { useApi } from 'hooks/useApi';
import { showFailure } from 'utils/message';
import { colors } from 'configs';
import { Screen, LoadingFull } from 'atoms';
import { PBeRegisterErrorMessage, NavBar } from 'organisms';
import { LOADING } from 'apis';

import { PbeFormButtonBottom, TitleStep } from './components';
import { Form, FormField } from 'components';
import {
  handleEKYCErrorResponse,
  PBE_USERNAME,
  updateNextApplyStep,
  usernameValidationSchema,
  ekycNavigateTo,
  PBE_PWORD,
} from './utils';
import { useTranslation } from 'react-i18next';

export const PbeUsername = ({ navigation, route }) => {
  const LANG_PREFIX = 'screens.ekycPbeUsername.text.';
  const { t } = useTranslation();

  const { viewOnly } = route?.params ?? {};
  const dispatch = useDispatch();
  const { userId, status, summaryItemStatus } = useSelector(getCasaApplication) || {};
  const store_getEncryptedEKYCApplyKey = useSelector(getEncryptedEKYCApplyKey);
  const submitPBeUsernameCheckApi = useApi(submitPBeUsernameCheck);
  const initialValues = { id: userId ?? '' };
  const [meetRequirements, setMeetRequirements] = useState(false);

  const callSubmit =
    ({ id }) =>
    async ({ applyKey = store_getEncryptedEKYCApplyKey }) => {
      if (meetRequirements) {
        const result = await submitPBeUsernameCheckApi.request({ applyKey, userId: id });

        if (result.status === 'S') {
          if (result.isUserIdExist === false) {
            dispatch(eKYCPBeUsernameStored({ userId: id }));
            dispatch(updateCurrentPageStatus({ item: PBE_USERNAME, value: formStatus.pass }));
            updateNextApplyStep({ pageStatus: summaryItemStatus[PBE_PWORD], page: PBE_PWORD, dispatch });
            return ekycNavigateTo({ currentPage: PBE_USERNAME, navigation });
          } else {
            showFailure(t(`${LANG_PREFIX}failureUserExist`));
          }
        }
        return await handleEKYCErrorResponse({ t, result, navigation, dispatch, retryApi: callSubmit({ id }) });
      }
    };

  const handleSubmit = async ({ id }) => callSubmit({ id })({});

  return (
    <Screen>
      <NavBar
        back
        showShadow={true}
        bottom={
          <TitleStep title={t(`${LANG_PREFIX}headerTitle`)} currentPage={1} lastPage={3} showPageNo={!viewOnly} />
        }
      />
      <Form
        initialValues={initialValues}
        onSubmit={handleSubmit}
        validationSchema={usernameValidationSchema(t)}
        {...(!viewOnly && {
          button: (
            <PbeFormButtonBottom
              title={t(`${LANG_PREFIX}buttonProceed`)}
              buttonStyle={{ backgroundColor: meetRequirements ? colors.primary : colors.lightgrey }}
            />
          ),
        })}
      >
        <View style={styles.form}>
          <FormField
            editable={!viewOnly}
            bold
            name='id'
            label={t(`${LANG_PREFIX}labelUserId`)}
            maxLength={12}
            keyboardType={'ascii-capable'}
          />
          <PBeRegisterErrorMessage setMeetRequirements={setMeetRequirements} />
        </View>
      </Form>
      {status === LOADING && <LoadingFull blur />}
    </Screen>
  );
};

export default PbeUsername;

const styles = StyleSheet.create({
  form: { flex: 1, backgroundColor: colors.white, paddingHorizontal: 20, paddingVertical: 15, marginTop: 10 },
});
