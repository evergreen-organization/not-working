import React, { useState } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

import * as Yup from 'yup';
import { colors } from 'configs';
import { validationMsg } from 'constant';
import { Icon } from 'atoms';
import { Form, FormFieldButton } from '../../forms';
import { useTranslation } from 'react-i18next';

export const AuthPWordModal = ({ value, loading, onSubmit }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'organisms.loginAuthPWordModal.';
  const LANG_PREFIX_VALIDATION = 'constant.validationMsg.';

  const [secureText, setSecureText] = useState(true);

  const validationSchema = Yup.object().shape({
    pWord: Yup.string()
      .required(t(validationMsg.required))
      .min(
        8,
        t(`${LANG_PREFIX_VALIDATION}minLength`)
          .replace('${label}', t(`${LANG_PREFIX}labelPWord`))
          .replace('${minLength}', 8),
      )
      .label(t(`${LANG_PREFIX}labelPWord`)),
  });

  return (
    <View>
      <Form
        initialValues={{ pWord: value }}
        onSubmit={onSubmit}
        validationSchema={validationSchema}
        alwaysBounceVertical={false}
      >
        <FormFieldButton
          custom
          label={t(`${LANG_PREFIX}labelPWord`)}
          name='pWord'
          bold
          secureTextEntry={secureText}
          textContentType={'password'}
          autoCapitalize='none'
          maxLength={12}
          showCounter={true}
          style={{ paddingLeft: 45, fontSize: 20, height: 55 }}
          loading={loading}
          keyboardType={'ascii-capable'}
        />
      </Form>
      <TouchableOpacity
        accessibilityLabel={secureText ? t(`${LANG_PREFIX}acsShowPWord`) : t(`${LANG_PREFIX}acsHidePWord`)}
        style={styles.button}
        onPress={() => setSecureText(!secureText)}
      >
        <View style={styles.buttonView}>
          {secureText ? (
            <Icon.Entypo name='eye-with-line' style={styles.icon} />
          ) : (
            <Icon.Entypo name='eye' style={styles.icon} />
          )}
        </View>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  button: {
    position: 'absolute',
    left: 0,
    height: '100%',
    top: 25,
  },
  icon: {
    fontSize: 18,
    color: colors.black,
  },
  buttonView: {
    backgroundColor: '#E8E4E4',
    padding: 10,
    borderRadius: 10,
  },
});

export default AuthPWordModal;
