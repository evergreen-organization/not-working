import React from 'react';
import { StyleSheet, View, Linking } from 'react-native';
import * as Yup from 'yup';
import { validationMsg } from 'constant';

import { Text, Heading2WithSub } from '../../text';
import { Form, FormFieldButton } from '../../forms';
import { LinkText } from 'atoms';
import { colors } from 'configs';
import { useTranslation } from 'react-i18next';

export const AuthUserId = ({ loading, onSubmit, aaop, url }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'organisms.loginAuthUserId.';

  const subtitle = aaop ? t(`${LANG_PREFIX}titleAaop`) : t(`${LANG_PREFIX}titleLogin`);
  const handleLink = () => Linking.openURL(url);

  const validationSchema = Yup.object().shape({
    userId: Yup.string()
      .required(t(validationMsg.required))
      .matches(/^[0-9a-zA-z]*$/, t(`${LANG_PREFIX}validationError`))
      .label(t(`${LANG_PREFIX}labelUserID`)),
  });

  return (
    <View style={styles.container}>
      <Heading2WithSub
        titleAccessibilityLabel={t(`${LANG_PREFIX}acsLabelUserID`).replace('${acsID}', 'I D')}
        title={t(`${LANG_PREFIX}labelUserID`)}
        subtitle={subtitle}
        style={{ marginBottom: 10 }}
      />
      <Form
        initialValues={{ userId: '' }}
        onSubmit={onSubmit}
        validationSchema={validationSchema}
        alwaysBounceVertical={false}
      >
        <FormFieldButton
          accessibilityLabel={t(`${LANG_PREFIX}acsLabelInput`).replace('${acsID}', 'I D')}
          custom
          name='userId'
          bold
          autoCapitalize='none'
          maxLength={12}
          showCounter={true}
          loading={loading}
          style={{ height: 55, fontSize: 20 }}
          keyboardType={'ascii-capable'}
        />
      </Form>

      <View style={{ marginVertical: 20 }}>
        <Text style={{ fontSize: 13, marginBottom: 5 }}>{`${t(`${LANG_PREFIX}labelNote`)}:`}</Text>
        <LinkText
          preLinkText={t(`${LANG_PREFIX}tncLinkText1`)}
          linkText={t(`${LANG_PREFIX}tncLinkText2`)}
          postLinkText={t(`${LANG_PREFIX}tncLinkText3`)}
          onPress={handleLink}
          style={styles.text}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { margin: 0 },
  text: {
    fontSize: 13,
    color: colors.medium,
  },
});

export default AuthUserId;
