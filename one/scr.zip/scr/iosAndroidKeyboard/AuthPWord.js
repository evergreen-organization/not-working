import React, { useEffect, useState } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { useFormikContext } from 'formik';

import { colors } from 'configs';
import { FormField } from '../../forms';
import { Icon } from 'atoms';
import { useTranslation } from 'react-i18next';

export const AuthPWord = ({ pWord }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'organisms.loginAuthPWord.';
  const { setFieldValue } = useFormikContext();

  const [secureText, setSecureText] = useState(true);

  useEffect(() => {
    setFieldValue('pWord', pWord);
  }, [pWord]);

  return (
    <View>
      <FormField
        accessibilityLabel={t(`${LANG_PREFIX}acsInput`)}
        custom
        label={t(`${LANG_PREFIX}labelPWord`)}
        name='pWord'
        bold
        secureTextEntry={secureText}
        textContentType={'password'}
        autoCapitalize='none'
        maxLength={12}
        showCounter={true}
        style={{ paddingLeft: 45, fontSize: 20, height: 55 }}
        keyboardType={'ascii-capable'}
      />
      <TouchableOpacity
        accessibilityLabel={secureText ? t(`${LANG_PREFIX}acsShowPWord`) : t(`${LANG_PREFIX}acsHidePWord`)}
        style={styles.button}
        onPress={() => setSecureText(!secureText)}
      >
        <View style={styles.buttonView}>
          {secureText ? (
            <Icon.Entypo name='eye-with-line' style={styles.icon} />
          ) : (
            <Icon.Entypo name='eye' style={styles.icon} />
          )}
        </View>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  button: {
    position: 'absolute',
    left: 0,
    height: '100%',
    top: 25,
  },
  icon: {
    fontSize: 18,
    color: colors.black,
  },
  buttonView: {
    backgroundColor: '#E8E4E4',
    padding: 10,
    borderRadius: 10,
  },
});

export default AuthPWord;
