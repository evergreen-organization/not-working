import React, { useEffect, useRef, useState } from 'react';
import { AccessibilityInfo, View } from 'react-native';
import { KeyboardKey } from 'atoms';
import { styles } from './styles';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppState } from 'hooks';
import { useTranslation } from 'react-i18next';

export const KeyboardView = ({ visible, onClose, onClick, onRemove }) => {
  const { t } = useTranslation();

  const isBackground = useAppState();
  const delTimeout = useRef();
  const insets = useSafeAreaInsets();

  const [isCapsLock, setIsCapsLock] = useState(false);
  const [isAlwaysCapsLock, setIsAlwaysCapsLock] = useState(false);
  const [isAltSymbol, setIsAltSymbol] = useState(false);
  const [isSymbol, setIsSymbol] = useState(false);
  const [isScreenReaderEnabled, setIsScreenReaderEnabled] = useState(false);

  const symbolsKey = isSymbol ? 'ABC' : '123';

  const alphabetKeys = [
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
    ['case', 'z', 'x', 'c', 'v', 'b', 'n', 'm', 'delete'],
    [symbolsKey, 'space', 'done'],
  ];

  const alphabetCapitalKeys = [
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
    ['case', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 'delete'],
    [symbolsKey, 'space', 'done'],
  ];

  const symbols1Keys = [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
    ['-', '/', ':', ';', '(', ')', '$', '&', '@', '"'],
    ['case', '.', ',', '?', '!', '`', 'delete'],
    [symbolsKey, 'space', 'done'],
  ];

  const symbols2Keys = [
    ['[', ']', '{', '}', '#', '%', '^', '*', '+', '='],
    ['_', '\\', '|', '~', '<', '>', '€', '£', '¥', '•'],
    ['case', '.', ',', '?', '!', "'", 'delete'],
    [symbolsKey, 'space', 'done'],
  ];

  useEffect(() => {
    if (isBackground) return;
    AccessibilityInfo.isScreenReaderEnabled().then(screenReaderEnabled => {
      setIsScreenReaderEnabled(screenReaderEnabled);
    });
  }, [isBackground]);

  const rows = () => {
    if (isSymbol) return isAltSymbol ? symbols2Keys : symbols1Keys;
    return isCapsLock ? alphabetCapitalKeys : alphabetKeys;
  };

  const onAltSymbol = () => setIsAltSymbol(!isAltSymbol);
  const onCapsLock = () => {
    if (isCapsLock && !isAlwaysCapsLock) {
      setIsAlwaysCapsLock(true);
    } else if (isAlwaysCapsLock && isCapsLock) {
      setIsAlwaysCapsLock(false);
      setIsCapsLock(false);
    } else {
      setIsCapsLock(true);
    }
  };
  const onSymbol = () => {
    setIsAltSymbol(false);
    setIsSymbol(!isSymbol);
  };
  const onLongDel = () => {
    onRemove();
    delTimeout.current = setTimeout(onLongDel, 10);
  };

  const preOnClick = key => {
    if (!isAlwaysCapsLock) setIsCapsLock(false);
    onClick(key);
  };

  if (!visible) return null;

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom }]}>
      {rows().map((keys, index) => (
        <View key={`row${index}`} style={styles.rows}>
          {keys.map((key, i) => (
            <KeyboardKey
              key={i}
              character={key}
              isSymbol={isSymbol}
              isAltSymbol={isAltSymbol}
              isCapsLock={isCapsLock}
              isAlwaysCapsLock={isAlwaysCapsLock}
              onAltSymbol={onAltSymbol}
              onRemove={onRemove}
              onCapsLock={onCapsLock}
              onSymbol={onSymbol}
              onLongDel={onLongDel}
              onPressOut={() => clearTimeout(delTimeout.current)}
              onClose={onClose}
              onClick={preOnClick}
              isScreenReaderEnabled={isScreenReaderEnabled}
              t={t}
            />
          ))}
        </View>
      ))}
    </View>
  );
};
