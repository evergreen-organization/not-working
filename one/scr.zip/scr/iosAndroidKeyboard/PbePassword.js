import React, { useState } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import { colors } from 'configs';
import { encryption } from 'utils/encryption';
import { getCasaApplication, eKYCPBePasswordStored, updateCurrentPageStatus, formStatus } from 'stores';
import { Form, FormField, Text } from 'components';
import { Screen, Space, Icon } from 'atoms';
import { PBeRegisterErrorMessage, NavBar } from 'organisms';

import { PbeFormButtonBottom, TitleStep } from './components';
import {
  passwordValidationSchema,
  PBE_PWORD,
  updateNextApplyStep,
  ekycNavigateTo,
  PBE_MEMORABLE_QUESTIONS,
} from './utils';
import { useTranslation } from 'react-i18next';

export const PbePassword = ({ route, navigation }) => {
  const LANG_PREFIX = 'screens.ekycPbePWord.text.';
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const { viewOnly } = route?.params ?? {};
  const [secureText, setSecureText] = useState(true);
  const store_casaApplication = useSelector(getCasaApplication);
  const { userId, summaryItemStatus } = store_casaApplication;
  const initialValues = { pWord: '', pWord2: '', plp: '' };

  const [meetRequirements, setMeetRequirements] = useState(false);

  const handleSubmit = async ({ pWord, plp }) => {
    if (meetRequirements) {
      const encryptMsg = encryption.encryptUserIdPassword({ password: pWord });
      dispatch(eKYCPBePasswordStored({ password: encryptMsg, plp }));
      dispatch(updateCurrentPageStatus({ item: PBE_PWORD, value: formStatus.pass }));
      updateNextApplyStep({
        pageStatus: summaryItemStatus[PBE_MEMORABLE_QUESTIONS],
        page: PBE_MEMORABLE_QUESTIONS,
        dispatch,
      });
      return ekycNavigateTo({ currentPage: PBE_PWORD, navigation });
    }
  };

  return (
    <Screen>
      <NavBar
        back
        showShadow={true}
        bottom={
          <TitleStep title={t(`${LANG_PREFIX}headerTitle`)} currentPage={2} lastPage={3} showPageNo={!viewOnly} />
        }
      />
      <Form
        enableReinitialize={true}
        initialValues={initialValues}
        onSubmit={handleSubmit}
        validationSchema={passwordValidationSchema(t)}
        {...(!viewOnly && {
          button: (
            <PbeFormButtonBottom
              title={t(`${LANG_PREFIX}buttonProceed`)}
              buttonStyle={{ backgroundColor: meetRequirements ? colors.primary : colors.lightgrey }}
            />
          ),
        })}
      >
        <View style={styles.form}>
          <FormField
            editable={!viewOnly}
            bold
            name='pWord'
            label={t(`${LANG_PREFIX}labelPWord`)}
            maxLength={12}
            secureTextEntry={secureText}
            keyboardType={'ascii-capable'}
          />
          <FormField
            editable={!viewOnly}
            bold
            name='pWord2'
            label={t(`${LANG_PREFIX}labelConfirmPWord`)}
            maxLength={12}
            secureTextEntry={secureText}
            keyboardType={'ascii-capable'}
          />
          <Space height={5} />
          <TouchableOpacity onPress={() => setSecureText(!secureText)}>
            <View
              style={{
                backgroundColor: '#E8E4E4',
                padding: 8,
                borderRadius: 10,
                flexDirection: 'row',
                justifyContent: 'center',
              }}
            >
              {secureText ? (
                <Icon.Entypo name='eye-with-line' style={{ fontSize: 18, color: '#333' }} />
              ) : (
                <Icon.Entypo name='eye' style={{ fontSize: 18, color: '#333' }} />
              )}
              <Space width={8} />
              <Text>{secureText ? t(`${LANG_PREFIX}showPWord`) : t(`${LANG_PREFIX}hidePWord`)}</Text>
            </View>
          </TouchableOpacity>
          <Space height={10} />
          <FormField
            editable={!viewOnly}
            bold
            name='plp'
            label={t(`${LANG_PREFIX}labelPersonalLoginPhrase`)}
            maxLength={20}
          />
          <Space height={10} />
          <PBeRegisterErrorMessage setMeetRequirements={setMeetRequirements} id={userId} />
          <Text style={{ fontSize: 12 }}>{`${t(`${LANG_PREFIX}titleNote`)}:`}</Text>
          <Space height={8} />
          <Text style={{ fontSize: 12 }}>
            <Text bold>{t(`${LANG_PREFIX}note1Bold`)}</Text> {t(`${LANG_PREFIX}note1`)}
          </Text>
          <Space height={8} />
          <Text style={{ fontSize: 12 }}>{t(`${LANG_PREFIX}note2`)}</Text>
        </View>
      </Form>
    </Screen>
  );
};

export default PbePassword;

const styles = StyleSheet.create({
  form: { backgroundColor: colors.white, paddingHorizontal: 20, paddingVertical: 20, marginTop: 10 },
  flex: { flex: 1 },
  pwdContainer: { flex: 1, flexDirection: 'row', alignItems: 'center' },
  text: { fontSize: 11, textAlign: 'center' },
});
