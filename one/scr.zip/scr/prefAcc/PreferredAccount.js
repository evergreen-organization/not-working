import React, { useEffect, useMemo, useState } from 'react';
import { StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';

import { useApi, useCasa, useHandleDispatch } from 'hooks';
import { showFailure, useAccessControl } from 'utils';
import routes from 'navigations/routes';
import { Flex, Space, ScreenFull, LoadingFull, InfoNotFound, SkeletonItem } from 'atoms';
import { AccountItem, ItemErrorRetry } from 'molecules';
import { NavBar } from 'organisms';
import { Heading2WithSub } from 'components';
import {
  getActiveFromAccCasa,
  getSoftToken,
  updatePrefAccount,
  isLoggedIn,
  casaAccountsStatus,
  loadCasa,
} from 'stores';
import { LOADING, SUCCESS } from 'apis';
import { View } from 'react-native';
import { colors } from 'configs';
import { FlatList } from 'react-native';
import { useTranslation } from 'react-i18next';

export const PreferredAccount = ({ navigation, route }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.preferredAccount.text.';

  useCasa({});
  const { isFromBinding, allowCardOnly, extraParam } = route.params || {};
  const handleDispatch = useHandleDispatch();
  const accessControl = useAccessControl({ navigation });
  const store_isLoggedIn = useSelector(isLoggedIn);
  const store_activeCasa = useSelector(getActiveFromAccCasa);
  const store_softToken = useSelector(getSoftToken);
  const casaStatus = useSelector(casaAccountsStatus);
  const updatePrefAccountApi = useApi(updatePrefAccount);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (casaStatus === SUCCESS) {
      if (store_activeCasa.accounts.length === 0 && allowCardOnly) {
        if (navigation.canGoBack()) navigation.goBack();
        accessControl.lastCheck(store_softToken.selectedRoute, extraParam);
      } else {
        if (isFromBinding) return;
        if (store_softToken.preferredAccountNo) {
          showFailure(t(`${LANG_PREFIX}errorNoPreferredAccount`));
        }
      }
    }
  }, [casaStatus]);

  const onPress = async ({ accountNo, accountDesc, accName }) => {
    setLoading(true);
    const result = await updatePrefAccountApi.request({
      isPublic: store_isLoggedIn ? true : false,
      accountNo,
      accountDesc,
      accName,
    });
    if (result.problem) return fail(result.problem);

    setLoading(false);

    if (!store_softToken.isActivated) {
      navigation.navigate(routes.MAIN_TAB);
      if (store_softToken.isLicenseAvailable)
        navigation.navigate(routes.SOFT_TOKEN_CHECKIC, { isFromBinding: true, disableBack: true });
      return;
    }

    if (store_softToken.selectedRoute) return navigation.replace(store_softToken.selectedRoute);
    navigation.navigate(routes.MAIN_TAB);
  };

  const fail = msg => {
    showFailure(msg);
    setLoading(false);
  };

  const renderHeader = useMemo(() => <Space height={10} />);
  const renderFooter = useMemo(() => <Space height={30} />);

  const renderContent = () => {
    if (store_activeCasa?.accounts?.length === 0) {
      return (
        <InfoNotFound
          title={t(`${LANG_PREFIX}titleNoOtherAccount`)}
          desc={t(`${LANG_PREFIX}labelNoValidSavingAccount`)}
        />
      );
    }

    return (
      <FlatList
        showsVerticalScrollIndicator={false}
        keyExtractor={(item, index) => index.toString()}
        ListHeaderComponent={renderHeader}
        ListFooterComponent={renderFooter}
        data={store_activeCasa?.accounts}
        renderItem={({ item, index }) => (
          <View style={{ backgroundColor: colors.white }}>
            <AccountItem
              key={index}
              status={item.accountStatus}
              nickname={item.nickName}
              name={item.accountDesc}
              accNo={item.accountNo}
              bal={item.currentBalance}
              currency={item.currency}
              isLast={index === store_activeCasa.accounts.length - 1}
              onPress={() => onPress(item)}
            />
          </View>
        )}
      />
    );
  };

  return (
    <ScreenFull>
      <NavBar
        back
        {...(!(store_activeCasa.accountsStatus === SUCCESS && store_activeCasa?.accounts?.length === 0) && {
          showShadow: true,
          bottom: (
            <Heading2WithSub
              style={styles.heading}
              subtitle={t(`${LANG_PREFIX}labelSelect`)}
              title={t(`${LANG_PREFIX}labelPreferredAccount`)}
            />
          ),
        })}
      />

      <Flex>
        {store_activeCasa.accountsStatus === SUCCESS ? (
          renderContent()
        ) : (
          <View style={{ backgroundColor: colors.white, marginTop: 10, alignItems: 'center' }}>
            {store_activeCasa.accountsStatus === LOADING ? (
              <SkeletonItem loop={2} title={true} subtitle={true} amount={true} />
            ) : (
              <ItemErrorRetry onRetry={() => handleDispatch(loadCasa())} />
            )}
          </View>
        )}
        {loading && <LoadingFull />}
      </Flex>
    </ScreenFull>
  );
};

const styles = StyleSheet.create({
  heading: {
    marginHorizontal: 20,
    marginBottom: 15,
  },
});

export default PreferredAccount;
