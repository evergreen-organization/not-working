import { createSlice, isAnyOf } from '@reduxjs/toolkit';
import { REHYDRATE } from 'redux-persist';
import {
  updateUsername,
  updateMobile,
  submitEmailAddress,
  cancelEmailAddressUpdate,
  getPersonalDetails,
  submitAppRating,
  getDevices,
  removeDevices,
} from './thunk';
import { FAIL, IDLE, LOADING, SUCCESS } from 'apis';
import { initUser } from 'stores/banking/softToken';
import { LOGIN_TYPE } from 'constant';
import { submitPostLogin, submitQuickLogin } from '../auth';

const initialState = {
  status: 'idle',
  name: null,
  fullName: null,
  email: null,
  phone: null,
  pbeId: null,
  deviceId: null,
  encryptedId: null,
  accessKey: null,
  secfaType: null,
  previousLoginDate: null,
  loginType: LOGIN_TYPE.PIN,

  //email update
  pbeEmail: null,
  pbeEmailNew: null,
  emailRefNo: null,
  emailStatus: IDLE,

  bindedDevices: {
    mypb: null,
    pbengage: [],
  },
};

const slice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    userReset: _ => initialState,
    userInfoReset: user => {
      user.emailStatus = initialState.emailStatus;
      user.pbeEmail = initialState.pbeEmail;
      user.pbeEmailNew = initialState.pbeEmailNew;
      user.emailRefNo = initialState.emailRefNo;
      user.bindedDevices = initialState.bindedDevices;

      //Post login info
      user.fullName = initialState.fullName; //Full Name used in eFD
      user.phone = initialState.phone;
    },
    tokenCleared: user => {
      user.accessKey = null;
      user.idNo = null;
    },
    lastLoginCleared: user => {
      user.previousLoginDate = null;
    },
    userLoggedIn: (user, { payload }) => {
      user.name = payload.name;
      user.email = payload.email;
      user.phone = payload.phone;
      user.pbeId = payload.pbeId;
      user.accessKey = payload.accessKey;
      user.encryptedId = payload.encryptedId;
      user.deviceId = payload.deviceId;
      user.isPBeUser = payload.isPBeUser;
      user.secfaType = payload.secfaType;
      user.fullName = payload.fullName;
      user.idNo = payload.idNo;
      user.deviceType = payload.deviceType;
      user.deviceModel = payload.deviceModel;
      user.deviceName = payload.deviceName;
      user.osVersion = payload.osVersion;
      user.cifNo = payload.cifNo;
    },
    requestUser: user => {
      user.status = 'loading';
    },
    quickLoggedIn: (user, { payload }) => {
      if (payload.accessKey !== undefined) user.accessKey = payload.accessKey;
      if (payload.displayName !== undefined) user.name = payload.displayName;
      if (payload.isPBeUser !== undefined) user.isPBeUser = payload.isPBeUser;
      if (payload.mobileNo !== undefined) user.phone = payload.mobileNo;
      if (payload.userId !== undefined) user.pbeId = payload.userId;
      if (payload.email !== undefined) user.email = payload.email;
      if (payload.name !== undefined) user.fullName = payload.name;
      if (payload.idNo !== undefined) user.idNo = payload.idNo;
      if (payload.previousLoginDate !== undefined) user.previousLoginDate = payload.previousLoginDate;
    },
    updateUserObject: (user, { payload }) => {
      user.status = 'succeeded';
      for (const key in payload) {
        user[key] = payload[key];
      }
    },
  },
  extraReducers: builder => {
    builder.addCase(REHYDRATE, (user, { payload }) => {
      if (payload?.user !== undefined) user = payload.user;
    });
    builder.addCase(updateUsername.pending, (user, { payload }) => {
      slice.caseReducers.requestUser(user, payload);
    });
    builder.addCase(updateUsername.fulfilled, (user, { payload }) => {
      user.status = 'succeeded';
      user.name = payload.displayName;
    });
    builder.addCase(updateUsername.rejected, (user, { payload }) => {
      user.status = 'failed';
      user.error = payload.problem;
    });
    builder.addCase(updateMobile.pending, (user, { payload }) => {
      slice.caseReducers.requestUser(user, payload);
    });
    builder.addCase(updateMobile.fulfilled, (user, { payload }) => {
      user.status = 'succeeded';
      user.phone = payload.mobileNo;
    });
    builder.addCase(updateMobile.rejected, (user, { payload }) => {
      user.status = 'failed';
      user.error = payload.problem;
    });
    builder.addCase(getPersonalDetails.pending, user => {
      user.emailStatus = LOADING;
    });
    builder.addCase(getPersonalDetails.fulfilled, (user, { payload }) => {
      user.emailStatus = SUCCESS;
      user.pbeEmail = payload.pbeEmail;
      if (payload.pbeEmailNew) user.pbeEmailNew = payload.pbeEmailNew;
      if (payload.emailRefNo) user.emailRefNo = payload.emailRefNo;
    });
    builder.addCase(getPersonalDetails.rejected, user => {
      user.emailStatus = FAIL;
    });
    builder.addCase(submitEmailAddress.fulfilled, (user, { meta, payload }) => {
      user.emailStatus = IDLE;
      user.pbeEmailNew = meta.arg.email;
    });
    builder.addCase(getDevices.pending, user => {
      user.status = LOADING;
    });
    builder.addCase(getDevices.fulfilled, (user, { payload }) => {
      user.status = SUCCESS;
      user.bindedDevices = payload;
    });
    builder.addCase(getDevices.rejected, user => {
      user.status = FAIL;
    });
    builder.addCase(removeDevices.pending, (user, { payload }) => {
      slice.caseReducers.requestUser(user, payload);
    });
    builder.addCase(removeDevices.fulfilled, (user, { meta }) => {
      user.status = SUCCESS;
      user.bindedDevices.pbengage = user.bindedDevices.pbengage.filter(device => device.deviceId !== meta.arg.deviceId);
    });
    builder.addCase(removeDevices.rejected, user => {
      user.status = FAIL;
    });

    builder.addCase(cancelEmailAddressUpdate.pending, user => {
      user.emailStatus = LOADING;
    });
    builder.addCase(cancelEmailAddressUpdate.fulfilled, user => {
      user.emailStatus = SUCCESS;
      user.pbeEmailNew = initialState.pbeEmailNew;
    });
    builder.addCase(cancelEmailAddressUpdate.rejected, user => {
      user.emailStatus = FAIL;
    });
    builder.addCase(initUser.fulfilled, (user, { payload }) => {
      user.cifNo = payload.cifNo;
    });
    builder.addCase(submitAppRating.pending, user => {
      user.status = LOADING;
    });
    builder.addCase(submitAppRating.fulfilled, user => {
      user.status = SUCCESS;
    });
    builder.addCase(submitAppRating.rejected, user => {
      user.status = FAIL;
    });
    builder.addMatcher(isAnyOf(submitQuickLogin.fulfilled, submitPostLogin.fulfilled), (user, { meta }) => {
      const { deviceType, deviceModel, deviceName, osVersion } = meta.arg || {};
      if (deviceType) {
        //Update redux store to record the latest device info updated to API
        //Quick Login to avoid passing device info if no changes, to reduce query to database
        user.deviceType = deviceType;
        user.deviceModel = deviceModel;
        user.deviceName = deviceName;
        user.osVersion = osVersion;
      }
    });
  },
});

export const {
  userReset,
  userInfoReset,
  tokenCleared,
  lastLoginCleared,
  userLoggedIn,
  quickLoggedIn,
  updateUserObject,
} = slice.actions;
export default slice.reducer;
