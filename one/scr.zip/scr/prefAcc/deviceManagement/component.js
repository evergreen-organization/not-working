import React from 'react';
import { Image, ScrollView, TouchableOpacity, View } from 'react-native';

import { Loading, Screen, Space, Text as AtomText } from 'atoms';
import { Text } from 'components';
import { NavBar } from 'organisms';
import { ActionModal, List } from 'molecules';

import { colors } from 'configs';

import { styles } from './styles';
import MyPBLogo from 'assets/images/icon/myPBlogo.png';
import PBengageLogo from 'assets/images/icon/PBengageLogo.png';
import KeyIcon from 'assets/images/basiccolor/key.png';

const LANG_PREFIX = 'screens.manageDevices.text.';

export const DeviceManagementComponent = ({
  mypb,
  pbengage,
  isMyPBModalVisible,
  isPBEngageModalVisible,
  selectedDeviceName,
  handlePopUpMyPB,
  handlePopUpPBengage,
  handleCancel,
  handleRemove,
  handleUnbind,
  t,
  isLoading,
}) => {
  const renderRemovePBengage = () => {
    return (
      <View>
        <Text style={styles.externalHeader} bold={true}>
          {t(`${LANG_PREFIX}confirmRemoveText`)}
        </Text>
        <Text style={styles.externalDescription}>
          {t(`${LANG_PREFIX}removeMsg1`)} {selectedDeviceName} {t(`${LANG_PREFIX}removeMsg2`)}
        </Text>
      </View>
    );
  };

  const renderUnbindMyPB = () => {
    return (
      <View>
        <Text style={styles.externalHeader} bold={true}>
          {t(`${LANG_PREFIX}confirmUnbindText`)}
        </Text>
        <Text style={styles.externalDescription}>{t(`${LANG_PREFIX}unbindMsg`)}</Text>
      </View>
    );
  };

  return (
    <Screen>
      <NavBar title={t(`${LANG_PREFIX}title`)} back />
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* MyPB Data */}
        {mypb?.deviceId && (
          <View style={styles.roundContainer} key={mypb?.deviceId}>
            <View style={styles.appsContainer}>
              <Image style={styles.appLogo} source={MyPBLogo} />
              <Text bold style={styles.sectionTitle}>
                MyPB
              </Text>
            </View>

            <View style={styles.container}>
              <DeviceItem
                t={t}
                item={mypb}
                isCurrentDevice={true}
                isLast={true}
                onPress={handlePopUpMyPB}
                buttonTitle={t(`${LANG_PREFIX}unbindText`)}
                isActivated={mypb?.softTokenActivated}
              />
            </View>
          </View>
        )}

        <Space height={10} />

        {/* PBengage Data */}
        {pbengage?.length > 0 && (
          <>
            <View style={styles.roundContainer}>
              <View style={styles.appsContainer}>
                <Image style={styles.appLogo2} source={PBengageLogo} />
                <Text bold style={styles.sectionTitle}>
                  PB engage
                </Text>
              </View>

              {pbengage.map((device, index) => (
                <View style={styles.container} key={device.deviceId}>
                  <DeviceItem
                    t={t}
                    item={device}
                    isCurrentDevice={false}
                    isLast={index === pbengage.length - 1}
                    onPress={() => handlePopUpPBengage({ deviceId: device.deviceId, deviceName: device.deviceName })}
                    buttonTitle={t(`${LANG_PREFIX}removeText`)}
                    isActivated={device.softTokenActivated}
                  />
                </View>
              ))}
            </View>
          </>
        )}
      </ScrollView>

      <ActionModal
        isVisible={isMyPBModalVisible}
        renderContent={renderUnbindMyPB}
        onAccept={handleUnbind}
        onModalHide={handleCancel}
        onDecline={handleCancel}
        leftButtonType={'normal'}
        leftButtonTitle={t(`${LANG_PREFIX}cancelText`)}
        rightButtonTitle={t(`${LANG_PREFIX}unbindText`)}
        onAcceptDisabled={isLoading}
      />

      <ActionModal
        isVisible={isPBEngageModalVisible}
        renderContent={renderRemovePBengage}
        onAccept={handleRemove}
        onModalHide={handleCancel}
        onDecline={handleCancel}
        leftButtonType={'normal'}
        leftButtonTitle={t(`${LANG_PREFIX}cancelText`)}
        rightButtonTitle={t(`${LANG_PREFIX}removeText`)}
      />

      {isLoading && <Loading variant={Loading.variants.blurFullscreen} />}
    </Screen>
  );
};

const DeviceItem = ({ t, item, onPress, buttonTitle, isLast, isCurrentDevice, isActivated }) => (
  <List.Item
    title={(isCurrentDevice ? item.deviceName + ' ' + t(`${LANG_PREFIX}currentDeviceText`) : item.deviceName) ?? ''}
    description={t(`${LANG_PREFIX}bindedText`)?.replace('${bindDateTime}', item.bindDateTime ?? '')}
    isLast={isLast}
    titleTypography={AtomText.type.P7}
    titleNumberOfLine={2}
    descriptionTypography={AtomText.type.P5}
    descriptionStyle={{ marginTop: 5 }}
    style={{ paddingHorizontal: 5, paddingVertical: 8 }}
    dividerStyle={{ marginHorizontal: 5 }}
    rightIconStyle={{ marginRight: 75 }}
    rightIcon={isActivated && { source: KeyIcon }}
    renderRight={
      <TouchableOpacity accessibilityRole={'button'} style={{ paddingVertical: 12 }} onPress={onPress}>
        <Text bold style={{ fontSize: 14, color: colors.primary }}>
          {buttonTitle}
        </Text>
      </TouchableOpacity>
    }
  />
);
export default DeviceManagementComponent;
