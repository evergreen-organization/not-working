import React, { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useHandleDispatch, useNotification } from 'hooks';
import routes from 'navigations/routes';
import { getDevices, getUser, removeDevices, unbound } from 'stores';

import { DeviceManagementComponent } from './component';
import { LOADING } from 'apis';
import { showFailure } from 'utils';

export const DeviceManagement = ({ navigation }) => {
  const { t } = useTranslation();
  const handleDispatch = useHandleDispatch();
  const dispatch = useDispatch();
  const devicesDataState = useSelector(getUser);
  const { bindedDevices, status } = devicesDataState || {};
  const { mypb, pbengage } = bindedDevices || {};

  const [isMyPBModalVisible, setIsMyPBModalVisible] = useState(false);
  const [isPBEngageModalVisible, setIsPBEngageModalVisible] = useState(false);
  const [selectedDeviceId, setSelectedDeviceId] = useState(null);
  const [selectedDeviceName, setSelectedDeviceName] = useState('');
  const [isUnbindLoading, setIsUnbindLoading] = useState(false);
  const pushNotificationUtils = useNotification();

  useEffect(() => {
    handleDispatch(getDevices());
  }, []);

  const handlePopUpMyPB = () => setIsMyPBModalVisible(true);

  const handlePopUpPBengage = useCallback(({ deviceId, deviceName }) => {
    setSelectedDeviceId(deviceId);
    setSelectedDeviceName(deviceName);
    setIsPBEngageModalVisible(true);
  }, []);

  const handleCancel = () => {
    setIsMyPBModalVisible(false);
    setIsPBEngageModalVisible(false);
  };

  const handleRemove = async () => {
    if (selectedDeviceId) {
      const result = await handleDispatch(removeDevices({ deviceId: selectedDeviceId }));
      setIsPBEngageModalVisible(false);
      if (result.problem) return showFailure(result.problem);
    }
  };

  const handleUnbind = async () => {
    setIsUnbindLoading(true);
    await pushNotificationUtils.deleteFcmToken();
    await dispatch(unbound());
    setIsMyPBModalVisible(false);
    navigation.replace(routes.MAIN_TAB);
    setIsUnbindLoading(false);
  };

  const props = {
    t,
    mypb,
    pbengage,
    isMyPBModalVisible,
    isPBEngageModalVisible,
    selectedDeviceId,
    selectedDeviceName,
    handlePopUpMyPB,
    handlePopUpPBengage,
    handleCancel,
    handleRemove,
    handleUnbind,
    isLoading: status === LOADING || isUnbindLoading,
  };

  return <DeviceManagementComponent {...props} />;
};

export default DeviceManagement;
