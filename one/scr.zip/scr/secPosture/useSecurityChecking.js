import { useEffect, useRef, useState } from 'react';
import { Platform, NativeModules, DeviceEventEmitter } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import dayjs from 'dayjs';

import { config } from 'configs';
import { APP_SECURITY_RISK_TYPE, ApiDateTimeFormat, UNTRUSTED_SOURCE_APP_PROMPT } from 'constant';
import {
  getSettingSecurity,
  securityRiskSkipped,
  getValidMyPBSourceList,
  isBound,
  submitNoThirdPartyApp,
  updateUntrustedSourceObject,
  getValidAppSourceList,
  getValidAppSignatureList,
  getInitAppStatus,
  retrieveScanAcceptanceInfo,
} from 'stores';
import { utc8DateTime } from 'utils';
import { useApi } from 'hooks/useApi';
import packageJson from '../../package.json';
import { FAIL, SUCCESS } from 'apis';
import { useHandleDispatch } from 'hooks/useHandleDispatch';

const { ShieldingModule, UntrustedAppDetectModule } = NativeModules;

export const useSecurityChecking = () => {
  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const submitNoThirdPartyAppApi = useApi(submitNoThirdPartyApp);
  const store_bound = useSelector(isBound);
  const { screenReader: sScreenReader, skipped: typeSkipped, untrustedSource } = useSelector(getSettingSecurity) || {};
  const validMyPBSourceList = useSelector(getValidMyPBSourceList);
  const validAppSourceList = useSelector(getValidAppSourceList);
  const validAppSignatureList = useSelector(getValidAppSignatureList);
  const initAppStatus = useSelector(getInitAppStatus);

  const [riskType, setRiskType] = useState('');
  const [riskData, setRiskData] = useState(null);
  const [doneMyPBScan, setDoneMyPBScan] = useState(false);

  const detectedRisksRef = useRef(null);
  const skippedListRef = useRef({
    [APP_SECURITY_RISK_TYPE.SCREEN_READER]: false,
  });

  useEffect(() => {
    const raspCallbackSub = DeviceEventEmitter.addListener('onRaspCallback', onRaspCallback);

    securityChecking();

    return () => {
      raspCallbackSub.remove();
    };
  }, []);

  useEffect(() => {
    if (Platform.OS === 'android' && (initAppStatus === SUCCESS || initAppStatus === FAIL)) {
      UntrustedAppDetectModule.checkIfMyPBValid(validMyPBSourceList);
    }
  }, [initAppStatus]);

  useEffect(() => {
    if (Platform.OS === 'android' && doneMyPBScan) {
      //Check BBO indicator to determine if untrusted source need to be trigger
      if (untrustedSource?.promptIndicator === UNTRUSTED_SOURCE_APP_PROMPT.OFF) return;

      const currentVersion = `${packageJson.version}.${packageJson.build}`;
      if (untrustedSource?.scanRejectedAppVersion !== currentVersion && untrustedSource?.disableScan) {
        dispatch(updateUntrustedSourceObject({ scanRejectedAppVersion: null }));
        return handleRisk(APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP_SCAN_CONSENT);
      }

      if (afterIntervalDate() && !untrustedSource?.disableScan) {
        if (untrustedSource?.acceptScan) {
          return UntrustedAppDetectModule.checkIfOtherAppValid(validAppSourceList, validAppSignatureList);
        }
        return handleRisk(APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP_SCAN_CONSENT);
      }
    }
  }, [doneMyPBScan]);

  useEffect(() => {
    if (typeSkipped) {
      dispatch(securityRiskSkipped(null));

      //Add to skip list, so next callback will not display this risk
      skippedListRef.current[typeSkipped] = true;

      //Proceed or Skip clicked by user - Remove risk from list
      const obj = { ...detectedRisksRef.current };
      delete obj[typeSkipped];
      updateRisks(obj);
    }
  }, [typeSkipped]);

  const onRaspCallback = event => {
    const { type, isSecure, data } = event;
    if (type === APP_SECURITY_RISK_TYPE.UNTRUSTED_MYPB) {
      setDoneMyPBScan(true);
    }
    if (isSecure) {
      if (type === APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP) {
        dispatch(
          updateUntrustedSourceObject({
            isDetected: false,
            untrustedShowDate: utc8DateTime().format(ApiDateTimeFormat),
          }),
        );
        if (store_bound) {
          requestNoThirdParty().then();
        }
      }
      //Secure - Remove risk from list
      const obj = { ...detectedRisksRef.current };
      delete obj[type];
      updateRisks(obj);
      return;
    }

    if (type === APP_SECURITY_RISK_TYPE.SCREEN_READER) {
      //User previously clicked "Don't show again"
      if (sScreenReader?.dontShowAgain) return;

      //User previously clicked "Skip"
      if (skippedListRef.current[type]) return;
    }
    if (type === APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP) {
      dispatch(
        updateUntrustedSourceObject({
          isDetected: true,
        }),
      );
      if (store_bound) {
        handleDispatch(retrieveScanAcceptanceInfo());
      }
    }

    //Detected risk - Add risk to list
    handleRisk(type, data);
  };

  const afterIntervalDate = () => {
    if (!untrustedSource?.untrustedShowDate) return true;
    const initialDate = dayjs(untrustedSource?.untrustedShowDate, ApiDateTimeFormat);
    return utc8DateTime().diff(initialDate, 'days') >= untrustedSource?.promptInterval;
  };

  const securityChecking = async () => {
    if (config.region === 'DEV') return;

    if (Platform.OS === 'android') ShieldingModule.init();
  };

  const requestNoThirdParty = async () => {
    const result = await submitNoThirdPartyAppApi.request({});
    if (result.status !== 'S') {
      dispatch(updateUntrustedSourceObject({ untrustedShowDate: null }));
    }
  };

  const updateRisks = obj => {
    detectedRisksRef.current = obj;

    if (Object.entries(detectedRisksRef.current).length > 0) {
      const [propName, propValue] = Object.entries(detectedRisksRef.current)[0];
      setRiskType(propName);
      setRiskData(propValue?.data);
      return;
    }

    setRiskType('');
  };

  const handleRisk = (type, data) => {
    const exist = detectedRisksRef.current?.[type]?.exist;
    if (!exist) {
      const obj = {
        ...detectedRisksRef.current,
        [type]: { exist: true, data },
      };
      updateRisks(obj);
    }
  };

  return { riskType, riskData };
};

export default useSecurityChecking;
