import { createSlice } from '@reduxjs/toolkit';
import { REHYDRATE } from 'redux-persist';
import { UNTRUSTED_SOURCE_APP_PROMPT, initialCache, IMPORTANT_FOR_ACCESSIBILITY } from 'constant';
import { initApp } from '../version';
import { getScanAcceptanceInfo, retrieveScanAcceptanceInfo, submitSecurityPosture } from './thunk';
import { SUCCESS, LOADING, FAIL, IDLE } from 'apis';

const initialState = {
  firstTimeUser: 0,
  app: {},
  otherUrl: [],
  alertList: [],
  onHoldCancellationReason: [],
  security: {
    skipped: null,
    screenReader: {
      dontShowAgain: false,
    },
    untrustedSource: {
      isDetected: false,
      acceptScan: false,
      acceptRisk: false,
      disableScan: false,
      scanRejectedAppVersion: null,
      untrustedShowDate: null,
      promptIndicator: UNTRUSTED_SOURCE_APP_PROMPT.ON,
      promptInterval: '0',
      startedUntrust: false,
      lastScanAcceptedDate: null,
    },
  },
  validMyPBSourceList: [
    //Google app store
    'com.android.vending',
    //huawei
    'com.huawei.appmarket',
  ],
  validSourceList: [],
  validSignatureList: [],
  festive: {
    bgImgUrl: '',
    bannerImg: [],
  },
  importantForAccessibility: IMPORTANT_FOR_ACCESSIBILITY.AUTO,
  appRating: {
    lastShownDate: '',
    isRated: false,
  },
  postureStatus: IDLE,
};

const slice = createSlice({
  name: 'setting',
  initialState,
  reducers: {
    accessibilityUpdated: (state, { payload }) => {
      state.importantForAccessibility = payload;
    },
    firstTimeSaved: (state, { payload }) => {
      state.firstTimeUser = payload;
    },
    publicKeySaved: (state, payload) => {
      state.publicKeys = payload.publicKeys;
    },
    otherUrlSaved: (state, payload) => {
      state.otherUrl = payload.list;
    },
    appSaved: (state, payload) => {
      state.app = payload;
    },
    resetUntrustedSource: state => {
      state.security.untrustedSource = initialState.security.untrustedSource;
    },
    securityPostureSaved: (state, payload) => {
      state.validMyPBSourceList = payload.validMyPBSourceList;
      state.validSourceList = payload.validSourceList;
      state.validSignatureList = payload.validSignatureList;
      state.security.untrustedSource.promptIndicator = payload.promptIndicator;
      state.security.untrustedSource.promptInterval = payload.promptInterval;
    },
    onHoldCancellationReasonSaved: (state, payload) => {
      state.onHoldCancellationReason = payload.list;
    },
    securityRiskSkipped: (state, { payload }) => {
      state.security.skipped = payload;
    },
    updateSecurityScreenReaderObject: (state, { payload }) => {
      for (const key in payload) {
        state.security.screenReader[key] = payload[key];
      }
    },
    updateUntrustedSourceObject: (state, { payload }) => {
      for (const key in payload) {
        state.security.untrustedSource[key] = payload[key];
      }
    },
    updateAppRatingLastShownDate: (state, { payload }) => {
      state.appRating.lastShownDate = payload?.lastShownDate;
    },
    updateAppRatingIsRated: (state, { payload }) => {
      state.appRating.isRated = payload;
    },
    appRatingReset: state => {
      state.appRating = initialState.appRating;
    },
  },
  extraReducers: builder => {
    builder.addCase(REHYDRATE, (state, { payload }) => {
      if (payload?.setting) {
        if (payload.setting.publicKeys && payload.version.publicKeysVersion > initialCache.version.publicKeysVersion)
          state.publicKeys = payload.setting.publicKeys;
        else state.publicKeys = initialCache.publicKey.publicKeys;

        if (payload.setting.otherUrl && payload.version.otherUrlVersion > initialCache.version.otherUrlVersion)
          state.otherUrl = payload.setting.otherUrl;
        else state.otherUrl = initialCache.otherUrl.list;

        if (payload.setting.validMyPBSourceList) state.validMyPBSourceList = payload.setting.validMyPBSourceList;
        if (payload.setting.validSourceList) state.validSourceList = payload.setting.validSourceList;
        if (payload.setting.validSignatureList) state.validSignatureList = payload.setting.validSignatureList;

        if (
          payload.setting.onHoldCancellationReason &&
          payload.version.onHoldCancellationReasonVersion > initialCache.version.onHoldCancellationReasonVersion
        )
          state.onHoldCancellationReason = payload.setting.onHoldCancellationReason;
        else state.onHoldCancellationReason = initialCache.onHoldCancellationReason.list;

        if (payload.setting.alertList) state.alertList = payload.setting.alertList;

        //Nested objects, handle existing device redux state
        if (payload.setting.security) {
          state.security.skipped = payload.setting.security.skipped ?? initialState.security.skipped;
          state.security.screenReader = payload.setting.security.screenReader ?? initialState.security.screenReader;
          state.security.untrustedSource =
            payload.setting.security.untrustedSource ?? initialState.security.untrustedSource;
        }

        if (payload.setting.festive) state.festive = payload.setting.festive;

        if (payload.setting.appRating) state.appRating = payload.setting.appRating;

        state.firstTimeUser = payload.setting.firstTimeUser;
        state.app = payload.setting.app;
      } else {
        state.publicKeys = initialCache.publicKey.publicKeys;
        state.otherUrl = initialCache.otherUrl.list;
        state.app = initialCache.app;
        state.onHoldCancellationReason = initialCache.onHoldCancellationReason.list;
      }
    });
    builder.addCase(submitSecurityPosture.fulfilled, state => {
      state.postureStatus = SUCCESS;
    });
    builder.addCase(submitSecurityPosture.pending, state => {
      state.postureStatus = LOADING;
    });
    builder.addCase(submitSecurityPosture.rejected, state => {
      state.postureStatus = FAIL;
    });

    builder.addCase(initApp.fulfilled, (state, { payload }) => {
      if (payload.publicKey?.publicKeys) slice.caseReducers.publicKeySaved(state, payload.publicKey);
      if (payload.otherUrl?.list) slice.caseReducers.otherUrlSaved(state, payload.otherUrl);
      if (payload.app) slice.caseReducers.appSaved(state, payload.app);
      if (payload.onHoldCancellationReason?.list)
        slice.caseReducers.onHoldCancellationReasonSaved(state, payload.onHoldCancellationReason);
      state.alertList = payload.alertList;
      if (payload?.securityPosture) slice.caseReducers.securityPostureSaved(state, payload.securityPosture);

      state.festive.bgImgUrl = payload.festive?.bgImgUrl;
      state.festive.bannerImg = payload.festive?.bannerImg;
    });
    builder.addCase(retrieveScanAcceptanceInfo.fulfilled, (state, { payload }) => {
      state.postureStatus = SUCCESS;
      state.security.untrustedSource.lastScanAcceptedDate = payload?.lastScanAcceptedDate;
    });
    builder.addCase(retrieveScanAcceptanceInfo.pending, state => {
      state.postureStatus = LOADING;
    });
    builder.addCase(retrieveScanAcceptanceInfo.rejected, state => {
      state.postureStatus = FAIL;
    });
  },
});

export const {
  firstTimeSaved,
  securityRiskSkipped,
  updateSecurityScreenReaderObject,
  updateUntrustedSourceObject,
  securityPostureSaved,
  accessibilityUpdated,
  updateAppRatingLastShownDate,
  updateAppRatingIsRated,
  appRatingReset,
  resetUntrustedSource,
} = slice.actions;
export default slice.reducer;
