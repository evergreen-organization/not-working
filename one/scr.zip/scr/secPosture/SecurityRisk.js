import React, { useState } from 'react';
import { Linking, NativeModules, Platform, StyleSheet, TouchableOpacity, View } from 'react-native';
import RNExitApp from 'react-native-exit-app';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';

import packageJson from '../../../package.json';
import { colors } from 'configs';
import { Button, DoneButton, Text } from 'components';
import { BottomView, Checkbox, CustomScrollView, Divider, LinkText, LoadingFull, Screen, Space } from 'atoms';
import { APP_SECURITY_RISK_TYPE, ApiDateTimeFormat, otherUrlTag, ReceiptDateTimeFormat } from 'constant';
import {
  getOtherUrlByTag,
  securityRiskSkipped,
  updateSecurityScreenReaderObject,
  updateUntrustedSourceObject,
  submitSecurityPosture,
  getUser,
  isBound,
  getValidAppSourceList,
  getValidAppSignatureList,
  resetUntrustedSource,
  getSettingPostureStatus,
  getSettingSecurity,
} from 'stores';
import { NavBar, Notes } from 'organisms';
import { ActionModal, MoreLess, Switch } from 'molecules';
import { showFailure, utc8DateTime } from 'utils';
import { useHandleDispatch } from 'hooks';
import { LOADING } from 'apis';

const { UntrustedAppDetectModule } = NativeModules;

export const SecurityRisk = ({ type, data }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.securityRisk.text.';
  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const today = utc8DateTime().format(ApiDateTimeFormat);
  const currentVersion = `${packageJson.version}.${packageJson.build}`;
  const mobileSecurityURL = useSelector(getOtherUrlByTag({ tag: otherUrlTag.INFO_MOBILE_SECURITY }));
  const { encryptedId, deviceId } = useSelector(getUser) || {};
  const status = useSelector(getSettingPostureStatus);
  const store_bound = useSelector(isBound);
  const isLoading = status === LOADING;
  const validAppSourceList = useSelector(getValidAppSourceList);
  const validAppSignatureList = useSelector(getValidAppSignatureList);
  const { untrustedSource } = useSelector(getSettingSecurity) || {};
  const [dontShowAgain, setDontShowAgain] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const [showScanNotice, setShowScanNotice] = useState(false);
  const [showAppListNotice, setShowAppListNotice] = useState(false);
  const [showCloseModal, setCloseModal] = useState(false);
  const [isDeviceScanEnabled, setIsDeviceScanEnabled] = useState(true);

  const handleLink = url => Linking.openURL(url);
  const closeApp = () => RNExitApp.exitApp();

  const selectDontShowAgain = () => setDontShowAgain(!dontShowAgain);

  const handleSkip = () => {
    dispatch(updateSecurityScreenReaderObject({ dontShowAgain: dontShowAgain }));
    dispatch(securityRiskSkipped(APP_SECURITY_RISK_TYPE.SCREEN_READER));
  };

  const onAllowScan = async () => {
    if (store_bound) {
      const payload = await handleDispatch(
        submitSecurityPosture({
          encryptedId,
          deviceId,
          type: 'SCAN',
          isAccept: true,
        }),
      );
      if (payload?.problem) {
        dispatch(resetUntrustedSource());
        return showFailure(payload?.problem);
      }
    }
    if (Platform.OS === 'android') {
      UntrustedAppDetectModule.checkIfOtherAppValid(validAppSourceList, validAppSignatureList);
    }
    dispatch(securityRiskSkipped(type));
    dispatch(
      updateUntrustedSourceObject({
        startedUntrust: true,
        disableScan: false,
        acceptScan: true,
      }),
    );
  };

  const onAcceptRisk = async () => {
    //Accept Risk
    setShowAppListNotice(false);
    if (store_bound) {
      const payload = await handleDispatch(
        submitSecurityPosture({
          encryptedId,
          deviceId,
          type: 'RISK',
          isAccept: true,
          isDeviceScanEnabled,
        }),
      );
      if (payload?.problem) {
        dispatch(resetUntrustedSource());
        return showFailure(payload?.problem);
      }
    }
    if (!isDeviceScanEnabled) {
      dispatch(
        updateUntrustedSourceObject({
          disableScan: true,
          acceptScan: false,
          scanRejectedAppVersion: currentVersion,
        }),
      );
    }
    dispatch(securityRiskSkipped(type));
    dispatch(updateUntrustedSourceObject({ untrustedShowDate: today, acceptRisk: true }));
  };

  const onNoScan = async () => {
    //Reject Scan
    setShowScanNotice(false);
    if (store_bound) {
      const payload = await handleDispatch(
        submitSecurityPosture({
          encryptedId,
          deviceId,
          type: 'SCAN',
          isAccept: false,
        }),
      );
      if (payload?.problem) {
        dispatch(resetUntrustedSource());
        return showFailure(payload?.problem);
      }
    }
    dispatch(securityRiskSkipped(type));
    dispatch(
      updateUntrustedSourceObject({
        untrustedShowDate: today,
        disableScan: true,
        acceptScan: false,
        scanRejectedAppVersion: currentVersion,
        startedUntrust: true,
      }),
    );
  };

  const onNotAcceptRisk = async () => {
    //Reject Risk
    setCloseModal(true);
    if (store_bound) {
      const payload = await handleDispatch(
        submitSecurityPosture({
          encryptedId,
          deviceId,
          type: 'RISK',
          isAccept: false,
          isDeviceScanEnabled,
        }),
      );
      if (payload?.problem) {
        dispatch(resetUntrustedSource());
        return showFailure(payload?.problem);
      }
    }
    if (!isDeviceScanEnabled) {
      dispatch(
        updateUntrustedSourceObject({
          disableScan: true,
          acceptScan: false,
          scanRejectedAppVersion: currentVersion,
        }),
      );
    }
  };

  const handleDeviceScanToggle = () => setIsDeviceScanEnabled(!isDeviceScanEnabled);

  const renderDeviceScanCard = () => {
    const formattedDate = dayjs(untrustedSource?.lastScanAcceptedDate, ApiDateTimeFormat).isValid()
      ? dayjs(untrustedSource?.lastScanAcceptedDate, ApiDateTimeFormat).format(ReceiptDateTimeFormat)
      : '-';
    return (
      <View style={styles.deviceScanCard}>
        <View style={styles.deviceScanHeader}>
          <View style={styles.deviceScanFlex}>
            <Text bold style={styles.deviceScanTitle}>
              {t(`${LANG_PREFIX}deviceScanTitle`)}
            </Text>
            <Text style={styles.deviceScanSubText}>
              {t(`${LANG_PREFIX}deviceScanDate`).replace('${date}', formattedDate)}
            </Text>
          </View>
          <Switch
            status={isDeviceScanEnabled}
            onPress={handleDeviceScanToggle}
            trackColorTrue={colors.yellow}
            thumbColor={colors.yellow}
          />
        </View>
        <Text style={styles.deviceScanText}>{t(`${LANG_PREFIX}deviceScanInfo`)}</Text>
      </View>
    );
  };

  const renderContent = () => {
    if (type === APP_SECURITY_RISK_TYPE.USB_DEBUGGING) {
      return (
        <>
          <View style={styles.sectionContainer}>
            <Text bold style={styles.title}>
              {t(`${LANG_PREFIX}usbDebuggingDetected`)}
            </Text>
            <Text
              style={{
                color: colors.medium,
                marginTop: 10,
                marginBottom: 20,
              }}
            >
              {t(`${LANG_PREFIX}usbDebuggingDetectedDesc`)}
            </Text>

            <View style={styles.notesContainer}>
              <Text bold style={{ fontSize: 13, marginBottom: 10 }}>
                {t(`${LANG_PREFIX}turnOffUsb`)}
              </Text>
              <Notes
                style={{ margin: 0 }}
                data={[
                  {
                    list: [
                      {
                        title: t(`${LANG_PREFIX}turnOffUsbStep1`),
                      },
                      {
                        title: t(`${LANG_PREFIX}turnOffUsbStep2`),
                      },
                      {
                        title: t(`${LANG_PREFIX}turnOffUsbStep3`),
                      },
                    ],
                  },
                ]}
              />
            </View>
            <Space height={10} />
            <View style={styles.notesContainer}>
              <Text bold style={{ fontSize: 13, marginBottom: 10 }}>
                {t(`${LANG_PREFIX}debugOffError`)}
              </Text>
              <Text style={{ fontSize: 13, marginBottom: 5, color: colors.medium }}>
                {`${t(`${LANG_PREFIX}debugOffErrorDesc1`)} `}
                <Text bold>{t(`${LANG_PREFIX}debugOffErrorDesc2`)}</Text>
                {` ${t(`${LANG_PREFIX}debugOffErrorDesc3`)} `}
                <Text bold>{t(`${LANG_PREFIX}debugOffErrorDesc4`)}</Text>
                {` ${t(`${LANG_PREFIX}debugOffErrorDesc5`)}`}
              </Text>
            </View>
            <Space />
            <View style={styles.notesContainer}>
              <Text
                bold
                style={{
                  fontSize: 13,
                  marginBottom: 10,
                  color: colors.primary,
                }}
              >
                {t(`${LANG_PREFIX}cannotFindDevOptions`)}
              </Text>
              <Text bold style={{ fontSize: 13, marginBottom: 10 }}>
                {t(`${LANG_PREFIX}cannotFindDevOptionsDesc`)}
              </Text>
              <Notes
                style={{ margin: 0 }}
                data={[
                  {
                    list: [
                      {
                        title: t(`${LANG_PREFIX}devOptionStep1`),
                      },
                      {
                        title: t(`${LANG_PREFIX}devOptionStep2`),
                      },
                      {
                        title: t(`${LANG_PREFIX}devOptionStep3`),
                      },
                      {
                        title: t(`${LANG_PREFIX}devOptionStep4`),
                      },
                      {
                        title: t(`${LANG_PREFIX}devOptionStep5`),
                      },
                    ],
                  },
                ]}
              />
            </View>
          </View>
          <View style={{ padding: 20 }}>
            <LinkText
              preLinkText={t(`${LANG_PREFIX}moreInfo1`)}
              linkText={t(`${LANG_PREFIX}moreInfo2`)}
              postLinkText={t(`${LANG_PREFIX}moreInfo3`)}
              onPress={() => handleLink(mobileSecurityURL?.url)}
              style={styles.desc}
              linkStyle={{ color: colors.primary }}
            />
          </View>
        </>
      );
    }

    if (type === APP_SECURITY_RISK_TYPE.EMULATOR) {
      return (
        <View style={styles.sectionContainer}>
          <Text bold style={styles.title}>
            {t(`${LANG_PREFIX}riskEmulator`)}
          </Text>
        </View>
      );
    }

    if (type === APP_SECURITY_RISK_TYPE.JAILBREAK) {
      return (
        <View style={styles.sectionContainer}>
          <Text bold style={styles.title}>
            {t(`${LANG_PREFIX}riskJailbreak`)}
          </Text>
        </View>
      );
    }

    if (type === APP_SECURITY_RISK_TYPE.HOOKING) {
      return (
        <View style={styles.sectionContainer}>
          <Text bold style={styles.title}>
            {t(`${LANG_PREFIX}riskHooking`)}
          </Text>
        </View>
      );
    }

    if (type === APP_SECURITY_RISK_TYPE.SCREEN_READER) {
      return (
        <View style={styles.sectionContainer}>
          <Text bold style={styles.title}>
            {t(`${LANG_PREFIX}riskScreenReader`)}
          </Text>
          <Text
            style={{
              color: colors.medium,
              marginTop: 10,
            }}
          >
            {t(`${LANG_PREFIX}riskScreenReaderDesc`)}
          </Text>
          <View style={styles.appNameContainer}>
            {data?.appNames?.map((item, index) => (
              <View key={index}>
                <View style={styles.appNameTextContainer}>
                  <Text bold style={styles.appNameText}>
                    {item}
                  </Text>
                </View>
                {index !== data?.appNames?.length - 1 && <Divider />}
              </View>
            ))}
          </View>

          <View style={styles.notesContainer}>
            <Text
              bold
              style={{
                fontSize: 13,
                marginBottom: 10,
              }}
            >
              {t(`${LANG_PREFIX}disableAcs`)}
            </Text>
            <Notes
              style={{ margin: 0 }}
              data={[
                {
                  list: [
                    {
                      title: t(`${LANG_PREFIX}disableAcsStep1`),
                    },
                    {
                      title: t(`${LANG_PREFIX}disableAcsStep2`),
                    },
                    {
                      title: t(`${LANG_PREFIX}disableAcsStep3`),
                    },
                    {
                      title: t(`${LANG_PREFIX}disableAcsStep4`),
                    },
                  ],
                },
              ]}
            />
          </View>
        </View>
      );
    }

    if (type === APP_SECURITY_RISK_TYPE.UNTRUSTED_MYPB) {
      return (
        <View style={styles.sectionContainer}>
          <Text bold>{t(`${LANG_PREFIX}untrustedMyPB1`)}</Text>
          <View style={styles.untrustedAppContainer}>
            <Text bold style={[styles.appNameText, { fontSize: 14 }]}>
              {t(`${LANG_PREFIX}untrustedMyPB2`)}
            </Text>
            <Text bold style={[styles.appNameText, { fontSize: 14 }]}>
              {t(`${LANG_PREFIX}untrustedMyPB3`)}
            </Text>
          </View>
          <Text style={{ fontSize: 13, color: colors.medium }}>
            {t(`${LANG_PREFIX}untrustedMyPB5`)}
            <Text style={{ color: colors.primary, marginTop: 10 }}>{` ${t(`${LANG_PREFIX}caseManagementEmail`)}`}</Text>
          </Text>
        </View>
      );
    }
    if (type === APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP_SCAN_CONSENT) {
      return (
        <View style={styles.sectionContainer}>
          <Text bold>{t(`${LANG_PREFIX}potentialRisk1`)}</Text>
          <Text style={{ fontSize: 13, marginTop: 20 }}>{t(`${LANG_PREFIX}potentialRisk2`)}</Text>
          <Divider style={{ fontSize: 13, marginTop: 20 }} />
          <Text style={{ fontSize: 13, marginTop: 20, color: colors.medium }}>{t(`${LANG_PREFIX}potentialRisk3`)}</Text>
        </View>
      );
    }

    if (type === APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP) {
      return (
        <View style={styles.sectionContainer}>
          <Text bold>{t(`${LANG_PREFIX}untrustedSourceApp1`)}</Text>
          <View style={{ marginVertical: 20 }}>
            <View style={styles.appNameUntrustedContainer}>
              {data?.untrustedApps?.map((item, index) => {
                if (index > 2 && !showMore) return;
                return (
                  <View key={index}>
                    {index !== 0 && <Divider />}
                    <View style={[styles.appNameTextContainer, { paddingHorizontal: 0 }]}>
                      <Text bold style={styles.appNameText}>
                        {item?.appName}
                      </Text>
                      {/* {item?.installerPackageName ? (
                        <Text style={styles.appInstallerNameText}>{item.installerPackageName}</Text>
                      ) : null}
                      {item?.sha256Signature ? (
                        <Text style={{ marginTop: 10, textAlign: 'center' }}>{item.sha256Signature}</Text>
                      ) : null} */}
                      {/* {item?.installerPackageName ? (
                        <Text style={styles.appInstallerNameText}>{item.installerPackageName}</Text>
                      ) : null}
                      {item?.sha256Signature ? (
                        <Text style={{ marginTop: 10, textAlign: 'center' }}>{item.sha256Signature}</Text>
                      ) : null} */}
                    </View>
                  </View>
                );
              })}
            </View>
            {data?.untrustedApps?.length > 3 ? (
              <View style={styles.moreLessContainer}>
                <MoreLess status={showMore} onPress={() => setShowMore(!showMore)} />
              </View>
            ) : null}
          </View>
          <Text style={{ fontSize: 12, color: colors.medium, marginBottom: 20 }}>
            {t(`${LANG_PREFIX}untrustedSourceApp2`)}
          </Text>
          <Divider />
          <Text style={{ fontSize: 12, marginTop: 20 }}>{t(`${LANG_PREFIX}untrustedSourceApp3`)}</Text>
        </View>
      );
    }
    return null;
  };
  const renderSubmission = () => {
    if (type === APP_SECURITY_RISK_TYPE.SCREEN_READER) {
      return (
        <>
          <TouchableOpacity onPress={selectDontShowAgain} style={styles.checkboxBtn}>
            <Checkbox disabled={true} status={dontShowAgain} />
            <Text>{t(`${LANG_PREFIX}doNotShow`)}</Text>
          </TouchableOpacity>
          <DoneButton title={t(`${LANG_PREFIX}buttonSkip`)} onPress={handleSkip} />
        </>
      );
    }

    if (type === APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP_SCAN_CONSENT) {
      return (
        <BottomView>
          <View style={{ flexDirection: 'row' }}>
            <Button
              style={{ backgroundColor: colors.white }}
              fontStyle={{ color: colors.red }}
              title={t(`${LANG_PREFIX}buttonNo`)}
              onPress={() => setShowScanNotice(true)}
            />
            <Button
              style={{ backgroundColor: colors.primary }}
              fontStyle={{ color: colors.white }}
              title={t(`${LANG_PREFIX}buttonProceed`)}
              onPress={onAllowScan}
            />
          </View>
        </BottomView>
      );
    }

    if (type === APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP) {
      return (
        <>
          {renderDeviceScanCard()}
          <BottomView>
            <View style={{ flexDirection: 'row' }}>
              <Button
                style={{ backgroundColor: colors.white }}
                fontStyle={{ color: colors.red }}
                title={t(`${LANG_PREFIX}buttonDoNotProceed`)}
                onPress={onNotAcceptRisk}
              />
              <Button
                style={{ backgroundColor: colors.primary }}
                fontStyle={{ color: colors.white }}
                title={t(`${LANG_PREFIX}buttonProceedAnyway`)}
                onPress={() => setShowAppListNotice(true)}
              />
            </View>
          </BottomView>
        </>
      );
    }

    return <DoneButton title={t(`${LANG_PREFIX}buttonCloseApp`)} onPress={closeApp} />;
  };

  return (
    <Screen
      singlePage={
        type !== APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP_SCAN_CONSENT &&
        type !== APP_SECURITY_RISK_TYPE.UNTRUSTED_SOURCE_APP
      }
    >
      <NavBar
        showShadow={true}
        bottom={
          <View style={styles.headerContainer}>
            <Text bold style={styles.header}>
              {t(`${LANG_PREFIX}titleSecurityNotice`)}
            </Text>
          </View>
        }
      />
      {isLoading && <LoadingFull blur={true} />}
      <CustomScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.contentContainer}>{renderContent()}</View>
      </CustomScrollView>

      {renderSubmission()}

      <ActionModal
        isVisible={showScanNotice}
        leftButtonType={'normal'}
        leftButtonTitle={t(`${LANG_PREFIX}buttonClose`)}
        rightButtonTitle={t(`${LANG_PREFIX}buttonUnderstand`)}
        variant={'modalize'}
        renderContent={() => {
          return (
            <View>
              <Text style={styles.noticeHeader} bold={true}>
                {t(`${LANG_PREFIX}securityNoticeModalHeader`)}
              </Text>
              <Text style={styles.noticeDesc}>{t(`${LANG_PREFIX}securityNoticeContent1`)}</Text>
            </View>
          );
        }}
        onDecline={() => setShowScanNotice(false)}
        onAccept={() => onNoScan()}
      />

      <ActionModal
        isVisible={showAppListNotice}
        leftButtonType={'normal'}
        leftButtonTitle={t(`${LANG_PREFIX}buttonClose`)}
        rightButtonTitle={t(`${LANG_PREFIX}buttonAgreeProceed`)}
        variant={'modalize'}
        renderContent={() => {
          return (
            <View>
              <Text style={styles.noticeHeader} bold={true}>
                {t(`${LANG_PREFIX}securityNoticeModalHeader`)}
              </Text>
              <Text style={styles.noticeDesc}>{t(`${LANG_PREFIX}securityNoticeContent2`)}</Text>
            </View>
          );
        }}
        onDecline={() => setShowAppListNotice(false)}
        onAccept={() => onAcceptRisk()}
      />

      <ActionModal
        isVisible={showCloseModal}
        rightButtonTitle={t(`${LANG_PREFIX}buttonCloseApp`)}
        renderContent={() => {
          return (
            <View>
              <Text style={styles.noticeHeader} bold={true}>
                {t(`${LANG_PREFIX}closeModalHeader`)}
              </Text>
              <Text style={styles.noticeDesc}>{t(`${LANG_PREFIX}closeModalContent`)}</Text>
            </View>
          );
        }}
        onAccept={() => closeApp()}
      />
    </Screen>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    margin: 20,
  },
  contentContainer: {
    marginVertical: 10,
    marginHorizontal: 10,
  },
  sectionContainer: {
    backgroundColor: colors.white,
    padding: 20,
    borderRadius: 5,
  },
  header: {
    fontSize: 16,
    color: colors.primary,
  },
  title: {
    fontSize: 15,
  },
  desc: {
    color: colors.medium,
    marginBottom: 3,
  },
  checkboxBtn: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
  },
  appNameContainer: {
    backgroundColor: colors.lightestBg,
    borderRadius: 5,
    marginVertical: 20,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: colors.border,
  },
  appNameTextContainer: {
    paddingVertical: 10,
  },
  appNameText: {
    fontSize: 15,
    color: colors.primary,
    textAlign: 'center',
  },
  appInstallerNameText: {
    textAlign: 'center',
  },
  notesContainer: {
    backgroundColor: '#FFF7F7',
    padding: 15,
    paddingBottom: 10,
    borderRadius: 5,
  },
  untrustedAppContainer: {
    borderRadius: 5,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.lightPink,
    marginVertical: 20,
    paddingVertical: 10,
  },
  appNameUntrustedContainer: {
    backgroundColor: colors.lightestBg,
    borderRadius: 5,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: colors.border,
  },
  moreLessContainer: {
    backgroundColor: colors.white,
    borderRadius: 5,
    overflow: 'hidden',
    borderTopWidth: 0,
    borderWidth: 1,
    borderColor: colors.border,
  },
  noticeHeader: {
    marginBottom: 10,
    fontSize: 16,
  },
  noticeDesc: {
    color: colors.medium,
  },
  deviceScanCard: {
    backgroundColor: '#FFFFF7',
    borderRadius: 5,
    paddingVertical: 15,
    paddingHorizontal: 15,
    marginHorizontal: 10,
    marginBottom: 10,
  },
  deviceScanHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  deviceScanFlex: {
    flex: 1,
  },
  deviceScanTitle: {
    fontSize: 14,
    color: colors.black,
  },
  deviceScanSubText: {
    fontSize: 13,
    color: colors.medium,
    marginTop: 5,
  },
  deviceScanText: {
    fontSize: 13,
    color: colors.black,
  },
});
