import React from 'react'
import { Switch as RNSwitch, Platform } from 'react-native'
import { colors } from 'configs'

export const Switch = ({
  status = false,
  onPress,
  disabled = false,
  trackColorTrue = colors.primary,
  thumbColor = colors.primary,
}) => {
  return (
    <RNSwitch
      disabled={disabled}
      value={status}
      onValueChange={onPress}
      style={{ transform: [{ scaleX: 0.75 }, { scaleY: 0.75 }], marginRight: -5 }} //Adjust size
      trackColor={{ true: trackColorTrue, false: '#AAA' }}
      {...(Platform.OS === 'android' && { thumbColor: thumbColor })}
    />
  );
};

export default Switch
