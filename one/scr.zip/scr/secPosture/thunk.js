import { createAsyncThunk } from '@reduxjs/toolkit';
import { apiEndpoint } from 'apis/apiUtils';
import { client } from 'apis';
import { Demo } from 'constant';

const demoResult = {
  status: 'S'
}

export const submitSecurityPosture = createAsyncThunk(
  'setting/submitSecurityPosture',
  async ({ encryptedId, deviceId, type, isAccept, isDeviceScanEnabled }, { dispatch, getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return demoResult;
    const result = await client.post(`${apiEndpoint.public}/updateSecurityPosture`, {
      encryptedId,
      deviceId,
      type,
      isAccept,
      isDeviceScanEnabled,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const submitNoThirdPartyApp = createAsyncThunk(
  'setting/submitNoThirdPartyApp',
  async (_, { rejectWithValue }) => {
    if (Demo.User.Check(getState)) return demoResult;
    const result = await client.get(`${apiEndpoint.public}/updateNoThirdPartyApp`);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const retrieveScanAcceptanceInfo = createAsyncThunk(
  'setting/getScanAcceptanceInfo',
  async (_, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return demoResult;
    const result = await client.get(`${apiEndpoint.public}/getScanAcceptanceInfo`);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
