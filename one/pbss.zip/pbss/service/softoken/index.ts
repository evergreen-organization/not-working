import { baseApi } from '../index';

import {
  TGetInitTransactionResponse,
  TGetPendingTransactionResponse,
  TGetSoftTokenStatusResponse,
  TPostActivateTokenInstanceResponse,
  TPostGenerateTokenInstanceResponse,
  TPostGenerateTokenLicenseResponse,
  TPostRegisterDSAppResponse, TPostRejectTransactionResponse,
  TPostRequestPacResponse,
  TPostValidateIdResponse,
  TPostValidateSecurePinResponse,
} from './types';
import { END_POINTS } from '../endpoints';

export const softTokenService = baseApi.injectEndpoints({
  endpoints: build => ({
    postValidateId: build.mutation<TPostValidateIdResponse, { id: string }>({
      query: ({ id }) => {
        return {
          apiClientType: 'privateClient',
          url: END_POINTS.VALIDATE_ID_PBSS,
          data: { id },
          method: 'post',
        };
      },
    }),
    //softTokenActivationStep1/v2
    postRegisterDSApp: build.mutation<TPostRegisterDSAppResponse, { secfa: string | null }>({
      query: ({ secfa }) => {
        return {
          apiClientType: 'privateClient',
          url: END_POINTS.REGISTER_DS_APP,
          data: { secfa },
          method: 'post',
        };
      },
    }),
    //softTokenActivationStep2
    postGenerateTokenLicense: build.mutation<
      TPostGenerateTokenLicenseResponse,
      { clientEphemeralPublicKey: string; clientEvidenceMessage: string }
    >({
      query: ({ clientEphemeralPublicKey, clientEvidenceMessage }) => {
        return {
          apiClientType: 'privateClient',
          url: END_POINTS.GENERATE_TOKEN_LICENSE,
          data: { clientEphemeralPublicKey, clientEvidenceMessage },
          method: 'post',
        };
      },
    }),
    //softTokenActivationStep3/v2
    postGenerateTokenInstance: build.mutation<
      TPostGenerateTokenInstanceResponse,
      { deviceCode: string; deviceName: string }
    >({
      query: ({ deviceCode, deviceName }) => {
        return {
          apiClientType: 'privateClient',
          url: END_POINTS.GENERATE_TOKEN_INSTANCE,
          data: { deviceCode, deviceName },
          method: 'post',
        };
      },
    }),
    //softTokenActivationStep4/v3
    postActivateTokenInstance: build.mutation<
      TPostActivateTokenInstanceResponse,
      { sequenceNumber: string; signature: string; quickLimit?: number }
    >({
      query: ({ sequenceNumber, signature, quickLimit }) => {
        return {
          apiClientType: 'privateClient',
          url: END_POINTS.ACTIVATE_TOKEN_INSTANCE,
          data: { sequenceNumber, signature, quickLimit },
          method: 'post',
        };
      },
    }),
    postUpdatePreferredAccount: build.mutation<
      TPostValidateIdResponse,
      { isPublic?: boolean; accountNo?: string; accName?: string; accountDesc?: string }
    >({
      query: ({ isPublic = true, accountNo }) => {
        return {
          apiClientType: isPublic ? 'publicClient' : 'privateClient',
          url: isPublic
            ? END_POINTS.UPDATE_PREFERRED_ACC_PUBLIC
            : END_POINTS.UPDATE_PREFERRED_ACC_PRIVATE,
          data: { accountNo },
          method: 'post',
        };
      },
    }),
    getSoftTokenStatus: build.query<TGetSoftTokenStatusResponse, void>({
      query: () => {
        return {
          apiClientType: 'client',
          url: END_POINTS.LOAD_SOFT_TOKEN_STATUS,
        };
      },
    }),
    getInitTransaction: build.query<TGetInitTransactionResponse, { isPublic: boolean }>({
      query: ({ isPublic = true }) => {
        return {
          apiClientType: isPublic ? 'client' : 'privateClient',
          url: isPublic ? END_POINTS.INIT_TRANSACTION_PUBLIC : END_POINTS.INIT_TRANSACTION_PRIVATE,
        };
      },
    }),
    postValidateSignature: build.mutation<
      TPostValidateIdResponse,
      { isPublic: boolean; transactionId?: string; signature?: string }
    >({
      query: ({ isPublic = true, transactionId, signature }) => {
        return {
          apiClientType: isPublic ? 'publicClient' : 'privateClient',
          url: isPublic
            ? END_POINTS.VALIDATE_SIGNATURE_PUBLIC
            : END_POINTS.VALIDATE_SECURE_PIN_PRIVATE,
          data: { transactionId, signature },
          method: 'post',
        };
      },
    }),
    postCheckSecfa: build.mutation<
      TPostValidateIdResponse,
      { isPublic: boolean; secfaInfo: Record<string, any> }
    >({
      query: ({ isPublic = true, secfaInfo }) => {
        return {
          apiClientType: isPublic ? 'publicClient' : 'privateClient',
          url: isPublic ? END_POINTS.CHECK_SECFA_PUBLIC : END_POINTS.CHECK_SECFA_PRIVATE,
          data: { ...secfaInfo },
          method: 'post',
        };
      },
    }),
    postValidateSecurePin: build.mutation<
      TPostValidateSecurePinResponse,
      { isPublic: boolean; pin: string; verifyMethod: 'Biometric' | 'PIN' }
    >({
      query: ({ isPublic = true, pin, verifyMethod }) => {
        return {
          apiClientType: isPublic ? 'publicClient' : 'privateClient',
          url: isPublic
            ? END_POINTS.VALIDATE_SECURE_PIN_PUBLIC
            : END_POINTS.VALIDATE_SECURE_PIN_PRIVATE,
          data: { pin, verifyMethod },
          method: 'post',
        };
      },
    }),
    postRequestPac: build.mutation<TPostRequestPacResponse, { isPublic: boolean }>({
      query: ({ isPublic }) => {
        return {
          apiClientType: isPublic ? 'publicClient' : 'privateClient',
          url: isPublic ? END_POINTS.REQUEST_PAC_PUBLIC : END_POINTS.REQUEST_PAC_PRIVATE,
          data: {},
          method: 'post',
        };
      },
    }),
    getPendingTransaction: build.query<TGetPendingTransactionResponse, void>({
      query: () => {
        return {
          apiClientType: 'client',
          url: END_POINTS.GET_PENDING_TRANSACTION,
        };
      },
    }),
    postRejectTransaction: build.mutation<TPostRejectTransactionResponse, { transactionId: string | null }>({
      query: ({ transactionId }) => {
        return {
          apiClientType: 'publicClient',
          url: END_POINTS.REJECT_PENDING_TRX,
          data: { transactionId },
          method: 'post',
        };
      },
    }),
  }),
});

export const {
  usePostValidateIdMutation,
  usePostRegisterDSAppMutation,
  usePostGenerateTokenLicenseMutation,
  usePostGenerateTokenInstanceMutation,
  usePostActivateTokenInstanceMutation,
  usePostUpdatePreferredAccountMutation,
  useLazyGetSoftTokenStatusQuery,
  useLazyGetInitTransactionQuery,
  usePostValidateSecurePinMutation,
  usePostRequestPacMutation,
  useLazyGetPendingTransactionQuery,
  usePostRejectTransactionMutation,
} = softTokenService;
