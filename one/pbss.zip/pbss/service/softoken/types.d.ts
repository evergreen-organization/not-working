import type { ApiOkResponse } from 'apisauce';
import { TPBSSActivationStatus } from '@/constants/softoken.ts';

export type TPostValidateId = {
  status: string;
  idAttempts?: number;
};

export type TPostRegisterDSApp = {
  status: string;
  secfaAttempts?: number;
  salt?: string;
  serverEphemeralPublicKe?: string;
};

export type TPostGenerateTokenLicense = {
  status: string;
  encryptedMultiDeviceLicenseActivationMessage?: string;
  serverEvidenceMessage?: string;
  mac?: string;
  encryptionCounter?: string;
};

export type TPostGenerateTokenInstance = {
  status: string;
  instanceActivationMessage?: string;
  randomPasswordDerivator?: string;
  serverUTCTime?: string;
};

export type TPostActivateTokenInstance = {
  status: string;
  mac?: string;
  softTokenActivationStatus: TPBSSActivationStatus;
  processedTime?: string;
  coolingOffHour?: number;
  isSoftTokenActivated: boolean;
};

export type TGetSoftTokenStatus = {
  status: string;
  isSoftTokenActivated: boolean;
  softTokenActivationStatus: TPBSSActivationStatus;
  processedTime?: string;
  coolingOffHour?: number;
};

export type TGetInitTransaction = {
  transactionId: string;
  transactionSecureChannelMessage: string;
  encryptedTransactionObject: string;
};

export type TPostValidateSignature = {
  status: string;
};

export type TPostCheckSecfa = {
  isQuickLimitReached?: boolean;
  isSecfaNotRequired?: boolean;
  isDuplicate?: boolean;
  isNewRecipient?: boolean;
  isNewRecipientBlocked?: boolean;
  duplicateTrxList?: TDuplicateTrx;
  availableSecfa: TSecfaType[];
};

export type TPostValidateSecurePin = {
  status: string;
  randomPasswordDerivator?: string;
  serverUTCTime?: string;
};

export type TPostRequestPac = {
  status: string;
  pacSeqNo?: string;
  phoneNo?: string;
};

export type TPendingTrx = {
  transactionSecureChannelMessage: string;
  isFinancial: boolean;
  softTokenType: TSecfaType;
  isNewRecipient: boolean;
  transactionId: string;
  encryptedTransactionObject: string;
};

export type TGetPendingTransaction = {
  status: string;
  pendingTrx?: TPendingTrx;
};

export type TPostRejectTransaction = {
  status: string;
};

export type TPostValidateIdResponse = ApiOkResponse<TPostValidateId>;
export type TPostRegisterDSAppResponse = ApiOkResponse<TPostRegisterDSApp>;
export type TPostGenerateTokenLicenseResponse = ApiOkResponse<TPostGenerateTokenLicense>;
export type TPostGenerateTokenInstanceResponse = ApiOkResponse<TPostGenerateTokenInstance>;
export type TPostActivateTokenInstanceResponse = ApiOkResponse<TPostActivateTokenInstance>;
export type TGetSoftTokenStatusResponse = ApiOkResponse<TGetSoftTokenStatus>;
export type TGetInitTransactionResponse = ApiOkResponse<TGetInitTransaction>;
export type TPostValidateSignatureResponse = ApiOkResponse<TPostValidateSignature>;
export type TPostCheckSecfaResponse = ApiOkResponse<TPostCheckSecfa>;
export type TPostValidateSecurePinResponse = ApiOkResponse<TPostValidateSecurePin>;
export type TPostRequestPacResponse = ApiOkResponse<TPostRequestPac>;
export type TGetPendingTransactionResponse = ApiOkResponse<TGetPendingTransaction>;
export type TPostRejectTransactionResponse = ApiOkResponse<TPostRejectTransaction>;
