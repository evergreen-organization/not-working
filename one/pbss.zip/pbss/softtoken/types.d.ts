import {
  TPostActivateTokenInstance,
  TPostActivateTokenInstanceResponse,
} from '@/services/softoken/types';
import { TAndroidPBSSFingerprintType } from '@/constants/softoken.ts';

export type TSoftTokeInfo = Partial<TPostActivateTokenInstance> & {
  wasActivatedOnSameDevice?: boolean;
  androidFingerprintType?: TAndroidPBSSFingerprintType;
  quickLimit?: number;
};

export type TPreferredAccInfo = {
  accountNo?: string;
  accountLvlName?: string;
  accountName?: string;
  accountStatus?: boolean;
};

export type TAuthInfo = {
  isPublic: boolean;
  lastPacReqTime: number | null;
};
