import { TAuthInfo, TPreferredAccInfo, TSoftTokeInfo } from '@/store/authData/softtoken/types';
import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { softTokenService } from '@/services/softoken';
import { ANDROID_SOFT_TOKEN_FINGERPRINT_TYPE } from '@/constants/softoken';
import { utilityService } from '@/services/utility';

interface InitialState {
  softTokenInfo: TSoftTokeInfo | null;
  preferredAccInfo: TPreferredAccInfo | null;
  authInfo: TAuthInfo;
}

const initialState: InitialState = {
  softTokenInfo: {
    androidFingerprintType: ANDROID_SOFT_TOKEN_FINGERPRINT_TYPE.HARDWARE,
  },
  preferredAccInfo: {},
  authInfo: {
    isPublic: true,
    lastPacReqTime: null,
  },
};

export const softTokenSlice = createSlice({
  name: 'softToken',
  initialState,
  reducers: {
    softTokenReset: _ => initialState,
    updateSoftTokenInfo: (state, { payload }: PayloadAction<Partial<TSoftTokeInfo>>) => {
      if (state.softTokenInfo === null) {
        state.softTokenInfo = payload;
      } else {
        Object.entries(payload!).forEach(([key, value]) => {
          state.softTokenInfo![key as keyof TSoftTokeInfo] = value as never;
        });
      }
    },
    updateAuthInfo: (state, { payload }: PayloadAction<Partial<TAuthInfo>>) => {
      Object.entries(payload!).forEach(([key, value]) => {
        state.authInfo![key as keyof TAuthInfo] = value as never;
      });
    },
  },
  extraReducers(builder) {
    builder.addMatcher(
      softTokenService.endpoints.postUpdatePreferredAccount.matchFulfilled,
      (state, { meta }) => {
        const { accountNo, accName, accountDesc } = meta.arg.originalArgs || {};
        state.preferredAccInfo = {
          accountNo,
          accountLvlName: accName,
          accountName: accountDesc,
          accountStatus: true,
        };
      },
    );
    builder.addMatcher(
      softTokenService.endpoints.getSoftTokenStatus.matchFulfilled,
      (state, { payload }) => {
        const { isSoftTokenActivated, softTokenActivationStatus, processedTime, coolingOffHour } =
          payload.data || {};
        state.softTokenInfo = {
          ...state.softTokenInfo,
          isSoftTokenActivated,
          softTokenActivationStatus,
          processedTime,
          coolingOffHour,
        };
      },
    );
    builder.addMatcher(utilityService.endpoints.getPing.matchFulfilled, state => {
      state.authInfo.isPublic = false;
    });
    builder.addMatcher(utilityService.endpoints.getPing.matchRejected, state => {
      state.authInfo.isPublic = true;
    });
  },
});

export const { softTokenReset, updateSoftTokenInfo, updateAuthInfo } = softTokenSlice.actions;

export default softTokenSlice.reducer;
