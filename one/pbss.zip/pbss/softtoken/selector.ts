import { RootState, useAppSelector } from '@/store';
import { createSelector } from '@reduxjs/toolkit';

const selectSoftToken = (state: RootState): RootState['authData']['softToken'] =>
  state.authData.softToken;

const softTokenSelector = createSelector([selectSoftToken], appData => appData);

const useSoftTokenSelector = () => {
  const { preferredAccInfo, softTokenInfo, authInfo } = useAppSelector(softTokenSelector);
  const isPreferredAccountSelected = !!preferredAccInfo?.accountNo;

  const {
    isSoftTokenActivated,
    softTokenActivationStatus,
    coolingOffHour,
    processedTime,
    quickLimit,
    androidFingerprintType,
  } = softTokenInfo || {};

  return {
    isPreferredAccountSelected,
    preferredAccInfo,
    isSoftTokenActivated,
    softTokenActivationStatus,
    coolingOffHour,
    processedTime,
    quickLimit,
    androidFingerprintType,
    authInfo,
  };
};

export { useSoftTokenSelector };
