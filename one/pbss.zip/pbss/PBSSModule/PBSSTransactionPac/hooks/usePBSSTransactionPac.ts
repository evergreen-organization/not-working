import { useCountDown } from '@/hooks/useCountDown.ts';
import { useEffect, useState } from 'react';
import { usePostRequestPacMutation } from '@/services/softoken';
import { Paths } from '@/navigators/types.ts';
import { useNavigation } from '@react-navigation/native';
import { useHandleApiError } from '@/hooks';
import { PAC_TIMER_DURATION } from '@/constants';
import { useSoftTokenSelector } from '@/store/authData/softtoken/selector.ts';
import { checkTranApiJunction } from '@/screens/PBSSModule/utils/PBSSGeneralUtils.ts';
import { TRAN_API_TYPE_JUNCTION, TTranApiType } from '@/screens/PBSSModule/constant/tranApiType.ts';
import { useAppDispatch } from '@/store';
import { updateAuthInfo } from '@/store/authData/softtoken';
import { utc8DateTime } from '@/utils';

export const usePBSSTransactionPac = ({
  tranApiType,
  onSubmit,
}: {
  tranApiType: TTranApiType;
  onSubmit: ({ secfa }: { secfa: string }) => Promise<void>;
}) => {
  const navigation = useNavigation();
  const dispatch = useAppDispatch();
  const { counter, resetCounter, startCounter } = useCountDown(PAC_TIMER_DURATION);
  const { handlePrivateClientError } = useHandleApiError();

  const { authInfo } = useSoftTokenSelector();
  const isPublic = checkTranApiJunction({
    isPublicState: authInfo.isPublic,
    value: TRAN_API_TYPE_JUNCTION[tranApiType],
  });

  const [postRequestPac, { isLoading: isRequestLoading, data: requestPacData }] =
    usePostRequestPacMutation();

  const [error, setError] = useState<string | null>('');
  const [isRequestRecently, setIsRequestRecently] = useState(false);

  useEffect(() => {
    preLoadPac().then();
  }, []);

  const preLoadPac = async () => {
    if (authInfo.lastPacReqTime && utc8DateTime().diff(authInfo.lastPacReqTime, 'second') < 60) {
      setIsRequestRecently(true);
      return;
    }

    await requestPAC();
  };

  // request pac
  const requestPAC = async (): Promise<void> => {
    try {
      await postRequestPac({ isPublic }).unwrap();
      dispatch(updateAuthInfo({ lastPacReqTime: utc8DateTime().valueOf() }));
      setIsRequestRecently(false);
      resetCounter();
      startCounter();
    } catch (error) {
      const err = handlePrivateClientError({ error });
      setError(err?.errorMessage ?? '');

      if (err.errorCode === 'L00003' || err.errorCode === 'E00079') {
        return navigation.reset({
          index: 1,
          routes: [{ name: Paths.HomeTabNavigator }],
        });
      }
    }
  };

  // submit pin and pac
  const onSubmitPAC = async (pacNumber: string): Promise<void> => {
    await onSubmit({ secfa: pacNumber });
  };

  return {
    onSubmitPAC,
    requestPAC,
    requestPacData,
    canRequestAgain: counter === 0,
    isLoading: isRequestLoading,
    error,
    counter,
    isRequestRecently,
  };
};
