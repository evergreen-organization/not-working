import { RequestPac } from '@/components/templates';
import React from 'react';
import { usePBSSTransactionPac } from '@/screens/PBSSModule/PBSSTransactionPac/hooks/usePBSSTransactionPac.ts';
import { ApplicationNavigatorProps, Paths } from '@/navigators/types.ts';

export const PBSSTransactionPac = ({
  route,
}: ApplicationNavigatorProps<Paths.PBSSTransactionPac>): React.ReactElement => {
  const { tranApiType, onSubmit } = route.params;
  const {
    requestPacData,
    requestPAC,
    onSubmitPAC,
    canRequestAgain,
    isRequestRecently,
    isLoading,
    counter,
  } = usePBSSTransactionPac({ tranApiType, onSubmit });

  return (
    <RequestPac
      requestPacData={requestPacData}
      isLoading={isLoading}
      onSubmitPAC={onSubmitPAC}
      requestPAC={requestPAC}
      counter={counter}
      canRequestAgain={canRequestAgain}
      isRequestRecently={isRequestRecently}
    />
  );
};
