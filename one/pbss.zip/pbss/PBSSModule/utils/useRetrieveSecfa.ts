import { useHandleApiError, usePingPrivate } from '@/hooks';
import { TPostCheckSecfa } from '@/services/softoken/types';
import { ErrorReturnType } from '@/utils';
import { postCheckSecfa } from '@/screens/PBSSModule/utils/PBSSApiUtil.ts';

export interface CheckSecfaResultProps extends
  Partial<TPostCheckSecfa>,
  Partial<ErrorReturnType> {
  isError?: boolean;
  isPublic: boolean;
  showPac?: boolean;
  showPasswordLogin?: boolean;
  showPinModal?: boolean;
  showSecfaModal?: boolean;
  showSecurePac?: boolean;
}

export const useRetrieveSecfa = () => {
  const { handlePrivateClientError } = useHandleApiError();
  const { pingPrivate, isPublic } = usePingPrivate();

  const checkSecfa = async (
    secfaInfo: Record<string, any>
  ): Promise<CheckSecfaResultProps> => {
    const pingPrivateResult = await pingPrivate();
    const apiResponse = await postCheckSecfa({ isPublic: pingPrivateResult.isPublic, secfaInfo });

    if (apiResponse?.problem) {
      const error = handlePrivateClientError({ error: apiResponse?.status });
      let { errorMessage, errorParam } = error;

      if (errorMessage?.includes('${amount}')) {
        errorMessage = errorMessage?.replace('${amount}', errorParam?.amount);
      }
      return {
        ...error,
        errorMessage,
        isError: true,
        isPublic,
      };
    }
    const { isQuickLimitReached, availableSecfa } = apiResponse?.data || {};

    // TODO: need to add PasswordProvider at checkSecfa component, or move this function to checkSecfa controller
    if (isQuickLimitReached) {
      return { showPasswordLogin: true, ...(apiResponse?.data ?? {}), isPublic };
    }

    if (availableSecfa && availableSecfa?.length > 1) {
      return { showSecfaModal: true, ...(apiResponse?.data ?? {}), isPublic };
    }

    if (
      availableSecfa &&
      (availableSecfa[0] === 'SECURE_PAC' || availableSecfa[0] === 'SOFT_TOKEN_PN')
    ) {
      return {
        showPinModal: true,
        showSecurePac: availableSecfa[0] === 'SECURE_PAC',
        ...(apiResponse?.data ?? {}),
        isPublic,
      };
    }

    return { showPac: true, ...(apiResponse?.data ?? {}), isPublic };
  };

  return {
    checkSecfa,
  };
};
