import { softTokenService } from '@/services/softoken';
import {
  TGetInitTransactionResponse,
  TPostActivateTokenInstanceResponse,
  TPostCheckSecfaResponse,
  TPostGenerateTokenInstanceResponse,
  TPostGenerateTokenLicenseResponse,
  TPostValidateSignatureResponse,
} from '@/services/softoken/types';
import { store } from '@/store';
import { ApiErrorType } from '@/utils';

type ResponseType<T> = { error: ApiErrorType; data: undefined } | { data: T; error: undefined };

const postGenerateTokenLicense = async (data: {
  clientEphemeralPublicKey: string;
  clientEvidenceMessage: string;
}) => {
  const result = store.dispatch<any>(
    softTokenService.endpoints.postGenerateTokenLicense.initiate(data),
  ) as ResponseType<TPostGenerateTokenLicenseResponse>;

  const { data: successData, error } = await result;

  return successData ?? error;
};

const postGenerateTokenInstance = async (data: { deviceCode: string; deviceName: string }) => {
  const result = store.dispatch<any>(
    softTokenService.endpoints.postGenerateTokenInstance.initiate(data),
  ) as ResponseType<TPostGenerateTokenInstanceResponse>;

  const { data: successData, error } = await result;

  return successData ?? error;
};

const postActivateTokenInstance = async (data: {
  sequenceNumber: string;
  signature: string;
  quickLimit?: number;
}) => {
  const result = store.dispatch<any>(
    softTokenService.endpoints.postActivateTokenInstance.initiate(data),
  ) as ResponseType<TPostActivateTokenInstanceResponse>;

  const { data: successData, error } = await result;

  return successData ?? error;
};

const getInitTransaction = async (data: { isPublic: boolean }) => {
  const result = (await store.dispatch<any>(
    softTokenService.endpoints.getInitTransaction.initiate(data),
  )) as ResponseType<TGetInitTransactionResponse>;

  const { data: successData, error } = await result;
  return successData ?? error;
};

const postValidateSignature = async (data: {
  isPublic: boolean;
  transactionId?: string;
  signature?: string;
}) => {
  const result = (await store.dispatch<any>(
    softTokenService.endpoints.postValidateSignature.initiate(data),
  )) as ResponseType<TPostValidateSignatureResponse>;

  const { data: successData, error } = await result;
  return successData ?? error;
};

const postCheckSecfa = async (data: { isPublic: boolean; secfaInfo: Record<string, any> }) => {
  const result = (await store.dispatch<any>(
    softTokenService.endpoints.postCheckSecfa.initiate(data),
  )) as ResponseType<TPostCheckSecfaResponse>;

  const { data: successData, error } = await result;
  return successData ?? error;
};

export {
  postActivateTokenInstance,
  postGenerateTokenInstance,
  postGenerateTokenLicense,
  getInitTransaction,
  postCheckSecfa,
  postValidateSignature,
};
