import { JUNCTION_TYPE, TJunctionType } from '@/screens/PBSSModule/constant/tranApiType.ts';

const checkTranApiJunction = ({
  isPublicState,
  value,
}: {
  isPublicState: boolean;
  value: TJunctionType;
}) => {
  if (value === JUNCTION_TYPE.BOTH) return isPublicState;
  return value === JUNCTION_TYPE.PUBLIC;
};

export { checkTranApiJunction };
