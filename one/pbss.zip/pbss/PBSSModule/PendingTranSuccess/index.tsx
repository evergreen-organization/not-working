import { ApplicationNavigatorProps, Paths } from '@/navigators/types.ts';
import React from 'react';
import { Button, CustomScrollView, Screen, Typography } from '@/components/atoms';
import { Receipt } from '@/components/organisms';
import { useWindowDimensions, View } from 'react-native';
import { AppColors, commonStyles } from '@/theme';

export const PendingTranSuccess = ({
  navigation,
}: ApplicationNavigatorProps<Paths.PendingTranSuccess>): React.ReactElement => {
  const window = useWindowDimensions();
  const onDone = () => navigation.popToTop();

  return (
    <Screen>
      <CustomScrollView>
        <Receipt
          animation
          title={'PB SecureSign Transaction Approval - Success'}
          titleStyle={{ fontWeight: 'bold', color: AppColors.black }}
          type={'success'}
          desc={
            <View
              style={{
                minHeight: window.height * 0.3 - 22,
                paddingVertical: 10,
                justifyContent: 'center',
              }}
            >
              <Typography variant={'bodyRegular'} style={[commonStyles.textCenter]}>
                {'This is not a confirmation of transaction status.'}
              </Typography>
              <Typography variant={'bodyRegular'} style={[commonStyles.textCenter]}>
                {
                  'Kindly return to the transaction initiation page to complete your transaction and view the receipt.'
                }
              </Typography>
            </View>
          }
        />
      </CustomScrollView>

      <View style={[commonStyles.x30SizeHMargin, commonStyles.x10SizeBMargin]}>
        <Button title="Done" onPress={onDone} />
      </View>
    </Screen>
  );
};
