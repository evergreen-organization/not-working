import React, { useState } from 'react';
import { showErrorToast } from '@/components/molecules';
import { Paths } from '@/navigators/types.ts';
import { usePingPrivate } from '@/hooks';
import { useNavigation } from '@react-navigation/native';
import { useSoftTokenTransAuth } from 'react-native-softtoken';
import { postValidateSignature } from '@/screens/PBSSModule/utils/PBSSApiUtil.ts';
import {SecurePacDisplayModal} from '@/screens/PBSSModule/components/SecurePacDisplayModal';
import { useActionModal } from '@/context';

export const useApprovePendingTrans = ({ transactionId , isSecurePac}: { transactionId: string, isSecurePac: boolean }) => {
  const navigation = useNavigation();
  const { showActionModal } = useActionModal();
  const [isPinVisible, setIsPinVisible] = useState(false);
  const [isApprovalLoading, setIsApprovalLoading] = useState(false);
  const { handleSignTransaction, validateTransactionSignature } = useSoftTokenTransAuth();
  const { pingPrivate } = usePingPrivate();

  const onSecurePinSuccess = async ({
    randomPasswordDerivator,
    serverUTCTime,
  }: {
    randomPasswordDerivator?: string;
    serverUTCTime?: string;
  }) => {
    setIsApprovalLoading(true);
    // sign the transaction
    const signResult = await handleSignTransaction({ randomPasswordDerivator, serverUTCTime });

    setIsPinVisible(false);

    if (signResult.status !== 'S') {
      setIsApprovalLoading(false);
      return showErrorToast({ message: signResult.errorMessage });
    }

    if(isSecurePac) {
      setIsApprovalLoading(false);
      showSecurePACDisplay(signResult?.data?.secureChannelMessageSignature)
    }

    const pingPrivateResult = await pingPrivate();

    const validateResult = await validateTransactionSignature({
      isPublic: pingPrivateResult.isPublic,
      transactionId,
      signature: signResult?.data?.secureChannelMessageSignature,
      postValidateSignature,
    });

    setIsApprovalLoading(false);

    if (validateResult.status === 'S') {
      return navigation.reset({
        index: 1,
        routes: [
          { name: Paths.HomeTabNavigator },
          {
            name: Paths.PendingTranSuccess,
          },
        ],
      });
    }

    navigation.reset({
      index: 1,
      routes: [
        { name: Paths.HomeTabNavigator },
        {
          name: Paths.PBSSFail,
          params: { title: 'Transaction Fail', errorMessage: validateResult.errorMessage },
        },
      ],
    });
  };

  const onCancelPin = () => setIsPinVisible(false);

  const onApprove = () => setIsPinVisible(true);

  const showSecurePACDisplay = (secureChannelMessageSignature?: string) => {
    showActionModal({
      renderContent: () => <SecurePacDisplayModal secureChannelMessageSignature={secureChannelMessageSignature}/>,
    rightButtonTitle: 'Done',
      onRightButtonPress: () =>     navigation.reset({
        index: 0,
        routes: [{ name: Paths.HomeTabNavigator }],
      })
  });
  };

  return {
    isPinVisible,
    onSecurePinSuccess,
    onCancelPin,
    onApprove,
    isApprovalLoading,
  };
};
