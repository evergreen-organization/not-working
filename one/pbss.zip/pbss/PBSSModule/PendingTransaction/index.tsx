import {
  useLazyGetPendingTransactionQuery,
  usePostRejectTransactionMutation,
} from '@/services/softoken';
import React, { useEffect, useState } from 'react';
import { useHandleApiError } from '@/hooks';
import {
  BottomView,
  Button,
  Divider,
  InfoNotFound,
  NavBar,
  Screen,
  Space,
  Typography,
} from '@/components/atoms';
import {showErrorToast, showSuccessToast, SkeletonTableItem, TableItemTag} from '@/components/molecules';
import { TPendingTrx } from '@/services/softoken/types';
import { useApprovePendingTrans } from '@/screens/PBSSModule/PendingTransaction/hooks/useApprovePendingTrans.tsx';
import { ScrollView, View } from 'react-native';
import { AppColors } from '@/theme';
import commonStyles from '@/theme/commonStyles.ts';
import { useSoftTokenTransAuth } from 'react-native-softtoken';
import {SecurePinSimple} from '../components/SecurePinSimple';
import {Paths} from '@/navigators/types.ts';
import {useNavigation} from '@react-navigation/native';
import {errorCodes} from '@/constants';
import {withAuth} from '@/hoc';

interface TPendingTranDetail {
  header: string;
  body: { subTitle: string; value: string[] }[];
}

const formatTagList = (descList: string[]) =>
  descList.map(item => {
    return { title: item };
  });

export const PendingTransactionScreen = (): React.ReactElement => {
  const navigation = useNavigation();
  const [getPendingTransaction, { isLoading: isLoadingPendingTran, isSuccess }] =
    useLazyGetPendingTransactionQuery();
  const { retrievePendingTransaction, decodeTransactionStr } = useSoftTokenTransAuth();
  const { handlePublicClientError } = useHandleApiError();

  const [isSubmissionLoading, setIsSubmissionLoading] = useState(false);
  const [details, setDetails] = useState<TPendingTranDetail[]>([]);
  const [transactionId, setTransactionId] = useState<string>('');
  const [isSecurePac, setIsSecurePac] = useState<boolean>(false);

  const { isPinVisible, isApprovalLoading, onSecurePinSuccess, onCancelPin, onApprove } =
    useApprovePendingTrans({
      transactionId,
      isSecurePac
    });

  const [postRejectTransaction, { isLoading: isPostRejectTransactionLoading }] = usePostRejectTransactionMutation();


  const isLoading = isLoadingPendingTran || isSubmissionLoading || isApprovalLoading || isPostRejectTransactionLoading;

  useEffect(() => {
    onRefresh();
  }, []);

  const onRefresh = async () => {
    setIsSubmissionLoading(true);
    try {
      const result = await getPendingTransaction().unwrap();

      const { pendingTrx } = result.data || {};

      if(pendingTrx?.softTokenType === 'SECURE_PAC') setIsSecurePac(true);

      if (pendingTrx) await handleRetrievePendingTransaction(pendingTrx);
      setIsSubmissionLoading(false);
    } catch (error) {
      handlePublicClientError({ error });
      setIsSubmissionLoading(false);
    }
  };

  const handleRetrievePendingTransaction = async (pendingTrx: TPendingTrx) => {
    const retrievalResult = await retrievePendingTransaction(pendingTrx);
    if (retrievalResult.status !== 'S')
      return showErrorToast({
        message: `${retrievalResult.status}-${retrievalResult.errorMessage}`,
      });

    const { transactionDetails, transactionId: trxId } = retrievalResult.data || {};

    setTransactionId(trxId!);

    const decodeResult = decodeTransactionStr(transactionDetails);

    if (decodeResult.status !== 'S')
      return showErrorToast({ message: `${decodeResult.status}-${decodeResult.errorMessage}` });

    setDetails(decodeResult.data);
  };

  const handleRejectTransaction = async () => {
    try {
      await postRejectTransaction({transactionId}).unwrap()
      showSuccessToast({message: 'Transaction rejected successfully'})
      return navigation.reset({
        index: 0,
        routes: [{ name: Paths.HomeTabNavigator }],
      })
    } catch (error) {
      const  {errorCode, errorMessage}= handlePublicClientError({ error });

      if(errorCode === errorCodes.E00039 || errorCode === errorCodes.E00076){
        return navigation.reset({
          index: 1,
          routes: [
            { name: Paths.HomeTabNavigator },
            {
              name: Paths.PBSSFail,
              
              params: { title: 'Transaction Fail', errorMessage },
            },
          ],
        });
      }
      showErrorToast({message: errorMessage})
    }
  }


  const renderField = (
    {
      header,
      body,
    }: {
      header: string;
      body: { subTitle: string; value: string[] }[];
    },
    index: number,
  ) => {
    const subTitle = body?.[0].subTitle;
    if (!subTitle) {
      const descList = [...(body?.[0]?.value || [])];
      descList.shift();

      const isFirstObj = index === 0;
      const prevObjHasDetail = details[index - 1]?.body?.[0]?.subTitle;

      return (
        <View style={[{ backgroundColor: AppColors.white }, commonStyles.x20SizeHPadding]}>
          {!isFirstObj && !prevObjHasDetail && <Divider />}
          <TableItemTag
            title={header}
            titleStyle={{ maxWidth: '70%' }}
            value={body?.[0].value[0]}
            tagList={formatTagList(descList)}
            isLast={true}
          />
        </View>
      );
    }

    return (
      <View
        style={[
          commonStyles.x20SizeHPadding,
          commonStyles.x15SizeTPadding,
          commonStyles.x10SizeVMargin,
          { backgroundColor: AppColors.white },
        ]}
      >
        <Typography variant={'titleSmall'}>{header}</Typography>
        {body?.map(({ subTitle, value }, index) => {
          const descList = [...value];
          descList.shift();
          return (
            <TableItemTag
              key={index}
              title={subTitle}
              titleStyle={{ maxWidth: '70%' }}
              value={value[0]}
              tagList={formatTagList(descList)}
              isLast={index === body?.length - 1}
            />
          );
        })}
      </View>
    );
  };

  const renderNotReady = () => {
    if (isLoading) return <SkeletonTableItem loop={6} />;
    return <InfoNotFound title={'No Pending Transaction'} />;
  };

  const renderTransaction = () => (
    <>
      <ScrollView>
        <View
          style={{
            backgroundColor: '#FFF7F7',
            paddingHorizontal: 20,
            paddingVertical: 15,
            marginVertical: 10,
            borderTopWidth: 1,
            borderBottomWidth: 1,
            borderColor: AppColors.border,
          }}
        >
          <Typography variant={'titleSmall'} style={{ color: AppColors.primary, marginBottom: 10 }}>
            {'Did not initiate this transaction'}
          </Typography>
          <Typography>
            {"Reject it immediately and deactivate your User ID from 'Profile' tab."}
          </Typography>
        </View>

        {details?.map((item, index) => <View key={index}>{renderField(item, index)}</View>)}
        <Space height={20} />
      </ScrollView>

      <BottomView>
        <View style={[commonStyles.row]}>
          <Button
            onPress={handleRejectTransaction}
            title={'Reject'}
            labelStyle={{ fontSize: 15, color: AppColors.primary }}
            style={{
              backgroundColor: AppColors.white,
              flex: 1,
              justifyContent: 'center',
              height: 50,
            }}
          />
          <Button
            onPress={onApprove}
            title={'Approve'}
            style={{
              backgroundColor: AppColors.primary,
              borderRadius: 0,
              borderBottomLeftRadius: 3,
              flex: 1,
              justifyContent: 'center',
              height: 50,
            }}
          />
        </View>
      </BottomView>
    </>
  );

  return (
    <Screen>
      <NavBar back title={'PB SecureSign'} />
      {isSuccess && details?.length > 0 ? renderTransaction() : renderNotReady()}
      <SecurePinSimple
        visible={isPinVisible}
        onCancel={onCancelPin}
        onSuccess={onSecurePinSuccess}
      />
    </Screen>
  );
};


export const PendingTransaction = withAuth(PendingTransactionScreen, {
  isSoftTokenActivationRequired: true,
  isLoggedInRequired: false
});
