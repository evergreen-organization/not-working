import React from 'react';
import { View } from 'react-native';
import { Divider, Money, Typography } from '@/components/atoms';
import { AppColors, commonStyles } from '@/theme';
import { displayReceiptDateTime } from '@/utils';

export const DuplicateTrans = ({
  duplicateTrxList,
  trxInfo,
}: {
  duplicateTrxList: Record<string, any>;
  trxInfo?: Record<string, any>;
}): React.ReactElement => {
  const onHoldFound =
    duplicateTrxList?.findIndex(
      (item: { refNo: string }) => item.refNo?.substring(0, 2) === 'OT',
    ) !== -1;

  return (
    <>
      <View style={[commonStyles.row, commonStyles.alignItemsCenter, commonStyles.x20SizeBMargin]}>
        <View style={[commonStyles.fill, commonStyles.x12SizeRPadding]}>
          <Typography style={[commonStyles.x5SizeBMargin, { color: AppColors.medium }]}>
            {'Recipient Account'}
          </Typography>
          <Typography variant={'titleSmall'}>{trxInfo?.accNo}</Typography>
        </View>
        <Money amount={trxInfo?.amount} currency={trxInfo?.currency} size={20} />
      </View>

      <Divider />
      <Typography style={[commonStyles.x15SizeVMargin, { color: AppColors.medium }]}>
        {'Possible duplicate transaction(s) detected:'}
      </Typography>

      <View style={{ marginHorizontal: -3 }}>
        <View
          style={[
            commonStyles.row,
            commonStyles.x10SizePadding,
            commonStyles.bgColor,
            {
              borderTopLeftRadius: 5,
              borderTopRightRadius: 5,
            },
          ]}
        >
          <Typography
            style={[
              commonStyles.fill,
              commonStyles.x10SizeRPadding,
              {
                color: AppColors.medium,
              },
            ]}
          >
            {'Reference No.'}
          </Typography>
          <Typography style={{ color: AppColors.medium }}>{'Date & Time'}</Typography>
        </View>
        <View
          style={{
            borderWidth: 1,
            borderTopWidth: 0,
            borderColor: AppColors.border,
            borderBottomLeftRadius: 5,
            borderBottomRightRadius: 5,
            paddingHorizontal: 10,
          }}
        >
          {duplicateTrxList?.map(
            (
              item: {
                refNo: string | undefined;
                creationDate: string | undefined;
              },
              index: React.Key | null | undefined,
            ) => (
              <View key={index}>
                <View
                  style={[
                    commonStyles.row,
                    commonStyles.alignItemsCenter,
                    commonStyles.x10SizeVPadding,
                  ]}
                >
                  <Typography style={[commonStyles.fill, commonStyles.x10SizeRPadding]}>
                    {item.refNo?.substring(0, 2) === 'OT' ? `*${item.refNo}` : item.refNo}
                  </Typography>
                  <Typography style={{ fontSize: 13 }}>
                    {displayReceiptDateTime(item.creationDate)}
                  </Typography>
                </View>
                {index !== duplicateTrxList?.length - 1 && <Divider />}
              </View>
            ),
          )}
        </View>
        {onHoldFound && (
          <Typography
            style={[
              commonStyles.x10SizeHPadding,
              commonStyles.x10SizeTMargin,
              {
                color: AppColors.medium,
              },
            ]}
          >
            {'* Transaction will be processed after the cooling-off period.'}
          </Typography>
        )}
      </View>
    </>
  );
};
