import React from 'react';
import { View } from 'react-native';
import { Typography } from '@/components/atoms';

export const NewRecipientWarning = (): React.ReactElement => {
  return (
    <View>
      <Typography variant={'titleSmall'}>Alert</Typography>
      <Typography variant={'bodyRegular'}>You are transferring to a new recipient.</Typography>
    </View>
  );
};
