import React from 'react';
import {View} from 'react-native';
import {Typography} from '@/components/atoms';

export const SecurePacDisplayModal = ({secureChannelMessageSignature}: {
  secureChannelMessageSignature?: string
}): React.ReactElement => {
  return (
    <View>
      <Typography variant={'titleMedium'}>Your Secure PAC is</Typography>
      <Typography variant={'titleMedium'} style={{ fontSize: 22, marginVertical: 20, textAlign: 'center' }}>{secureChannelMessageSignature}</Typography>
      <Typography variant={'bodyRegular'}>Please DO NOT share</Typography>
    </View>
  );
};
