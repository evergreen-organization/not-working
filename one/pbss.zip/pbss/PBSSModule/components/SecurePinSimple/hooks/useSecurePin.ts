import { usePostValidateSecurePinMutation } from '@/services/softoken';
import { useHandleApiError } from '@/hooks';
import { useNavigation } from '@react-navigation/native';
import { useState } from 'react';
import {
  biometricKeychainPinErrorType,
  encryption,
  GetKeychainError,
  getKeychainPin,
} from '@/utils';
import { showErrorToast } from '@/components/molecules';
import { Paths } from '@/navigators/types.ts';
import { WEBSEAL_TIMEOUT } from '@/constants';

export const useSecurePin = ({
  onSuccess,
  onCancel,
  isPublic = true,
}: {
  onCancel: () => void;
  onSuccess: ({
    randomPasswordDerivator,
    serverUTCTime,
  }: {
    randomPasswordDerivator?: string;
    serverUTCTime?: string;
  }) => void;
  isPublic?: boolean;
}) => {
  const [postValidateSecurePin] = usePostValidateSecurePinMutation();
  const { handlePrivateClientError } = useHandleApiError();
  const navigation = useNavigation();
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);

  const onPressBiometric = async () => {
    try {
      const { data: storedPin } = await getKeychainPin('Quick Payment');

      await submitPin({ pinNumber: storedPin, verifyMethod: 'Biometric' });
    } catch (error) {
      const errorData = error as GetKeychainError;
      if (
        errorData.errorType === biometricKeychainPinErrorType.limit ||
        errorData.errorType === biometricKeychainPinErrorType.locked
      ) {
        //TODO: Disable biometric login
        return showErrorToast({ message: 'Please log in with PIN' });
      }
    }
  };

  const onChangePin = (digit: string) => {
    const updatedPin = pin + digit;
    const isPinInputCompleted = updatedPin.length === 6;
    setPin(updatedPin);

    if (!isPinInputCompleted) return;
    submitPin({ pinNumber: updatedPin, verifyMethod: 'PIN' });
  };

  const onDelete = (): void => {
    setPin(prev => prev.slice(0, -1));
  };

  const submitPin = async ({
    pinNumber,
    verifyMethod,
  }: {
    pinNumber: string;
    verifyMethod: 'PIN' | 'Biometric';
  }) => {
    const encryptMsg = encryption.encryptUserIdPassword({ password: pinNumber });

    try {
      const result = await postValidateSecurePin({
        isPublic,
        pin: encryptMsg,
        verifyMethod,
      }).unwrap();
      setPin('');
      const { randomPasswordDerivator, serverUTCTime } = result.data || {};

      //TODO: Enable back biometric login after success Pin Login

      onSuccess({ randomPasswordDerivator, serverUTCTime });
    } catch (error) {
      setPin('');
      const err = handlePrivateClientError({ error, shouldShowErrorToast: false });

      console.log({err})
      const { errorCode, errorMessage, errorParam } = err;

      if (errorParam?.isPinLocked) {
        return navigation.reset({
          index: 1,
          routes: [{ name: Paths.HomeTabNavigator }, { name: Paths.ResetPin }],
        });
      }

      if(errorMessage?.includes('${count}') && errorParam?.pinAttempts) {
        setError(errorMessage.replace('${count}', errorParam?.pinAttempts.toString()) as string);
      }

      if (errorCode === WEBSEAL_TIMEOUT || errorCode === 'E00016') {
        return onCancel();
      }
    }
  };

  return {
    onChangePin,
    onPressBiometric,
    onDelete,
    pin,
    error,
  };
};
