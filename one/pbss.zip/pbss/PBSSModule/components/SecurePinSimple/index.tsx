import { BottomModal, PinInputSmall } from '@/components/molecules';
import React from 'react';
import { useSecurePin } from './hooks/useSecurePin.ts';

export const SecurePinSimple = ({
  visible,
  onSuccess,
  onCancel,
  isPublic,
  isLoading = false,
}: {
  visible: boolean;
  onCancel: () => void;
  onSuccess: ({
    randomPasswordDerivator,
    serverUTCTime,
  }: {
    randomPasswordDerivator?: string;
    serverUTCTime?: string;
  }) => void;
  isPublic?: boolean;
  isLoading?: boolean;
}): React.ReactElement => {
  const {error, pin, onChangePin, onDelete, onPressBiometric } = useSecurePin({
    onCancel,
    onSuccess,
    isPublic,
  });

  return (
    <BottomModal visible={visible}>
      <PinInputSmall
        value={pin}
        onChange={onChangePin}
        isVisible={true}
        title={'Enter Pin to Continue'}
        onDelete={onDelete}
        onBiometric={onPressBiometric}
        closeModal={onCancel}
        errorTitle={error}
        isLoading={isLoading}
      />

    </BottomModal>
  );
};
