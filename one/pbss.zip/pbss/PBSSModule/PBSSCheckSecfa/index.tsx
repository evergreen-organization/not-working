import React, { useCallback, useState } from 'react';
import { TSecfaType } from '@/constants/softoken';
import { useActionModal, usePasswordModal } from '@/context';
import { useNavigation } from '@react-navigation/native';
import { Paths } from '@/navigators/types';
import { TTranApiType } from '@/screens/PBSSModule/constant/tranApiType';
import { showErrorToast } from '@/components/molecules';
import {
  CheckSecfaResultProps,
  useRetrieveSecfa,
} from '@/screens/PBSSModule/utils/useRetrieveSecfa.ts';
import { useSoftTokenTransAuth } from 'react-native-softtoken';
import { getInitTransaction, postValidateSignature } from '@/screens/PBSSModule/utils/PBSSApiUtil';
import { NewRecipientWarning } from '@/screens/PBSSModule/components/NewRecipeintWarning';
import { PBSSSecurePac } from '@/screens/PBSSModule/PBSSSecurePac';
import { getErrorMessageFromStatus } from '@/utils';
import { DuplicateTrans } from '@/screens/PBSSModule/components/DuplicateTrans';
import { errorCodes } from '@/constants';
import { FullScreenLoading } from '@/components/atoms';
import { SecurePinSimple } from '@/screens/PBSSModule/components/SecurePinSimple';

interface PBSSCheckSecfaProps {
  secfaInfo: Record<string, any>;
  trxInfo?: Record<string, any>;
  tranApiType: TTranApiType;
  onSubmit: () => Promise<void>;
  onFailure?: ({ errorMessage }: { errorMessage?: string }) => Promise<void>;
}

export const usePBSSCheckSecfa = ({
  secfaInfo,
  tranApiType,
  onSubmit,
  onFailure,
  trxInfo,
}: PBSSCheckSecfaProps) => {
  const navigation = useNavigation();
  const { checkSecfa } = useRetrieveSecfa();
  const {
    initTransaction,
    handleSignTransaction,
    validateTransactionSignature,
    retrieveSecuredTransaction,
  } = useSoftTokenTransAuth();
  const { showPasswordModal } = usePasswordModal();
  const { showActionModal } = useActionModal();

  const [secfaType, setSecfaType] = useState<TSecfaType>('PBSS_NO_SECFA');
  const [isPublicRef, setIsPublicRef] = useState<boolean>(true);
  const [transactionId, setTransactionId] = useState<string | undefined>('');
  const [isSecurePac, setIsSecurePac] = useState<boolean>(false);
  const [secureChannelMessageSignature, setSecureChannelMessageSignature] = useState<
    string | undefined
  >('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isPinLoading, setIsPinLoading] = useState<boolean>(false);

  const startCheckSecfa = useCallback(async () => {
    setIsLoading(true);
    const checkSecfaResult = await checkSecfa(secfaInfo);

    const {
      isNewRecipient,
      showPasswordLogin,
      isPublic,
      isDuplicate,
      duplicateTrxList,
      isError,
      errorCode,
      errorMessage,
    } = checkSecfaResult!;

    setIsLoading(false);

    if (isError) {
      if (errorCode === errorCodes.W00001) return;
      return navigation.reset({
        index: 1,
        routes: [
          { name: Paths.HomeTabNavigator },
          {
            name: Paths.PBSSFail,
            params: { title: 'Transaction Fail', errorMessage },
          },
        ],
      });
    }

    setIsPublicRef(isPublic!);

    if (isNewRecipient) {
      return showNewRecipientWarning(checkSecfaResult);
    }

    if (isDuplicate) {
      return showDuplicateWarning({ duplicateTrxList, checkSecfaResult });
    }

    if (showPasswordLogin) {
      return showPasswordModal({ passwordLoginSuccessCallback: startCheckSecfa });
    }

    return handleSecfaAuthentication(checkSecfaResult);
  }, [secfaInfo, checkSecfa]);

  const handleSecfaAuthentication = async (checkSecfaResult: CheckSecfaResultProps) => {
    const { isSecfaNotRequired, showPinModal, showSecurePac, showPac } = checkSecfaResult!;

    if (showSecurePac) setIsSecurePac(true);

    if (showPinModal) {
      await initializeTransaction();
    }

    if (showPac) return navigation.navigate(Paths.PBSSTransactionPac, { tranApiType, onSubmit });

    if (isSecfaNotRequired) {
      return onSubmit();
    }
  };

  const showNewRecipientWarning = (checkSecfaResult: CheckSecfaResultProps) => {
    showActionModal({
      renderContent: () => <NewRecipientWarning />,
      leftButtonTitle: 'Cancel',
      rightButtonTitle: 'Confirm',
      onLeftButtonPress: () => console.log('pressed cancel'),
      onRightButtonPress: () => handleSecfaAuthentication(checkSecfaResult),
    });
  };

  const showDuplicateWarning = ({
    duplicateTrxList,
    checkSecfaResult,
  }: {
    duplicateTrxList: Record<string, any>;
    checkSecfaResult: CheckSecfaResultProps;
  }) => {
    showActionModal({
      renderContent: () => <DuplicateTrans duplicateTrxList={duplicateTrxList} trxInfo={trxInfo} />,
      leftButtonTitle: 'Cancel',
      rightButtonTitle: 'Confirm',
      onLeftButtonPress: () => console.log('pressed cancel'),
      onRightButtonPress: () => handleSecfaAuthentication(checkSecfaResult),
    });
  };

  const initializeTransaction = async () => {
    setIsLoading(true);
    const initResult = await initTransaction({ isPublic: isPublicRef, getInitTransaction });
    const { transactionId, transactionSecureChannelMessage, encryptedTransactionObject } =
      initResult;
    const result = await retrieveSecuredTransaction({
      transactionId,
      transactionSecureChannelMessage,
      encryptedTransactionObject,
    });
    if (result.status === 'S') {
      setTransactionId(initResult?.transactionId);
      setSecfaType('SOFT_TOKEN_PN');
    }
    setIsLoading(false);
  };

  const onSecurePinSuccess = async ({
    randomPasswordDerivator,
    serverUTCTime,
  }: {
    randomPasswordDerivator?: string;
    serverUTCTime?: string;
  }) => {
    setIsPinLoading(true);
    setSecfaType('PBSS_NO_SECFA');

    const signResult = await handleSignTransaction({ randomPasswordDerivator, serverUTCTime });

    if (signResult.status !== 'S') {
      setIsPinLoading(false);
      // TODO: handle strong box issue and perform silent enrolment
      return showErrorToast({ message: signResult.errorMessage });
    }

    setSecureChannelMessageSignature(signResult?.data?.secureChannelMessageSignature);

    if (isSecurePac) return setSecfaType('SECURE_PAC');

    await handleValidateSignature({ signature: signResult?.data?.secureChannelMessageSignature });
  };

  const handleValidateSignature = async ({ signature }: { signature?: string }) => {
    const validateResult = await validateTransactionSignature({
      isPublic: isPublicRef,
      transactionId,
      signature,
      postValidateSignature,
    });

    setIsPinLoading(false);

    // TODO: redirect to call the submit api and handle the submission result
    if (validateResult.status === 'S') return onSubmit();

    const validateResultErrorCode = validateResult.errorMessage;
    const validateResultErrorMessage = getErrorMessageFromStatus(validateResultErrorCode);

    if (['E00039', 'E00076'].includes(validateResultErrorCode)) {
      return navigation.reset({
        index: 1,
        routes: [
          { name: Paths.HomeTabNavigator },
          {
            name: Paths.PBSSFail,
            params: { title: 'Transaction Fail', errorMessage: validateResultErrorMessage },
          },
        ],
      });
    }

    showErrorToast({
      message: validateResultErrorMessage?.replace(
        '${count}',
        validateResult?.errorParam?.secfaAttempts,
      ),
    });

    onFailure && (await onFailure({ errorMessage: validateResultErrorMessage }));
  };

  const onCancelSecurePin = () => {
    setSecfaType('PBSS_NO_SECFA');
  };

  const PBSSCheckSecfaComponent = useCallback(
    () => (
      <>
        <SecurePinSimple
          visible={secfaType === 'SOFT_TOKEN_PN'}
          onCancel={onCancelSecurePin}
          onSuccess={onSecurePinSuccess}
          isPublic={isPublicRef}
          isLoading={isPinLoading}
        />
        <PBSSSecurePac
          isVisible={secfaType === 'SECURE_PAC'}
          onCloseModal={onCancelSecurePin}
          secureChannelMessageSignature={secureChannelMessageSignature}
          onSubmit={handleValidateSignature}
        />
        {isLoading && <FullScreenLoading blur={true} />}
      </>
    ),
    [secfaType, isPublicRef, secureChannelMessageSignature, isLoading, isPinLoading],
  );

  return {
    startCheckSecfa,
    PBSSCheckSecfaComponent,
  };
};
