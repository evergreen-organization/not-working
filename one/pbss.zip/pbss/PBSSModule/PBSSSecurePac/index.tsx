import { BottomModal } from '@/components/molecules';
import { TouchableOpacity, View, Image } from 'react-native';
import { AppColors, commonStyles } from '@/theme';
import { BaseTextInput, Typography } from '@/components/atoms';
import CloseIcon from '@/assets/images/icons/close.png';
import React, {useState} from 'react';

export const PBSSSecurePac = ({
  isVisible,
  onCloseModal,
  secureChannelMessageSignature,
  onSubmit,
}: {
  isVisible: boolean;
  onCloseModal: () => void;
  secureChannelMessageSignature?: string;
  onSubmit: ({signature}: {   signature?: string | undefined; }) => Promise<void>}): React.ReactElement => {
  const [securePac, setSecurePac] = useState('');


  const onSecurePacChanged = async (signature: string) => {
    setSecurePac(signature);
    if (signature.length < 6) return;
    const result = onSubmit({ signature });
    if(!result )setSecurePac('')
  };


  return (
    <BottomModal visible={isVisible} onCancel={onCloseModal}>
      <TouchableOpacity
        accessibilityLabel={'Close'}
        style={[
          commonStyles.x15SizePadding,
          commonStyles.absolute,
          commonStyles.right0,
          commonStyles.zIndex1,
        ]}
        onPress={onCloseModal}
      >
        <Image source={CloseIcon} style={{ width: 14, height: 14, tintColor: AppColors.primary }} />
      </TouchableOpacity>
      <View style={{ paddingHorizontal: 20, paddingVertical: 10 }}>
        <View
          style={{
            backgroundColor: AppColors.primary,
            padding: 10,
            alignSelf: 'flex-start',
            marginTop: 15,
          }}
        >
          <Typography style={{ fontSize: 20, color: AppColors.white }}>
            {secureChannelMessageSignature}
          </Typography>
        </View>
      </View>
      {/*{secfaAuth.errorMsg !== null && <Text style={styles.errorText}>{secfaAuth.errorMsg}</Text>}*/}
      <View style={{ marginHorizontal: 20, marginBottom: 20 }}>
        <BaseTextInput
          keyboardType={'numeric'}
          maxLength={6}
          value={securePac}
          onChangeText={text => onSecurePacChanged(text)}
          style={{ flex: 0, fontSize: 22, minHeight: 55 }}
        />
      </View>
    </BottomModal>
  );
};
