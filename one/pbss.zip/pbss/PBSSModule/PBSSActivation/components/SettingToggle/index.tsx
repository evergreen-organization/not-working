import React, { type ReactNode } from 'react';
import { StyleSheet, View, TouchableWithoutFeedback } from 'react-native';

import { Divider, Switch, Typography } from '@/components/atoms';
import { Tag } from '@/components/molecules';
import { commonStyles, TagColors } from '@/theme';

const variants = {
  toggle: 'toggle',
  tag: 'tag',
};

interface ISettingToggle {
  variant?: 'toggle' | 'tag';
  title: string;
  value: boolean | string;
  valueDesc?: string;
  // eslint-disable-next-line no-unused-vars
  onChange: (value: boolean) => void;
  children?: ReactNode;
  showDivider?: boolean;
  bold?: boolean;
}

const SettingToggle = ({
  variant = 'toggle',
  title,
  value,
  valueDesc = '',
  onChange,
  children,
  showDivider,
  bold,
}: ISettingToggle): React.ReactElement => {
  const renderStatusText = (text: string, color: any): React.ReactElement => (
    <Tag
      title={text}
      color={color}
      mode="dark"
      fontStyle={styles.tagFontStyle}
      style={styles.tagStyle}
    />
  );

  const renderStatus = (): React.ReactElement => {
    if (value === 'pending') {
      return renderStatusText(getValueDesc('Pending'), TagColors.yellow);
    }
    if (value) {
      return renderStatusText(getValueDesc('Active'), TagColors.green);
    }
    return renderStatusText(getValueDesc('Inactive'), TagColors.red);
  };

  const getValueDesc = (defaultValue: string): string => {
    if (valueDesc) {
      return valueDesc;
    }
    return defaultValue;
  };

  const renderAction = (): React.ReactElement | null => {
    if (variant === variants.toggle) {
      return <Switch status={Boolean(value)} onPress={onChange} />;
    }
    if (variant === variants.tag) {
      return renderStatus();
    }

    return null;
  };

  return (
    <>
      <TouchableWithoutFeedback accessible accessibilityRole="switch">
        <View style={styles.container}>
          <View style={styles.titleContainer}>
            <Typography variant={bold ? 'titleSmall' : 'bodySmall'}>{title}</Typography>
          </View>
          {renderAction()}
        </View>
      </TouchableWithoutFeedback>
      {showDivider && <Divider style={commonStyles.x20SizeHMargin} />}
      {children}
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 50,
  },
  titleContainer: {
    flex: 1,
    marginRight: 5,
  },
  tagFontStyle: {
    fontSize: 14,
  },
  tagStyle: {
    marginRight: 0,
    paddingVertical: 3,
    paddingHorizontal: 8,
  },
});

export default SettingToggle;
