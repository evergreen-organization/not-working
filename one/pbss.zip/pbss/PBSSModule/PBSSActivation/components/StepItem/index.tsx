import React, { type ReactNode } from 'react';
import { StyleSheet, View } from 'react-native';

import { Divider } from '@/components/atoms';
import { AppColors, commonStyles } from '@/theme';

const StepItem = ({
  title,
  desc,
  isLast = false,
}: {
  title: ReactNode;
  desc?: ReactNode;
  isLast?: boolean;
}): React.ReactElement => {
  return (
    <>
      <View style={styles.container}>
        <View
          style={[commonStyles.row, commonStyles.x10SizeVPadding, commonStyles.alignItemsCenter]}
        >
          <View style={styles.dot} />
          <View style={commonStyles.fill}>{title}</View>
        </View>
        {desc && (
          <View
            style={[commonStyles.row, commonStyles.x10SizeBPadding, commonStyles.alignItemsCenter]}
          >
            <View style={styles.space} />
            <View style={commonStyles.fill}>{desc}</View>
          </View>
        )}
      </View>

      {!isLast && <Divider style={commonStyles.x20SizeLMargin} />}
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    minHeight: 45,
    justifyContent: 'center',
  },
  dot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: AppColors.black,
    marginRight: 15,
  },
  space: {
    width: 5,
    height: 5,
    marginRight: 15,
  },
});

export default StepItem;
