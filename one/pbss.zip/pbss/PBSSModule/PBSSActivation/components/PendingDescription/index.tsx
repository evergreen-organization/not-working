import React from 'react';
import { View } from 'react-native';
import { Typography, LinkText } from '@/components/atoms';
import { commonStyles } from '@/theme';
import { SOFT_TOKEN_ACTIVATION_STATUS } from '@/constants/softoken.ts';
import styles from '../../styles.ts';
import StepItem from '../StepItem';

interface PendingDescriptionProps {
  softTokenActivationStatus?: string;
  coolingOffHour?: number;
}

export const PendingDescription: React.FC<PendingDescriptionProps> = ({
  softTokenActivationStatus,
  coolingOffHour,
}) => {
  if (softTokenActivationStatus === SOFT_TOKEN_ACTIVATION_STATUS.PENDING) {
    return (
      <View style={styles.section}>
        <View style={commonStyles.x4SizeLMargin}>
          <StepItem
            title={<Typography>Activate at Public Bank Automated Teller Machine (ATM).</Typography>}
            desc={
              <Typography color="medium">
                {
                  'Select "Other Services > More Services > PB SecureSign / Challenge Questions Activation"'
                }
              </Typography>
            }
          />
          <StepItem
            isLast
            title={
              <Typography>Activate at any Public Bank / Public Islamic Bank Branch</Typography>
            }
          />
        </View>
      </View>
    );
  }

  if (softTokenActivationStatus === SOFT_TOKEN_ACTIVATION_STATUS.COOLING) {
    return (
      <View style={styles.section}>
        <Typography style={commonStyles.x10SizeBMargin}>
          {`Your PB SecureSign will be activated in ${coolingOffHour} hours.`}
        </Typography>
        <Typography style={commonStyles.x10SizeBMargin} color="medium">
          We thank you for your patience as we work to secure your access.
        </Typography>
        <LinkText
          color="medium"
          text="Click here for more information."
          links={[
            {
              link: 'here',
              onPress: () => {},
            },
          ]}
        />
      </View>
    );
  }

  return null;
};
