import React from 'react';
import { Image, View } from 'react-native';
import { Typography } from '@/components/atoms';
import { commonStyles } from '@/theme';
import { displayReceiptDateTime } from '@/utils';
import BankPendingIcon from '@/assets/images/icons/bankPending.png';
import MobileCoolingOffIcon from '@/assets/images/icons/mobile-clock.png';
import { SOFT_TOKEN_ACTIVATION_STATUS } from '@/constants/softoken.ts';
import ReceiptIcon from '../ReceiptIcon';
import styles from '../../styles.ts';

interface TopContentProps {
  error?: string;
  softTokenActivationStatus?: string;
  processedTime?: string;
}

export const TopContent: React.FC<TopContentProps> = ({
  error,
  softTokenActivationStatus,
  processedTime,
}) => {
  if (error) {
    return (
      <>
        <ReceiptIcon type="failed" />
        <Typography style={commonStyles.x10SizeLMargin}>Fail</Typography>
      </>
    );
  }

  if (softTokenActivationStatus === SOFT_TOKEN_ACTIVATION_STATUS.PENDING) {
    return (
      <>
        <Image source={BankPendingIcon} style={styles.iconSize} />
        <View style={[commonStyles.fill, commonStyles.x10SizeLMargin]}>
          <Typography>Pending</Typography>
        </View>
      </>
    );
  }

  if (softTokenActivationStatus === SOFT_TOKEN_ACTIVATION_STATUS.COOLING) {
    return (
      <>
        <Image source={MobileCoolingOffIcon} style={styles.iconSize} />
        <View style={commonStyles.x10SizeLMargin}>
          <Typography style={styles.marginBottom5} variant="titleMedium">
            In Progress
          </Typography>
          <Typography color="medium">{displayReceiptDateTime(processedTime)}</Typography>
        </View>
      </>
    );
  }

  return (
    <>
      <ReceiptIcon />
      <View style={commonStyles.x10SizeLMargin}>
        <Typography>PB SecureSign is active now</Typography>
      </View>
    </>
  );
};
