import React from 'react';
import { View } from 'react-native';
import { Typography, Divider } from '@/components/atoms';
import { TableItemTag } from '@/components/molecules';
import { commonStyles, TagColors } from '@/theme';
import styles from '../../styles.ts';
import SettingToggle from '../SettingToggle';

interface SettingsSectionProps {
  quickLimit?: string | number;
}

export const SettingsSection: React.FC<SettingsSectionProps> = ({ quickLimit }) => {
  return (
    <View style={styles.settingsContainer}>
      <Typography style={styles.sectionHeader}>Other features</Typography>
      <Divider />
      <SettingToggle title="Biometric Approval" value={false} onChange={() => {}} />
      <View style={[commonStyles.x20SizeHMargin, commonStyles.x20SizeBMargin]}>
        <Divider />
        {quickLimit ? (
          <TableItemTag
            title="Quick Payment"
            value="Active"
            titleStyle={styles.titleStyleBlack}
            valueFontStyle={styles.valueFontStyleGreen}
            isLast
            tagList={[
              {
                title: `LKR ${quickLimit}`,
                color: TagColors.grey,
              },
            ]}
          />
        ) : (
          <TableItemTag
            title="Quick Payment"
            value="Inactive"
            titleStyle={styles.titleStyleBlack}
            valueFontStyle={styles.valueFontStyleRed}
            isLast
          />
        )}
      </View>
    </View>
  );
};
