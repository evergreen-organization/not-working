import LottieView from 'lottie-react-native';
import type { AnimationObject } from 'lottie-react-native/src/types.ts';
import React, { useEffect, useRef } from 'react';
import { Image, StyleSheet, View, type ViewStyle, type ImageSourcePropType } from 'react-native';

import CheckIcon from '@/assets/images/icons/check.png';
import CrossIcon from '@/assets/images/icons/close.png';
import PendingIcon from '@/assets/images/icons/exclamation.png';
import failedIcon from '@/assets/lottie/fail.json';
import successIcon from '@/assets/lottie/tick2.json';
import warningIcon from '@/assets/lottie/warning.json';
import { AppColors } from '@/theme';

type ReceiptIconProps = {
  type?: 'success' | 'failed' | 'pending';
  animation?: boolean;
  style?: ViewStyle;
};

type ImageProps = {
  style: ViewStyle;
  image: ImageSourcePropType;
};

const getImageProps = (type: 'success' | 'failed' | 'pending'): ImageProps => {
  switch (type) {
    case 'pending':
      return {
        style: styles.pendingBackground,
        image: PendingIcon,
      };
    case 'failed':
      return {
        style: styles.failedBackground,
        image: CrossIcon,
      };
    default:
      return {
        style: styles.successBackground,
        image: CheckIcon,
      };
  }
};

export const ReceiptIcon: React.FC<ReceiptIconProps> = ({
  type = 'success',
  animation = false,
  style,
}) => {
  const lottieRef = useRef<LottieView>(null);
  const imageProps = getImageProps(type);

  useEffect(() => {
    // if (!isBackground) lottieRef.current?.play();
  }, []);

  const lottieSource = (): string | AnimationObject | { uri: string } => {
    switch (type) {
      case 'pending':
        return warningIcon;
      case 'failed':
        return failedIcon;
      default:
        return successIcon;
    }
  };

  if (animation) {
    return (
      <View style={[styles.lottieContainer, style]}>
        <LottieView
          ref={lottieRef}
          source={lottieSource()}
          loop={false}
          style={styles.lottieIcon}
        />
      </View>
    );
  }

  return (
    <View style={[styles.imageContainer, imageProps.style, style]}>
      <Image source={imageProps.image} style={styles.image} />
    </View>
  );
};

const styles = StyleSheet.create({
  lottieContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 50,
    width: 50,
  },
  imageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 35,
    width: 35,
    borderRadius: 17.5,
  },
  lottieIcon: {
    width: '100%',
    height: '100%',
  },
  image: {
    width: 20,
    height: 20,
    tintColor: AppColors.white,
  },
  successBackground: {
    backgroundColor: AppColors.green,
  },
  failedBackground: {
    backgroundColor: AppColors.red,
  },
  pendingBackground: {
    backgroundColor: AppColors.yellow,
  },
});

export default ReceiptIcon;
