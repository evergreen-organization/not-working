import LottieView from 'lottie-react-native';
import React from 'react';
import { ScrollView, View } from 'react-native';

import loadingLottie from '@/assets/lottie/loading-qrcode.json';
import { BottomButton, Screen, Typography } from '@/components/atoms';
import type { ApplicationNavigatorProps, Paths } from '@/navigators/types.ts';
import { commonStyles } from '@/theme';
import { PendingDescription } from './components/PendingDescription';
import { SettingsSection } from './components/SettingsSection';
import { TopContent } from './components/TopContent';
import usePBSSActivate from './hooks/usePBSSActivate.ts';
import styles from './styles.ts';

export const PBSSActivation = (
  props: ApplicationNavigatorProps<Paths.PBSSActivation>,
): React.ReactElement => {
  const {
    error,
    isLoading,
    softTokenActivationStatus,
    processedTime,
    coolingOffHour,
    quickLimit,
    onSubmit,
  } = usePBSSActivate(props);

  if (isLoading) {
    return (
      <Screen safeTopOnly>
        <LottieView source={loadingLottie} autoPlay loop style={commonStyles.fill} />
      </Screen>
    );
  }

  return (
    <Screen safeTopOnly>
      <Typography variant="titleLarge" style={commonStyles.x20SizeMargin}>
        PB SecureSign Activation
      </Typography>
      <View style={styles.topContentContainer}>
        <TopContent
          error={error}
          softTokenActivationStatus={softTokenActivationStatus}
          processedTime={processedTime}
        />
      </View>
      <ScrollView>
        {error ? (
          <View style={styles.section}>
            <Typography style={commonStyles.x10SizeBMargin}>{`Error code: ${error}`}</Typography>
            <Typography color="medium">Try again</Typography>
          </View>
        ) : (
          <>
            <PendingDescription
              softTokenActivationStatus={softTokenActivationStatus}
              coolingOffHour={coolingOffHour}
            />
            <SettingsSection quickLimit={quickLimit} />
          </>
        )}
      </ScrollView>
      <BottomButton onPress={onSubmit}>Done</BottomButton>
    </Screen>
  );
};
