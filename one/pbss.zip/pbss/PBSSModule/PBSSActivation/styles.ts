import { StyleSheet } from 'react-native';

import { AppColors } from '@/theme';

const styles = StyleSheet.create({
  heading: {
    margin: 20,
    fontSize: 16,
  },
  topContentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 65,
    marginHorizontal: 20,
    paddingVertical: 12,
  },
  section: {
    backgroundColor: AppColors.white,
    padding: 20,
    marginTop: 10,
    paddingVertical: 10,
  },
  sectionHeader: {
    fontSize: 14,
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  settingsContainer: {
    backgroundColor: AppColors.white,
    marginVertical: 10,
  },
  text: {
    fontSize: 14,
    flex: 1,
  },
  errorTitle: {
    fontSize: 20,
    color: AppColors.primary,
    marginBottom: 10,
  },
  errorDesc: {
    fontSize: 15,
    color: AppColors.medium,
  },
  icon: {
    width: 7,
    height: 7,
    tintColor: AppColors.primary,
    marginLeft: 3,
    marginRight: -2,
  },
  iconSize: {
    width: 30,
    height: 30,
  },
  marginBottom5: {
    marginBottom: 5,
  },
  doneButton: {
    backgroundColor: AppColors.primary,
    borderRadius: 10,
    height: 45,
    justifyContent: 'center',
  },
  doneButtonText: {
    fontSize: 15,
    color: AppColors.white,
    textAlign: 'center',
  },
  titleStyleBlack: {
    color: AppColors.black,
  },
  valueFontStyleGreen: {
    color: AppColors.green,
  },
  valueFontStyleRed: {
    color: AppColors.red,
  },
});

export default styles;
