import { useEffect, useState } from 'react';

import { SOFT_TOKEN_ACTIVATION_STATUS } from '@/constants/softoken.ts';
import type { ApplicationNavigatorProps, Paths } from '@/navigators/types.ts';
import { updateSoftTokenInfo } from '@/store/authData/softtoken';
import { useSoftTokenSelector } from '@/store/authData/softtoken/selector.ts';
import { useUserSelector } from '@/store/authData/user/selector.ts';
import { useDispatch } from 'react-redux';
import { ApiErrorType, getDeviceName } from '@/utils';
import { useSoftTokenActivation } from 'react-native-softtoken';
import {
  postActivateTokenInstance,
  postGenerateTokenInstance,
  postGenerateTokenLicense,
} from '../../utils/PBSSApiUtil.ts';
import { useHandleApiError } from '@/hooks';

type ActivationResult = {
  softTokenActivationStatus?: 'PENDING' | 'PROCESSING' | 'ACTIVATED';
  processedTime?: string;
  coolingOffHour?: number;
  isSoftTokenActivated?: boolean;
};

const usePBSSActivate = ({
  navigation,
  route,
}: ApplicationNavigatorProps<Paths.PBSSActivation>) => {
  const [error, setError] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { activationPWord, salt, serverEphemeralPublicKey, quickLimit } = route.params || {};
  const { userInformation, isDemo } = useUserSelector();
  const { androidFingerprintType } = useSoftTokenSelector();
  const { handlePrivateClientError } = useHandleApiError();

  const { activateSoftToken } = useSoftTokenActivation({
    postGenerateTokenInstance,
    postGenerateTokenLicense,
    postActivateTokenInstance,
  });

  const { softTokenActivationStatus, coolingOffHour, processedTime, isSoftTokenActivated } =
    useSoftTokenSelector();

  const dispatch = useDispatch();

  const onSubmit = (): void => {
    navigation.popToTop();
  };

  useEffect(() => {
    if (!isSoftTokenActivated) activatePBSS().then();
  }, []);

  const activatePBSS = async () => {
    if (isDemo) {
      return dispatch(
        updateSoftTokenInfo({
          softTokenActivationStatus: SOFT_TOKEN_ACTIVATION_STATUS.ACTIVE,
          isSoftTokenActivated: true,
        }),
      );
    }
    setIsLoading(true);

    const deviceName = await getDeviceName();

    const result = await activateSoftToken<ActivationResult, ApiErrorType>({
      activationPWord,
      salt,
      serverEphemeralPublicKey,
      quickLimit,
      deviceId: userInformation?.deviceId!,
      encryptedId: userInformation?.encryptedId!,
      androidFingerprintType,
      deviceName,
    });

    console.log({ path: 'activationResult', result });

    let errorMessage = `${result.errorCode} - ${result.errorMessage}`;

    // this is for server error response
    if (result?.serverError && !result?.serverError?.ok) {
      const serverError = handlePrivateClientError({ error: result?.serverError });
      errorMessage = `${result.errorCode} - ${serverError.errorMessage}`;
    }

    setIsLoading(false);

    if (result.status !== 'S') {
      setError(errorMessage);
      return;
    }

    const { softTokenActivationStatus, processedTime, coolingOffHour, isSoftTokenActivated } =
      result.data ?? {};

    dispatch(
      updateSoftTokenInfo({
        softTokenActivationStatus,
        processedTime,
        coolingOffHour,
        isSoftTokenActivated,
      }),
    );
  };

  return {
    error,
    isLoading,
    softTokenActivationStatus,
    processedTime,
    coolingOffHour,
    quickLimit,
    onSubmit,
  };
};

export default usePBSSActivate;
