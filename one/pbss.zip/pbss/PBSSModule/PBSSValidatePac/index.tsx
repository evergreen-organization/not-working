import React from 'react';
import { ApplicationNavigatorProps, Paths } from '@/navigators/types.ts';
import { RequestPac } from '@/components/templates/RequestPac';
import { useValidatePBSSPac } from '@/screens/PBSSModule/PBSSValidatePac/hooks/useValidatePBSSPac.ts';

export const PBSSValidatePac = ({
  route,
}: ApplicationNavigatorProps<Paths.PBSSValidatePac>): React.ReactElement => {
  const { quickLimit } = route.params || {};
  const { onSubmitPAC, requestPAC, requestPacData, isLoading, canRequestAgain, counter } =
    useValidatePBSSPac({ quickLimit });

  return (
    <RequestPac
      requestPacData={requestPacData}
      isLoading={isLoading}
      onSubmitPAC={onSubmitPAC}
      requestPAC={requestPAC}
      counter={counter}
      canRequestAgain={canRequestAgain}
    />
  );
};
