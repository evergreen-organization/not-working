import { useCountDown } from '@/hooks/useCountDown.ts';
import { usePostInitSoftTokenActivationMutation } from '@/services/authentication';
import { useUserSelector } from '@/store/authData/user/selector.ts';
import { useCallback, useEffect, useState } from 'react';
import { usePostRegisterDSAppMutation } from '@/services/softoken';
import { Paths } from '@/navigators/types.ts';
import { useNavigation } from '@react-navigation/native';
import { useHandleApiError } from '@/hooks';
import { PAC_TIMER_DURATION } from '@/constants';

export const useValidatePBSSPac = ({ quickLimit }: { quickLimit: number }) => {
  const navigation = useNavigation();
  const { counter, resetCounter, startCounter } = useCountDown(PAC_TIMER_DURATION);
  const { handlePrivateClientError } = useHandleApiError();

  const [postInitSoftTokenActivation, { isLoading: isRequestLoading, data: requestPacData }] =
    usePostInitSoftTokenActivationMutation();
  const [postRegisterDSApp, { isLoading: isPostRegistDSAppLoading }] =
    usePostRegisterDSAppMutation();
  const { userInformation } = useUserSelector() || {};

  const [error, setError] = useState('');

  useEffect(() => {
    requestPAC().then();
  }, []);

  // request pac
  const requestPAC = async (): Promise<void> => {
    if (userInformation?.secfaType === 'HARD_TOKEN') return console.log('call hard token api');
    await postInitSoftTokenActivation({ secfa: '' });
    resetCounter();
    startCounter();
  };

  // submit pin and pac
  const onSubmitPAC = useCallback(async (pacNumber: string): Promise<void> => {
    await validateCheckSum(pacNumber);
  }, []);

  const validateCheckSum = async (activationPWord: string) => {
    const secfa = userInformation?.secfaType === 'PAC' ? activationPWord : null;

    try {
      const result = await postRegisterDSApp({ secfa }).unwrap();

      if (result.ok) {
        return navigation.reset({
          index: 1,
          routes: [
            { name: Paths.HomeTabNavigator },
            {
              name: Paths.PBSSActivation,
              params: { quickLimit, activationPWord, ...result?.data },
            },
          ],
        });
      }
    } catch (error) {
      handlePrivateClientError({
        error,
      });
    }
  };

  return {
    onSubmitPAC,
    requestPAC,
    requestPacData,
    canRequestAgain: counter === 0,
    isLoading: isRequestLoading || isPostRegistDSAppLoading,
    error,
    counter,
  };
};
