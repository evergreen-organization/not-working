import { Button, CustomScrollView, Screen, Typography } from '@/components/atoms';
import { Receipt } from '@/components/organisms';
import React from 'react';
import { ApplicationNavigatorProps, Paths } from '@/navigators/types.ts';
import { commonStyles } from '@/theme';
import { useWindowDimensions, View } from 'react-native';

export const PBSSFail = ({
  route,
  navigation,
}: ApplicationNavigatorProps<Paths.PBSSFail>): React.ReactElement => {
  const { title, errorMessage } = route.params || {};
  const window = useWindowDimensions();

  const onDone = () => navigation.popToTop();

  return (
    <Screen>
      <CustomScrollView>
        <Receipt
          title={title}
          titleStyle={{ fontWeight: 'bold' }}
          type={'failed'}
          desc={
            <View style={{ minHeight: window.height * 0.3 }}>
              <Typography variant={'bodyRegular'} style={[commonStyles.textCenter]}>
                {errorMessage}
              </Typography>
            </View>
          }
        />
      </CustomScrollView>

      <View style={[commonStyles.x30SizeHMargin, commonStyles.x10SizeBMargin]}>
        <Button title="Done" onPress={onDone} />
      </View>
    </Screen>
  );
};
