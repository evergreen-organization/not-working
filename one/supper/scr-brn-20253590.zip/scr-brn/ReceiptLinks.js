import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Image, Platform } from 'react-native';
import { Text } from 'components';
import Share from 'react-native-share';
import RNFS from 'react-native-fs';

import { showInfo } from 'utils/message';
import { colors } from 'configs';
import { Divider } from '../atoms/view/Divider';
import { QuickLinkItem } from '../molecules/QuickLinkItem';
import { ViewToImage } from '../organisms/ViewToImage';
import { Flex } from 'atoms';

import ShareIcon from 'assets/images/basiccolor/share.png';
import PBBFullIcon from 'assets/images/corporation/pbbpibb.png';
import PBBTaglineIcon from 'assets/images/corporation/pbbtagline.png';
import { useTranslation } from 'react-i18next';

const LANG_PREFIX = 'components.receipt.text.';

export const ReceiptLinks = ({ content, extraButton, centerButton, isShareEnabled = true }) => {
  const { t } = useTranslation();

  const [receiptBase64, setReceiptBase64] = useState('');
  const [isReceiptReady, setIsReceiptReady] = useState(false);

  useEffect(() => {
    setTimeout(() => setIsReceiptReady(true), 1000);
  }, []);

  const onShare = async () => {
    if (!receiptBase64) return showInfo(t(LANG_PREFIX + 'imageReceiptNotReady'));
    if (Platform.OS === 'ios') {
      await RNFS.writeFile(`${RNFS.CachesDirectoryPath}/Receipt.png`, receiptBase64, 'base64');
      return share({
        url: `${RNFS.CachesDirectoryPath}/Receipt.png`,
        type: 'image/png',
      });
    }
    share({ url: `data:image/png;base64,${receiptBase64}` });
  };

  const share = prop => {
    Share.open(prop)
      .then((onfulfilled, onrejected) => {})
      .catch(err => {
        //empty
      });
  };

  return (
    <>
      <View style={styles.quickLinkContainer}>
        {extraButton && (
          <>
            {extraButton}
            <Divider vertical style={{ borderLeftColor: colors.lightgrey, height: 15, alignSelf: 'center' }} />
          </>
        )}

        {centerButton && (
          <>
            {centerButton}
            <Divider vertical style={{ borderLeftColor: colors.lightgrey, height: 15, alignSelf: 'center' }} />
          </>
        )}

        <QuickLinkItem
          disabled={!isShareEnabled}
          style={styles.quicklink}
          icon={ShareIcon}
          label={t(LANG_PREFIX + 'buttonShareReceipt')}
          onPress={onShare}
          iconStyle={styles.icon}
        />
      </View>

      <ViewToImage isReady={isReceiptReady} onComplete={base64 => setReceiptBase64(base64)}>
        <View style={styles.contentContainer}>
          {content}
          <View style={styles.footerContainer}>
            <Flex>
              <Image source={PBBTaglineIcon} style={styles.taglineImg} />
            </Flex>
            <Flex>
              <Image source={PBBFullIcon} style={styles.pbbImg} />
            </Flex>
          </View>
          <View style={styles.brnContainer}>
            <Text style={styles.brnText}>{t(LANG_PREFIX + 'pbbBRN')}</Text>
            <Text style={styles.brnText}>{t(LANG_PREFIX + 'pibbBRN')}</Text>
          </View>
        </View>
      </ViewToImage>
    </>
  );
};

const styles = StyleSheet.create({
  quickLinkContainer: {
    flexDirection: 'row',
    marginVertical: 5,
    marginHorizontal: 20,
    justifyContent: 'center',
  },
  contentContainer: {
    paddingTop: 20,
    paddingBottom: 30,
  },
  footerContainer: {
    backgroundColor: colors.lightestBg,
    alignItems: 'center',
    flexDirection: 'row',
    marginHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 10,
    marginTop: -10,
  },
  quicklink: {
    flex: 0.5,
  },
  icon: {
    width: 28,
    height: 28,
  },
  pbbImg: {
    width: 118,
    height: undefined,
    aspectRatio: 1600 / 365,
    alignSelf: 'center',
  },
  taglineImg: {
    width: 128,
    height: undefined,
    aspectRatio: 897 / 55,
    alignSelf: 'center',
  },
  brnContainer: {
    marginTop: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  brnText: { fontSize: 12, color: colors.medium, textAlign: 'center' },
});

export default ReceiptLinks;
