#!/bin/bash
# Batch file for auto rollback
#Script begining
echo 'Auto Rollback Begin'
echo '======================================='
echo 'Preparation Begin'
echo '======================================='
#home directory
HOME=/root/20241206_pbb
PROJECTDIRECATORY=/app/public_html
# Set project identity variables
PATCHNAME=EKYC_20241206
RELEASE_DIR=$HOME/$PATCHNAME
echo 'Preparation Completed'
echo '======================================='
echo 'Preparing Backup'

echo 'backup directory : backup /backend/themes/basic/landmark-application/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/landmark-application/view.php
RELEASE_CONSOLE_PATH=$BACKUP_DIR
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/landmark-application/
cp -R $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'backup directory : backup /backend/themes/basic/system-configuration-application/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/system-configuration-application/view.php
RELEASE_CONSOLE_PATH=$BACKUP_DIR
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/system-configuration-application/
cp -R $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'backup directory : backup /backend/themes/basic/thredhold-color/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-color/index.php
RELEASE_CONSOLE_PATH=$BACKUP_DIR
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-color/
cp -R $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'backup directory : backup /backend/themes/basic/thredhold-facial-recognition/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-facial-recognition/index.php
RELEASE_CONSOLE_PATH=$BACKUP_DIR
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-facial-recognition/
cp -R $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'backup directory : backup /backend/themes/basic/thredhold-kba/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-kba/index.php
RELEASE_CONSOLE_PATH=$BACKUP_DIR
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-kba/
cp -R $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'backup directory : backup /backend/themes/basic/thredhold-landmark/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-landmark/index.php
RELEASE_CONSOLE_PATH=$BACKUP_DIR
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-landmark/
cp -R $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'backup directory : backup /backend/themes/basic/thredhold-similarity/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-similarity/index.php
RELEASE_CONSOLE_PATH=$BACKUP_DIR
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-similarity/
cp -R $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'Auto Rollback Completed'
echo '======================================='
