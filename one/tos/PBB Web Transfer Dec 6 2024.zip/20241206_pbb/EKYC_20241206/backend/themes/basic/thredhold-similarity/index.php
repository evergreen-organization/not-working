<?php

use backend\models\User;
use yii\helpers\Html;
use kartik\grid\GridView;
use kartik\icons\FontAwesomeAsset;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Similarity Threshold');
$this->params['breadcrumbs'][] = $this->title;
FontAwesomeAsset::register($this);
$getModel = $dataProvider->getModels();
$js = <<< JS
     $(".alert").animate({opacity: 1.0}, 3000).fadeOut("slow");
JS;
$this->registerJs($js, yii\web\View::POS_READY);

$authManager = Yii::$app->authManager->getPermissionsByUser(Yii::$app->user->id);
$checkManual = false;
foreach ($authManager as $vals) {

    if ($vals->name == 'Threshold Approve' || $vals->name == '/*') {
        $checkManual = true;

    }
}
$url = \yii\helpers\Url::to(['thredhold-similarity/request']);
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>

    function updateValue(element, column, id, system_id) {
        var value = element.innerText.replace(/(\r\n|\n|\r)/gm,"");

        if(system_id == 5 || system_id == 10 || system_id == 10 || system_id == 30 || system_id == 33) {

        }else{
            if(value>100 || isNaN(value)){
                alert("Numeric only and not higher than 100");
                location.reload();
                return false;
            }
        }
    }

    function updateValue2(element, count) {
        var value = document.getElementById("dropdownidnew_field_value"+ count).innerHTML;
    }


    function request(id,count) {

        if ($('#text_status'+count).length) {
            var value = document.getElementById("text_status"+ count).innerHTML;
        }

        if(value == null){
            var value = document.getElementById("dropdownidnew_field_value"+ count).value;
        }

        var status = document.getElementById("dropdownidnew_field_status"+ count).value;

        if(value == 'NA' && status == ''){
            alert("Please make a change before request");
            return false;
        }

        if(value || status){
            var reason = prompt("Please enter the reason and confirm:", "");
        }
        $.ajax({
            'url': '<?= $url ?>',
            'type': 'post',
            'data': {
                id: id,
                value: value,
                status: status,
                reason: reason
            },
            success: function (php_result) {
                console.log(php_result);
                $(element).removeAttr('class');
            }
        })
    }

    function activate(element) {
        $(element).attr('class', 'activate')

    }

    function updateStatus(column, id, system_id, count,status) {
        var value_status = document.getElementById("dropdownidnew_field_status"+ count).value;
        if(system_id == 36 || system_id == 37 || system_id == 38 || system_id == 39 || system_id == 40) {
            if(value_status == '0' && status == '1'){

                $("#dropdownidnew_field_value"+ count).prop("selectedIndex", 0).val();
                $("#dropdownidnew_field_value"+ count).attr('disabled', true);

            }else if(value_status == '1' && status == '1'){
                $("#dropdownidnew_field_value"+ count).attr('disabled', false);

            }
        }else{
            if(value_status == '0' && status == '1'){
                document.getElementById("text_status"+ count).innerHTML = "N/A";
                document.getElementById("text_status"+ count).contentEditable = false;
                document.getElementById("text_status"+ count).style.color = "black";
            }else if(value_status == '1' && status == '1'){
                document.getElementById("text_status"+ count).contentEditable = true;
                document.getElementById("text_status"+ count).style.color = "dodgerblue";

            }
        }

    }

    $(document).keypress(
        function(event){
            if (event.which == '13') {
                event.preventDefault();
            }
        });

</script>
<style>
    .activate {
        background: white;
        border-top: 1px solid #333;
        border-left: 1px solid #333;
        border-right: 1px solid #ccc;
        border-bottom: 1px solid #ccc;
    }

    select {
        border-radius: 5px;
    }

    .custom {
        width: 78px !important;
    }

</style>



<div class="landmark-thredhold-index col-md-12">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="well">
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
            <th>No.</th>
            <th>Landmark</th>
            <th>Threshold</th>
            <th>Status</th>
            <th>New Proposed Threshold</th>
            <th>New Proposed Status</th>
            <th>Action</th>
            <th>Requestor Reason</th>
            <th>Last Updated At</th>
            <th>Last Updated By</th>
            <th>Last Decision At</th>
            <th>Last Decision By</th>

            <?php
            $count = 1;
            foreach ($getModel as $val) {

                $name = $val['name'];
                $value = $val['value'];
                $status = $val['system_status'];
                $new_field_value = $val['new_field_value'];
                $new_field_status = $val['new_field_status'];
                $newid = $val['newid'];
                $requester_reason = $val['requester_reason'];
                $created_at = $val['created_at'];
                $requester_id  = $val['requester_id'];
                $approval_id = $val['approval_id'];
                $updated_at = $val['updated_at'];
                $approve_at = $val['approved_at'];
                $id = $val['id'];
                $system_id = $val['system_id'];
                ?>
                <tr>
                    <td><?php echo $count ?></td>
                    <td><?php echo $name ?></td>
                    <td><?php echo $value ?></td>
                    <td><?php if ($status == 0): echo 'OFF'; elseif ($status == 1): echo 'ON';endif; ?></td>

                    <?php if ($system_id == 36 || $system_id == 37 || $system_id == 38 || $system_id == 39 || $system_id == 40) { ?>
                        <?php if($status == 0){?>
                            <td><select disabled id="dropdownidnew_field_value<?php echo $count; ?>" onclick="activate(this)" class="select"
                                        onchange="updateValue2('new_field_value','<?php echo $count; ?>')">
                                    <option value="<?php echo $new_field_value?>"><?php if ($new_field_value == 'YES'): echo 'YES';
                                            $optionValue = 'NO';
                                            $getVersa = 'NO';
                                            $optionValue2 = '';
                                            $getVersa2 = '';
                                        elseif ($new_field_value == 'NO'): echo 'NO';
                                            $optionValue = 'YES';
                                            $getVersa = 'YES';
                                            $optionValue2 = '';
                                            $getVersa2 = '';
                                        else: echo '';
                                            $optionValue = 'YES';
                                            $getVersa = 'YES';
                                            $optionValue2 = 'NO';
                                            $getVersa2 = 'NO';
                                        endif; ?>
                                    </option>
                                    <option value="<?php echo $optionValue; ?>"><?php echo $getVersa; ?></option>
                                    <option value="<?php echo $optionValue2; ?>"><?php echo $getVersa2; ?></option>
                                </select></td>
                        <?php }else{ ?>
                            <td><select id="dropdownidnew_field_value<?php echo $count; ?>" onclick="activate(this)" class="select"
                                        onchange="updateValue2('new_field_value','<?php echo $count; ?>')">
                                    <option value="<?php echo $new_field_value?>"><?php if ($new_field_value == 'YES'): echo 'YES';
                                            $optionValue = 'NO';
                                            $getVersa = 'NO';
                                            $optionValue2 = '';
                                            $getVersa2 = '';
                                        elseif ($new_field_value == 'NO'): echo 'NO';
                                            $optionValue = 'YES';
                                            $getVersa = 'YES';
                                            $optionValue2 = '';
                                            $getVersa2 = '';
                                        else: echo '';
                                            $optionValue = 'YES';
                                            $getVersa = 'YES';
                                            $optionValue2 = 'NO';
                                            $getVersa2 = 'NO';
                                        endif; ?>
                                    </option>
                                    <option value="<?php echo $optionValue; ?>"><?php echo $getVersa; ?></option>
                                    <option value="<?php echo $optionValue2; ?>"><?php echo $getVersa2; ?></option>
                                </select></td>
                        <?php } ?>
                    <?php } else { ?>
                        <?php if($status == 0){?>
                            <td style="color: dodgerblue; text-decoration: underline;">
                                <div id="text_status<?php echo $count; ?>" contenteditable="false"
                                     onblur="updateValue(this,'new_field_value','<?php echo $newid; ?>')"
                                     onKeyDown="if(event.keyCode==13) updateValue(this,'new_field_value','<?php echo $newid; ?>');"
                                     style="color: black"><?php echo $new_field_value ?></div>
                            </td>
                        <?php }else{ ?>
                            <td style="color: dodgerblue; text-decoration: underline;">
                                <div id="text_status<?php echo $count; ?>" contenteditable="true"
                                     onblur="updateValue(this,'new_field_value','<?php echo $newid; ?>')"
                                     onKeyDown="if(event.keyCode==13) updateValue(this,'new_field_value','<?php echo $newid; ?>');"
                                     onclick="activate(this)"><?php echo $new_field_value ?></div>
                            </td>
                        <?php } ?>
                    <?php } ?>



                    <td>
                        <select id="dropdownidnew_field_status<?php echo $count; ?>" onclick="activate(this)" class="select"
                                onchange="updateStatus('new_field_status','<?php echo $newid; ?>','<?php echo $system_id; ?>','<?php echo $count; ?>','<?php echo $status; ?>')">
                            <option value="<?php echo $new_field_status ?>">
                                <?php
                                if ($new_field_status == '0'): echo 'OFF';
                                    $optionValue = 1;
                                    $getVersa = 'ON';
                                    $optionValue2 = '';
                                    $getVersa2 = '';
                                elseif ($new_field_status == '1'): echo 'ON';
                                    $optionValue = 0;
                                    $getVersa = 'OFF';
                                    $optionValue2 = '';
                                    $getVersa2 = '';
                                else: echo '';
                                    $optionValue = 1;
                                    $getVersa = 'ON';
                                    $optionValue2 = 0;
                                    $getVersa2 = 'OFF';
                                endif; ?>
                            </option>
                            <option value="<?php echo $optionValue; ?>"><?php echo $getVersa; ?></option>
                            <option value="<?php echo $optionValue2; ?>"><?php echo $getVersa2; ?></option>
                        </select>
                    </td>
                    <?php echo "<td>
                    <button type='button' class='btn btn-primary custom' onclick='request($newid,$count)'>Request</button>
                </td>";?>
                    <td><?php echo $requester_reason ?></td>
                    <td><?php echo Yii::$app->formatter->asDate($created_at, 'dd-MM-yyyy H:i:s'); ?></td>
                    <td><?php echo User::findUserById2($requester_id) ?></td>
                    <td><?php echo Yii::$app->formatter->asDate($approve_at, 'dd-MM-yyyy H:i:s'); ?></td>
                    <td><?php echo User::findUserById2($approval_id) ?></td>

                </tr>
                <?php $count++;
            } ?>
        </table>
        </div>
    </div>
</div>
