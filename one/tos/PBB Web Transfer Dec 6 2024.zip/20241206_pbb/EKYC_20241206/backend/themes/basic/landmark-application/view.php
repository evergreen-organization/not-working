<?php

use backend\models\User;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use kartik\grid\GridView;
use kartik\icons\FontAwesomeAsset;

/* @var $this yii\web\View */
/* @var $model backend\models\LandmarkApplication */


$this->title = $username . '  >   ' . $package_name;
$this->params['breadcrumbs'][] = ['label' => 'Landmark Individual Threshold', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
FontAwesomeAsset::register($this);
$getlist = ArrayHelper::map(\backend\models\LandmarkThredhold::find()->all(), 'id', 'landmark');
$getModel = $dataProvider->getModels();
$js = <<< JS
     $(".alert").animate({opacity: 1.0}, 3000).fadeOut("slow");
JS;
$this->registerJs($js, yii\web\View::POS_READY);
$url = \yii\helpers\Url::to(['landmark-application/request']);
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>

    function updateValue(element, column, id, app_id) {
        var value = element.innerText.replace(/(\r\n|\n|\r)/gm,"");

        if(value>100 || isNaN(value)){
            alert("Numeric only and not higher than 100");
            location.reload();
            return false;
        }
    }


    function request(id,count,old_value,old_status,app_id) {

        var value = document.getElementById("text_status"+ count).innerHTML;
        var status = document.getElementById("dropdownidnew_field_status"+ count).value;

        if(old_status == '0') {
            if(status == '' || status == '0' ){
                alert("Please make a change before request");
                return false;
            }
        }
        if(old_status =='1'){
            if(status == '' || (status == '1' && value == 'N/A')){
                alert("Please make a change before request");
                return false;
            }
            if(value == old_value){
                alert("New threshold cannot be the same as old threshold");
                return false;
            }
        }

        if(value || status){
            var reason = prompt("Please enter the reason and confirm:", "");
        }
        $.ajax({
            'url': '<?= $url ?>',
            'type': 'post',
            'data': {
                id: id,
                value: value,
                status: status,
                reason: reason,
                app_id: app_id
            },
            success: function (php_result) {
                console.log(php_result);
                $(element).removeAttr('class');
            }
        })
    }

    function activate(element) {
        $(element).attr('class', 'activate')
    }

    function updateStatus(column, id, app_id, count,status) {
        //document.getElementById("demo").innerHTML = "You selected: " + x;
        var value_status = document.getElementById("dropdownidnew_field_status"+ count).value;
        if(value_status == '0' && status == '1'){
            document.getElementById("text_status"+ count).innerHTML = "N/A";
            document.getElementById("text_status"+ count).contentEditable = false;
            document.getElementById("text_status"+ count).style.color = "black";
        }else if(value_status == '1' && status == '1'){
            document.getElementById("text_status"+ count).contentEditable = true;
            document.getElementById("text_status"+ count).style.color = "dodgerblue";

        }
        //alert(value_status);
    }

    $(document).keypress(
        function(event){
            if (event.which == '13') {
                event.preventDefault();
            }
        });

</script>
<style>
    .activate {
        background: white;
        border-top: 1px solid #333;
        border-left: 1px solid #333;
        border-right: 1px solid #ccc;
        border-bottom: 1px solid #ccc;
    }

    select {
        border-radius: 5px;
    }

</style>

<div class="landmark-individual-threshold-view col-md-12">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="well">
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
            <th>No.</th>
            <th>Landmark</th>
            <th>Threshold</th>
            <th>Status</th>
            <th>New Proposed Threshold</th>
            <th>New Proposed Status</th>
            <th>Action</th>
            <th>Requestor Reason</th>
            <th>Last Updated At</th>
            <th>Last Updated By</th>
            <th>Last Decision At</th>
            <th>Last Decision By</th>
            <?php /*if($checkManual):echo"<th>Action</th>"; endif;*/?>
            <!--<th>Alert</th>
            <th>Alert Level</th>
            <th>Alert Value</th>
            <th>Created At</th>
            <th>Updated At</th>-->

            <?php
            $count = 1;
            //print_r($getModel);
            foreach ($getModel as $val) {

                $landmark = $val['landmark_id'];
                $threshold = $val['threshold'];
                $status = $val['threshold_status'];
                $new_field_value = $val['new_field_value'];
                $new_field_status = $val['new_field_status'];
                $newid = $val['newid'];
                $requester_reason = $val['requester_reason'];
                $created_at = $val['created_at'];
                $requester_id  = $val['requester_id'];
                $approval_id = $val['approval_id'];
                $updated_at = $val['updated_at'];
                $approve_at = $val['approved_at'];
                $app_id = $val['app_id'];
                $id = $val['id'];
                ?>
                <tr>
                    <td><?php echo $count ?></td>
                    <td><?php echo \backend\models\LandmarkThresholdReview::findLandmarkName($landmark); ?></td>
                    <td><?php echo (int)$threshold ?></td>
                    <td><?php if ($status == 0): echo 'OFF'; elseif ($status == 1): echo 'ON';endif; ?></td>
                    <?php if($status == 0 || $new_field_status == '0'){?>
                        <td style="color: dodgerblue; text-decoration: underline;">
                            <div id="text_status<?php echo $count; ?>" contenteditable="false"
                                 onblur="updateValue(this,'new_field_value','<?php echo $newid; ?>')"
                                 onKeyDown="if(event.keyCode==13) updateValue(this,'new_field_value','<?php echo $newid; ?>');"
                                 style="color: black"><?php echo $new_field_value ?></div>
                        </td>
                    <?php }else{ ?>
                        <td style="color: dodgerblue; text-decoration: underline;">
                            <div id="text_status<?php echo $count; ?>" contenteditable="true"
                                 onblur="updateValue(this,'new_field_value','<?php echo $newid; ?>')"
                                 onKeyDown="if(event.keyCode==13) updateValue(this,'new_field_value','<?php echo $newid; ?>');"
                                 onclick="activate(this)"><?php echo $new_field_value ?></div>
                        </td>
                    <?php } ?>
                    <td>
                        <select id="dropdownidnew_field_status<?php echo $count; ?>" onclick="activate(this)" class="select"
                                onchange="updateStatus('new_field_status','<?php echo $newid; ?>','<?php echo $landmark; ?>','<?php echo $count; ?>','<?php echo $status; ?>')">
                            <option value="<?php echo $new_field_status ?>">
                                <?php
                                if ($new_field_status == '0'): echo 'OFF';
                                    $optionValue = 1;
                                    $getVersa = 'ON';
                                    $optionValue2 = '';
                                    $getVersa2 = '';
                                elseif ($new_field_status == '1'): echo 'ON';
                                    $optionValue = 0;
                                    $getVersa = 'OFF';
                                    $optionValue2 = '';
                                    $getVersa2 = '';
                                else: echo '';
                                    $optionValue = 1;
                                    $getVersa = 'ON';
                                    $optionValue2 = 0;
                                    $getVersa2 = 'OFF';
                                endif; ?>
                            </option>
                            <option value="<?php echo $optionValue; ?>"><?php echo $getVersa; ?></option>
                            <option value="<?php echo $optionValue2; ?>"><?php echo $getVersa2; ?></option>
                        </select>
                    </td>
                    <?php echo "<td>
                    <button type='button' class='btn btn-primary custom' onclick='request($newid,$count,$threshold,$status,$app_id)'>Request</button>
                </td>";?>
                    <td><?php echo $requester_reason ?></td>
                    <td><?php echo Yii::$app->formatter->asDate($created_at, 'dd-MM-yyyy H:i:s'); ?></td>
                    <td><?php echo User::findUserById2($requester_id) ?></td>
                    <td><?php echo Yii::$app->formatter->asDate($approve_at, 'dd-MM-yyyy H:i:s'); ?></td>
                    <td><?php echo User::findUserById2($approval_id) ?></td>
                    <?php /*if($checkManual): echo "<td>
                    <button type='button' class='btn btn-danger custom' onclick='reject($newid )'>Reject</button>
                    <button type='button' class='btn btn-success custom' onclick='approve($newid)'>Approve</button>
                </td>"; endif;*/?>
                </tr>
                <?php $count++;
            } ?>
        </table>
        </div>
    </div>
</div>
