#!/bin/bash
# Batch file for auto deployment
#Script begining
echo 'Auto Deployment Begin'
echo '======================================='
echo 'Preparation Begin'
echo '======================================='
#home directory
HOME=/root/20241206_pbb
PROJECTDIRECATORY=/app/public_html
# Set project identity variables
PATCHNAME=EKYC_20241206
RELEASE_DIR=$HOME/$PATCHNAME
echo 'Preparation Completed'
echo '=======================================' 

echo 'deploy : /backend/themes/basic/landmark-application/'
echo '======================================='
RELEASE_CONSOLE_PATH=$RELEASE_DIR/backend/themes/basic/landmark-application/*
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/landmark-application/
cp $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'deploy : /backend/themes/basic/system-configuration-application/'
echo '======================================='
RELEASE_CONSOLE_PATH=$RELEASE_DIR/backend/themes/basic/system-configuration-application/*
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/system-configuration-application/
cp $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'deploy : /backend/themes/basic/thredhold-color/'
echo '======================================='
RELEASE_CONSOLE_PATH=$RELEASE_DIR/backend/themes/basic/thredhold-color/*
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-color/
cp $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'deploy : /backend/themes/basic/thredhold-facial-recognition/'
echo '======================================='
RELEASE_CONSOLE_PATH=$RELEASE_DIR/backend/themes/basic/thredhold-facial-recognition/*
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-facial-recognition/
cp $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'deploy : /backend/themes/basic/thredhold-kba/'
echo '======================================='
RELEASE_CONSOLE_PATH=$RELEASE_DIR/backend/themes/basic/thredhold-kba/*
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-kba/
cp $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'deploy : /backend/themes/basic/thredhold-landmark/'
echo '======================================='
RELEASE_CONSOLE_PATH=$RELEASE_DIR/backend/themes/basic/thredhold-landmark/*
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-landmark/
cp $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'deploy : /backend/themes/basic/thredhold-similarity/'
echo '======================================='
RELEASE_CONSOLE_PATH=$RELEASE_DIR/backend/themes/basic/thredhold-similarity/*
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-similarity/
cp $RELEASE_CONSOLE_PATH  $TARGET_CONSOLE_PATH

echo 'Auto Deployment Completed'
echo '======================================='
echo '======================================='