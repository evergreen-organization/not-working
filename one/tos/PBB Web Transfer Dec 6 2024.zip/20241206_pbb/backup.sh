#!/bin/bash
# Batch file for auto backup
#Script begining
echo 'Auto Backup Begin'
echo '======================================='
echo 'Preparation Begin'
echo '======================================='
#home directory
HOME=/root/20241206_pbb
PROJECTDIRECATORY=/app/public_html
# Set project identity variables
PATCHNAME=EKYC_20241206
RELEASE_DIR=$HOME/$PATCHNAME
echo 'Preparation Completed'
echo '======================================='
echo 'Preparing Backup'

#backup directory : /backend/themes/basic/landmark-application/
echo 'backup directory : /backend/themes/basic/landmark-application/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/landmark-application/
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/landmark-application/
cp -R $TARGET_CONSOLE_PATH/* $BACKUP_DIR

#backup directory : /backend/themes/basic/system-configuration-application/
echo 'backup directory : /backend/themes/basic/system-configuration-application/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/system-configuration-application/
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/system-configuration-application/
cp -R $TARGET_CONSOLE_PATH/* $BACKUP_DIR

#backup directory : /backend/themes/basic/thredhold-color/
echo 'backup directory : /backend/themes/basic/thredhold-color/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-color/
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-color/
cp -R $TARGET_CONSOLE_PATH/* $BACKUP_DIR

#backup directory : /backend/themes/basic/thredhold-facial-recognition/
echo 'backup directory : /backend/themes/basic/thredhold-facial-recognition/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-facial-recognition/
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-facial-recognition/
cp -R $TARGET_CONSOLE_PATH/* $BACKUP_DIR

#backup directory : /backend/themes/basic/thredhold-kba/
echo 'backup directory : /backend/themes/basic/thredhold-kba/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-kba/
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-kba/
cp -R $TARGET_CONSOLE_PATH/* $BACKUP_DIR

#backup directory : /backend/themes/basic/thredhold-landmark/
echo 'backup directory : /backend/themes/basic/thredhold-landmark/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-landmark/
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-landmark/
cp -R $TARGET_CONSOLE_PATH/* $BACKUP_DIR

#backup directory : /backend/themes/basic/thredhold-similarity/
echo 'backup directory : /backend/themes/basic/thredhold-similarity/'
echo '======================================='
BACKUP_DIR=$HOME/$PATCHNAME/backup/backend/themes/basic/thredhold-similarity/
TARGET_CONSOLE_PATH=$PROJECTDIRECATORY/backend/themes/basic/thredhold-similarity/
cp -R $TARGET_CONSOLE_PATH/* $BACKUP_DIR

echo 'Backup Completed'
echo '======================================='

