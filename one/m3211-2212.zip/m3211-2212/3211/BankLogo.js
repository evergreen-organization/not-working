import React from 'react';
import { View, Image, StyleSheet } from 'react-native';

import { colors } from 'configs';
import { bankLogoMapping } from 'constant';
import { Text } from '../../text';

export const BankLogo = ({ id, name, size = 26 }) => {
  const src = bankLogoMapping[id];
  if (src) return <Image source={src} style={[styles.image, { width: size, height: size }]} resizeMode='contain' />;
  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Text bold>{name?.charAt(0)}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  image: {
    borderRadius: 5,
  },
  container: {
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.bg,
  },
});

export default BankLogo;
