import React from 'react';
import { useSelector } from 'react-redux';
import { Alert, ScrollView, StyleSheet, View } from 'react-native';

import { colors } from 'configs';
import routes from 'navigations/routes';
import { useApi } from 'hooks';
import { showFailure } from 'utils';
import { Flex, LoadingFull, Screen, Space } from 'atoms';
import { ButtonList, QuickLinkItem, TableItemTag } from 'molecules';
import { NavBar } from 'organisms';
import { deleteRecurringTran, getRecurringDetailsObj } from 'stores';

import DocumentIcon from 'assets/images/basiccolor/document.png';
import HistoryIcon from 'assets/images/basiccolor/history.png';
import BinIcon from 'assets/images/basiccolor/bin.png';
import { useTranslation } from 'react-i18next';

export const RecurringDetails = ({ navigation, route }) => {
  const LANG_PREFIX = 'screens.scheduledTransRecurringDetails.text.';
  const LANG_PREFIX_ESI_FREQ = 'constant.ESI_FREQUENCY.';
  const { t } = useTranslation();
  const item = route.params.item;
  const { refNo, alias, type, fromAcc, effectiveDate, frequency, occurrence, amount, status } = route.params.item || {};
  const { status: detailsStatus } = useSelector(getRecurringDetailsObj(refNo)) || {};

  const deleteRecurringTranApi = useApi(deleteRecurringTran);

  const preDelete = () => {
    Alert.alert(t(`${LANG_PREFIX}alertTitle`), t(`${LANG_PREFIX}alertMessage`), [
      {
        text: t(`${LANG_PREFIX}alertCancel`),
      },
      {
        text: t(`${LANG_PREFIX}alertDelete`),
        style: 'destructive',
        onPress: () => onDelete(),
      },
    ]);
  };

  const onDelete = async () => {
    const result = await deleteRecurringTranApi.request({ refNo });
    if (result.problem) return showFailure(result.problem);
    navigation.navigate(routes.ESI);
  };

  return (
    <Screen>
      <NavBar title={t(`${LANG_PREFIX}navTitle`)} back />
      <Flex>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.tableContainer}>
            <TableItemTag title={t(`${LANG_PREFIX}itemRefNo`)} value={refNo} />
            <TableItemTag title={t(`${LANG_PREFIX}itemPaymentAlias`)} value={alias} />
            <TableItemTag title={t(`${LANG_PREFIX}itemTransactionType`)} value={type} />
            <TableItemTag title={t(`${LANG_PREFIX}itemFromAccount`)} value={fromAcc} />
            <TableItemTag title={t(`${LANG_PREFIX}itemEffectiveDate`)} value={effectiveDate} />
            <TableItemTag title={t(`${LANG_PREFIX}itemFrequency`)} value={t(LANG_PREFIX_ESI_FREQ + frequency)} />
            <TableItemTag title={t(`${LANG_PREFIX}itemOccurrence`)} value={occurrence} />
            <TableItemTag title={t(`${LANG_PREFIX}itemAmount`)} value={amount} currency={'RM'} />
            {status === 'P' ? (
              <TableItemTag
                title={t(`${LANG_PREFIX}itemStatus`)}
                value={t(`${LANG_PREFIX}itemValueOngoing`)}
                valueFontStyle={{ color: colors.yellow }}
                isLast={true}
              />
            ) : (
              <TableItemTag
                title={t(`${LANG_PREFIX}itemStatus`)}
                value={t(`${LANG_PREFIX}itemValueCompleted`)}
                valueFontStyle={{ color: colors.green }}
                isLast={true}
              />
            )}
          </View>

          <ButtonList title={t(`${LANG_PREFIX}buttonListTitleView`)}>
            {status === 'P' && (
              <QuickLinkItem
                icon={DocumentIcon}
                label={t(`${LANG_PREFIX}buttonUpcoming`)}
                onPress={() => navigation.navigate(routes.RECURRING_HISTORY, { item, tab: 'Upcoming' })}
              />
            )}
            <QuickLinkItem
              icon={HistoryIcon}
              label={t(`${LANG_PREFIX}buttonPast`)}
              onPress={() => navigation.navigate(routes.RECURRING_HISTORY, { item, tab: 'Past' })}
            />
          </ButtonList>

          {status === 'P' && (
            <ButtonList title={t(`${LANG_PREFIX}buttonListTitleOthers`)}>
              <QuickLinkItem icon={BinIcon} label={t(`${LANG_PREFIX}buttonDeleteTransaction`)} onPress={preDelete} />
            </ButtonList>
          )}
          <Space height={50} />
        </ScrollView>

        {detailsStatus === 'loading' && <LoadingFull blur />}
      </Flex>
    </Screen>
  );
};

export default RecurringDetails;

const styles = StyleSheet.create({
  tableContainer: {
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    marginBottom: 10,
  },
});
