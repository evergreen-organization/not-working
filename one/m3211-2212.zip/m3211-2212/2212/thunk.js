import { createAsyncThunk } from '@reduxjs/toolkit';
import { publicClient } from 'apis/publicClient';
import { apiEndpoint } from 'apis/apiUtils';
import { Demo } from '../../../constant';

export const getRecurring = createAsyncThunk('getRecurring', async (param, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return Demo.ScheduledTran.Recurring;
  const result = await publicClient.get(`${apiEndpoint.public}/esi/getTrxList/v2`);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const getRecurringDetails = createAsyncThunk(
  'getRecurringDetails',
  async ({ refNo }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.ScheduledTran.RecurringDetails;
    const result = await publicClient.post(`${apiEndpoint.public}/esi/getTrxDetails`, { refNo });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const deleteRecurringTran = createAsyncThunk(
  'deleteRecurringTran',
  async ({ refNo }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return;
    const result = await publicClient.post(`${apiEndpoint.public}/esi/deleteEsiTrx`, { refNo });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const deleteRecurringDetails = createAsyncThunk(
  'deleteRecurringDetails',
  async ({ refNo, srowId }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return;
    const result = await publicClient.post(`${apiEndpoint.public}/esi/deleteEsiDetails`, { refNo, srowId });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
