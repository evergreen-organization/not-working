import React, { useEffect, useRef, useState } from 'react';
import { AccessibilityInfo, Platform, Pressable, StyleSheet, View } from 'react-native';
import FlashMessage from 'react-native-flash-message';
import Toast from 'react-native-toast-message';

import { colors } from 'configs';
import { Cross, Divider, Tick } from 'atoms';
import { Button, Text } from 'components';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FONT_FAMILY_BOLD, FONT_FAMILY_REGULAR } from 'styles/fonts';
import { announceInfo, setAccessibilityFocus } from 'utils';
import { useTranslation } from 'react-i18next';
import { ActionMessageToast, AppRatingToast, ChangeIconToast, EnrolCQToast, ExternalLinkToast , CloneDeviceToast} from 'organisms';
import { HardBlockToast } from 'organisms';

const variants = {
  custom: 'custom',
  secureSign: 'secureSign',
  appRating: 'appRating',
  externalLink: 'externalLink',
  changeIcon: 'changeIcon',
  accessDeniedHardBlock: 'accessDeniedHardBlock',
  actionMessage: 'actionMessage',
  enrolCq: 'enrolCq',
  cloneDevice: 'cloneDevice',
};

export const AppMessage = navigation => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.appMessage.text.';
  const insets = useSafeAreaInsets();
  const toastRef = useRef(null);
  const customToastRef = useRef(null);
  const [isScreenReaderEnabled, setScreenReaderEnabled] = useState(false);

  useEffect(() => {
    AccessibilityInfo.isScreenReaderEnabled().then(isEnabled => {
      setScreenReaderEnabled(isEnabled);
    });
  }, []);

  const toastConfig = {
    custom: ({ text1, text2, onPress }) => (
      <Pressable accessible={true} ref={customToastRef} style={{ width: '100%' }} onPress={onPress}>
        <View style={styles.toastContainerStyle}>
          <Text bold style={styles.toastText}>
            {text1}
          </Text>
          <Text>{text2}</Text>
        </View>
      </Pressable>
    ),
    secureSign: ({ onPress }) => (
      <Pressable
        accessible={true}
        ref={toastRef}
        onMagicTap={() => onPress(1)}
        style={{ width: '100%' }}
        onPress={() => onPress(0)}>
        <View style={[styles.toastContainerStyle, { paddingBottom: 0 }]}>
          <View style={{ paddingBottom: 10 }}>
            <Text accessibilityLabel={t(`${LANG_PREFIX}titlePendingTrx`)} bold style={styles.toastText}>
              {t(`${LANG_PREFIX}titlePendingTrx`)}
            </Text>
            <Text accessibilityLabel={t(`${LANG_PREFIX}acsNavigatePBSS`)}>{t(`${LANG_PREFIX}navigatePBSS`)}</Text>
          </View>
          <View style={styles.toastButtonContainer}>
            <Button
              accessibilityLabel={t(`${LANG_PREFIX}buttonDoubleTapClose`)}
              accessibilityRole={'button'}
              title={t(`${LANG_PREFIX}buttonClose`)}
              style={styles.toastButton}
              fontStyle={styles.toastButtonText}
              isBold={false}
              onPress={() => onPress(0)}
            />
            <Divider vertical style={styles.toastDivider} />
            <Button
              accessibilityLabel={`${
                Platform.OS === 'ios'
                  ? t(`${LANG_PREFIX}buttonDoubleTapTwoFingers`)
                  : t(`${LANG_PREFIX}buttonDoubleTap`)
              } `}
              accessibilityRole={'button'}
              title={t(`${LANG_PREFIX}buttonView`)}
              style={styles.toastButton}
              fontStyle={styles.toastButtonText}
              isBold={false}
              onPress={() => onPress(1)}
            />
          </View>
        </View>
      </Pressable>
    ),
    [variants.appRating]: ({ onPress }) => <AppRatingToast onPress={onPress} ref={toastRef} />,
    [variants.externalLink]: ({ onPress, props }) => (
      <ExternalLinkToast onPress={onPress} props={props} ref={toastRef} />
    ),
    [variants.changeIcon]: ({ onPress, props }) => <ChangeIconToast onPress={onPress} props={props} ref={toastRef} />,
    viewOnly: ({ onPress }) => (
      <Pressable accessible={true} ref={toastRef} style={{ width: '100%' }} onPress={onPress}>
        <View style={[styles.toastContainerStyle, { paddingBottom: 0 }]}>
          <View style={{ paddingBottom: 10 }}>
            <Text bold style={styles.toastText}>
              {t(`${LANG_PREFIX}noAccessRight`)}
            </Text>
            <Text>{t(`${LANG_PREFIX}availableForStandardProfile`)}</Text>
          </View>
          <View style={styles.toastButtonContainer}>
            <Button
              accessibilityLabel={t(`${LANG_PREFIX}buttonDoubleTapClose`)}
              accessibilityRole={'button'}
              title={t(`${LANG_PREFIX}buttonClose`)}
              style={styles.toastButton}
              fontStyle={styles.toastButtonText}
              isBold={false}
              onPress={() => onPress(0)}
            />
            <Divider vertical style={styles.toastDivider} />
            <Button
              accessibilityLabel={`${
                Platform.OS === 'ios'
                  ? t(`${LANG_PREFIX}buttonDoubleTapTwoFingers`)
                  : t(`${LANG_PREFIX}buttonDoubleTapTwoFingers`)
              } `}
              accessibilityRole={'button'}
              title={t(`${LANG_PREFIX}buttonChangeProfile`)}
              style={styles.toastButton}
              fontStyle={styles.toastButtonText}
              isBold={false}
              onPress={() => onPress(1)}
            />
          </View>
        </View>
      </Pressable>
    ),
    [variants.accessDeniedHardBlock]: ({ props }) => (
      <HardBlockToast referenceId={props?.referenceId} description={props?.description} />
    ),
    [variants.actionMessage]: ({ onPress, props }) => (
      <ActionMessageToast onPress={onPress} props={props} ref={toastRef} />
    ),
    [variants.enrolCq]: ({ props }) => <EnrolCQToast onAccept={props?.onAccept} />,
    [variants.cloneDevice]: () => <CloneDeviceToast />,
  };

  const onToast = () => {
    if (!isScreenReaderEnabled) return;
    if (toastRef.current) return setAccessibilityFocus(toastRef);
    if (customToastRef.current) return setAccessibilityFocus(customToastRef);
  };

  return (
    <>
      <FlashMessage
        statusBarHeight={insets.top}
        style={styles.messageStyle}
        titleStyle={styles.titleStyle}
        textStyle={styles.textStyle}
        duration={6000}
        position='top'
        floating
        renderFlashMessageIcon={customRenderFlashMessageIcon}
      />
      <Toast
        autoHide={!isScreenReaderEnabled}
        onHide={() => announceInfo('Notification dismissed')}
        onShow={onToast}
        visibilityTime={10000}
        config={toastConfig}
        //node_modules/react-native-toast-message/lib/src/useToast.js default value 40
        {...(insets.top > 40 && { topOffset: insets.top })}
      />
    </>
  );
};

const customRenderFlashMessageIcon = (icon = 'success') => {
  switch (icon) {
    case 'success':
      return <Tick style={{ marginRight: 10 }} />;
    case 'danger':
      return <Cross style={{ marginRight: 10, backgroundColor: colors.primary }} />;
    default:
      return null;
  }
};

AppMessage.variants = variants;

const styles = StyleSheet.create({
  messageStyle: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    backgroundColor: 'rgba(255,255,255,0.95)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  titleStyle: {
    fontFamily: FONT_FAMILY_BOLD,
    fontSize: 15,
    marginRight: 15,
  },
  textStyle: {
    fontFamily: FONT_FAMILY_REGULAR,
    fontSize: 15,
    marginRight: 15,
  },
  toastContainerStyle: {
    backgroundColor: 'rgba(255,255,255,0.98)',
    margin: 0,
    marginHorizontal: 10,
    borderRadius: 10,
    paddingHorizontal: 15,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  toastButtonContainer: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  toastText: {
    fontSize: 15,
    paddingBottom: 5,
  },
  toastButton: {
    height: 45,
  },
  toastButtonText: {
    fontSize: 14,
  },
  toastDivider: {
    borderLeftColor: colors.border,
    height: 15,
    alignSelf: 'center',
  },
  toastTitleText: {
    fontSize: 18,
    paddingBottom: 5,
  },
  toastBodyText: {
    fontSize: 14,
    paddingBottom: 5,
  },

  iconContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 5,
  },
  icon: {
    width: 35,
    height: 35,
    zIndex: 1,
    marginHorizontal: 8,
  },
  buttonContainer: {
    height: 30,
    borderRadius: 3,
    borderColor: colors.black,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
