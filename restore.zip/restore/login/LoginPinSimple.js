import React, { useRef, useState } from 'react';
import { Image, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import { colors } from 'configs';
import { useAuthentication, useSoftToken } from 'hooks';
import {  BiometricAccess, CLONE_DEVICE_ERROR, LOGIN_TYPE } from 'constant';
import { getKeychain, showFailure, useDeviceInfo, setAccessibilityFocus, checkIsDeviceInfoUpdated } from 'utils';
import { LoadingFull } from 'atoms';
import { NumpadSmall } from 'organisms';
import { Text } from 'components';
import {
  FLOW_TYPE,
  getAuth,
  getUser,
  reInitialize,
  unBindLocalDevice,
  unbound,
  updateBiometricObject,
  updateUserObject,
} from 'stores';

import CloseIcon from 'assets/images/icon/close.png';
import { useNavigation } from '@react-navigation/native';
import routes from 'navigations/routes';
import { useTranslation } from 'react-i18next';
import { checkTransactionActivityDeclined } from '../../softToken/utils';
import { useCheckCloneDevice } from 'softToken';
import Toast from 'react-native-toast-message';
import { AppMessage } from 'screens';

export const LoginPinSimple = ({ flow, flowProps, onCancel, onSuccess, onChallenge, autoPromptBiometric = true }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.authLoginPinPopUp.text.';
  const navigation = useNavigation();
  const softToken = useSoftToken({ navigation });
  const dispatch = useDispatch();
  const store_auth = useSelector(getAuth);
  const store_user = useSelector(getUser);
  const { deviceId, encryptedId } = useSelector(getUser) || {};
  const authHook = useAuthentication({ flow, props: flowProps });
  const deviceInfo = useDeviceInfo();
  const { getUniqueDeviceId } = useCheckCloneDevice();

  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const requestRef = useRef({});
  const portalizeRef = useRef(null);

  const biometricLogin = async () => {
    const { data, error } = await getKeychain('Quick login');

    if (error === 'limit' || error === 'locked') {
      //Disable biometric login
      dispatch(updateBiometricObject({ isLocked: true }));
      return showFailure(t(`${LANG_PREFIX}errorBioLock`));
    }
    if (error === 'newEnrolmentDetected') {
      dispatch(updateBiometricObject({ isStored: false, isLoginEnabled: false, isTranApprovalEnabled: false }));
      return showFailure(t(`${LANG_PREFIX}errorBioChange`), t(`${LANG_PREFIX}errorBioChangeDesc`));
    }
    if (!data) return;

    return await submitPin(data, 'Biometric');
  };

  const submitPin = async (newPin, loginMethod) => {
    if (authHook.flowType === FLOW_TYPE.QUICK_LOGIN) {
      dispatch(reInitialize(false)); //Clear data loaded after logout because API may respond late
    }

    requestRef.current = {
      pin: newPin,
      deviceId,
      encryptedId,
      loginMethod,
    };

    if (checkIsDeviceInfoUpdated({ store_user, deviceInfo }))
      requestRef.current = { ...requestRef.current, ...deviceInfo };

    // Check for clone device and add uniqueDeviceId if needed
    const uniqueDeviceId = await getUniqueDeviceId();
    if (uniqueDeviceId) {
      requestRef.current = { ...requestRef.current, uniqueDeviceId };
    }

    handleLogin();
  };

  const handleLogin = async () => {
    const result = await authHook.submitPin(requestRef.current);
    setError(result.problem);

    if (result.status === CLONE_DEVICE_ERROR) return forceUnbindLocal();
    if (result.status === 'E00007') return forceUnbind(result.problem);
    if (result.status === 'E00125') return onlyAllowPassword(result.problem);
    if (checkTransactionActivityDeclined(result.status)) {
      onCancel();
      return navigation.navigate(routes.SOFT_TOKEN_FAIL, {
        title: t(`softToken.submit.text.msgActivityDenied`),
        status: result.status,
      });
    }

    const response = authHook.handlePinResponse(result, navigation);
    setPin('');

    if (response.error) return;

    if (result.cqEnrolmentRequired) return softToken.activateAfterSuccessfulPinLogin({});

    if (result.challengeQuestion) return onChallenge();

    onSuccess(result);
  };

  const forceUnbind = problem => {
    showFailure(problem);
    dispatch(unbound());
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.LOGIN_PBE_OLD);
  };

  const forceUnbindLocal = () => {
    Toast.show({
      type: AppMessage.variants.cloneDevice,
      autoHide: false,
      swipeable: false,
      topOffset: 0,
    });
    dispatch(unBindLocalDevice());
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.LOGIN_PBE_OLD);
  };

  const onlyAllowPassword = problem => {
    dispatch(updateUserObject({ loginType: LOGIN_TYPE.PASSWORD }));
    showFailure(problem);
    navigation.navigate(routes.MAIN_TAB);
  };

  const handleChange = async digit => {
    const newPin = pin + digit;
    setPin(newPin);

    if (newPin.length === 6) return submitPin(newPin, 'PIN');
  };

  const handleDelete = () => setPin(pin.slice(0, -1));

  const onLayout = () => setAccessibilityFocus(portalizeRef).then();

  return (
    <>
      <TouchableOpacity style={styles.cancelBtn} onPress={onCancel}>
        <Image source={CloseIcon} style={styles.icon} />
      </TouchableOpacity>
      <View style={styles.titleContainer}>
        <View ref={portalizeRef} onLayout={onLayout} style={{ marginBottom: 15, alignItems: 'center' }}>
          {error !== '' && <Text style={styles.errorText}>{error?.replace('${count}', store_auth.errorAttempt)}</Text>}
          <Text style={styles.title}>{t(`${LANG_PREFIX}titleEnterPin`)}</Text>
        </View>
        <View style={styles.pinContainer}>
          <View style={[styles.pin, pin.length > 0 && styles.filledPin]} />
          <View style={[styles.pin, pin.length > 1 && styles.filledPin]} />
          <View style={[styles.pin, pin.length > 2 && styles.filledPin]} />
          <View style={[styles.pin, pin.length > 3 && styles.filledPin]} />
          <View style={[styles.pin, pin.length > 4 && styles.filledPin]} />
          <View style={[styles.pin, pin.length > 5 && styles.filledPin]} />
        </View>
      </View>
      <NumpadSmall
        onPress={handleChange}
        onDelete={handleDelete}
        onBiometric={biometricLogin}
        biometricType={BiometricAccess.LOGIN}
        autoPromptBiometric={autoPromptBiometric}
      />
      {store_auth.status === 'loading' && <LoadingFull />}
    </>
  );
};

const styles = StyleSheet.create({
  cancelBtn: {
    alignSelf: 'flex-end',
    padding: 15,
  },
  icon: {
    width: 14,
    height: 14,
    tintColor: colors.primary,
  },
  titleContainer: {
    alignItems: 'center',
    marginBottom: 25,
  },
  title: {
    fontSize: 14,
  },
  pinContainer: {
    width: '60%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
  },
  errorText: {
    fontSize: 14,
    color: colors.red,
    marginBottom: 8,
    marginHorizontal: 20,
  },
  pin: {
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: colors.medium,
  },
  filledPin: {
    backgroundColor: colors.medium,
  },
});

export default LoginPinSimple;
