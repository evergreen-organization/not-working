import React, { useEffect, useRef, useState } from 'react';
import { TouchableOpacity, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import { AUTH_TYPE, useAuthentication, useHandleDispatch, useReEnrollBiometricHook, useSoftToken } from 'hooks';
import { colors } from 'configs';
import routes from 'navigations/routes';
import { CLONE_DEVICE_ERROR, LOGIN_TYPE, tranApiType } from 'constant';
import {
  checkIsDeviceInfoUpdated,
  checkIsPromptReEnrolBiometric,
  getKeychain,
  showFailure,
  showSuccess,
  useAuthUtil,
  useDeviceInfo,
} from 'utils';
import { LoadingFull, Screen } from 'atoms';
import { RoundButton, Text } from 'components';
import { BiometricButton, PinInput } from 'organisms';
import {
  BIOMETRIC_TYPE,
  FLOW_TYPE,
  getAuth,
  getBiometric,
  getCqChallengeResult,
  getUser,
  reInitialize,
  storeBiometric,
  unBindLocalDevice,
  unbound,
  updateAuthObject,
  updateAwarenessConsent,
  updateBiometricObject,
  updateCqChallengeResult,
  updateDisplayBalance,
  updateUserObject,
} from 'stores';

import { useTranslation } from 'react-i18next';
import { useRetry } from 'contexts';
import { SecurityTipsModal } from 'screens/security';
import { checkTransactionActivityDeclined } from '../../softToken/utils';
import { useCheckCloneDevice } from 'softToken';
import Toast from 'react-native-toast-message';
import { AppMessage } from 'screens';

export const LoginPin = ({ route, navigation }) => {
  const { t } = useTranslation();
  const LANG_PREFIX = 'screens.authLoginPin.text.';

  const softToken = useSoftToken({ navigation });
  const authUtils = useAuthUtil();
  const dispatch = useDispatch();
  const handleDispatch = useHandleDispatch();
  const store_auth = useSelector(getAuth);
  const store_user = useSelector(getUser);
  const { deviceId, encryptedId, loginType } = useSelector(getUser) || {};
  const cqChallengeResult = useSelector(getCqChallengeResult);
  const store_biometric = useSelector(getBiometric);

  const flow = route.params.flow;
  const authHook = useAuthentication({ flow });
  const { newRoute, params, isUpdateDisplayBalance, preferredAccountNo } = route.params || {};
  const { setIsPBeLoginVisible, setFunctionToRetry } = useRetry();
  const deviceInfo = useDeviceInfo();
  const { getUniqueDeviceId } = useCheckCloneDevice();

  const isPasswordLogin = loginType === LOGIN_TYPE.PASSWORD;

  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const requestRef = useRef({});

  const isPromptReEnrollBiometric = checkIsPromptReEnrolBiometric({
    keyChainState: store_biometric.keyChainState,
    isStored: store_biometric.isStored,
  });
  const reEnrollBiometric = useReEnrollBiometricHook();
  const [isSecurityTipsModalVisible, setIsSecurityTipsModalVisible] = useState(false);

  useEffect(() => {
    start();
  }, []);

  useEffect(() => {
    //Ensure logout successful only prompt for login
    if (store_auth.isLoginReady) checkIfPasswordLogin();
  }, [store_auth.isLoginReady]);

  useEffect(() => {
    if (isPromptReEnrollBiometric) reEnrollBiometric.promptReEnrolAlert();
  }, [isPromptReEnrollBiometric]);

  useEffect(() => {
    if (cqChallengeResult?.type === tranApiType.QUICK_LOGIN) {
      handleSuccessfulResult(cqChallengeResult);
      dispatch(updateCqChallengeResult(null));
    }
  }, [cqChallengeResult?.type]);

  const start = () => {
    dispatch(updateAuthObject({ status: 'idle', error: null }));
  };

  const checkIfPasswordLogin = () => {
    if (isPasswordLogin) {
      // fix  password modal not pop out after secure pin shown
      setTimeout(() => {
        setIsPBeLoginVisible(true);
      }, 0);
      setFunctionToRetry(() => () => successfulRoute());
    }
  };

  const preLogin = async newPin => {
    dispatch(updateAuthObject({ status: 'loading' }));
    await submitPin(newPin, 'PIN');
  };

  const biometricLogin = async () => {
    const { data, error } = await getKeychain('Quick login');

    if (error === 'limit' || error === 'locked') {
      //Disable biometric login
      dispatch(updateBiometricObject({ isLocked: true }));
      return showFailure(t(`${LANG_PREFIX}errorBioLock`));
    }
    if (error === 'newEnrolmentDetected') {
      dispatch(updateBiometricObject({ isStored: false, isLoginEnabled: false, isTranApprovalEnabled: false }));
      return reEnrollBiometric.promptBiometricChangedAlert();
    }
    if (!data) return;

    dispatch(updateAuthObject({ status: 'loading', pin: data }));
    await submitPin(data, 'Biometric');
  };

  const submitPin = async (newPin, loginMethod) => {
    dispatch(reInitialize(false)); //Clear data loaded after logout because API may respond late

    requestRef.current = {
      pin: newPin,
      deviceId,
      encryptedId,
      loginMethod,
    };

    if (checkIsDeviceInfoUpdated({ store_user, deviceInfo }))
      requestRef.current = { ...requestRef.current, ...deviceInfo };

    // Check for clone device and add uniqueDeviceId if needed
    const uniqueDeviceId = await getUniqueDeviceId();
    if (uniqueDeviceId) {
      requestRef.current = { ...requestRef.current, uniqueDeviceId };
    }

    await handleLogin();
  };

  const handleLogin = async () => {
    const result = await authHook.submitPin(requestRef.current);
    setError(result.problem);

    if (result.status === CLONE_DEVICE_ERROR) return forceUnbindLocal();
    if (result.status === 'E00007') return forceUnbind(result.problem);
    if (result.status === 'E00125') return onlyAllowPassword(result.problem);
    if (checkTransactionActivityDeclined(result.status)) {
      navigation.navigate(routes.MAIN_TAB);
      return navigation.navigate(routes.SOFT_TOKEN_FAIL, {
        title: t(`softToken.submit.text.msgActivityDenied`),
        status: result.status,
      });
    }

    const response = authHook.handlePinResponse(result, navigation);
    setPin('');

    if (response.error) return;

    if (result.cqEnrolmentRequired) return softToken.activateAfterSuccessfulPinLogin({});

    if (result.challengeQuestion) {
      return navigation.navigate(routes.CQ_CHALLENGE, {
        type: tranApiType.QUICK_LOGIN,
      });
    }

    handleSuccessfulResult(result);
  };

  const handleSuccessfulResult = async result => {
    authUtils.storeLoginKey({ result });

    //re-enroll biometric if still using old settings if there enroll biometric before
    if (reEnrollBiometric.isAcceptBiometricReEnroll) {
      const reEnrollBiometricStatus = await dispatch(
        storeBiometric({ pin: requestRef.current.pin, type: BIOMETRIC_TYPE.ALL }),
      );
      if (reEnrollBiometricStatus.status === 'S') showSuccess(t(`${LANG_PREFIX}successBiometricEnabled`));
      else showFailure(t(`${LANG_PREFIX}errorBiometricEnrolmentFail`));
    }

    //eSMR 2024-2772: to display security tips popup from 15/01/2025 to 31/03/2025
    if (result.isAwarenessRequired) return setIsSecurityTipsModalVisible(true);

    successfulRoute();
  };

  const successfulRoute = async () => {
    //update display balance at home after successful login
    if (isUpdateDisplayBalance)
      await handleDispatch(updateDisplayBalance({ allowShowBalance: true, preferredAccountNo }));

    navigation.navigate(routes.MAIN_TAB);
    if (newRoute) {
      navigation.navigate(newRoute, params);
    }
  };

  const forceUnbind = problem => {
    showFailure(problem);
    dispatch(unbound());
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.LOGIN_PBE_OLD);
  };

  const forceUnbindLocal = () => {
    Toast.show({
      type: AppMessage.variants.cloneDevice,
      autoHide: false,
      swipeable: false,
      topOffset: 0,
    });
    dispatch(unBindLocalDevice());
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.LOGIN_PBE_OLD);
  };

  const onlyAllowPassword = problem => {
    dispatch(updateUserObject({ loginType: LOGIN_TYPE.PASSWORD }));
    showFailure(problem);
    navigation.navigate(routes.MAIN_TAB);
  };

  const handleChange = async digit => {
    const newPin = pin + digit;
    setPin(newPin);
    if (newPin.length === 6) await preLogin(newPin);
  };

  const handleDeleteCancel = () => {
    if (pin.length === 0) return navigation.goBack();
    setPin(pin.slice(0, -1));
  };

  const handleDelete = () => setPin(pin.slice(0, -1));

  const handleCancel = () => navigation.goBack();

  const forgetPIN = () => navigation.navigate(routes.CONFIRM_RESET_PIN, { flow: AUTH_TYPE.RESET_PIN, forgotPIN: true });

  const buttonTitle = () =>
    pin.length > 0 ? t(`${LANG_PREFIX}loginButtonDelete`) : t(`${LANG_PREFIX}loginButtonCancel`);

  const buttonTitleColor = () => (pin.length > 0 ? { color: colors.black } : { color: colors.medium });

  //To redirect and handle modal visibility upon consent confirmation
  const handleSecurityTipsConsent = () => {
    setIsSecurityTipsModalVisible(false);
    handleDispatch(updateAwarenessConsent());
    successfulRoute();
  };

  return (
    <>
      {isPasswordLogin ? null : (
        <Screen singlePage>
          <View style={{ flex: 1, justifyContent: 'center' }}>
            <View style={{ marginTop: 5, marginRight: 15, alignItems: 'flex-end' }}>
              <TouchableOpacity onPress={forgetPIN}>
                <View style={{ padding: 5 }}>
                  <Text style={{ fontSize: 14 }}>{t(`${LANG_PREFIX}buttonForgotPin`)}</Text>
                </View>
              </TouchableOpacity>
            </View>
            <PinInput
              title={t(`${LANG_PREFIX}titlePin`)}
              errorTitle={error?.replace('${count}', store_auth.errorAttempt)}
              value={pin}
              onChange={handleChange}
            />
          </View>

          <View style={{ justifyContent: 'flex-end', marginBottom: 20 }}>
            <View style={{ flexDirection: 'row' }}>
              {authHook.flowType === FLOW_TYPE.QUICK_LOGIN ? (
                <>
                  {store_auth.isLoginReady && <BiometricButton onPress={biometricLogin} allowAutoPrompt={true} />}

                  <RoundButton
                    title={buttonTitle()}
                    textColor={buttonTitleColor()}
                    disable={pin.length === 0}
                    onPress={handleDeleteCancel}
                  />
                </>
              ) : (
                <>
                  <RoundButton
                    title={t(`${LANG_PREFIX}pinButtonCancel`)}
                    textColor={{ color: colors.red }}
                    onPress={handleCancel}
                  />
                  <RoundButton
                    title={t(`${LANG_PREFIX}pinButtonDelete`)}
                    textColor={buttonTitleColor()}
                    disable={pin.length === 0}
                    onPress={handleDelete}
                  />
                </>
              )}
            </View>
          </View>
        </Screen>
      )}

      {/** display security tips modal based on API returns */}
      <SecurityTipsModal isVisible={isSecurityTipsModalVisible} onPress={handleSecurityTipsConsent} />
      {(store_auth.status === 'loading' || !store_auth.isLoginReady) && <LoadingFull blur />}
    </>
  );
};

export default LoginPin;
