import { logAttestationError } from './app/attestation/utils';

if (__DEV__) {
  require('./ReactotronConfig');
}

import React, { useEffect, useState } from 'react';
import { Provider } from 'react-redux';
import { Appearance, Platform, StatusBar, View } from 'react-native';
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/lib/integration/react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import messaging from '@react-native-firebase/messaging';
import { CaptureProtection, CaptureProtectionProvider } from 'react-native-capture-protection';

import { logger } from 'configs';
import { configureStore } from 'stores/configureStore';
import { RetryProvider } from 'contexts';
import { Router } from 'navigations/Router';

import { PBeLoginModal } from 'screens/PBeLoginModal';
import { OfflineNotice } from 'organisms';
import { AppMessage, WebViewProvider } from 'screens';
import {Text} from 'components'
import { navigationRef, useAppState, useGlobalErrorHandler } from 'hooks';
import { HmsPushMessaging } from '@hmscore/react-native-hms-push';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { Host } from 'react-native-portalize';
import { ActionSheetProvider } from '@expo/react-native-action-sheet';
import { Translator } from 'localization/TranslatorView';
import { initializeStorage, migrateFromAsyncStorage, migrateSensitiveInfoToMMKV } from './app/utils/storage';

if (__DEV__) {
  require('./ReactotronConfig');
}

const welcomeScreenVersion = 0;

logger.start();

// const store = configureStore();

messaging().setBackgroundMessageHandler(async msg => {});

HmsPushMessaging?.setBackgroundMessageHandler(msg => {});

function App() {
  useGlobalErrorHandler();
  const [colorScheme, setColorScheme] = useState(Appearance.getColorScheme());
  const isBackground = useAppState();
  const [initialRender, setInitialRender] = useState(true);
  const [hasMigrated, setHasMigrated] = useState(false);
  const [persist, setPersist] = useState(null);
  const [store, setStore] = useState(null);
  const [isReady, setIsReady]= useState(false)

  useEffect(() => {
    migrateMMKV().then();
  }, []);

  useEffect(() => {
    setInitialRender(false);
    preventScreenshot();

    const appearance = Appearance.addChangeListener(preferences => {
      setColorScheme(preferences.colorScheme);
    });

    return () => {
      allowScreenshot();
      appearance.remove();
    };
  }, []);

  useEffect(() => {
    if (isBackground || initialRender) return;
    if (Platform.OS === 'android') preventScreenshot();
  }, [isBackground]);

  const preventScreenshot = () =>
    CaptureProtection?.prevent({
      screenshot: true,
      record: false,
      appSwitcher: true,
    });
  const allowScreenshot = () => CaptureProtection.allow();

  const migrateMMKV = async () => {
    try {
      const initializeStorageSuccess = await initializeStorage();
      if (!initializeStorageSuccess) return;
      const isMMKVMigrated = await migrateFromAsyncStorage();
      const isSensitiveInfoMigrated = await migrateSensitiveInfoToMMKV();
      setHasMigrated(isMMKVMigrated && isSensitiveInfoMigrated);
      const storeTemp = await configureStore();
      if (!storeTemp) return;
      setPersist(persistStore(storeTemp));
      setStore(storeTemp);
      setIsReady(true)
    }
    catch (error){
      logAttestationError(error)
      setIsReady(true)
    }
  };

  if(!isReady) return  null;

  if (!hasMigrated || !persist || !store) return (
    <View style={{alignItems: 'center', justifyContent: 'center', flex: 1, marginHorizontal: 20}}>
      <Text style={{textAlign: 'center'}}>{`Something went wrong unexpectedly. Please restart your device and try again.`}</Text>
      <Text>{`Error ${hasMigrated ? 1 : 0}${persist ? 1 : 0}${store ? 1 : 0}`}</Text>
    </View>
  )

  return (
    <Provider store={store}>
      <StatusBar barStyle={Platform.OS === 'android' && colorScheme === 'dark' ? 'light-content' : 'dark-content'} />
      <PersistGate loading={null} persistor={persist}>
        <SafeAreaProvider>
          <Translator>
            <OfflineNotice>
              <CaptureProtectionProvider>
                <RetryProvider>
                  <GestureHandlerRootView style={{ flex: 1 }}>
                  <ActionSheetProvider>
                  <WebViewProvider>
                    <Host>
                      <Router navigationRef={navigationRef} welcomeScreenVersion={welcomeScreenVersion} />
                      <PBeLoginModal navigationRef={navigationRef} />
                    </Host>
                  </WebViewProvider>
                </ActionSheetProvider>
                    <AppMessage />
                  </GestureHandlerRootView>
                </RetryProvider>
              </CaptureProtectionProvider>
            </OfflineNotice>
          </Translator>
        </SafeAreaProvider>
      </PersistGate>
    </Provider>
  );
}

export default App;
