import routes from 'navigations/routes';
import { FLOW_TYPE, junctionType, submitPostLogin } from 'stores';

import { AUTH_TYPE, useHandleDispatch } from 'hooks';

const usePostLogin = () => {
  const handleDispatch = useHandleDispatch();
  const flowType = FLOW_TYPE.POST_LOGIN;
  const junction = junctionType.OPEN;

  const submitPin = ({
    deviceId,
    encryptedId,
    deviceType,
    deviceModel,
    deviceName,
    osVersion,
    postLoginToken,
    uniqueDeviceId,
  }) => {
    return handleDispatch(
      submitPostLogin({
        deviceId,
        encryptedId,
        deviceType,
        deviceModel,
        deviceName,
        osVersion,
        postLoginToken,
        uniqueDeviceId,
      }),
    );
  };

  const handlePinResponse = (result, navigation) => {
    if (result.problem) {
      if (result.data?.isPinLocked) {
        navigation.navigate(routes.MAIN_TAB);
        navigation.navigate(routes.CONFIRM_RESET_PIN, { flow: AUTH_TYPE.RESET_PIN });
      }
      return { error: true, message: null };
    }

    return { error: false, message: null };
  };

  const requestPac = () => {};
  const submitPac = () => {};
  const handlePacResponse = () => {};

  return {
    flowType,
    junction,
    submitPin,
    handlePinResponse,
    requestPac,
    submitPac,
    handlePacResponse,
  };
};

export default usePostLogin;
