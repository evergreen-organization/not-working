import routes from 'navigations/routes';
import { FLOW_TYPE, junctionType, submitQuickLogin } from 'stores';

import { AUTH_TYPE, useHandleDispatch } from 'hooks';

const useQuickLogin = () => {
  const handleDispatch = useHandleDispatch();
  const flowType = FLOW_TYPE.QUICK_LOGIN;
  const junction = junctionType.OPEN;

  const submitPin = async ({
    deviceId,
    encryptedId,
    pin,
    loginMethod,
    deviceType,
    deviceModel,
    deviceName,
    osVersion,
    uniqueDeviceId,
  }) => {
    return handleDispatch(
      submitQuickLogin({
        deviceId,
        encryptedId,
        pin,
        loginMethod,
        deviceType,
        deviceModel,
        deviceName,
        osVersion,
        uniqueDeviceId,
      }),
    );
  };

  const handlePinResponse = (result, navigation) => {
    if (result.problem) {
      if (result.data?.isPinLocked) {
        navigation.navigate(routes.MAIN_TAB);
        navigation.navigate(routes.CONFIRM_RESET_PIN, { flow: AUTH_TYPE.RESET_PIN });
      }
      return { error: true, message: null };
    }
    return { error: false, message: null };
  };

  const requestPac = () => {};
  const submitPac = () => {};
  const handlePacResponse = () => {};

  return {
    flowType,
    junction,
    submitPin,
    handlePinResponse,
    requestPac,
    submitPac,
    handlePacResponse,
  };
};

export default useQuickLogin;
