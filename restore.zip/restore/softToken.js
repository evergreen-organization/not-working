import { createAsyncThunk, createSelector, createSlice, isAnyOf } from '@reduxjs/toolkit';
import { REHYDRATE } from 'redux-persist';

import { client } from 'apis/client';
import { publicClient } from 'apis/publicClient';
import { privateClient } from 'apis/privateClient';
import { apiEndpoint } from 'apis/apiUtils';
import { changeCQ, checkPBO, enrolCQ, updateQuickPayment } from '../lifestyle/auth';
import { submitBillPayment } from './bill';
import { submitCardPayment } from './cardPayment';
import { loadCasa, submitLockFund, submitUnlockFund } from './casa';
import { submitCashAdvance } from './cashAdvance';
import { manageDuitNowProxy, registerDuitNowProxy } from './duitNowId';
import { submitFundTransfer } from './fundTransfer';
import { submitLoanPayment } from './loanPayment';
import { submitAlipayPlus, submitQRPayment } from './qrPayment';
import { submitTopUp } from './topUp';
import { submitCardlessWithdraw } from './cardlessWithdraw';
import { FAIL, IDLE, LOADING, SUCCESS } from 'apis';
import { submitBakong } from './remittance';
import { submitCarbonOffset } from './carbonTracker';
import { ANDROID_SOFT_TOKEN_FINGERPRINT_TYPE, CQ_ACTIVATION_STATUS, Demo, PROFILE_TYPE } from '../../constant';
import { SOFT_TOKEN_ACTIVATION_STATUS } from 'constant';
import { submitDepositPlacement, submitDepositWithdraw } from './depositPlacement';
import { submitOpenEFD } from './deposit';
import { submitEmailAddress } from '../lifestyle/user';
import { submitCardPin } from './card';
import { submitBuyGold, submitCloseGoldAccount, submitOpenGoldAcc, submitSellGold } from './gold';
import { submitLonpacInsuranceConsent } from './insurance';
import { addCardTokenization } from '../banking/walletTokenization';

const initialState = {
  selectedRoute: null,
  status: IDLE,
  isActivated: false,
  softTokenActivationStatus: SOFT_TOKEN_ACTIVATION_STATUS.PENDING,
  wasActivatedOnSameDevice: false,
  isLicenseAvailable: false,
  androidFingerprintType: ANDROID_SOFT_TOKEN_FINGERPRINT_TYPE.HARDWARE,
  profileType: PROFILE_TYPE.STANDARD,
  cqActivationStatus: CQ_ACTIVATION_STATUS.ACTIVE,
  preferredAccountNo: '',
  preferredAccountName: '',
  preferredAccountActive: false,
  preferredAccountLvlName: '',
  quickLimit: null,
  isPBCUser: false,
  name: '',
  serviceFee: null,
  secureStorageEmpty: false,
  transaction: {
    transactionId: '',
    secureChannelMessageSignature: '',
  },
  pendingTransactionStatus: IDLE,
  pendingTransaction: {
    transactionId: null,
    transactionSecureChannelMessage: null,
    encryptedTransactionObject: null,
  },
  auth: {
    isPublic: true,
    selectedSecfa: null,
    pacSeqNo: null,
    phoneNo: null,
    challengeCode1: null,
    challengeCode2: null,
    status: IDLE,
    errorAttempt: null,
    errorMsg: null,
    lastPacReqTime: null,
    isQuickLimitReached: false,
  },
};

export const initUser = createAsyncThunk(
  'initUser',
  async ({ deviceId, encryptedId, appVersion, languageCode }, { getState, rejectWithValue }) => {
    //To update appVersion at app launch and successful binding only
    if (Demo.User.Check(getState))
      return { ...Demo.User.Init, isSoftTokenActivated: getState().bankingEntities.softToken.isActivated };
    const result = await client.post(`${apiEndpoint.public}/initUser`, {
      deviceId,
      encryptedId,
      appVersion,
      languageCode,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const validateId = createAsyncThunk('validateId', async ({ id }, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) {
    if (Demo.User.CheckIC(id)) return Demo.SoftToken.ValidateId;
    return rejectWithValue(Demo.SoftToken.ValidateIdRejected);
  }
  const result = await privateClient.post(`${apiEndpoint.private}/softTokenValidateId`, { id });
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const registerDSApp = createAsyncThunk('registerDSApp', async ({ secfa }, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return Demo.SoftToken.RegisterDSApp;
  const result = await privateClient.post(`${apiEndpoint.private}/softTokenActivationStep1/v2`, {
    secfa,
  });
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const generateTokenLicense = createAsyncThunk('generateTokenLicense', async (param, { rejectWithValue }) => {
  const result = await privateClient.post(`${apiEndpoint.private}/softTokenActivationStep2`, param);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const generateTokenInstance = createAsyncThunk('generateTokenInstance', async (param, { rejectWithValue }) => {
  const result = await privateClient.post(`${apiEndpoint.private}/softTokenActivationStep3/v2`, param);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const activateTokenInstance = createAsyncThunk('activateTokenInstance', async (param, { rejectWithValue }) => {
  const result = await privateClient.post(`${apiEndpoint.private}/softTokenActivationStep4/v3`, param);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const deactivateSoftToken = createAsyncThunk('deactivateSoftToken', async (param, { rejectWithValue }) => {
  const result = await publicClient.get(`${apiEndpoint.public}/deactivateSoftToken`);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const initSoftTokenActivationSilently = createAsyncThunk(
  'initSoftTokenActivationSilently',
  async ({ isPublic, deviceId, encryptedId, uniqueDeviceId }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.InitSoftTokenActivation;
    let result;
    if (isPublic) {
      result = await publicClient.post(`${apiEndpoint.public}/softTokenSilentActivationInit/v2`, {
        deviceId,
        encryptedId,
        uniqueDeviceId,
      });
    } else {
      result = await privateClient.post(`${apiEndpoint.private}/softTokenSilentActivationInit/v2`, {
        deviceId,
        encryptedId,
        uniqueDeviceId,
      });
    }
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const registerDSAppSilently = createAsyncThunk(
  'registerDSAppSilently',
  async ({isPublic}, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.SoftToken.RegisterDSApp;
    let result;
    if (isPublic) {
      result = await publicClient.get(`${apiEndpoint.public}/softTokenSilentActivationStep1`);
    } else {
      result = await privateClient.get(`${apiEndpoint.private}/softTokenSilentActivationStep1`);
    }
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const generateTokenLicenseSilently = createAsyncThunk(
  'generateTokenLicenseSilently',
  async (param, { rejectWithValue }) => {
    let result;
    if (param?.isPublic) {
      result = await publicClient.post(`${apiEndpoint.public}/softTokenSilentActivationStep2`, param);
    } else {
      result = await privateClient.post(`${apiEndpoint.private}/softTokenSilentActivationStep2`, param);
    }
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const generateTokenInstanceSilently = createAsyncThunk(
  'generateTokenInstanceSilently',
  async (param, { rejectWithValue }) => {
    let result;
    if (param?.isPublic) {
      result = await publicClient.post(`${apiEndpoint.public}/softTokenSilentActivationStep3`, param);
    } else {
      result = await privateClient.post(`${apiEndpoint.private}/softTokenSilentActivationStep3`, param);
    }
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const activateTokenInstanceSilently = createAsyncThunk(
  'activateTokenInstanceSilently',
  async (param, { rejectWithValue }) => {
    let result;
    if (param?.isPublic) {
      result = await publicClient.post(`${apiEndpoint.public}/softTokenSilentActivationStep4`, param);
    } else {
      result = await privateClient.post(`${apiEndpoint.private}/softTokenSilentActivationStep4`, param);
    }
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const updatePrefAccount = createAsyncThunk(
  'updatePrefAccount',
  async ({ isPublic = true, accountNo, accountDesc, accName }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.SoftToken.PreferredAccountUpdate;
    let result;
    if (isPublic) result = await publicClient.post(`${apiEndpoint.public}/updatePrefAccount`, { accountNo });
    else result = await privateClient.post(`${apiEndpoint.private}/updatePrefAccount`, { accountNo });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const initTransaction = createAsyncThunk('initTransaction', async ({ isPublic }, { rejectWithValue }) => {
  let result;
  if (isPublic) result = await client.get(`${apiEndpoint.public}/softToken/generateTxnSCM`);
  else result = await privateClient.get(`${apiEndpoint.private}/softToken/generateTxnSCM`);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const validateSecurePIN = createAsyncThunk(
  'validateSecurePIN',
  async ({ isPublic, pin, verifyMethod }, { rejectWithValue }) => {
    let result;
    if (isPublic) result = await client.post(`${apiEndpoint.public}/softToken/getRPD`, { pin, verifyMethod });
    else result = await privateClient.post(`${apiEndpoint.private}/softToken/getRPD`, { pin, verifyMethod });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const validateSignature = createAsyncThunk(
  'validateSignature',
  async ({ isPublic, transactionId, signature }, { rejectWithValue }) => {
    let result;
    if (isPublic) {
      result = await client.post(`${apiEndpoint.public}/softToken/valSignature`, {
        transactionId,
        signature,
      });
    } else {
      result = await privateClient.post(`${apiEndpoint.private}/softToken/valSignature`, {
        transactionId,
        signature,
      });
    }
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

// export const getSoftTokenActivationStatus = createAsyncThunk(
//   'getSoftTokenStatus',
//   async (param, { getState, rejectWithValue }) => {
//     if (Demo.User.Check(getState)) return Demo.SoftToken.ActivationStatus;
//     const result = await client.get(`${apiEndpoint.public}/getSoftTokenStatus/v2`);
//     if (!result.ok) return rejectWithValue(result);
//     return result.data;
//   },
// );

export const getSoftTokenCQStatus = createAsyncThunk(
  'getSoftTokenCQStatus',
  async (param, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.SoftToken.ActivationStatus;
    const result = await client.get(`${apiEndpoint.public}/getSoftTokenCQStatus`);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const getSecfa = createAsyncThunk('getSecfa', async ({ isPublic, secfaInfo }, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return Demo.SoftToken.Secfa;
  let result;
  if (isPublic) result = await publicClient.post(`${apiEndpoint.public}/getSecfa/v3`, secfaInfo);
  else result = await privateClient.post(`${apiEndpoint.private}/getSecfa/v3`, secfaInfo);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const ping = createAsyncThunk('/ping', async ({ isPublic }, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return Demo.SoftToken.Ping;
  let result;
  if (isPublic) result = await publicClient.get(`${apiEndpoint.public}/ping`);
  else result = await privateClient.get(`${apiEndpoint.private}/ping`);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const requestPac = createAsyncThunk('fundTransfer/requestPac', async ({ isPublic }, { rejectWithValue }) => {
  let result;
  if (isPublic) {
    result = await publicClient.post(`${apiEndpoint.public}/requestPac`, {});
  } //HACK: Put empty body to make sure not blocked by eSec
  else {
    result = await privateClient.post(`${apiEndpoint.private}/requestPac`, {});
  }
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const requestChallengeCode = createAsyncThunk(
  'fundTransfer/requestChallengeCode',
  async ({ isPublic }, { rejectWithValue }) => {
    let result;
    if (isPublic) result = await publicClient.post(`${apiEndpoint.public}/requestChallengeCode`, {});
    else result = await privateClient.post(`${apiEndpoint.private}/requestChallengeCode`, {});
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const getPendingTransaction = createAsyncThunk(
  'getPendingTransaction',
  async (param, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.SoftToken.PendingTransaction;
    const result = await client.get(`${apiEndpoint.public}/softToken/getPendingTrx`);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const retrieveTransactionStatus = createAsyncThunk(
  'retrieveTransactionStatus',
  async ({ transactionId }, { rejectWithValue }) => {
    const result = await client.post(`${apiEndpoint.public}/softToken/checkTrxStatus/v2`, { transactionId });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const rejectPendingTransaction = createAsyncThunk(
  'rejectTransaction',
  async ({ transactionId, rejectedFrom }, { rejectWithValue }) => {
    const result = await client.post(`${apiEndpoint.public}/softToken/rejectTrx`, { transactionId, ...(rejectedFrom && { rejectedFrom }) });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const softTokenActivationCheckEngage = createAsyncThunk(
  'softTokenActivationCheckEngage',
  async (param, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.SoftToken.CheckEngageActivation;
    const result = await privateClient.get(`${apiEndpoint.private}/softTokenActivationCheckEngage`);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const softTokenActivationCheckEngageApproval = createAsyncThunk(
  'softTokenActivationCheckEngageApproval',
  async ({ transactionId }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.SoftToken.CheckEngageApproval;
    const result = await privateClient.post(`${apiEndpoint.private}/softTokenActivationCheckEngageApproval`, {
      transactionId,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const updateProfileAccess = createAsyncThunk(
  'updateProfileAccess',
  async ({ secfa }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.SoftToken.UpdateProfileAccess;
    const result = await publicClient.post(`${apiEndpoint.public}/changeProfileAccess`, {
      secfa,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

const slice = createSlice({
  name: 'softToken',
  initialState,
  reducers: {
    softTokenReset: _ => initialState,
    updateSoftTokenObject: (state, { payload }) => {
      for (const key in payload) {
        state[key] = payload[key];
      }
    },
    updateSoftTokenTransactionObject: (state, { payload }) => {
      for (const key in payload) {
        state.transaction[key] = payload[key];
      }
    },
    updateSoftTokenAuthObject: (state, { payload }) => {
      for (const key in payload) {
        state.auth[key] = payload[key];
      }
    },
    selectedSecfaUpdated: (state, { payload }) => {
      state.auth.selectedSecfa = payload;
    },
    softTokenPendingTranReset: state => {
      state.pendingTransaction = initialState.pendingTransaction;
    },
    paymentAuthReset: state => {
      state.auth = initialState.auth;
    },
    paymentAuthPacReset: state => {
      const { isPublic, lastPacReqTime } = state.auth;
      state.auth = { ...initialState.auth, isPublic, lastPacReqTime };
    },
    routeSelected: (state, { payload }) => {
      state.selectedRoute = payload;
    },
    selectedRouteReset: state => {
      state.selectedRoute = initialState.selectedRoute;
    },
    softTokenDeactivated: state => {
      state.isActivated = initialState.isActivated;
    },
    quickLimitReachedReset: state => {
      state.auth.isQuickLimitReached = initialState.auth.isQuickLimitReached;
    },
  },
  extraReducers: builder => {
    builder.addCase(REHYDRATE, (state, { payload }) => {
      if (payload?.softToken !== undefined) state = payload.softToken;
    });
    builder.addCase(initUser.fulfilled, (state, { payload }) => {
      state.status = SUCCESS;
      state.pendingTransactionStatus = SUCCESS;

      state.isLicenseAvailable = payload.isLicenseAvailable;
      state.isActivated = payload.isSoftTokenActivated;
      state.profileType = payload.profileType;
      state.quickLimit = payload.quickLimit;
      state.isPBCUser = payload.isPBCUser;
      state.name = payload.name;
      state.pendingTransaction = payload.pendingTrx;
      state.serviceFee = payload.serviceFee;
    });
    builder.addCase(getSoftTokenCQStatus.pending, state => {
      state.status = LOADING;
    });
    builder.addCase(getSoftTokenCQStatus.fulfilled, (state, { payload }) => {
      state.status = SUCCESS;
      state.isActivated = payload.isSoftTokenActivated;
      state.softTokenActivationStatus = payload.softTokenActivationStatus;
      state.processedTime = payload.processedTime;
      state.coolingOffHour = payload.coolingOffHour;
      state.cqActivationStatus = payload.cqActivationStatus;
      // state.cqEnrolmentRequired = payload.cqEnrolmentRequired;
    });
    builder.addCase(getSoftTokenCQStatus.rejected, state => {
      state.status = FAIL;
    });

    builder.addCase(getPendingTransaction.pending, state => {
      state.pendingTransactionStatus = LOADING;
    });
    builder.addCase(getPendingTransaction.fulfilled, (state, { payload }) => {
      state.pendingTransactionStatus = SUCCESS;
      state.pendingTransaction = payload.pendingTrx;
    });
    builder.addCase(getPendingTransaction.rejected, state => {
      state.pendingTransactionStatus = FAIL;
    });

    builder.addCase(loadCasa.fulfilled, (state, { payload }) => {
      const found = payload.accountSummary?.find(x => x.accountNo === payload.prefAccount);
      state.preferredAccountNo = payload.prefAccount;
      if (found && found.accountStatus) {
        state.preferredAccountName = found.accountDesc;
        state.preferredAccountActive = true;
        state.preferredAccountLvlName = found.accName;
      } else {
        state.preferredAccountName = '';
        state.preferredAccountActive = false;
        state.preferredAccountLvlName = '';
      }
    });
    builder.addCase(validateId.pending, state => {
      state.status = LOADING;
    });
    builder.addCase(validateId.fulfilled, state => {
      state.status = SUCCESS;
    });
    builder.addCase(validateId.rejected, state => {
      state.status = FAIL;
    });

    // builder.addCase(activateTokenInstance.fulfilled, (state, { meta }) => {
    //   state.isActivated = true;
    //   state.wasActivatedOnSameDevice = true;
    //   if (meta.arg.quickLimit) state.quickLimit = meta.arg.quickLimit;
    // });
    builder.addCase(deactivateSoftToken.fulfilled, state => {
      state.isActivated = false;
    });
    builder.addCase(updatePrefAccount.pending, state => {
      state.status = LOADING;
    });
    builder.addCase(updatePrefAccount.fulfilled, (state, { meta }) => {
      state.status = SUCCESS;
      state.preferredAccountNo = meta.arg.accountNo;
      state.preferredAccountName = meta.arg.accountDesc;
      state.preferredAccountActive = true;
      state.preferredAccountLvlName = meta.arg.accName;
    });
    builder.addCase(updatePrefAccount.rejected, state => {
      state.status = FAIL;
    });
    builder.addCase(updateQuickPayment.fulfilled, (state, { meta, payload }) => {
      if (payload.challengeQuestion) return;
      state.quickLimit = meta.arg.quickLimit;
    });
    builder.addCase(requestPac.fulfilled, (state, { payload }) => {
      state.auth.status = SUCCESS;
      state.auth.pacSeqNo = payload.pacSeqNo;
      state.auth.phoneNo = payload.phoneNo;
    });
    builder.addCase(requestPac.pending, state => {
      state.auth.status = LOADING;
    });
    builder.addCase(requestPac.rejected, state => {
      state.auth.status = FAIL;
    });
    builder.addCase(requestChallengeCode.fulfilled, (state, { payload }) => {
      state.auth.status = SUCCESS;
      state.auth.challengeCode2 = payload.challengeCode2;
      state.auth.challengeCode1 = payload.challengeCode1;
    });
    builder.addCase(requestChallengeCode.pending, state => {
      state.auth.status = LOADING;
    });
    builder.addCase(requestChallengeCode.rejected, state => {
      state.auth.status = FAIL;
    });
    builder.addCase(ping.fulfilled, (state, { meta }) => {
      state.auth.isPublic = meta.arg.isPublic;
    });
    builder.addCase(ping.rejected, state => {
      state.auth.isPublic = true;
    });
    builder.addCase(checkPBO.fulfilled, state => {
      state.auth.isPublic = false;
    });
    builder.addCase(validateSecurePIN.fulfilled, state => {
      state.auth.status = SUCCESS;
      state.auth.errorAttempt = initialState.auth.errorAttempt;
    });
    builder.addCase(validateSecurePIN.pending, state => {
      state.auth.status = LOADING;
    });
    builder.addCase(validateSecurePIN.rejected, (state, { payload }) => {
      state.auth.status = FAIL;
      if (payload.data && typeof payload.data !== 'string') {
        state.auth.errorAttempt = payload.data.pinAttempts;
      }
    });
    builder.addCase(validateSignature.fulfilled, state => {
      // state.auth.status = "succeeded"
    });
    builder.addCase(validateSignature.pending, state => {
      state.auth.status = LOADING;
    });
    builder.addCase(validateSignature.rejected, (state, { payload }) => {
      state.auth.status = FAIL;
      if (payload.data && typeof payload.data !== 'string') {
        state.auth.errorAttempt = payload.data.secfaAttempts;
      }
    });
    builder.addCase(updateProfileAccess.fulfilled, (state, { meta }) => {
      state.profileType = meta.arg.profileType;
      if (meta.arg.profileType === PROFILE_TYPE.VIEW) {
        state.isActivated = initialState.isActivated;
        state.softTokenActivationStatus = initialState.softTokenActivationStatus;
      }
    });
    builder.addCase(getSecfa.fulfilled, (state, { payload, meta }) => {
      if (meta.arg.isPublic && payload.isQuickLimitReached) {
        state.auth.isQuickLimitReached = payload.isQuickLimitReached;
      }
    });
    builder.addMatcher(isAnyOf(enrolCQ.fulfilled, changeCQ.fulfilled), (state, { payload }) => {
      state.processedTime = payload.processedTime;
      state.coolingOffHour = payload.coolingOffHour;
      state.cqActivationStatus = payload.cqActivationStatus;
    });
    builder.addMatcher(
      isAnyOf(
        submitFundTransfer.fulfilled,
        submitCardPayment.fulfilled,
        submitLoanPayment.fulfilled,
        submitQRPayment.fulfilled,
        submitTopUp.fulfilled,
        submitCashAdvance.fulfilled,
        submitBillPayment.fulfilled,
        registerDuitNowProxy.fulfilled,
        manageDuitNowProxy.fulfilled,
        enrolCQ.fulfilled,
        submitCardlessWithdraw.fulfilled,
        submitBakong.fulfilled,
        updateQuickPayment.fulfilled,
        submitAlipayPlus.fulfilled,
        submitOpenEFD.fulfilled,
        submitDepositPlacement.fulfilled,
        submitDepositWithdraw.fulfilled,
        submitCarbonOffset.fulfilled,
        submitLockFund.fulfilled,
        submitUnlockFund.fulfilled,
        submitEmailAddress.fulfilled,
        submitCardPin.fulfilled,
        submitBuyGold.fulfilled,
        submitSellGold.fulfilled,
        submitOpenGoldAcc.fulfilled,
        submitCloseGoldAccount.fulfilled,
        updateProfileAccess.fulfilled,
        changeCQ.fulfilled,
        enrolCQ.fulfilled,
        addCardTokenization.fulfilled,
        submitLonpacInsuranceConsent.fulfilled,
      ),
      state => {
        state.auth.status = SUCCESS;
        state.auth.errorAttempt = initialState.auth.errorAttempt;
      },
    );
    builder.addMatcher(
      isAnyOf(
        submitFundTransfer.pending,
        submitCardPayment.pending,
        submitLoanPayment.pending,
        submitQRPayment.pending,
        submitTopUp.pending,
        submitCashAdvance.pending,
        submitBillPayment.pending,
        registerDuitNowProxy.pending,
        manageDuitNowProxy.pending,
        enrolCQ.pending,
        submitCardlessWithdraw.pending,
        submitBakong.pending,
        updateQuickPayment.pending,
        submitAlipayPlus.pending,
        submitOpenEFD.pending,
        submitDepositPlacement.pending,
        submitDepositWithdraw.pending,
        submitCarbonOffset.pending,
        submitLockFund.pending,
        submitUnlockFund.pending,
        submitEmailAddress.pending,
        submitCardPin.pending,
        submitBuyGold.pending,
        submitSellGold.pending,
        submitOpenGoldAcc.pending,
        submitCloseGoldAccount.pending,
        updateProfileAccess.pending,
        changeCQ.pending,
        enrolCQ.pending,
        addCardTokenization.pending,
        submitLonpacInsuranceConsent.pending,
      ),
      state => {
        state.auth.status = LOADING;
      },
    );
    builder.addMatcher(
      isAnyOf(
        submitFundTransfer.rejected,
        submitCardPayment.rejected,
        submitLoanPayment.rejected,
        submitQRPayment.rejected,
        submitTopUp.rejected,
        submitCashAdvance.rejected,
        submitBillPayment.rejected,
        registerDuitNowProxy.rejected,
        manageDuitNowProxy.rejected,
        enrolCQ.rejected,
        submitCardlessWithdraw.rejected,
        submitBakong.rejected,
        updateQuickPayment.rejected,
        submitAlipayPlus.rejected,
        submitOpenEFD.rejected,
        submitDepositPlacement.rejected,
        submitDepositWithdraw.rejected,
        submitCarbonOffset.rejected,
        submitLockFund.rejected,
        submitUnlockFund.rejected,
        submitEmailAddress.rejected,
        submitCardPin.rejected,
        submitBuyGold.rejected,
        submitSellGold.rejected,
        submitOpenGoldAcc.rejected,
        submitCloseGoldAccount.rejected,
        updateProfileAccess.rejected,
        changeCQ.rejected,
        enrolCQ.rejected,
        addCardTokenization.rejected,
        submitLonpacInsuranceConsent.rejected,
      ),
      (state, { payload }) => {
        state.auth.status = FAIL;
        if (payload.data && typeof payload.data !== 'string') {
          state.auth.errorAttempt = payload.data.secfaAttempts;
        }
      },
    );
  },
});

export const {
  updateSoftTokenObject,
  softTokenReset,
  updateSoftTokenTransactionObject,
  updateSoftTokenAuthObject,
  selectedSecfaUpdated,
  softTokenPendingTranReset,
  paymentAuthReset,
  paymentAuthPacReset,
  routeSelected,
  selectedRouteReset,
  softTokenDeactivated,
  quickLimitReachedReset,
} = slice.actions;
export default slice.reducer;

export const getSoftToken = createSelector(
  state => state.bankingEntities.softToken,
  softToken => softToken,
);

export const getSoftTokenAndroidFingerprintType = createSelector(
  state => state.bankingEntities.softToken,
  softToken => softToken.androidFingerprintType,
);

export const getSoftTokenTransaction = createSelector(
  state => state.bankingEntities.softToken,
  softToken => softToken.transaction,
);

export const getSecfaAuth = createSelector(
  state => state.bankingEntities.softToken?.auth,
  auth => auth,
);

export const getSoftTokenPendingTran = createSelector(
  state => state.bankingEntities.softToken.pendingTransaction,
  pendingTransaction => pendingTransaction,
);

export const getSoftTokenPendingTranStatus = createSelector(
  state => state.bankingEntities.softToken.pendingTransactionStatus,
  status => status,
);

export const getServiceFee = createSelector(
  state => state.bankingEntities.softToken.serviceFee,
  serviceFee => serviceFee,
);

export const checkIsPBCUser = createSelector(
  state => state.bankingEntities.softToken.isPBCUser,
  isPBCUser => isPBCUser,
);

export const checkProfileType = type =>
  createSelector(
    state => state.bankingEntities.softToken.profileType,
    profileType => profileType === type,
  );

export const getProfileType = createSelector(
  state => state.bankingEntities.softToken.profileType,
  profileType => profileType,
);
