import { createAsyncThunk } from '@reduxjs/toolkit';
import qs from 'qs';
import { apiEndpoint } from 'apis/apiUtils';
import {
  guardedPublicClient,
  publicClient
} from 'apis/publicClient';
import {
  guardedPrivateClient,
  privateClient
} from 'apis/privateClient';
import { eaiClient } from 'apis/eaiClient';
import { authStorage } from 'auth/storage';
import { Demo } from 'constant';
import { encryption } from 'utils/encryption';
import { publicClientForLogout } from 'apis/publicClientForLogout';
import { encodeEmail } from 'utils';
import { Attestation } from 'attestation';
// import { flowType } from './reducer';

export const FLOW_TYPE = Object.freeze({
  LINK_PBE: 'linkPBe',
  REGISTER_PBE: 'registerPBe',
  REGISTER_PBO: 'registerPBO',
  LOGIN_PBE: 'loginPBe',
  LOGIN_PBO: 'loginPBo',
  LOGIN_PBE_RESET_PIN: 'loginPBeResetPin',
  LOGIN_PBO_RESET_PIN: 'loginPBoResetPin',
  RESET_PIN: 'resetPin',
  QUICK_LOGIN: 'quickLogin',
  POST_LOGIN: 'postLogin',
  CHANGE_PIN: 'changePin',
  ALIPAY_PLUS_GEN_PAYCODE: 'alipayPlusGenPayCode',
  DUITNOW_GEN_PAYCODE: 'duitNowGenPayCode',
});

export const requestSession = createAsyncThunk(
  'auth/eaijct/requestSession',
  async ({ username }, { rejectWithValue }) => {
    if (Demo.User.CheckCredential(username)) return Demo.Auth.UsernameCheck;
    const result = await eaiClient.post(
      `${apiEndpoint.eaijct}/PBAuthenticate`,
      qs.stringify({ username, Next: 'Next' }),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' } },
    );
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const sessionLogin = createAsyncThunk(
  'auth/eaijct/login',
  async ({ username, password }, { rejectWithValue }) => {
    if (Demo.User.CheckCredential(username, password)) return Demo.Auth.SessionLogin;
    const result = await eaiClient.post(
      `${apiEndpoint.eaijct}/PBAuthenticate`,
      qs.stringify({ username, encryptMsg: encryption.encryptUserIdPassword({ password }), Submit: 'Login' }),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' } },
    );
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const checkPBO = createAsyncThunk(
  'auth/login/checkPBO',
  async ({ deviceModel, deviceId, encryptedId, isQuickLimitReached }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.CheckPBO;
    const attestation = await Attestation.Init({ state: getState, deviceId });

    const result = await privateClient.post(`${apiEndpoint.private}${apiEndpoint.mobileLogin}`, {
      deviceModel, //For non-binded user duplicate login checking audit trail
      deviceId, //API to recognize private login from binded or non-binded user
      encryptedId, //API to recognize private login from binded or non-binded user
      isQuickLimitReached,
      ...attestation,
    });
    if (!result.ok) return rejectWithValue(result);

    const accessKey = result.data?.accessKey;
    if (accessKey) await authStorage.storePrivateAccessToken(accessKey).then();

    return result.data;
  },
);

export const requestLogout = createAsyncThunk('auth/logout', async ({ isPublic, accessToken }, { getState }) => {
  if (Demo.User.Check(getState)) return;
  let result;

  if (accessToken) publicClientForLogout.setHeaders({ 'ACCESS-TOKEN': accessToken });

  if (isPublic) {
    result = await publicClientForLogout.get(`${apiEndpoint.public}/logout`);
  } else {
    result = await privateClient.get(`${apiEndpoint.private}/logout`);
    await eaiClient.get(apiEndpoint.logout); //to logout webseal
  }

  return result.data;
});

export const requestLogoutWebseal = createAsyncThunk('auth/logoutWebseal', async (_, { getState }) => {
  if (Demo.User.Check(getState)) return;
  await eaiClient.get(apiEndpoint.logout); //to logout webseal
  return true;
});

export const requestUnbind = createAsyncThunk('auth/unbind', async ({ accessToken }, { getState }) => {
  if (Demo.User.Check(getState)) return;
  if (accessToken) publicClientForLogout.setHeaders({ 'ACCESS-TOKEN': accessToken });
  await publicClientForLogout.get(`${apiEndpoint.public}/unbind`);
});

export const requestSecfaType = createAsyncThunk(
  'auth/secfaType',
  async ({ email, flowType }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return { ...Demo.Auth.RequestSecfaType, email, flowType };
    const result = await publicClient.post(`${apiEndpoint.public}/getSecfaType`, {
      email: encodeEmail(email),
      isEmailEncoded: true,
    });
    if (!result.ok) return rejectWithValue(result);
    return { ...result.data, email, flowType };
  },
);

export const requestAuthPac = createAsyncThunk(
  'auth/requestPac',
  async ({ isPublic, email, tranType }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.RequestAuthPac;
    let result;
    if (isPublic) {
      result = await publicClient.post(`${apiEndpoint.public}/requestPac`, {
        tranType,
        email: encodeEmail(email),
        isEmailEncoded: true,
      });
    } else {
      result = await privateClient.post(`${apiEndpoint.private}/requestPac`, { tranType });
    }
    if (!result.ok) return rejectWithValue(result);
    return { ...result.data, isPublic };
  },
);

export const requestAuthChallengeCode = createAsyncThunk(
  'auth/requestChallengeCode',
  async ({ isPublic, email, tranType }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.RequestChallengeCode;
    let result;
    if (isPublic) {
      result = await publicClient.post(`${apiEndpoint.public}/requestChallengeCode`, {
        tranType,
        email: encodeEmail(email),
        isEmailEncoded: true,
      });
    } else {
      result = await privateClient.post(`${apiEndpoint.private}/requestChallengeCode`, { tranType });
    }
    if (!result.ok) return rejectWithValue(result);
    return { ...result.data, isPublic };
  },
);

export const updateQuickPayment = createAsyncThunk(
  'updateQuickPayment',
  async ({ secfa, quickLimit }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.QuickPayment;
    const result = await publicClient.post(`${apiEndpoint.public}/updateQuickPayment`, {
      secfa,
      quickLimit,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const initSoftTokenActivation = createAsyncThunk(
  'initSoftTokenActivation',
  async ({ secfa }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.InitSoftTokenActivation;
    const result = await privateClient.post(`${apiEndpoint.private}/softTokenActivationInitialization`, { secfa });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const submitRegistration = createAsyncThunk(
  'auth/register',
  async (
    {
      isPublic = true,
      secfa,
      email,
      isUpdateEmail,
      displayName,
      mobileNo,
      pin,
      deviceType,
      deviceModel,
      deviceName,
      osVersion,
      pushNotificationToken,
      pushNotificationIsHms,
      languageCode,
    },
    { rejectWithValue },
  ) => {
    const data = {
      secfa,
      email: encodeEmail(email.toLowerCase()),
      isEmailEncoded: true,
      isUpdateEmail,
      displayName,
      mobileNo,
      pin,
      deviceType,
      deviceModel,
      deviceName,
      osVersion,
      pushNotificationToken,
      pushNotificationIsHms,
      languageCode,
    };

    let result;
    if (isPublic) result = await publicClient.post(`${apiEndpoint.public}/registration`, data);
    else result = await privateClient.post(`${apiEndpoint.private}/registration`, data);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const validateEmail = createAsyncThunk(
  'auth/validate/email',
  async ({ email, isNewEmail, isPublic = true }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.ValidateEmail;
    let result;
    const request = {
      email: encodeEmail(email),
      isEmailEncoded: true,
      ...(isNewEmail !== undefined && { isNewEmail }),
    };
    if (isPublic) result = await publicClient.post(`${apiEndpoint.public}/validateEmail`, request);
    else result = await privateClient.post(`${apiEndpoint.private}/validateEmail`, request);
    if (!result.ok) return rejectWithValue(result);
    return { ...result.data, email };
  },
);

export const validateEmailMobile = createAsyncThunk(
  'auth/validate/emailMobile',
  async ({ email, phone }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.ValidateEmail;
    const result = await publicClient.post(`${apiEndpoint.public}/validateEmail`, {
      email: encodeEmail(email),
      isEmailEncoded: true,
    });
    if (!result.ok) return rejectWithValue(result);
    return { ...result.data, email, phone, flowType: FLOW_TYPE.REGISTER_PBO };
  },
);

export const submitQuickLogin = createAsyncThunk(
  'auth/quickLogin',
  async (
    { deviceId, encryptedId, pin, secfa, loginMethod, deviceType, deviceModel, deviceName, osVersion, uniqueDeviceId },
    { getState, rejectWithValue },
  ) => {
    if (Demo.User.Check(getState)) {
      if (Demo.User.CheckPin(pin, getState)) return Demo.Auth.QuickLogin;
      return rejectWithValue(Demo.Auth.QuickLoginRejected);
    }
    const attestation = await Attestation.Init({ state: getState, deviceId });
    const result = await publicClient.post(`${apiEndpoint.public}/quickLogin/v6`, {
      deviceId,
      encryptedId,
      pin: encryption.encryptUserIdPassword({ password: pin }),
      secfa,
      loginMethod,
      deviceType,
      deviceModel,
      deviceName,
      osVersion,
      uniqueDeviceId,
      ...attestation,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const submitPostLogin = createAsyncThunk(
  'auth/postLogin',
  async (
    { deviceId, encryptedId, deviceType, deviceModel, deviceName, osVersion, postLoginToken, uniqueDeviceId },
    { getState, rejectWithValue },
  ) => {
    if (Demo.User.Check(getState)) return Demo.Auth.QuickLogin;
    const result = await publicClient.post(`${apiEndpoint.public}/postLogin/v3`, {
      deviceId,
      encryptedId,
      deviceType,
      deviceModel,
      deviceName,
      osVersion,
      postLoginToken,
      uniqueDeviceId,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const validatePin = createAsyncThunk(
  'auth/validate/pin',
  async ({ pin, email, isPublic }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.ValidatePin;
    let result;
    const encryptedPin = encryption.encryptUserIdPassword({ password: pin });
    const request = { pin: encryptedPin, email: encodeEmail(email), isEmailEncoded: true };
    if (isPublic) {
      result = await publicClient.post(`${apiEndpoint.public}/validatePin`, request);
    } else {
      result = await privateClient.post(`${apiEndpoint.private}/validatePin`, request);
    }
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const requestBind = createAsyncThunk(
  'auth/bind',
  async (
    {
      isPublic,
      secfa,
      pin,
      email,
      deviceType,
      deviceModel,
      deviceName,
      osVersion,
      pushNotificationToken,
      pushNotificationIsHms,
      languageCode,
    },
    { getState, rejectWithValue },
  ) => {
    const data = {
      secfa,
      pin: encryption.encryptUserIdPassword({ password: pin }),
      email: encodeEmail(email),
      isEmailEncoded: true,
      deviceType,
      deviceModel,
      deviceName,
      osVersion,
      pushNotificationToken,
      pushNotificationIsHms,
      languageCode,
    };
    if (Demo.User.Check(getState)) return Demo.Auth.RequestBind;
    let result;
    if (isPublic) result = await publicClient.post(`${apiEndpoint.public}/binding`, data);
    else result = await privateClient.post(`${apiEndpoint.private}/binding`, data);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const requestLinkPBe = createAsyncThunk(
  'auth/linkPbe',
  async ({ secfa, deviceId, encryptedId }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.RequestLinkPBe;
    const result = await privateClient.post(`${apiEndpoint.private}/pbeLink`, { secfa, deviceId, encryptedId });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const requestChangePin = createAsyncThunk(
  'auth/changePin',
  async ({ isPublic, secfa, pin }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return { ...Demo.Auth.RequestChangePin, pin };

    const encryptedPin = encryption.encryptUserIdPassword({ password: pin });
    let result;
    if (isPublic) {
      result = await publicClient.post(`${apiEndpoint.public}/changePin`, {
        secfa,
        pin: encryptedPin,
      });
    } else {
      result = await privateClient.post(`${apiEndpoint.private}/changePin/v2`, {
        secfa,
        pin: encryptedPin,
      });
    }

    if (!result.ok) return rejectWithValue(result);
    return { ...result.data, pin: encryptedPin };
  },
);

export const closeProfile = createAsyncThunk('auth/closeProfile', async (param, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return;
  const result = await publicClient.get(`${apiEndpoint.public}/closeProfile`);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const answerAAOP = createAsyncThunk(
  'aaop/answer',
  async ({ aaopAnswer, isPublic }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.AnswerAAOP;
    let result;
    if (isPublic)
      result = await guardedPublicClient.post(`${apiEndpoint.public}/aaop/authenticate`, {
        aaopAnswer,
      });
    else
      result = await guardedPrivateClient.post(`${apiEndpoint.private}/aaop/authenticate`, {
        aaopAnswer,
      });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const preEnrolCQ = createAsyncThunk(
  'challengeQuestion/preEnrol',
  async ({ aaopAnswers }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.EnrolAAOP;
    const result = await privateClient.post(`${apiEndpoint.private}/challengeQuestion/preEnrol`, { aaopAnswers });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const enrolCQ = createAsyncThunk('challengeQuestion/enrol', async ({ secfa }, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return Demo.Auth.EnrolAAOP;
  const result = await privateClient.post(`${apiEndpoint.private}/challengeQuestion/enrol`, {
    secfa,
  });
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const getCQ = createAsyncThunk('challengeQuestion/get', async (_, { getState, rejectWithValue }) => {
  if (Demo.User.Check(getState)) return Demo.Auth.EnrolAAOP;
  const result = await privateClient.get(`${apiEndpoint.private}/challengeQuestion/get`);
  if (!result.ok) return rejectWithValue(result);
  return result.data;
});

export const changeCQ = createAsyncThunk(
  'challengeQuestion/change',
  async ({ secfa }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return Demo.Auth.EnrolAAOP;
    const result = await privateClient.post(`${apiEndpoint.private}/challengeQuestion/change`, {
      secfa,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
export const updateAwarenessConsent = createAsyncThunk(
  'auth/updateAwarenessConsent',
  async (param, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return;
    const result = await publicClient.get(`${apiEndpoint.public}/updateAwarenessConsent`);
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);

export const updateMarketingConsent = createAsyncThunk(
  'consent/updateMarketingConsent',
  async ({ indicator }, { getState, rejectWithValue }) => {
    if (Demo.User.Check(getState)) return;
    const result = await publicClient.post(`${apiEndpoint.public}/consent/updateMarketingConsent`, {
      indicator,
    });
    if (!result.ok) return rejectWithValue(result);
    return result.data;
  },
);
