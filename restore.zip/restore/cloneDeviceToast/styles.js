import { StyleSheet } from 'react-native';
import { colors } from 'configs';

export const styles = StyleSheet.create({
  backdrop: {
    backgroundColor: 'rgba(0,0,0,0.2)',
    justifyContent: 'center',
    paddingHorizontal: 20,
    flex: 1,
  },
  container: {
    backgroundColor: colors.white,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    paddingBottom: 0,
    overflow: 'hidden',
  },
  padding: {
    padding: 20,
    gap: 10,
    justifyContent: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    borderTopWidth: 0.33,
    borderTopColor: '#D8D8D8',
    overflow: 'hidden',
  },
  buttonBg: {
    backgroundColor: colors.primary,
  },
  buttonText: {
    color: colors.white,
  },
});
