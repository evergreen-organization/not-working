import React from 'react';
import { useWindowDimensions, View } from 'react-native';
import { Text } from 'components';
import { colors } from 'configs';
import { useTranslation } from 'react-i18next';
import Toast from 'react-native-toast-message';
import { styles } from './styles';
import Button from '../../button/Button';

const LANG_PREFIX = 'organisms.cloneDeviceToast.';

export const CloneDeviceToast = () => {
  const { width, height } = useWindowDimensions();

  const { t } = useTranslation();

  const handleClose = () => Toast.hide();

  return (
    <View style={[styles.backdrop, { width, height }]}>
      <View style={styles.container}>
        <View style={styles.padding}>
          <Text bold style={{ color: colors.primary }}>
            {t(`${LANG_PREFIX}alertTitle`)}
          </Text>
          <Text style={{ marginTop: 10 }}>{t(`${LANG_PREFIX}alertDescription`)}</Text>
        </View>

        <View style={styles.buttonContainer}>
          <Button
            title={t(`${LANG_PREFIX}doneButton`)}
            style={styles.buttonBg}
            fontStyle={styles.buttonText}
            onPress={handleClose}
          />
        </View>
      </View>
    </View>
  );
};
