import { useSelector } from 'react-redux';
import { getSoftToken, getSoftTokenAndroidFingerprintType } from 'stores';
import useSoftTokenSigner from './useSoftTokenSigner';
import useDeviceUniqueID from './useDeviceUniqueID';

export const useCheckCloneDevice = () => {
  const { isActivated: isSoftTokenActivated } = useSelector(getSoftToken) || {};
  const androidFingerprintType = useSelector(getSoftTokenAndroidFingerprintType);
  const { getSecureStorage } = useSoftTokenSigner();
  const deviceUniqueIDUtils = useDeviceUniqueID();

  const getUniqueDeviceId = async () => {
    if (!isSoftTokenActivated) return null;

    const secureStorageResult = await getSecureStorage();
    
    if (secureStorageResult.status === 'S' && secureStorageResult?.data?.secureStorageSize === 0) {
      const uniqueDeviceId = await deviceUniqueIDUtils.get(androidFingerprintType);
      return uniqueDeviceId;
    }

    return null;
  };

  return {
    getUniqueDeviceId,
  };
};
