import { useApi, usePing } from 'hooks';
import { NativeModules } from 'react-native';
import { getDeviceName } from 'react-native-device-info';
import {
  activateTokenInstanceSilently,
  generateTokenInstanceSilently,
  generateTokenLicenseSilently,
  getSoftToken,
  getUser,
  initSoftTokenActivationSilently,
  registerDSAppSilently,
  unBindLocalDevice,
} from 'stores';
import useDeviceUniqueID from './useDeviceUniqueID';
import { useSoftTokenUtils } from './useSoftTokenUtils';
import { useDispatch, useSelector } from 'react-redux';
import { ANDROID_SOFT_TOKEN_FINGERPRINT_TYPE, CLONE_DEVICE_ERROR } from 'constant';
import { showFailure } from 'utils';
import routes from '../navigations/routes';
import { useNavigation } from '@react-navigation/native';

const specialCharactersRegex = /[^0-9A-Za-z ]/g;

let deviceName = '';

getDeviceName().then(val => {
  const name = val?.replace(specialCharactersRegex, '');
  deviceName = name ? name : 'n/a';
});

const { SoftTokenModule } = NativeModules;

/*eslint no-unsafe-optional-chaining: 0 */

export const useSoftTokenReactivation = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const sUser = useSelector(getUser);
  const { androidFingerprintType: storedAndroidFingerprintType, secureStorageEmpty } = useSelector(getSoftToken);
  const { deviceId, encryptedId } = sUser || {};
  const deviceUniqueIDUtils = useDeviceUniqueID();
  const softTokenUtils = useSoftTokenUtils();

  const androidFingerprintType = ANDROID_SOFT_TOKEN_FINGERPRINT_TYPE.TEE;
  const initSoftTokenActivationApi = useApi(initSoftTokenActivationSilently);
  const registerDSAppApi = useApi(registerDSAppSilently);
  const generateTokenLicenseApi = useApi(generateTokenLicenseSilently);
  const generateTokenInstanceApi = useApi(generateTokenInstanceSilently);
  const activateTokenInstanceApi = useApi(activateTokenInstanceSilently);
  const { pingPrivate } = usePing();

  const activate = async () => {
    let uniqueDeviceId = '';
    const id = deviceId + encryptedId;
    const userIdentifier = softTokenUtils.getUserIdentifier(id);

    if (secureStorageEmpty) {
      uniqueDeviceId = await deviceUniqueIDUtils.get(storedAndroidFingerprintType);
    }

    const privateSession = await pingPrivate();

    const initResult = await initSoftTokenActivationApi.request({
      deviceId,
      encryptedId,
      uniqueDeviceId,
      isPublic: !privateSession,
    });

    // handle clone device error
    if (initResult.status === CLONE_DEVICE_ERROR) {
      showFailure(initResult.problem);
      dispatch(unBindLocalDevice());
      navigation.navigate(routes.MAIN_TAB);
      navigation.navigate(routes.LOGIN_PBE_OLD);
      return;
    }

    const { encryptedActivationPassword, salt: initialSalt, iv } = initResult || {};

    const secretKey = softTokenUtils.genSecretKey(userIdentifier, initialSalt);
    const activationPassword = softTokenUtils.decrypt(encryptedActivationPassword, secretKey, iv);

    const result1 = await registerDSAppApi.request({ isPublic: !privateSession });
    const { serverEphemeralPublicKey, salt } = result1 || {};

    const clientEphemeralKey = await SoftTokenModule.generateSRPClientEphemeralKey();
    if (clientEphemeralKey?.status !== 'S') return fail('F01', clientEphemeralKey);

    const { clientEphemeralPrivateKey, clientEphemeralPublicKey } = clientEphemeralKey?.data;

    const sessionKey = await SoftTokenModule.generateSRPSessionKey(
      clientEphemeralPublicKey,
      clientEphemeralPrivateKey,
      serverEphemeralPublicKey,
      userIdentifier,
      activationPassword,
      salt,
    );
    if (sessionKey?.status !== 'S') return fail('F02', sessionKey);

    const { clientSessionKey, clientEvidenceMessage } = sessionKey?.data;
    //Step 2
    const result2 = await generateTokenLicenseApi.request({
      clientEphemeralPublicKey,
      clientEvidenceMessage,
      isPublic: !privateSession,
    });
    if (result2.problem) return fail('B02', result2);
    const { encryptedMultiDeviceLicenseActivationMessage, serverEvidenceMessage, mac, encryptionCounter } = result2;

    const verifyServerEvidenceResult = await SoftTokenModule.verifySRPServerEvidenceMessage(
      clientEphemeralPublicKey,
      clientEvidenceMessage,
      serverEvidenceMessage,
      clientSessionKey,
    );
    if (verifyServerEvidenceResult?.status !== 'S') return fail('F03', verifyServerEvidenceResult);

    const decryptSRPDataResult = await SoftTokenModule.decryptSRPData(
      clientSessionKey,
      encryptedMultiDeviceLicenseActivationMessage,
      encryptionCounter,
      mac,
    );
    if (decryptSRPDataResult?.status !== 'S') return fail('F04', decryptSRPDataResult);

    const { multiDeviceLicenseActivationMessage } = decryptSRPDataResult?.data;

    const parseSecureChannelMessageResult = await SoftTokenModule.parseSecureChannelMessage(
      multiDeviceLicenseActivationMessage,
      androidFingerprintType, //IOS to declare same parameter format without using this variable
    );
    if (parseSecureChannelMessageResult?.status !== 'S') return fail('F05', parseSecureChannelMessageResult);

    const { deviceCode, updatedAndroidFingerprintType } = parseSecureChannelMessageResult?.data;

    //Step 3
    const result3 = await generateTokenInstanceApi.request({ deviceCode, deviceName, isPublic: !privateSession });
    if (result3.problem) return fail('B03', result3);
    const { instanceActivationMessage, randomPasswordDerivator, serverUTCTime } = result3;
    const encrypt_rp_iv = softTokenUtils.getRandomString(16);

    const parseSecureChannelMessage2Result = await SoftTokenModule.parseSecureChannelMessage2(
      instanceActivationMessage,
      randomPasswordDerivator,
      serverUTCTime.toString(),
      encrypt_rp_iv,
      updatedAndroidFingerprintType, //IOS to declare same parameter format without using this variable
    );
    if (parseSecureChannelMessage2Result?.status !== 'S') return fail('F06', parseSecureChannelMessage2Result);

    const { sequenceNumber, signature } = parseSecureChannelMessage2Result?.data;

    //Step 4
    uniqueDeviceId = await deviceUniqueIDUtils.get(updatedAndroidFingerprintType);
    const result4 = await activateTokenInstanceApi.request({
      sequenceNumber,
      signature,
      uniqueDeviceId,
      isPublic: !privateSession,
    });
    if (result4.problem) return fail('B04', result4);

    const { mac: SRPMAC } = result4;

    const verifySRPMACResult = await SoftTokenModule.verifySRPMAC(SRPMAC, clientSessionKey, userIdentifier);
    if (verifySRPMACResult?.status !== 'S') return fail('F07', verifySRPMACResult);

    return {
      status: true,
      updatedAndroidFingerprintType,
    };
  };

  const fail = (mainErrorCode, result) => {
    if (!result) return { status: false, msg: mainErrorCode };

    const { status, errorCode, problem } = result || {};
    const errorMessage = errorCode ?? problem ?? '0';
    const msg = `${mainErrorCode} | ${status} | ${errorMessage}`;

    return { status: false, msg };
  };

  return {
    activate,
  };
};

export default useSoftTokenReactivation;
