import { useRef } from 'react';
import { NativeModules } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { useSoftTokenUtils } from './useSoftTokenUtils';
import {
  getSoftTokenAndroidFingerprintType,
  initTransaction,
  updateSoftTokenAuthObject,
  updateSoftTokenTransactionObject,
  validateSignature,
} from 'stores';
import { useApi } from 'hooks/useApi';

const { SoftTokenSigner } = NativeModules;

/*eslint no-unsafe-optional-chaining: 0 */

export const useSoftTokenSigner = () => {
  const dispatch = useDispatch();
  const utils = useSoftTokenUtils();
  const androidFingerprintType = useSelector(getSoftTokenAndroidFingerprintType);
  const initTransactionApi = useApi(initTransaction);
  const validateSignatureApi = useApi(validateSignature);
  const transactionIdRef = useRef();

  const init = async ({ isPublic = true }) => {
    const result = await initTransactionApi.request({ isPublic });
    return await retrieveTransaction(result);
  };

  const sign = async ({ randomPasswordDerivator, serverUTCTime }) => {
    const signTranResult = await SoftTokenSigner.signTransaction(
      randomPasswordDerivator,
      serverUTCTime.toString(),
      androidFingerprintType, //IOS to declare same parameter format without using this variable
    );
    const { status } = signTranResult || {};
    if (status !== 'S') return signTranResult;

    const { secureChannelMessageSignature } = signTranResult?.data;
    dispatch(updateSoftTokenTransactionObject({ secureChannelMessageSignature }));

    if (secureChannelMessageSignature) return { status, secureChannelMessageSignature };
    return { status: 'F' };
  };

  const submit = async ({ isPublic = true, transactionId, signature }) => {
    const request = {
      isPublic,
      transactionId,
      signature,
    };
    const result = await validateSignatureApi.request(request);
    if (result.problem) {
      if (
        result.status === 'E00039' || //Authentication Expired
        result.status === 'E00076' //Transaction Cancelled
      )
        return { errorPage: true, problem: result.problem };
      dispatch(
        updateSoftTokenAuthObject({ errorMsg: result.problem?.replace('${count}', result.data?.secfaAttempts) }),
      );
      return false;
    }
    return true;
  };

  const retrieveTransaction = async ({
    transactionId,
    transactionSecureChannelMessage,
    encryptedTransactionObject,
  }) => {
    transactionIdRef.current = transactionId;
    dispatch(updateSoftTokenTransactionObject({ transactionId }));
    const retrievalResult = await SoftTokenSigner.retrieveDeviceBindingEssentials(
      transactionSecureChannelMessage,
      androidFingerprintType, //IOS to declare same parameter format without using this variable
    );
    const { status } = retrievalResult || {};
    if (status !== 'S') return retrievalResult;

    const { password, salt, iv, txnHash, refKey } = JSON.parse(retrievalResult?.data.jsonString);
    const secretKey = utils.genSecretKey(password, salt);
    const transactionStr = utils.decrypt(encryptedTransactionObject, secretKey, iv);
    const hashedTransactionStr = utils.getSHA512hash(transactionStr);
    if (
      hashedTransactionStr === txnHash.toUpperCase() &&
      utils.getNumbersFromHash(hashedTransactionStr).substr(0, 8) === refKey.toUpperCase()
    ) {
      //Valid match
      return { status, transactionStr };
    }
    return { status: 'F' };
  };

  const getSecureStorage = async () => {
    return await SoftTokenSigner.getSecureStorage(androidFingerprintType);
  };

  const removeSecureStorage = async () => {
    await SoftTokenSigner.removeSecureStorage();
  };

  return { init, sign, submit, retrieveTransaction, getSecureStorage, removeSecureStorage };
};

export default useSoftTokenSigner;
