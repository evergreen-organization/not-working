import { useRef } from 'react';
import { useApi } from 'hooks';
import { NativeModules } from 'react-native';
import { getDeviceName } from 'react-native-device-info';
import {
  activateTokenInstance,
  generateTokenInstance,
  generateTokenLicense,
  getDemo,
  getSoftTokenAndroidFingerprintType,
} from 'stores';
import useDeviceUniqueID from './useDeviceUniqueID';
import { useSoftTokenUtils } from './useSoftTokenUtils';
import { ANDROID_SOFT_TOKEN_FINGERPRINT_TYPE, SOFT_TOKEN_ACTIVATION_STATUS } from 'constant';
import { useSelector } from 'react-redux';

const specialCharactersRegex = /[^0-9A-Za-z ]/g;

let deviceName = '';

getDeviceName().then(val => {
  const name = val?.replace(specialCharactersRegex, '');
  deviceName = name ? name : 'n/a';
});

const { SoftTokenModule } = NativeModules;

/*eslint no-unsafe-optional-chaining: 0 */

export const useSoftTokenActivation = () => {
  const isDemo = useSelector(getDemo);
  const utils = useSoftTokenUtils();
  const deviceUniqueIDUtils = useDeviceUniqueID();

  const androidFingerprintType = useSelector(getSoftTokenAndroidFingerprintType);
  const generateTokenLicenseApi = useApi(generateTokenLicense);
  const generateTokenInstanceApi = useApi(generateTokenInstance);
  const activateTokenInstanceApi = useApi(activateTokenInstance);

  const valueRefs = useRef({
    userIdentifier: null,
    clientSessionKey: null,
    updatedAndroidFingerprintType: null,
    quickLimit: null,
  });

  const activate = async ({ id, activationPassword, quickLimit, salt, serverEphemeralPublicKey }) => {
    if (isDemo) {
      return {
        status: true,
        softTokenActivationStatus: SOFT_TOKEN_ACTIVATION_STATUS.ACTIVE,
        processedTime: null,
        updatedAndroidFingerprintType: ANDROID_SOFT_TOKEN_FINGERPRINT_TYPE.HARDWARE,
      };
    }

    valueRefs.current.userIdentifier = utils.getUserIdentifier(id);
    valueRefs.current.quickLimit = quickLimit;

    const clientEphemeralKey = await SoftTokenModule.generateSRPClientEphemeralKey();
    if (clientEphemeralKey?.status !== 'S') return fail('F01', clientEphemeralKey);

    const { clientEphemeralPrivateKey, clientEphemeralPublicKey } = clientEphemeralKey?.data;

    const sessionKey = await SoftTokenModule.generateSRPSessionKey(
      clientEphemeralPublicKey,
      clientEphemeralPrivateKey,
      serverEphemeralPublicKey,
      valueRefs.current.userIdentifier,
      activationPassword,
      salt,
    );
    if (sessionKey?.status !== 'S') return fail('F02', sessionKey);

    const { clientSessionKey, clientEvidenceMessage } = sessionKey?.data;
    valueRefs.current.clientSessionKey = clientSessionKey;
    //Step 2
    const result2 = await generateTokenLicenseApi.request({ clientEphemeralPublicKey, clientEvidenceMessage });
    if (result2.problem) return fail('B02', result2);
    const { encryptedMultiDeviceLicenseActivationMessage, serverEvidenceMessage, mac, encryptionCounter } = result2;

    const verifyServerEvidenceResult = await SoftTokenModule.verifySRPServerEvidenceMessage(
      clientEphemeralPublicKey,
      clientEvidenceMessage,
      serverEvidenceMessage,
      clientSessionKey,
    );
    if (verifyServerEvidenceResult?.status !== 'S') return fail('F03', verifyServerEvidenceResult);

    const decryptSRPDataResult = await SoftTokenModule.decryptSRPData(
      clientSessionKey,
      encryptedMultiDeviceLicenseActivationMessage,
      encryptionCounter,
      mac,
    );
    if (decryptSRPDataResult?.status !== 'S') return fail('F04', decryptSRPDataResult);

    const { multiDeviceLicenseActivationMessage } = decryptSRPDataResult?.data;

    const parseSecureChannelMessageResult = await SoftTokenModule.parseSecureChannelMessage(
      multiDeviceLicenseActivationMessage,
      androidFingerprintType, //IOS to declare same parameter format without using this variable
    );
    if (parseSecureChannelMessageResult?.status !== 'S') return fail('F05', parseSecureChannelMessageResult);

    const { deviceCode, updatedAndroidFingerprintType } = parseSecureChannelMessageResult?.data;
    valueRefs.current.updatedAndroidFingerprintType = updatedAndroidFingerprintType;

    //Step 3
    const result3 = await generateTokenInstanceApi.request({ deviceCode, deviceName });
    if (result3.problem) return fail('B03', result3);
    if (result3.challengeQuestion) return { status: true, challengeQuestion: true };

    return resumeActivationAfterCQ(result3);
  };

  const resumeActivationAfterCQ = async result3 => {
    const { instanceActivationMessage, randomPasswordDerivator, serverUTCTime } = result3;
    const encrypt_rp_iv = utils.getRandomString(16);
    const updatedAndroidFingerprintType = valueRefs.current.updatedAndroidFingerprintType;

    const parseSecureChannelMessage2Result = await SoftTokenModule.parseSecureChannelMessage2(
      instanceActivationMessage,
      randomPasswordDerivator,
      serverUTCTime.toString(),
      encrypt_rp_iv,
      updatedAndroidFingerprintType, //IOS to declare same parameter format without using this variable
    );
    if (parseSecureChannelMessage2Result?.status !== 'S') return fail('F06', parseSecureChannelMessage2Result);

    const { sequenceNumber, signature } = parseSecureChannelMessage2Result?.data;

    //Step 4
    const uniqueDeviceId = await deviceUniqueIDUtils.get(updatedAndroidFingerprintType);
    const result4 = await activateTokenInstanceApi.request({
      sequenceNumber,
      signature,
      quickLimit: valueRefs.current.quickLimit,
      uniqueDeviceId,
    });
    if (result4.problem) return fail('B04', result4);

    const {
      mac: SRPMAC,
      softTokenActivationStatus,
      processedTime,
      coolingOffHour,
      cqActivationStatus,
      unfinishedEvent,
    } = result4;

    const verifySRPMACResult = await SoftTokenModule.verifySRPMAC(
      SRPMAC,
      valueRefs.current.clientSessionKey,
      valueRefs.current.userIdentifier,
    );
    if (verifySRPMACResult?.status !== 'S') return fail('F07', verifySRPMACResult);

    return {
      status: true,
      softTokenActivationStatus,
      processedTime,
      coolingOffHour,
      cqActivationStatus,
      unfinishedEvent,
      updatedAndroidFingerprintType,
    };
  };

  const fail = (mainErrorCode, result) => {
    if (!result) return { status: false, msg: mainErrorCode };

    const { status, errorCode, problem } = result || {};
    const errorMessage = errorCode ?? problem ?? '0';
    const msg = `${mainErrorCode} | ${status} | ${errorMessage}`;

    return { status: false, msg };
  };

  return {
    activate,
    resumeActivationAfterCQ,
  };
};

export default useSoftTokenActivation;
