//
//  SoftTokenSigner.h
//  pbOne
//
//  Created by administrator on 24/11/2021.
//

#import <React/RCTBridgeModule.h>

@interface RCT_EXTERN_MODULE(SoftTokenSigner, NSObject)

RCT_EXTERN_METHOD(retrieveDeviceBindingEssentials :
                  (NSString *)transactionSecureChannelMessage
                  fingerprintType: (NSString *)fingerprintType
                  resolver: (RCTPromiseResolveBlock)resolve
                  rejecter: (RCTPromiseRejectBlock)reject )
RCT_EXTERN_METHOD(signTransaction :
                  (NSString *)randomPasswordDerivatorFromResponse
                  serverUTCTime: (NSString *)serverUTCTime
                  fingerprintType: (NSString *)fingerprintType
                  resolver: (RCTPromiseResolveBlock)resolve
                  rejecter: (RCTPromiseRejectBlock)reject )
RCT_EXTERN_METHOD(getSecureStorage :
                  (NSString *)fingerprintType
                  resolver: (RCTPromiseResolveBlock)resolve
                  rejecter: (RCTPromiseRejectBlock)reject )
RCT_EXTERN_METHOD(removeSecureStorage)
@end
