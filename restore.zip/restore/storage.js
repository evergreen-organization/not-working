import { createMMKV } from 'react-native-mmkv';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Keychain from 'react-native-keychain';
import { getRandomString } from './bodyEncryption';
import { EXISTING_AUTH_STORAGE_KEY_CONFIG } from '../auth/authStorageMigration';
import SInfo from 'react-native-sensitive-info';
import { logAttestationError } from '../attestation/utils';

export const MMKV_KEY = 'mypbMMKV';

const getOrCreateEncryptionKey = async () => {
  try {
    const existing = await Keychain.getGenericPassword({ service: MMKV_KEY });
    if (existing) return existing.password;
    return createEncryptionKey();
  } catch (error) {
    logAttestationError(error)
  }
};

const createEncryptionKey = async () => {
  try {
    const randomKey = getRandomString(10);
    await Keychain.setGenericPassword('mmkv', randomKey, {
      service: MMKV_KEY,
    });
    return randomKey;
  } catch (error) {
    return null;
  }
};

export let mmkvStorage = null;

export const initializeStorage = async () => {
  const encryptionKey = await getOrCreateEncryptionKey();
  if (!encryptionKey) return false;
  mmkvStorage = createMMKV({
    id: 'secure-storage',
    encryptionKey,
  });
  return true;
};

export const getReduxMMKVStorage = async () => {
  if (!mmkvStorage) return false;

  return {
    setItem: (key, value) => {
      mmkvStorage.set(key, value); // value must be string
      return Promise.resolve();
    },
    getItem: key => {
      const value = mmkvStorage.getString(key); // value returned as string
      return Promise.resolve(value ?? null);
    },
    removeItem: key => {
      mmkvStorage.remove(key);
      return Promise.resolve();
    },
  };
};

export const hasMigratedFromAsyncStorage = async () => {
  if (!mmkvStorage)
    return {
      error: true,
    };

  return { result: mmkvStorage.getBoolean('hasMigratedFromAsyncStorage') };
};

export const hasMigratedFromSensitiveInfo = async () => {
  if (!mmkvStorage)
    return {
      error: true,
    };

  return { result: mmkvStorage.getBoolean('hasMigratedFromSensitiveInfo') };
};

export async function migrateFromAsyncStorage() {
  const hasMigrated = await hasMigratedFromAsyncStorage();

  if (hasMigrated?.error) return false;

  if (hasMigrated?.result) return true;

  try {
    const keys = await AsyncStorage.getAllKeys();
    for (const key of keys) {
      const value = await AsyncStorage.getItem(key);

      if (value) {
        mmkvStorage.set(key, value);
      }
    }
    await AsyncStorage.multiRemove(keys);
    mmkvStorage.set('hasMigratedFromAsyncStorage', true);
    return true;
  } catch (e) {
    return false;
  }
}

export const migrateSensitiveInfoToMMKV = async () => {
  const hasMigrated = await hasMigratedFromSensitiveInfo();

  if (hasMigrated?.error) return false;
  if (hasMigrated?.result) return true;
  try {
    for (const key of Object.keys(EXISTING_AUTH_STORAGE_KEY_CONFIG)) {
      const value = await SInfo.getItem(key, {
        sharedPreferencesName: EXISTING_AUTH_STORAGE_KEY_CONFIG[key]?.sharedPreferencesName,
        keychainService: EXISTING_AUTH_STORAGE_KEY_CONFIG[key]?.keychainService,
      });

      if (value) {
        mmkvStorage.set(key, value);
        await SInfo.deleteItem(key, {
          sharedPreferencesName: EXISTING_AUTH_STORAGE_KEY_CONFIG[key]?.sharedPreferencesName,
          keychainService: EXISTING_AUTH_STORAGE_KEY_CONFIG[key]?.keychainService,
        });
      }
    }
    mmkvStorage.set('hasMigratedFromSensitiveInfo', true);
    return true;
  } catch (error) {
    return false;
  }
};
