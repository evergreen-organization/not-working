import { useDispatch, useSelector } from 'react-redux';
import routes from 'navigations/routes';
import { getUser, reInitialize, unBindLocalDevice, unbound } from 'stores';
import { checkIsDeviceInfoUpdated, showFailure, useDeviceInfo } from 'utils';
import { AppMessage, useAuthUtil } from 'screens';
import { AUTH_TYPE, useAuthentication } from './authentication';
import { useCheckCloneDevice } from 'softToken';
import { CLONE_DEVICE_ERROR } from '../constant';
import Toast from 'react-native-toast-message';

export const usePostLogin = ({ navigation }) => {
  const dispatch = useDispatch();
  const store_user = useSelector(getUser);
  const { deviceId, encryptedId } = useSelector(getUser) || {};

  const deviceInfo = useDeviceInfo();
  const authUtils = useAuthUtil();
  const authHook = useAuthentication({ flow: AUTH_TYPE.POST_LOGIN });
  const { getUniqueDeviceId } = useCheckCloneDevice();

  const load = async postLoginToken => {
    dispatch(reInitialize(false)); //Clear data loaded after logout because API may respond late

    let request = {
      deviceId,
      encryptedId,
      postLoginToken,
    };

    if (checkIsDeviceInfoUpdated({ store_user, deviceInfo })) request = { ...request, ...deviceInfo };

    // Check for clone device and add uniqueDeviceId if needed
    const uniqueDeviceId = await getUniqueDeviceId();
    if (uniqueDeviceId) {
      request = { ...request, uniqueDeviceId };
    }

    const result = await authHook.submitPin(request);

    if (result.status === CLONE_DEVICE_ERROR) {
      forceUnbindLocal();
      return false;
    }

    if (result.status === 'E00007' || result.status === CLONE_DEVICE_ERROR) {
      forceUnbind(result.problem);
      return false;
    }

    const response = authHook.handlePinResponse(result, navigation);

    if (response.error) return false;

    authUtils.storeLoginKey({ result });

    return true;
  };

  const forceUnbind = problem => {
    showFailure(problem);
    dispatch(unbound());
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.LOGIN_PBE_OLD);
  };

  const forceUnbindLocal = () => {
    Toast.show({
      type: AppMessage.variants.cloneDevice,
      autoHide: false,
      swipeable: false,
      topOffset: 0,
    });
    dispatch(unBindLocalDevice());
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.LOGIN_PBE_OLD);
  };

  return { load };
};

export default usePostLogin;
