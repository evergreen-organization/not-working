//
//  SoftTokenSigner.swift
//  pbOne
//
//  Created by administrator on 23/11/2021.
//

import Foundation
import MSSDSAPPClient
import MSSDigipass
import MSSSecureStorage

@objc (SoftTokenSigner)
class SoftTokenSigner : NSObject {
  private var parsedTxnSCM: SecureChannelMessage?
  @objc
  static func requiresMainQueueSetup() -> Bool {
    return false
  }

  @objc
  func retrieveDeviceBindingEssentials(
    _ transactionSecureChannelMessage: String,
    fingerprintType: String,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock) {
      var storage: SecureStorageSDK?
      var secureStorageSize: Int?

      do {
        let storageSalt = try SoftTokenUtils.getStorageSalt()
        let storageFingerprint = try SoftTokenUtils.getDeviceFingerprint(storageSalt!)

        storage = try SecureStorageSDK(fileName: Constants.Storage.V_STORAGE, fingerprint: storageFingerprint)
        secureStorageSize = storage?.count()

        let staticVector = try storage?.getData(key: Constants.Storage.V_KEY_SV_STORAGE)
        let dynamicVector = try storage?.getData(key: Constants.Storage.V_KEY_DV_STORAGE)

        let digipassSalt = try SoftTokenUtils.getDigipassSalt()
        let digipassFingerprint = try SoftTokenUtils.getDeviceFingerprint(digipassSalt!)

        let secureChannelParseResponse = try DigipassSDK.parseSecureChannelMessage(transactionSecureChannelMessage)

        parsedTxnSCM = secureChannelParseResponse
        let secureChannelDecryptionResponse = try DigipassSDK.decryptBody(
          ofSecureChannelMessage: secureChannelParseResponse,
          staticVector: staticVector!,
          dynamicVector: dynamicVector!,
          platformFingerprint: digipassFingerprint)

        let decodedSigningPayload = secureChannelDecryptionResponse.response?.convertHexToData(using: .hexadecimal)

        return resolve([
          "status": "S",
          "data": ["jsonString": String(decoding: decodedSigningPayload!, as: UTF8.self)],
        ])
      } catch let error as DigipassSDKError {
        resolve([
          "status": String(error.errorCode),
          "errorCode": "S1001",
          "errorMessage": error.errorDescription ?? ""
        ])
      } catch let error as WBCError {
        resolve([
          "status": String(error.errorCode),
          "errorCode": "S1002",
          "errorMessage": error.errorDescription ?? ""
        ])
      }catch let error as SecureStorageError {
//        let signingUnavailable = secureStorageSize != 0
        resolve([
          "status": String(error.errorCode),
          "errorCode": "S1003",
          "signingUnavailable": true,
          "secureStorageEmpty": secureStorageSize == 0,
          "errorMessage": error.errorDescription ?? ""
        ])
      }catch let error {
        resolve([
          "status": "S1004",
          "errorCode": "S1004",
          "errorMessage": error.localizedDescription
        ])
      }
    }

  @objc
  func signTransaction(
    _ randomPasswordDerivatorFromResponse: String,
    serverUTCTime: String,
    fingerprintType: String,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock) {
      var storage: SecureStorageSDK?
      var rpStorage: SecureStorageSDK?
      var secureStorageSize: Int?


      do {
        let storageSalt = try SoftTokenUtils.getStorageSalt()
        let storageFingerprint = try SoftTokenUtils.getDeviceFingerprint(storageSalt!)

        storage = try SecureStorageSDK(fileName: Constants.Storage.V_STORAGE, fingerprint: storageFingerprint)
        secureStorageSize = storage?.count()

        let deviceFingerprintRP = try SoftTokenUtils.getDeviceFingerprint(SoftTokenUtils.getStorageRPSalt(storageRPSalt: randomPasswordDerivatorFromResponse, storageRPIv: Constants.RPStorage.RP_IV)!)

        rpStorage = try SoftTokenUtils.getRPStorage(deviceFingerprintRP)

        let encryptedRandomPassword = try rpStorage?.getData(key: Constants.RPStorage.RP_KEY_ENC_RP)
        let encryptedRpIV = try rpStorage?.getData(key: Constants.RPStorage.RP_KEY_ENC_IV)
        let randomPassword = try SoftTokenUtils.wbcDecrypt(encryptedRandomPassword!, iv: encryptedRpIV!)
        let deviceFingerprintDigipass = try SoftTokenUtils.getDeviceFingerprint(SoftTokenUtils.getDigipassSalt()!)
        let staticVectorForSignature = try storage?.getData(key: Constants.Storage.V_KEY_SV_STORAGE)
        let dynamicVectorForSignature = try storage?.getData(key: Constants.Storage.V_KEY_DV_STORAGE)
        let clientServerTimeShift = DigipassSDK.computeClientServerTimeShift(fromServerTime: Int(serverUTCTime)!)
        let generationResponse = try DigipassSDK.generateSignature(
          fromSecureChannelMessage: parsedTxnSCM!,
          staticVector: staticVectorForSignature!,
          dynamicVector: dynamicVectorForSignature!,
          encryptionKey: randomPassword!,
          clientServerTimeShift: clientServerTimeShift,
          cryptoApplicationIndex: .app5,
          platformFingerprint: deviceFingerprintDigipass
        )

        try storage?.put(data: generationResponse.dynamicVector!, key: Constants.Storage.V_KEY_DV_STORAGE)
        try storage?.write(fingerPrint: storageFingerprint)

        return resolve([
          "status": "S",
          "data": [
            "secureChannelMessageSignature": generationResponse.response
          ],
        ])
      }
      catch let error as WBCError {
        resolve([
          "status": String(error.errorCode),
          "errorCode": "S1101",
          "errorMessage": error.errorDescription ?? ""
        ])
      }catch let error as SecureStorageError {
//        let signingUnavailable = secureStorageSize != 0
        resolve([
          "status": String(error.errorCode),
          "errorCode": "S1102",
          "signingUnavailable": true,
          "secureStorageEmpty": secureStorageSize == 0,
          "errorMessage": error.errorDescription ?? ""
        ])
      } catch {
        resolve([
          "status": "S1103",
          "errorCode": "S1103",
          "errorMessage": error.localizedDescription
        ])
      }
    }
  
  
  @objc
  func getSecureStorage(
    _ fingerprintType: String,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock) {
      var errorCode = "GS01"
      var storage: SecureStorageSDK?
      var secureStorageSize: Int?


      do {
        let storageSalt = try SoftTokenUtils.getStorageSalt()
        let storageFingerprint = try SoftTokenUtils.getDeviceFingerprint(storageSalt!)

        storage = try SecureStorageSDK(fileName: Constants.Storage.V_STORAGE, fingerprint: storageFingerprint)
        secureStorageSize = storage?.count()

        resolve([
          "status": "S",
          "data": [
            "secureStorageSize": secureStorageSize,
          ],
        ])
        
      }     catch let error as SecureStorageError {
        resolve([
          "status": String(error.errorCode),
          "errorCode": "GS02",
          "errorMessage": error.errorDescription ?? ""
        ])
      }
      catch let error as WBCError {
        resolve([
          "status": String(error.errorCode),
          "errorCode": "GS03",
          "errorMessage": error.errorDescription ?? ""
        ])}
      catch let error as DigipassSDKError {
        resolve([
          "status": String(error.errorCode),
          "errorCode": "GS04",
          "errorMessage": error.errorDescription ?? ""
        ])
      }
      catch let error {
        resolve([
          "status": "GS05",
          "errorCode": "GS05",
          "errorMessage": error.localizedDescription
        ])
      }
    }
  
  @objc
  func removeSecureStorage(){
    do{
      try SoftTokenUtils.removeStorage(Constants.RPStorage.TO_REMOVE_RP)
      try SoftTokenUtils.removeStorage(Constants.Storage.TO_REMOVE_V)
    }catch{
      print("error")
    }
  }

}
