import { utc8DateTime } from 'utils';

export const accountSummary = {
  casa: [
    {
      type: 'sa',
      accNo: '3300330088',
      availableBal: 12356,
      currentBal: 12366,
      debitCardNo: '5723345388990012',
    },
    {
      type: 'sa',
      accNo: '3300330055',
      availableBal: 1328,
      currentBal: 1338,
      debitCardNo: '',
    },
    {
      type: 'ca',
      accNo: '1122123777',
      availableBal: 24880,
      currentBal: 24890,
      debitCardNo: '',
    },
  ],
  card: [
    {
      accountStatus: true,
      accountType: 'V',
      accountDesc: 'Visa Gold',
      accountNo: '1234123412341234',
      outstandingBalance: 1853,
      currency: 'RM',
    },
    {
      accountStatus: true,
      accountType: 'M',
      accountDesc: 'Mastercard Gold',
      accountNo: '1234123412341234',
      outstandingBalance: 1853,
      currency: 'RM',
    },
  ],
  deposit: [
    {
      type: 'fd',
      name: 'Fixed',
      accNo: '1001008888',
      availableBal: 30000,
      currentBal: 30000,
    },
    {
      type: 'fdi',
      name: 'Islamic Term',
      accNo: '2002008888',
      availableBal: 10000,
      currentBal: 10000,
    },
  ],
  invest: [
    {
      type: 'gold',
      name: 'Gold',
      accNo: '567283111',
      bal: 39,
    },
  ],
  loan: [
    {
      type: 'house',
      accNo: '5789237111',
      bal: 298888,
    },
    {
      type: 'car',
      accNo: '3399339900',
      bal: 85000,
    },
  ],
  fund: [
    {
      type: '1',
      name: 'Cash Scheme',
      bal: 10231,
    },
    {
      type: '2',
      name: 'EPF Scheme',
      bal: 1002,
    },
  ],
};

export const WEBSEAL_TIMEOUT = 'W00001';
export const SERVER_UNAVAILABLE = 'E00011';
export const NETWORK_UNAVAILABLE = 'E00098';
export const ACCESS_DENIED = 'E00154';
export const TRANSACTION_ACTIVITY_DECLINED_NON_FINANCIAL = 'E00028';
export const TRANSACTION_ACTIVITY_DECLINED_FINANCIAL = 'E00241';
export const TRANSACTION_ACTIVITY_DECLINED_VERY_HIGH_RISK_FINANCIAL = 'L00017';
export const TRANSACTION_ACTIVITY_DECLINED_VERY_HIGH_RISK_NON_FINANCIAL = 'L00018';
export const ERROR_UUID_DUPLICATED = 'E00237';
export const AAOP_LOCKED = 'L00007';
export const ERROR_PUBLIC_KEY_ATTESTATION_EXIST = 'E00247';
export const ERROR_ATTESTATION_NOT_ENROLLED = 'E00248';
export const ERROR_ATTESTATION_VERIFICATION_FAILED = 'E00249';
export const CONNECTION_TIMEOUT = 'CONNECTION_TIMEOUT';
export const CONNECTION_TIMEOUT_STR = 'Connection Timeout';
export const CONNECTION_TIMEOUT_MSG = 'constant.text.connectionTimeout';
export const FORBIDDEN_REQUEST = 403;
export const HOST_ERROR = 'EHOST';
export const max_length_amount = 10;
export const CLONE_DEVICE_ERROR = 'E00246';

export const showEAnggpow = utc8DateTime().isBetween('2024-04-10', '2024-04-29');
