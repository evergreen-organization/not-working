package com.pbb.mypb.softtoken;

import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.Context;
import android.os.Build;
import android.util.Base64;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.BadPaddingException;
import javax.crypto.NoSuchPaddingException;

import com.google.android.gms.common.util.Hex;

import com.vasco.digipass.sdk.utils.devicebinding.DeviceBindingSDKErrorCodes;
import com.vasco.dsapp.client.DSAPPClient;
import com.vasco.dsapp.client.exceptions.DSAPPException;
import com.vasco.dsapp.client.responses.SRPClientEphemeralKeyResponse;
import com.vasco.dsapp.client.responses.SRPSessionKeyResponse;

import com.vasco.digipass.sdk.DigipassSDK;
import com.vasco.digipass.sdk.DigipassSDKConstants;
import com.vasco.digipass.sdk.DigipassSDKReturnCodes;
import com.vasco.digipass.sdk.responses.ActivationResponse;
import com.vasco.digipass.sdk.responses.DigipassPropertiesResponse;
import com.vasco.digipass.sdk.responses.GenerationResponse;
import com.vasco.digipass.sdk.responses.SecureChannelParseResponse;
import com.vasco.digipass.sdk.responses.MultiDeviceLicenseActivationResponse;
import com.vasco.digipass.sdk.utils.wbc.WBCSDK;
import com.vasco.digipass.sdk.utils.wbc.WBCSDKConstants;
import com.vasco.digipass.sdk.utils.wbc.WBCSDKException;
import com.vasco.digipass.sdk.utils.wbc.WBCSDKTables;
import com.vasco.digipass.sdk.utils.securestorage.SecureStorageSDK;
import com.vasco.digipass.sdk.utils.securestorage.SecureStorageSDKException;
import com.vasco.digipass.sdk.utils.devicebinding.DeviceBindingSDKException;
import com.vasco.digipass.sdk.responses.ActivationResponse;
import com.vasco.digipass.sdk.responses.SecureChannelDecryptionResponse;
import com.vasco.digipass.sdk.responses.SecureChannelParseResponse;
import com.vasco.digipass.sdk.responses.MultiDeviceLicenseActivationResponse;
import com.vasco.digipass.sdk.models.SecureChannelMessage;

import static com.vasco.digipass.sdk.DigipassSDK.decryptSecureChannelMessageBody;
import static com.vasco.digipass.sdk.DigipassSDK.parseSecureChannelMessage;
import static com.vasco.digipass.sdk.DigipassSDK.generateSignatureFromSecureChannelMessageWithKey;

import com.pbb.mypb.softtoken.wbc.WBCSDKTablesImpl;

public class SoftTokenSigner extends ReactContextBaseJavaModule {
  private final ReactApplicationContext reactContext;
  private SecureChannelMessage parsedTxnSCM;

  public SoftTokenSigner(final ReactApplicationContext reactContext, boolean loadConstantsAsynchronously) {
    super(reactContext);
    this.reactContext = reactContext;
  }


  @ReactMethod
  private void retrieveDeviceBindingEssentials(String transactionSecureChannelMessage, final String fingerprintType,
      final Promise promise) {

    int storageSize= 0;
    try {
      String deviceFingerprintStorage = SoftTokenUtils.getDeviceFingerprintForSigning(
          SoftTokenUtils.getStorageSalt(),
          fingerprintType,
          reactContext);

      SecureStorageSDK storage  = SecureStorageSDK.init(SoftTokenUtils.V_STORAGE, deviceFingerprintStorage,
          SoftTokenUtils.ITERATION_COUNTER, reactContext);

      storageSize = storage.size();
      byte[] staticVector = storage.getBytes(SoftTokenUtils.V_KEY_SV_STORAGE);
      byte[] dynamicVector = storage.getBytes(SoftTokenUtils.V_KEY_DV_STORAGE);

      String deviceFingerprintDigipass = SoftTokenUtils.getDeviceFingerprintForSigning(
          SoftTokenUtils.getDigipassSalt(),
          fingerprintType,
          reactContext);
      SecureChannelParseResponse secureChannelParseResponse = parseSecureChannelMessage(
          transactionSecureChannelMessage);

      if (secureChannelParseResponse.getReturnCode() != DigipassSDKReturnCodes.SUCCESS) {
        WritableMap response = Arguments.createMap();
        response.putString("status", String.valueOf(secureChannelParseResponse.getReturnCode()));
        response.putString("errorCode", "S1001");
        response.putString("errorMessage", "Failed to parse secure channel message.");
        promise.resolve(response);
        return;
      }

      parsedTxnSCM = secureChannelParseResponse.getMessage();
      SecureChannelDecryptionResponse secureChannelDecryptionResponse = decryptSecureChannelMessageBody(staticVector,
          dynamicVector, parsedTxnSCM, deviceFingerprintDigipass);

      if (secureChannelDecryptionResponse.getReturnCode() != DigipassSDKReturnCodes.SUCCESS) {
        WritableMap response = Arguments.createMap();
        response.putString("status", String.valueOf(secureChannelDecryptionResponse.getReturnCode()));
        response.putString("errorCode", "S1002");
        response.putString("errorMessage", "Failed to decrypt secure channel message.");
        promise.resolve(response);
        return;
      }

      String hexSigningPayload = secureChannelDecryptionResponse.getMessageBody();

      byte[] hexSigningPayloadInBytes = Hex.stringToBytes(hexSigningPayload);
      String decodedSigningPayload = new String(hexSigningPayloadInBytes, StandardCharsets.UTF_8);

      WritableMap data = Arguments.createMap();
      data.putString("jsonString", decodedSigningPayload);

      WritableMap response = Arguments.createMap();
      response.putString("status", "S");
      response.putMap("data", data);
      promise.resolve(response);
    } catch (SecureStorageSDKException e) {
      WritableMap response = Arguments.createMap();
      response.putString("status", String.valueOf(e.getErrorCode()));
      response.putString("errorCode", "S1003");
      response.putString("errorMessage", e.getMessage());
      response.putBoolean("signingUnavailable", true);
      response.putBoolean("secureStorageEmpty", storageSize == 0);
      promise.resolve(response);
    } catch (WBCSDKException e) {
      WritableMap response = Arguments.createMap();
      response.putString("status", String.valueOf(e.getErrorCode()));
      response.putString("errorCode", "S1004");
      response.putString("errorMessage", e.getMessage());
      promise.resolve(response);
    } catch (DeviceBindingSDKException e) {
      WritableMap response = Arguments.createMap();
      response.putString("status", String.valueOf(e.getErrorCode()));
      response.putString("errorCode", "S1005");
      response.putString("errorMessage", e.getMessage());
      response.putBoolean("signingUnavailable", e.getErrorCode() == DeviceBindingSDKErrorCodes.STRONGBOX_UNAVAILABLE
          || e.getErrorCode() == DeviceBindingSDKErrorCodes.INTERNAL_ERROR);
      promise.resolve(response);
    }
  }

  @ReactMethod
  private void signTransaction(String randomPasswordDerivatorFromResponse, String serverUTCTime,
      final String fingerprintType,
      final Promise promise){

    int storageSize= 0;

    try {
      String deviceFingerprintStorage = SoftTokenUtils.getDeviceFingerprintForSigning(
          SoftTokenUtils.getStorageSalt(),
          fingerprintType,
          reactContext);
      SecureStorageSDK storage = SecureStorageSDK.init(SoftTokenUtils.V_STORAGE, deviceFingerprintStorage,
          SoftTokenUtils.ITERATION_COUNTER, reactContext);

      storageSize = storage.size();

      // initialize randomPassword storage
      String deviceFingerprintRP = SoftTokenUtils.getDeviceFingerprintForSigning(
          SoftTokenUtils.getStorageRPSalt(randomPasswordDerivatorFromResponse,
              SoftTokenUtils.class_getRandomPasswordIV()),
          fingerprintType,
          reactContext);

      SecureStorageSDK rpStorage = SecureStorageSDK.init(
          SoftTokenUtils.RP_STORAGE,
          deviceFingerprintRP,
          SoftTokenUtils.ITERATION_COUNTER,
          reactContext);

      // get randomPassword
      byte[] encryptedRandomPassword = rpStorage.getBytes(SoftTokenUtils.RP_KEY_ENC_RP);
      byte[] encryptedRpIv = rpStorage.getBytes(SoftTokenUtils.RP_KEY_ENC_IV);
      byte[] randomPassword = SoftTokenUtils.wbcDecrypt(encryptedRandomPassword, encryptedRpIv);
      String deviceFingerprintDigipass = SoftTokenUtils.getDeviceFingerprintForSigning(
          SoftTokenUtils.getDigipassSalt(),
          fingerprintType,
          reactContext);
      String randomPasswordInString = new String(randomPassword, StandardCharsets.UTF_8);
      byte[] staticVectorForSignature = storage.getBytes(SoftTokenUtils.V_KEY_SV_STORAGE);
      byte[] dynamicVectorForSignature = storage.getBytes(SoftTokenUtils.V_KEY_DV_STORAGE);
      long clientServerTimeShift = DigipassSDK
          .computeClientServerTimeShiftFromServerTime(Long.parseLong(serverUTCTime));
      GenerationResponse generationResponse = generateSignatureFromSecureChannelMessageWithKey(staticVectorForSignature,
          dynamicVectorForSignature, parsedTxnSCM, randomPassword, clientServerTimeShift,
          DigipassSDKConstants.CRYPTO_APPLICATION_INDEX_APP_5, deviceFingerprintDigipass);

      storage.putBytes(SoftTokenUtils.V_KEY_DV_STORAGE, generationResponse.getDynamicVector());
      storage.write(deviceFingerprintStorage, SoftTokenUtils.ITERATION_COUNTER, reactContext);

      staticVectorForSignature = null;
      dynamicVectorForSignature = null;

      if (generationResponse.getReturnCode() != DigipassSDKReturnCodes.SUCCESS) {
        WritableMap response = Arguments.createMap();
        response.putString("status", String.valueOf(generationResponse.getReturnCode()));
        response.putString("errorCode", "S1101");
        response.putString("errorMessage", "Failed to generate signature from secure channel.");
        promise.resolve(response);
        return;
      }

     WritableMap data = Arguments.createMap();
     data.putString("secureChannelMessageSignature", generationResponse.getResponse());

     WritableMap response = Arguments.createMap();
     response.putString("status", "S");
     response.putMap("data", data);
     promise.resolve(response);
    } catch (SecureStorageSDKException e) {
      WritableMap response = Arguments.createMap();
      response.putString("status", String.valueOf(e.getErrorCode()));
      response.putString("errorCode", "S1102");
      response.putString("errorMessage", e.getMessage());
      response.putBoolean("signingUnavailable", true);
      response.putBoolean("secureStorageEmpty", storageSize == 0);
      promise.resolve(response);
    } catch (WBCSDKException e) {
      WritableMap response = Arguments.createMap();
      response.putString("status", String.valueOf(e.getErrorCode()));
      response.putString("errorCode", "S1103");
      response.putString("errorMessage", e.getMessage());
      promise.resolve(response);
    } catch (DeviceBindingSDKException e) {
      WritableMap response = Arguments.createMap();
      response.putString("status", String.valueOf(e.getErrorCode()));
      response.putString("errorCode", "S1104");
      response.putString("errorMessage", e.getMessage());
      response.putBoolean("signingUnavailable", e.getErrorCode() == DeviceBindingSDKErrorCodes.STRONGBOX_UNAVAILABLE
          || e.getErrorCode() == DeviceBindingSDKErrorCodes.INTERNAL_ERROR);
      promise.resolve(response);
    }
  }


  @ReactMethod
  private void getSecureStorage(final String fingerprintType,final Promise promise) {

    int storageSize= 0;

    try {
      String deviceFingerprintStorage = SoftTokenUtils.getDeviceFingerprintForSigning(
              SoftTokenUtils.getStorageSalt(),
              fingerprintType,
              reactContext);
      SecureStorageSDK storage = SecureStorageSDK.init(SoftTokenUtils.V_STORAGE, deviceFingerprintStorage,
              SoftTokenUtils.ITERATION_COUNTER, reactContext);

      storageSize = storage.size();

      WritableMap data = Arguments.createMap();
      data.putInt("secureStorageSize", storage.size());

      WritableMap result = Arguments.createMap();
      result.putString("status", "S");
      result.putMap("data", data);
      promise.resolve(result);
    }catch (SecureStorageSDKException e) {
      WritableMap response = Arguments.createMap();
      response.putString("status", String.valueOf(e.getErrorCode()));
      response.putString("errorCode", "GS02");
      response.putString("errorMessage", e.getMessage());
      promise.resolve(response);
    }
    catch (WBCSDKException e) {
      WritableMap response = Arguments.createMap();
      response.putString("status", String.valueOf(e.getErrorCode()));
      response.putString("errorCode", "GS03");
      response.putString("errorMessage", e.getMessage());
      promise.resolve(response);
    } catch (DeviceBindingSDKException e) {
      WritableMap response = Arguments.createMap();
      response.putString("status", String.valueOf(e.getErrorCode()));
      response.putString("errorCode", "GS04");
      response.putString("errorMessage", e.getMessage());
      promise.resolve(response);
    }
  }

  @ReactMethod
  private void removeSecureStorage(){
    try {
      SoftTokenUtils.removeStorage(reactContext, SoftTokenUtils.TO_REMOVE_RP);
      SoftTokenUtils.removeStorage(reactContext, SoftTokenUtils.TO_REMOVE_V);
    } catch (SecureStorageSDKException e) {
      Log.d("SoftTokenSigner", "error");
    }
  }

  /*
   * SOFT TOKEN - key comparison functions
   */
  private String getHash(String data) throws NoSuchAlgorithmException {
    MessageDigest md = MessageDigest.getInstance("SHA-512");
    byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));
    return Hex.bytesToStringUppercase(hash);
  }

  private String retrieveNumbersFromHash(String hash) {
    String numberOnly = hash.replaceAll("[^0-9]", "");
    return numberOnly.substring(0, 8);
  }

  @Override
  public String getName() {
    return "SoftTokenSigner";
  }
}
