# Beautify SMS Log - Chrome Extension

A Chrome extension that beautifies the SMS log page and reverses the order so the latest entry appears first with special highlighting.

## Features

- 🎨 Modern, beautiful UI with gradient backgrounds
- 🔄 Reverses list order (last entry becomes first)
- ⭐ Highlights the latest entry with special styling
- 📱 Responsive design
- ✨ Smooth animations and hover effects

## Installation

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in the top right)
3. Click "Load unpacked"
4. Select the `beautify-mypb-smslog` folder
5. The extension will automatically activate on the SMS log page

## Usage

Simply navigate to:
```
http://uatvmcms001/logs/smslog.log
```

The extension will automatically:
- Reverse the order of all `<li>` elements
- Apply beautiful styling
- Highlight the latest (now first) entry

## Files

- `manifest.json` - Extension configuration
- `content.js` - Script that modifies the page
- `styles.css` - Styling for the beautified page
- `README.md` - This file

## Notes

- The extension only runs on the specified URL
- It waits for the page to load and also checks for dynamically loaded content
- If the page structure is different, you may need to adjust the selectors in `content.js`

