
const beautifiedPreTags = new WeakSet();

function beautifySMSLog() {
  const allPreTags = document.querySelectorAll('pre');
  
  allPreTags.forEach((preTag) => {
    if (beautifiedPreTags.has(preTag)) {
      return;
    }
    
    const text = preTag.textContent;
    if (!text || text.trim().length === 0) {
      return;
    }
    
    const entries = parsePreContent(text);
    
    const pacEntries = entries.filter(entry => 
      entry?.text?.toUpperCase().includes('PAC')
    );
    
    if (pacEntries.length > 0) {
      beautifyPreTag(preTag, pacEntries);
      beautifiedPreTags.add(preTag);
    }
  });
}

function parsePreContent(text) {
  const entries = [];
  
  const timestampPattern = /(\d{2}\/\d{2}\/\d{4}\s+\d{1,2}:\d{2}:\d{2}\s+(?:AM|PM)):0=>\{/g;
  
  let match;
  const timestamps = [];
  
  while ((match = timestampPattern.exec(text)) !== null) {
    timestamps.push({
      index: match.index,
      timestamp: match[1],
      fullMatch: match[0]
    });
  }
  
  for (let i = 0; i < timestamps.length; i++) {
    const startIndex = timestamps[i].index;
    const endIndex = i < timestamps.length - 1 ? timestamps[i + 1].index : text.length;
    const entryText = text.substring(startIndex, endIndex);
    
    const parsed = parseEntry(entryText, timestamps[i].timestamp);
    if (parsed) {
      entries.push(parsed);
    }
  }
  
  return entries;
}

function parseEntry(entryText, timestamp) {
  try {
    const jsonStart = entryText.indexOf('{');
    if (jsonStart === -1) return null;
    
    let jsonText = entryText.substring(jsonStart);
    
    let braceCount = 0;
    let jsonEnd = -1;
    for (let i = 0; i < jsonText.length; i++) {
      if (jsonText[i] === '{') braceCount++;
      if (jsonText[i] === '}') {
        braceCount--;
        if (braceCount === 0) {
          jsonEnd = i + 1;
          break;
        }
      }
    }
    
    if (jsonEnd === -1) return null;
    
    jsonText = jsonText.substring(0, jsonEnd);
    
    jsonText = jsonText.replace(/[""]/g, '"').replace(/['']/g, "'");
    
    let data;
    try {
      data = JSON.parse(jsonText);
    } catch (e) {
      console.debug('JSON parse failed, using manual extraction:', e.message);
      data = extractFieldsManually(jsonText);
    }
    
    let pacNumber = '';
    
    const rawPatterns = [
      /PAC[+\s]+No%3A[+\s]+(\d{6,})/i,
      /PAC[+\s]+No[:\s]+(\d{6,})/i,
      /PAC[+\s%]*No[:\s%]*(\d{6,})/i,
      /PAC\D*(\d{6,})/i
    ];
    
    for (const pattern of rawPatterns) {
      const match = entryText.match(pattern);
      if (match) {
        pacNumber = match[1];
        break;
      }
    }
    
    if (!pacNumber && data.Message) {
      let messageText = data.Message;
      
      let decodedMessage = messageText.replace(/\+/g, ' ');
      
      try {
        decodedMessage = decodeURIComponent(decodedMessage);
      } catch (e) {
        decodedMessage = decodedMessage.replace(/%0A/g, '\n').replace(/%3A/g, ':').replace(/%2F/g, '/').replace(/%2C/g, ',').replace(/%2B/g, '+');
      }
      
      const messagePatterns = [
        /PAC\s+No\s*:\s*(\d{6,})/i,
        /PAC[+\s]+No[:\s]+(\d{6,})/i,
        /PAC\D*(\d{6,})/i
      ];
      
      for (const pattern of messagePatterns) {
        const match = decodedMessage.match(pattern);
        if (match) {
          pacNumber = match[1];
          break;
        }
      }
    }
    
    const dateTime = parseTimestamp(timestamp);
    
    return {
      timestamp: timestamp,
      date: dateTime.date,
      time: dateTime.time,
      pacNumber: pacNumber,
      message: data.Message || '',
      companyID: data.CompanyID || '',
      phoneNumber: data.PhoneNumber || '',
      refNo: data.refNo || '',
      text: entryText
    };
  } catch (e) {
    console.error('Error parsing entry:', e);
    return null;
  }
}

function extractFieldsManually(text) {
  const data = {};
  
  const messagePatterns = [
    /"Message"\s*:\s*"((?:[^"\\]|\\.|[\r\n])*)"/,
    /"Message"\s*:\s*"([^"]*)"/,
    /"Message"\s*:\s*'([^']*)'/
  ];
  
  for (const pattern of messagePatterns) {
    const messageMatch = text.match(pattern);
    if (messageMatch) {
      data.Message = messageMatch[1]
        .replace(/\\"/g, '"')
        .replace(/\\n/g, '\n')
        .replace(/\\'/g, "'")
        .replace(/[\r\n]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      break;
    }
  }
  
  const companyPatterns = [
    /"CompanyID"\s*:\s*"([^"]*)"/,
    /"CompanyID"\s*:\s*'([^']*)'/
  ];
  for (const pattern of companyPatterns) {
    const companyMatch = text.match(pattern);
    if (companyMatch) {
      data.CompanyID = companyMatch[1];
      break;
    }
  }
  
  const phonePatterns = [
    /"PhoneNumber"\s*:\s*"([^"]*)"/,
    /"Phone\s*umber"\s*:\s*"([^"]*)"/,
    /"PhoneNumber"\s*:\s*'([^']*)'/
  ];
  for (const pattern of phonePatterns) {
    const phoneMatch = text.match(pattern);
    if (phoneMatch) {
      data.PhoneNumber = phoneMatch[1];
      break;
    }
  }
  
  const refNoPatterns = [
    /"refNo"\s*:\s*"([^"]*)"/,
    /"refNo"\s*:\s*'([^']*)'/
  ];
  for (const pattern of refNoPatterns) {
    const refNoMatch = text.match(pattern);
    if (refNoMatch) {
      data.refNo = refNoMatch[1];
      break;
    }
  }
  
  return data;
}

function parseTimestamp(timestampStr) {
  const match = timestampStr.match(/(\d{2})\/(\d{2})\/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})\s+(AM|PM)/);
  if (match) {
    return {
      date: `${match[3]}-${match[2]}-${match[1]}`,
      time: `${match[4]}:${match[5]}:${match[6]} ${match[7]}`
    };
  }
  return { date: '', time: timestampStr };
}

function formatLogEntry(parsed, isLatest) {
  const itemClass = isLatest ? 'sms-log-item sms-log-latest' : 'sms-log-item';
  
  return `
    <li class="${itemClass}">
      <div class="sms-log-header">
        <div class="sms-log-date-time">
          <span class="sms-log-label">${parsed.companyID || 'SMS Log'}</span>
          <span class="sms-log-date">${parsed.date} ${parsed.time}</span>
        </div>
        <span class="sms-log-level">${isLatest ? 'Latest' : 'SMS PAC'}</span>
      </div>
      <div class="sms-log-content">
        <div class="sms-log-field">
          <span class="sms-log-value sms-log-pac">${parsed.pacNumber || 'N/A'}</span>
        </div>
        ${parsed.refNo ? `<div class="sms-log-field">
          <span class="sms-log-label">Ref No</span>
          <span class="sms-log-value">${parsed.refNo}</span>
        </div>` : ''}
        ${parsed.phoneNumber ? `<div class="sms-log-field">
          <span class="sms-log-label">Phone</span>
          <span class="sms-log-value">${parsed.phoneNumber}</span>
        </div>` : ''}
      </div>
    </li>
  `;
}

function beautifyPreTag(preTag, entries) {
  if (entries.length === 0) {
    return;
  }
  
  let wrapper = preTag.parentElement;
  if (!wrapper || !wrapper.classList.contains('beautified-sms-log-wrapper')) {
    wrapper = document.createElement('div');
    wrapper.classList.add('beautified-sms-log-wrapper');
    
    const header = document.createElement('div');
    header.classList.add('beautified-sms-log-header');
    header.textContent = 'UAT SMS Log - PAC Entries';
    wrapper.appendChild(header);
    
    preTag.before(wrapper);
  }
  
  const listElement = document.createElement('ul');
  listElement.classList.add('beautified-sms-log');
  
  const reversedEntries = [...entries].reverse();
  
  reversedEntries.forEach((parsed, index) => {
    const isLatest = index === 0;
    const formattedHTML = formatLogEntry(parsed, isLatest);
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = formattedHTML;
    const newLi = tempDiv.firstElementChild;
    
    newLi.dataset.index = String(reversedEntries.length - index);
    
    listElement.appendChild(newLi);
  });
  
  wrapper.appendChild(listElement);
  
  preTag.style.display = 'none';
}

beautifySMSLog();

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', beautifySMSLog);
} else {
  beautifySMSLog();
}

const observer = new MutationObserver((mutations) => {
  let shouldCheck = false;
  
  mutations.forEach((mutation) => {
    if (mutation.addedNodes.length > 0) {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === 1) {
          if (node.tagName === 'PRE' || 
              node.tagName === 'LI' || node.tagName === 'UL' || node.tagName === 'OL' ||
              (node.querySelector && (node.querySelector('pre') || node.querySelector('li') || node.querySelector('ul') || node.querySelector('ol')))) {
            shouldCheck = true;
          }
        }
      });
    }
  });
  
  if (shouldCheck) {
    setTimeout(beautifySMSLog, 100);
  }
});

function startObserving() {
  const target = document.body || document.documentElement;
  if (target) {
    observer.observe(target, {
      childList: true,
      subtree: true
    });
  } else {
    setTimeout(startObserving, 100);
  }
}

startObserving();
