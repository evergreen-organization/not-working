# PHP 8.4.28 offline security patch: ACS / RHB / PBB

Use the package named for the environment. This is an in-place patch for the
previously delivered PHP 8.4.27 runtime on RHEL 8.10 x86_64, glibc 2.28, FIPS off.
It is not a fresh installer and does not patch Remi/system PHP or Aeon's EL7 runtime.

| Environment | Stable runtime path | Existing service |
|---|---|---|
| ACS | `/opt/acs/php-8.4.27` | `acs-php84-fpm.service` |
| RHB | `/opt/rhb/php-8.4.27` | `rhb-php84-fpm.service` |
| PBB | `/opt/pbb/php-8.4.27` | `pbb-php84-fpm.service` |

The directory name intentionally stays `php-8.4.27`. The actual CLI and FPM
versions become **8.4.28**. Existing CLI symlinks, systemd paths, boot startup and
FPM/Nginx endpoints remain valid. `BUILD_INFO.txt` is updated to record the patch.
The package replaces PHP CLI, PHP-FPM, matching mbstring/OPcache modules and build
metadata. Private dependencies, ini files, pool tuning, slow-log settings, CA
configuration, application/vendor files and Nginx configuration are retained.
GD and each profile's existing module/image-format capabilities are preserved;
the patch does not add WebP/AVIF/XPM to a build that did not already support them.
ACS retains its FPM ACL and CLI readline support. RHB/PBB retain their own profiles.
No Python, compiler, online repository, Composer or application archive is needed.

## Prerequisites

Use a maintenance window; the script stops/restarts the selected FPM service and
there is a brief request interruption. Test staging first and production nodes
one at a time. Keep application/system recovery and a deployment rollback plan.
Existing FPM must be active, enabled and reachable using its installed pool/helper
metadata. Review and drain long-running application jobs before patching. The
script does not kill unrelated CLI jobs or alter other PHP installations.

The preflight verifies hashes of the original PHP files and private ELF libraries.
A modified/custom/manual installation is refused before service changes; do not
bypass the hashes or replace the baseline manifest. Report the mismatch for a
matching build. Custom third-party extensions not supplied by the original
package also require a separately validated patch. Paths redirected by symlinks
are refused. A custom active FPM configuration path, PHP ini startup arguments
or PHP/loader environment override requires a matching preflight and is refused
before file/service changes. Use the package for the correct environment.

## Upload, check and install

Upload the environment's `.tar.gz` and `.tar.gz.sha256` together. Example for ACS:

```bash
sha256sum -c acs-php-8.4.28-rhel810-x86_64-security-patch.tar.gz.sha256
tar -xzf acs-php-8.4.28-rhel810-x86_64-security-patch.tar.gz
cd acs-php8428-security-patch
sudo bash install.sh --check
sudo bash install.sh
```

For RHB/PBB use the corresponding archive and extracted directory names. Run the
install step only after preflight passes. `--check` creates/removes a root-private
staging directory but changes no installed PHP/configuration files or services.
Checksums are validated on every entry, including rollback. Preflight checks the
compiled prefix, dependencies, configured module/GD parity and new FPM config
compatibility using staged new PHP modules. Installation preserves executable
ownership/modes/ACLs and existing SELinux file labels on a SELinux-enabled host.

The installer backs up replaced files in a private transaction directory under
`/var/lib/ENV-php84-patches`. It validates that backup before stopping FPM,
atomically replaces each file while FPM is stopped, starts FPM and probes every
configured pool over FastCGI. On startup/config/health failure it restores the
old files and attempts to restart the previous FPM. Inspect errors if it reports
an incomplete rollback. Automatic rollback is not protection against power loss;
the verified backup and system recovery remain necessary.

A repeated successful install verifies the 8.4.28 file hashes, service and pool
health, then exits without restarting. The patch retains service boot enablement;
it does not enable/disable any old service. Do not rerun the original 8.4.27 full
installer after patching; its version guard intentionally expects 8.4.27.

## Verify

ACS example (substitute the environment path/service for RHB or PBB):

```bash
/opt/acs/php-8.4.27/bin/php -v
/opt/acs/php-8.4.27/sbin/php-fpm -v
/opt/acs/php-8.4.27/bin/php --ri gd
sudo systemctl status acs-php84-fpm.service --no-pager -l
sudo systemctl is-enabled acs-php84-fpm.service
```

Expect PHP/FPM 8.4.28 and active/enabled service. Test real APIs, uploads/images,
database connections, OCR/external integrations and scheduled jobs. FastCGI ping
confirms connectivity, not business behavior. The patch does not diagnose or
promise to fix previously observed OCR HTTP 499 responses.

Shell `php -v` changes only if its command path already points to this runtime.
Another `/usr/bin/php`, Remi or manually installed old CLI remains separate.
Check `command -v php` and update explicit job paths through normal review.
Long-running CLI/queue processes keep the old executable/modules mapped until
restarted; the script reports old matching executable mappings. Review all queue
workers/cron jobs/containers and restart their owning services safely. Do not
blindly kill every PHP process. Confirm boot behavior in staging after an actual
reboot; the package retains the existing service's startup configuration.

## Rollback

Keep the exact package and the transaction path printed by installation. Example:

```bash
sudo bash install.sh --rollback /var/lib/acs-php84-patches/transaction-ACTUAL
```

Replace `transaction-ACTUAL` with the real printed directory. A stale rollback
from before a newer transaction is refused. Rollback restores only the backed-up
PHP files/build metadata and restarts the same FPM; it does not replace app/data
or configuration. Restoring 8.4.27 reintroduces vulnerabilities fixed in 8.4.28.
Validate APIs/jobs again and prepare a corrected patch promptly.

After acceptance, copy the backup transaction off-server and verify
`BACKUP_SHA256SUMS` there. Protect it as a root-only recovery artifact. The backup
contains vulnerable 8.4.27 binaries; retaining it locally can cause security scan
findings. Remove the local recovery copy only after off-server recovery is
verified and approved under your retention/change procedure. Subsequent rollback
requires restoring the protected transaction to its recorded location first.

## Validation limits

`PATCH_INFO.json` records actual completed workstation tests. Validation uses
isolated EL8 userspace, real PHP/FPM and simulated systemctl. Actual systemd,
SELinux, reboot, client/proxy routing and application/third-party integrations
remain host acceptance checks. No customer server is modified during preparation.
Other vulnerable PHP copies/archives and unrelated component findings require
separate cleanup; this patch does not uninstall them or guarantee a clean scan.
