#!/usr/bin/env bash
set -euo pipefail
kit=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ $EUID == 0 ]] || { echo "Run as root." >&2; exit 1; }
cd "$kit"
sha256sum -c SHA256SUMS
exec bash "$kit/scripts/patch-php84.sh" pbb "$@"
