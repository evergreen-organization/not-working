# PHP 8.4.28 security patch — ACS, RHB and PBB

Released upstream: **19 November 2026**.

Upgrades the previously supplied RHEL 8.10 x86_64 PHP CLI/FPM runtimes from
8.4.27 to 8.4.28. Existing runtime paths, FPM services/boot enablement, pool/ini
configuration, CLI links, Nginx endpoints, application files and private native
dependencies are retained. Matching mbstring/OPcache modules are replaced with
the new PHP build; GD support and existing image-format capabilities are retained.
Build metadata records the installed patch version.

PHP classifies 8.4.28 as a security release. Selected fixes include FPM epoll
memory handling, request-body handling and status-page escaping, timezone-cache
memory safety and DOM XML serialization. The upstream changelog contains the
complete security and bug-fix list; this package does not claim to resolve an
uninvestigated application error or OCR timeout.

Installation includes baseline/dependency integrity checks, module/GD parity,
configuration preflight, a verified backup, a short FPM restart, per-pool FastCGI
checks and automatic rollback on failure. Explicit rollback and repeat execution
are supported. No online repository or compiler is needed on the target.

Validate staging and then deploy production nodes individually. Actual server
systemd/SELinux/reboot and business APIs/jobs remain acceptance checks. Move
verified vulnerable-version recovery files off the scanned server after acceptance.
The stable directory label `php-8.4.27` is retained intentionally; `php -v` and
`php-fpm -v` report **8.4.28** after patching.

- [Official PHP 8.4.28 security release](https://www.php.net/releases/8_4_28.php)
- [Official PHP 8.4.28 changelog](https://www.php.net/ChangeLog-8.php#8.4.28)
