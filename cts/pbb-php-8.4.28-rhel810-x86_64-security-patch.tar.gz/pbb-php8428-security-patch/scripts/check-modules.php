<?php
declare(strict_types=1);
try {
    $before=json_decode(file_get_contents($argv[1]),true,512,JSON_THROW_ON_ERROR);
    foreach($before['modules'] as $module) {
        if (!extension_loaded($module)) throw new RuntimeException('Configured extension is missing in patch: '.$module);
    }
    $inside=false; $count=0;
    foreach(file($argv[2],FILE_IGNORE_NEW_LINES) as $line) {
        $module=trim($line);
        if(preg_match('/^\[.*Modules\]$/',$module)){$inside=true;continue;}
        if(!$inside||$module===''||$module==='cgi-fcgi')continue;
        ++$count;
        if(!extension_loaded($module))throw new RuntimeException('FPM extension missing in patch: '.$module);
    }
    if($count<10)throw new RuntimeException('Cannot identify old FPM module list.');
    if (!extension_loaded('gd')) throw new RuntimeException('GD is required.');
    $gd=gd_info();
    foreach($before['gd'] as $key=>$value) {
        if(is_bool($value)&&$value&&empty($gd[$key])) throw new RuntimeException('GD capability lost: '.$key);
    }
    echo "Configured modules and GD image capabilities retained.\n";
} catch(Throwable $e) {fwrite(STDERR,$e->getMessage()."\n");exit(1);}
