#!/usr/bin/env bash
# Upgrade only the PHP CLI/FPM ELF files from the matched 8.4.27 kit. No configuration changes.
set -euo pipefail
umask 077
export LC_ALL=C
unset PHPRC PHP_INI_SCAN_DIR LD_LIBRARY_PATH
profile=${1:-}; [[ $# -gt 0 ]] && shift
case $profile in acs|rhb|pbb) ;; *) echo 'Unknown patch profile.' >&2; exit 2;; esac
kit=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
prefix=/opt/$profile/php-8.4.27
unit=$profile-php84-fpm.service
base=/var/lib/$profile-php84-patches
helper=$prefix/etc/$profile-fpm-helper.php
pools=$prefix/etc/$profile-fpm-pools.json
extension_dir=lib/php/extensions/no-debug-non-zts-20240924
files=(bin/php sbin/php-fpm "$extension_dir/mbstring.so" "$extension_dir/opcache.so" BUILD_INFO.txt)
stage=
changed=no
state=
die() { echo "$*" >&2; exit 1; }
property() { systemctl show "$unit" -p "$1" 2>/dev/null | sed -n "s/^$1=//p"; }
health() {
    systemctl is-active --quiet "$unit" || return 1
    local pid
    pid=$(property MainPID)
    [[ $pid =~ ^[1-9][0-9]*$ && $(readlink -f "/proc/$pid/exe") == "$prefix/sbin/php-fpm" ]] || return 1
    "$prefix/bin/php" "$helper" probe "$pools"
}
wait_health() {
    local attempt log=${1:-$state/health.private}
    for ((attempt=0;attempt<15;attempt++)); do
        if health >"$log" 2>&1; then return; fi
        sleep 1
    done
    return 1
}
restore() {
    local failed=0
    echo "Restoring PHP 8.4.27 from $state"
    (cd "$state"; sha256sum -c BACKUP_SHA256SUMS) || return 1
    systemctl stop "$unit" || return 1
    local restore_stage relative
    restore_stage=$(mktemp -d "$prefix/.php8428-restore-XXXXXX") || return 1
    if ! tar --acls --xattrs --selinux --numeric-owner -xzpf "$state/before.tar.gz" -C "$restore_stage"; then
        rm -rf -- "$restore_stage"; return 1
    fi
    if ! (cd "$restore_stage"; sha256sum -c "$kit/BASE_PHP_SHA256SUMS"); then
        rm -rf -- "$restore_stage"; return 1
    fi
    for relative in "${files[@]}"; do
        if ! mv -T -- "$restore_stage/$relative" "$prefix/$relative"; then
            rm -rf -- "$restore_stage"; return 1
        fi
    done
    rm -rf -- "$restore_stage"
    systemctl start "$unit" || return 1
    wait_health "$state/rollback-health.private" || return 1
    "$prefix/bin/php" -r 'exit(PHP_VERSION==="8.4.27"?0:1);' || return 1
    touch "$state/ROLLED_BACK"
    echo 'PHP 8.4.27 restored; configuration and service boot settings retained.'
}
finish() {
    local result=$?
    trap - EXIT INT TERM HUP
    if [[ $changed == yes && $result != 0 ]]; then
        if ! restore; then echo "AUTOMATIC ROLLBACK INCOMPLETE. Inspect $unit and $state." >&2; fi
    fi
    [[ -z $stage ]] || rm -rf -- "$stage"
    exit "$result"
}
[[ $EUID == 0 ]] || die 'Run as root.'
[[ $(cat "$kit/PROFILE") == "$profile" ]] || die 'Wrong patch package for this environment.'
[[ ${1:-} != --help && ${1:-} != -h ]] || { echo "Usage: sudo bash install.sh [--check | --rollback TRANSACTION]"; exit; }
[[ $(uname -m) == x86_64 ]] || die 'This patch is for x86_64 only.'
grep -Eq 'release 8\.10([. ]|$)' /etc/redhat-release || die 'This patch requires RHEL 8.10.'
if [[ -r /proc/sys/crypto/fips_enabled && $(cat /proc/sys/crypto/fips_enabled) == 1 ]]; then die 'This private OpenSSL runtime is not FIPS-validated.'; fi
[[ $(readlink -f "$prefix") == "$prefix" && -d /run/systemd/system ]] || die 'Expected installed runtime and running systemd are required.'
for relative in "${files[@]}"; do
    [[ -f $prefix/$relative && ! -L $prefix/$relative ]] || die "Unexpected/missing runtime file: $relative"
    [[ $(stat -c %u "$prefix/$relative") == 0 ]] || die 'Runtime executables/modules must be root-owned.'
done
[[ -f $helper && -f $pools ]] || die 'The completed original installer pool/helper metadata is required.'
mkdir -p "$base" /var/lib/$profile-php84-cutover
chmod 700 "$base"
exec 9>"$base/lock"; flock -n 9 || die 'Another PHP patch is running.'
exec 8>"/var/lib/$profile-php84-cutover/lock"; flock -n 8 || die 'A PHP cutover is running.'
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM HUP
if [[ ${1:-} == --rollback ]]; then
    [[ $# == 2 ]] || die 'Specify the exact transaction directory.'
    state=$(readlink -f -- "$2")
    [[ $state == "$base/transaction-"* && -f $state/before.tar.gz && -f $state/BACKUP_SHA256SUMS ]] || die 'Unknown rollback transaction.'
    [[ $(stat -c %u "$state") == 0 && $(stat -c %a "$state") == 700 ]] || die 'Rollback directory must be root-owned and private.'
    [[ ! -f $state/ROLLED_BACK ]] || die 'Transaction is already rolled back.'
    if [[ -f $base/latest && $(cat "$base/latest") != "$state" ]]; then die 'A newer patch transaction exists; refusing stale rollback.'; fi
    restore || die "Rollback incomplete; inspect $state."
    exit
fi
[[ $# == 0 || ( $# == 1 && $1 == --check ) ]] || die 'Usage: sudo bash install.sh [--check | --rollback TRANSACTION]'
(cd "$prefix"; sha256sum -c "$kit/BASE_DEPENDENCIES_SHA256SUMS") || die 'Private libraries differ from the validated baseline; no files or services changed.'
systemctl is-enabled --quiet "$unit" || die 'Expected service must already be enabled; no service settings changed.'
health || die 'The existing PHP-FPM service must be active and healthy before patching.'
version=$("$prefix/bin/php" -r 'echo PHP_VERSION;')
if [[ $version == 8.4.28 ]]; then
    (cd "$prefix"; sha256sum -c "$kit/NEW_PHP_SHA256SUMS") || die 'Installed PHP 8.4.28 differs from this patch; review before proceeding.'
    "$prefix/bin/php" -r 'exit(extension_loaded("gd")&&extension_loaded("mbstring")&&extension_loaded("Zend OPcache")?0:1);'
    echo 'PHP 8.4.28 patch is already installed; FPM active/enabled. No changes made.'
    exit
fi
[[ $version == 8.4.27 ]] || die 'This patch requires the original PHP 8.4.27 installation.'
(cd "$prefix"; sha256sum -c "$kit/BASE_PHP_SHA256SUMS") || die 'PHP binaries/modules differ from the validated original; no changes made.'
stage=$(mktemp -d "$prefix/.php8428-stage-XXXXXX")
master_pid=$(property MainPID)
master_title=$(tr '\0' ' ' <"/proc/$master_pid/cmdline")
[[ $master_title == *"master process ($prefix/etc/php-fpm.conf)"* ]] || die 'The active FPM configuration path differs from the installed baseline; review before patching.'
tr '\0' '\n' <"/proc/$master_pid/environ" >"$stage/master-environment.private" || die 'Cannot inspect the active FPM environment.'
if grep -Eq '^(PHPRC|PHP_INI_SCAN_DIR|LD_LIBRARY_PATH)=' "$stage/master-environment.private"; then die 'Custom service PHP/loader environment needs a matching patch preflight.'; fi
start_command=$(property ExecStart)
if printf '%s\n' "$start_command" | grep -Eq '(^|[[:space:]])(-c|-d|--php-ini|--define)(=|[[:space:]])'; then die 'Custom service PHP ini/define arguments need review.'; fi
"$prefix/sbin/php-fpm" -m >"$stage/before-fpm-modules.txt" 2>&1 || die 'Cannot read existing FPM modules.'

for relative in "${files[@]}"; do
    mkdir -p "$stage/$(dirname "$relative")"
    cp -- "$kit/payload/$relative" "$stage/$relative"
    cp --attributes-only --preserve=mode,ownership,xattr "$prefix/$relative" "$stage/$relative"
    if [[ -e /sys/fs/selinux/enforce ]]; then chcon --reference="$prefix/$relative" "$stage/$relative"; fi
done
if env -u LD_LIBRARY_PATH ldd "$stage/bin/php" "$stage/sbin/php-fpm" "$stage/$extension_dir/mbstring.so" "$stage/$extension_dir/opcache.so" | grep -q 'not found'; then die 'A patched ELF dependency is missing.'; fi
args=(-n -d "extension=$stage/$extension_dir/mbstring.so" -d "zend_extension=$stage/$extension_dir/opcache.so")
"$stage/bin/php" "${args[@]}" -r 'exit(PHP_VERSION==="8.4.28"&&PHP_CONFIG_FILE_PATH===$argv[1]?0:1);' "$prefix/etc" || die 'Unexpected patch version/compiled prefix.'
"$prefix/bin/php" -r 'echo json_encode(["modules"=>get_loaded_extensions(),"gd"=>gd_info()]);' >"$stage/before.json"
"$stage/bin/php" "${args[@]}" "$kit/scripts/check-modules.php" "$stage/before.json" "$stage/before-fpm-modules.txt" || die 'The patch does not preserve the configured module/GD feature set.'
"$stage/sbin/php-fpm" "${args[@]}" -t -y "$prefix/etc/php-fpm.conf" >"$stage/config-test.private" 2>&1 || { cat "$stage/config-test.private" >&2; die 'New FPM configuration test failed; no service changed.'; }
if [[ ${1:-} == --check ]]; then echo 'PHP 8.4.28 preflight passed. No installed files or services changed.'; exit; fi
state=$(mktemp -d "$base/transaction-$(date +%Y%m%d-%H%M%S)-XXXXXX")
printf '%s\n' "${files[@]}" >"$state/files.txt"
tar --acls --xattrs --selinux --numeric-owner -czpf "$state/before.tar.gz" -C "$prefix" -T "$state/files.txt"
gzip -t "$state/before.tar.gz"
tar -tzf "$state/before.tar.gz" >"$state/backup-contents.txt"
cp "$kit/PATCH_INFO.json" "$state/PATCH_INFO.json"
(cd "$state"; sha256sum before.tar.gz files.txt PATCH_INFO.json >BACKUP_SHA256SUMS; sha256sum -c BACKUP_SHA256SUMS)
changed=yes
echo "Stopping $unit briefly to replace PHP CLI/FPM and matching modules."
systemctl stop "$unit"
for process in /proc/[0-9]*/exe; do
    resolved=$(readlink "$process" 2>/dev/null || true)
    [[ $resolved != "$prefix/sbin/php-fpm" && $resolved != "$prefix/sbin/php-fpm (deleted)" ]] || die 'A matching FPM process is still running; rolling back.'
done
for relative in "${files[@]}"; do mv -T -- "$stage/$relative" "$prefix/$relative"; done
(cd "$prefix"; sha256sum -c "$kit/NEW_PHP_SHA256SUMS")
"$prefix/bin/php" -r 'exit(PHP_VERSION==="8.4.28"?0:1);'
"$prefix/sbin/php-fpm" -t -y "$prefix/etc/php-fpm.conf" >"$state/config-test.private" 2>&1
systemctl start "$unit"
wait_health || die "Patched FPM failed its health checks; see $state/health.private"
systemctl is-enabled --quiet "$unit" || die 'FPM boot enablement changed unexpectedly.'
touch "$state/SUCCESS"
printf '%s\n' "$state" >"$base/latest"
changed=no
"$prefix/bin/php" -v
echo "PHP 8.4.28 installed; configuration, endpoints and enabled service retained. Transaction: $state"
echo "The directory name $prefix is intentionally unchanged."
echo "Rollback: sudo bash $kit/install.sh --rollback $state"
echo 'After acceptance, move the verified vulnerable-version backup off the scanned server.'
for process in /proc/[0-9]*/exe; do
    resolved=$(readlink "$process" 2>/dev/null || true)
    case $resolved in "$prefix/bin/php (deleted)"|"$prefix/sbin/php-fpm (deleted)") process_id=${process#/proc/}; process_id=${process_id%/exe}; echo "Old PHP executable still mapped by PID $process_id; review and restart its job/service.";; esac
done
