import {createSelector} from '@reduxjs/toolkit';
import {moneyMarketDepositAdapter} from './reducer';

export const getCasa = createSelector(
  state => state.bankingEntities?.casa,
  casa => casa,
);

export const getTotalCasaAmount = createSelector(
  state => state.bankingEntities?.casa,
  ({accounts}) => accounts?.reduce((sum, i) => sum + i.currentBalance, 0) ?? 0,
);

export const getCasaHistory = createSelector(
  state => state.bankingEntities.casa,
  ({endOfHistory, historyStatus, historyNextKey, history}) => {
    return {
      endOfHistory,
      historyStatus,
      historyNextKey,
      history,
    };
  },
);
const moneyMarketDepositSelectors = moneyMarketDepositAdapter.getSelectors(
  state => state.bankingEntities?.casa.moneyMarket,
);

export const getCasaMoneyMarketStatus = createSelector(
  state => state.bankingEntities?.casa,
  casa => casa.moneyMarketStatus,
);

export const getCasaMoneyMarketByAccount = (state, accountNo) =>
  moneyMarketDepositSelectors.selectById(state, accountNo);
export const getForeignCurrencyStatus = createSelector(
  state => state.bankingEntities?.casa,
  casa => casa.foreignCurrencyStatus,
);
