import {createEntityAdapter, createSlice} from '@reduxjs/toolkit';
import {FAILED, IDLE, LOADING, SUCCESS} from '@/api';
import {
  requestCasaHistory,
  requestCasaMoneyMarket,
  requestCasaSummary,
  requestForeignCurrency,
} from './thunk';
import {sortAccountHistoryData} from 'utils/accounts';

export const moneyMarketDepositAdapter = createEntityAdapter({
  selectId: moneyMarketDeposit => moneyMarketDeposit.id,
});

const initialState = {
  accounts: null,
  accountsStatus: 'loading',
  history: [],
  historyStatus: 'idle',
  historyNextKey: '0',
  endOfHistory: false,
  problem: null,
  status: null,
  foreignCurrency: {},
  foreignCurrencyStatus: '',
  moneyMarket: moneyMarketDepositAdapter.getInitialState(),
  moneyMarketStatus: IDLE,
};

const slice = createSlice({
  name: 'casa',
  initialState,
  reducers: {
    casaReset: _ => initialState,
    casaHistoryReset: state => {
      state.history = [];
      state.endOfHistory = false;
    },
    casaMoneyMarketReset: state => {
      moneyMarketDepositAdapter.removeAll(state.moneyMarket);
      state.moneyMarketStatus = IDLE;
    },
  },
  extraReducers: builder => {
    builder.addCase(requestCasaSummary.pending, state => {
      state.problem = null;
      state.error = null;
      state.accountsStatus = LOADING;
    });
    builder.addCase(requestCasaSummary.fulfilled, (state, {payload}) => {
      state.accountsStatus = SUCCESS;
      state.accounts = payload.accountSummary;
    });
    builder.addCase(requestCasaSummary.rejected, (state, {payload}) => {
      state.problem = payload.problem;
      state.error = payload.status;
      state.accountsStatus = FAILED;
    });

    builder.addCase(requestCasaHistory.pending, state => {
      state.historyStatus = LOADING;
    });
    builder.addCase(requestCasaHistory.fulfilled, (state, {payload, meta}) => {
      state.historyStatus = SUCCESS;
      if (payload.accountHistory) {
        if (meta.arg.pageNo !== '1') {
          state.history = sortAccountHistoryData(
            payload.accountHistory,
            meta.arg.sortType,
          );
        } else {
          state.history.push(
            ...sortAccountHistoryData(
              payload.accountHistory,
              meta.arg.sortType,
            ),
          );
        }
        state.historyNextKey = payload.pageNo;
      }
      if (payload.pageNo === '0') {
        state.endOfHistory = true;
      }
    });
    builder.addCase(requestCasaHistory.rejected, (state, {payload}) => {
      state.error = payload.problem;
      state.historyStatus = FAILED;
    });
    builder.addCase(requestCasaMoneyMarket.pending, state => {
      state.error = null;
      state.moneyMarketStatus = LOADING;
    });
    builder.addCase(
      requestCasaMoneyMarket.fulfilled,
      (state, {payload, meta}) => {
        state.moneyMarketStatus = SUCCESS;
        if (payload.mmdList) {
          moneyMarketDepositAdapter.upsertOne(state.moneyMarket, {
            id: meta.arg.accountNo,
            ...payload.mmdList,
          });
        }
      },
    );
    builder.addCase(requestCasaMoneyMarket.rejected, (state, {payload}) => {
      state.error = payload.problem;
      state.moneyMarketStatus = FAILED;
    });
    builder.addCase(requestForeignCurrency.pending, state => {
      state.foreignCurrencyStatus = LOADING;
    });
    builder.addCase(requestForeignCurrency.fulfilled, (state, {payload}) => {
      state.foreignCurrencyStatus = SUCCESS;
      state.foreignCurrency = payload.accoountDetails;
    });
    builder.addCase(requestForeignCurrency.rejected, state => {
      state.foreignCurrencyStatus = FAILED;
    });
  },
});

const {casaReset, casaHistoryReset, casaMoneyMarketReset} = slice.actions;
export default slice.reducer;

export const resetCasa = () => casaReset();
export const resetCasaHistory = () => casaHistoryReset();
export const resetCasaMoneyMarket = () => casaMoneyMarketReset();
