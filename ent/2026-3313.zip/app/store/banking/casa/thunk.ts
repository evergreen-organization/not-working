import {createAsyncThunk} from '@reduxjs/toolkit';
import {checkDemoFromState} from '@/utils';
import {DemoData} from '@/constants';
import {handleResponse, publicClient} from '@/api';
import {END_POINTS} from '@/services/endpoints';

export const requestCasaSummary = createAsyncThunk(
  'casa/summary',
  async (_, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromState(getState())) {
      return DemoData.Casa.Summary;
    }
    const result = await publicClient.get(END_POINTS.LOAD_CASA_PUBLIC);
    return handleResponse({
      result,
      dispatch,
      state: getState(),
      rejectWithValue,
    });
  },
);

export const requestCasaHistory = createAsyncThunk(
  'casa/history',
  async (request, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromState(getState())) {
      return DemoData.Casa.History;
    }
    const result = await publicClient.post(
      END_POINTS.LOAD_CASA_HISTORY,
      request,
    );
    return handleResponse({
      result,
      dispatch,
      state: getState(),
      rejectWithValue,
    });
  },
);

export const requestCasaMoneyMarket = createAsyncThunk(
  'casa/moneyMarket',
  async (req, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromState(getState())) {
      return DemoData.Casa.MoneyMarket;
    }
    const result = await publicClient.post(
      END_POINTS.LOAD_CASA_MONEY_MARKET,
      req,
    );
    return handleResponse({
      result,
      dispatch,
      state: getState(),
      rejectWithValue,
    });
  },
);

export const requestForeignCurrency = createAsyncThunk(
  'casa/foreignCurrency',
  async (request, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromState(getState())) {
      return DemoData.Casa.mfCasa;
    }
    const result = await publicClient.post(
      END_POINTS.LOAD_CASA_FOREIGN_CURRENCY,
      request,
    );
    return handleResponse({
      result,
      dispatch,
      state: getState(),
      rejectWithValue,
    });
  },
);
