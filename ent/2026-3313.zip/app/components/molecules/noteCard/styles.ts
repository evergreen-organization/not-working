import {StyleSheet} from 'react-native';
import {colors} from '@/styles';

export const styles = StyleSheet.create({
  noteCard: {
    backgroundColor: colors.white,
    marginBottom: 12,
    borderRadius: 16,
    padding: 16,
    shadowColor: colors.black,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#EFEFEF',
    overflow: 'hidden',
  },
  noteCardGrid: {
    padding: 12,
  },
  noteHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  refNo: {
    color: colors.grey,
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.4,
    flexShrink: 1,
    marginRight: 8,
  },
  rateBadge: {
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 6,
  },
  rateBadgeGrid: {
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  rateBadgeText: {
    color: colors.white,
    fontWeight: '700',
    fontSize: 12,
  },
  amountRow: {
    marginTop: 10,
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
  },
  dateRange: {
    color: colors.darkGrey,
    fontSize: 12,
  },
  dateRangeGrid: {
    fontSize: 11,
  },
  footerDivider: {
    height: 1,
    backgroundColor: '#F0F1F3',
    marginTop: 14,
    marginBottom: 12,
  },
  footerDividerGrid: {
    marginTop: 10,
    marginBottom: 8,
  },
  footerRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  footerRowGrid: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    gap: 8,
  },
  productRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  productRowGrid: {
    flex: 0,
    alignSelf: 'stretch',
  },
  productIconTile: {
    width: 30,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  productIconTileGrid: {
    width: 30,
    height: 30,
    borderRadius: 8,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    color: colors.black,
    fontWeight: '700',
    fontSize: 13,
    lineHeight: 18,
  },
  productNameGrid: {
    fontSize: 12,
    lineHeight: 16,
  },
  branchName: {
    color: colors.grey,
    fontSize: 10,
    letterSpacing: 0.3,
    marginTop: 3,
    textTransform: 'uppercase',
  },
  branchNameGrid: {
    fontSize: 9,
    marginTop: 2,
  },
  verticalDivider: {
    width: 1,
    alignSelf: 'stretch',
    backgroundColor: '#EDEDED',
    marginHorizontal: 12,
  },
  tenureBlock: {
    alignItems: 'flex-end',
    minWidth: 70,
  },
  tenureBlockLeft: {
    alignItems: 'flex-start',
    minWidth: 0,
  },
  tenureLabel: {
    color: colors.grey,
    fontSize: 10,
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  tenureValue: {
    fontWeight: '700',
    fontSize: 16,
    marginTop: 2,
  },
});
