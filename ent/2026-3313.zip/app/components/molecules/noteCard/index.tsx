import React from 'react';
import {View} from 'react-native';
import {Icon, Text} from '@/components/atoms';
import {Money} from '../money';
import {styles} from './styles';
import {colors, tagColors} from '@/styles';
import DateIcon from '@/assets/images/icon/calendar-outline.png';
import ProductIcon from '@/assets/images/icon/accounts-icon.png';

export interface NoteCardProps {
  refNo?: string;
  rate?: string;
  isMatured?: boolean;
  amount?: number | string | null;
  currency?: string;
  startDate?: string;
  endDate?: string;
  productName?: string;
  branch?: string;
  tenure?: string | number;
  grid?: boolean;
}

export const NoteCard: React.FC<NoteCardProps> = ({
  refNo,
  rate,
  isMatured = false,
  amount,
  currency,
  startDate,
  endDate,
  productName,
  branch,
  tenure,
  grid = false,
}) => {
  const statusColor = isMatured
    ? tagColors.orange.primary
    : tagColors.green.primary;

  const hasProduct = !!productName || !!branch;
  const hasTenure = tenure !== null && tenure !== undefined;

  return (
    <View style={[styles.noteCard, grid && styles.noteCardGrid]}>
      <View style={styles.noteHeader}>
        <Text as={Text.type.P4} style={styles.refNo} params={{}}>
          {refNo}
        </Text>
        {rate !== null && rate !== undefined && (
          <View
            style={[
              styles.rateBadge,
              grid && styles.rateBadgeGrid,
              {backgroundColor: statusColor},
            ]}
          >
            <Text as={Text.type.P4} style={styles.rateBadgeText} params={{}}>
              {rate}
            </Text>
          </View>
        )}
      </View>

      {amount !== null && amount !== undefined && (
        <View style={styles.amountRow}>
          <Money
            amount={Number(amount)}
            currency={currency}
            size={grid ? 17 : 26}
            color={colors.black}
          />
        </View>
      )}

      {(!!startDate || !!endDate) && (
        <View style={styles.dateRow}>
          <Icon
            source={DateIcon}
            size={grid ? 12 : 14}
            color={colors.primary}
          />
          <Text
            as={Text.type.P4}
            style={[styles.dateRange, grid && styles.dateRangeGrid]}
            params={{}}
          >
            {`${startDate ?? ''}  - ${grid ? '\n' : ''}${endDate ?? ''}`}
          </Text>
        </View>
      )}

      {(hasProduct || hasTenure) && (
        <>
          <View
            style={[styles.footerDivider, grid && styles.footerDividerGrid]}
          />
          <View style={[styles.footerRow, grid && styles.footerRowGrid]}>
            {hasProduct && (
              <View style={[styles.productRow, grid && styles.productRowGrid]}>
                {!grid && (
                  <View
                    style={[
                      styles.productIconTile,
                      grid && styles.productIconTileGrid,
                      {backgroundColor: colors.ultraUltraLightGrey},
                    ]}
                  >
                    <Icon
                      source={ProductIcon}
                      size={20}
                      color={colors.darkGrey}
                    />
                  </View>
                )}
                <View style={styles.productInfo}>
                  {!!productName && (
                    <Text
                      as={Text.type.P4}
                      style={[
                        styles.productName,
                        grid && styles.productNameGrid,
                      ]}
                      params={{}}
                    >
                      {productName}
                    </Text>
                  )}
                  {!!branch && (
                    <Text
                      as={Text.type.P4}
                      style={[styles.branchName, grid && styles.branchNameGrid]}
                      params={{}}
                    >
                      {branch}
                    </Text>
                  )}
                </View>
              </View>
            )}
            {hasProduct && hasTenure && !grid && (
              <View style={styles.verticalDivider} />
            )}
            {hasTenure && (
              <View
                style={[
                  styles.tenureBlock,
                  (!hasProduct || grid) && styles.tenureBlockLeft,
                ]}
              >
                <Text as={Text.type.P4} style={styles.tenureLabel} params={{}}>
                  Tenure
                </Text>
                <Text
                  as={Text.type.P4}
                  style={[styles.tenureValue, {color: statusColor}]}
                  params={{}}
                >
                  {tenure}
                </Text>
              </View>
            )}
          </View>
        </>
      )}
    </View>
  );
};
