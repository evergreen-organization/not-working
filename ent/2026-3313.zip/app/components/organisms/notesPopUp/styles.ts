import {StyleSheet} from 'react-native';
import {colors} from '@/styles';

export const styles = StyleSheet.create({
  modernHeaderContainer: {
    backgroundColor: `rgba(0, 2, 108, 0.8)`,
    zIndex: 20,
  },
  headerTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 24,
  },
  headerArrowBackContainer: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 100,
  },
  headerIconContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    opacity: 0.05,
    position: 'absolute',
    right: -20,
    top: -50,
  },
  headerTextContainer: {
    flex: 1,
  },
  modernHeaderTitle: {
    color: colors.white,
    fontWeight: '600',
  },
  modernHeaderSubtitle: {
    color: 'rgba(255, 255, 255, 0.8)',
    marginTop: -2,
    fontSize: 11,
  },
  notesContainer: {
    flex: 1,
  },
  headerTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  infoIconContainer: {
    padding: 2,
  },
  tooltip: {
    position: 'absolute',
    top: 54,
    left: 24,
    right: 24,
    backgroundColor: colors.white,
    borderRadius: 14,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    shadowColor: colors.black,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 8,
    zIndex: 100,
  },
  tooltipIconCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: 'rgba(200, 30, 45, 0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  tooltipCaret: {
    position: 'absolute',
    top: -6,
    left: 60,
    width: 0,
    height: 0,
    borderLeftWidth: 6,
    borderRightWidth: 6,
    borderBottomWidth: 6,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: colors.white,
  },
  tooltipText: {
    flex: 1,
    color: colors.darkGrey,
    fontSize: 12,
    lineHeight: 18,
  },
});
