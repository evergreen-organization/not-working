import React, {useState} from 'react';
import {
  View,
  Platform,
  Dimensions,
  ScrollView,
  TouchableOpacity,
  ImageSourcePropType,
} from 'react-native';
import {Icon, Text} from '@/components/atoms';
import {BottomPopUp} from '@/components/molecules';
import {TransactionList} from '../transactionList';
import {styles} from './styles';
import {colors} from '@/styles';
import PlacementIcon from '@/assets/images/icon/percent.png';
import InfoIcon from '@/assets/images/icon/info.png';
import {ViewStyle} from 'react-native';

const {height} = Dimensions.get('window');

export interface NotesPopUpProps {
  isVisible: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  titleInfo?: string;
  icon?: ImageSourcePropType;
  data?: any[];
  loading?: boolean;
  isEnd?: boolean;
  onLoad?: () => void;
  endText?: string;
  renderItem?: ({item}: {item: any}) => React.ReactElement;
  headerStyle?: ViewStyle;
  headerContent?: React.ReactNode;
  children?: React.ReactNode;
}

export const NotesPopUp: React.FC<NotesPopUpProps> = ({
  isVisible,
  onClose,
  title,
  subtitle,
  titleInfo,
  icon = PlacementIcon,
  data,
  loading,
  isEnd,
  onLoad,
  endText = 'No Placements Available',
  renderItem,
  headerStyle = {},
  headerContent,
  children,
}) => {
  const [infoVisible, setInfoVisible] = useState(false);

  return (
    <BottomPopUp
      isVisible={isVisible}
      cancel
      onClose={onClose}
      adjustToContentHeight={Platform.OS === 'ios'}
      scrollViewProps={{scrollEnabled: false}}
      propStyle={{
        paddingBottom: 10,
        height: height * 0.9,
        ...(Platform.OS === 'android' && {height: height * 0.92}),
      }}
      avoidKeyboard={true}
    >
      <View style={[styles.modernHeaderContainer, headerStyle]}>
        <View style={styles.headerTopRow}>
          <TouchableOpacity
            onPress={onClose}
            style={styles.headerArrowBackContainer}
          >
            <Icon source={icon} size={30} color={colors.white} />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <View style={styles.headerTitleRow}>
              <Text
                as={Text.type.P12}
                style={styles.modernHeaderTitle}
                params={{}}
              >
                {title}
              </Text>
              {!!titleInfo && (
                <TouchableOpacity
                  onPress={() => setInfoVisible(!infoVisible)}
                  style={styles.infoIconContainer}
                >
                  <Icon source={InfoIcon} size={16} color={colors.white} />
                </TouchableOpacity>
              )}
            </View>
            {subtitle && (
              <Text
                as={Text.type.P4}
                style={styles.modernHeaderSubtitle}
                params={{}}
              >
                {subtitle}
              </Text>
            )}
          </View>
          <View style={styles.headerIconContainer}>
            <Icon source={icon} size={150} color={colors.white} />
          </View>
        </View>

        {headerContent}

        {!!titleInfo && infoVisible && (
          <TouchableOpacity
            style={styles.tooltip}
            activeOpacity={0.95}
            onPress={() => setInfoVisible(false)}
          >
            <View style={styles.tooltipCaret} />
            <View style={styles.tooltipIconCircle}>
              <Icon source={InfoIcon} size={18} color={colors.primary} />
            </View>
            <Text as={Text.type.P4} style={styles.tooltipText} params={{}}>
              {titleInfo}
            </Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView
        style={styles.notesContainer}
        showsVerticalScrollIndicator={false}
      >
        {children ? (
          children
        ) : (
          <TransactionList
            onLoad={onLoad}
            data={data}
            loading={loading}
            noHeader
            noFooter
            isEnd={isEnd}
            endText={endText}
            error={null}
            renderItem={renderItem}
          />
        )}
      </ScrollView>
    </BottomPopUp>
  );
};
