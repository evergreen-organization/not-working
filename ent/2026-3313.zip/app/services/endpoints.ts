import Config from '@/config/config';

export const BASE_URL =
  Config.BASE_URL ?? 'https://secure-uat.pbenterprise.com';

export const PATHS = {
  PUBLIC: '/pubcmsapps/mycms/mobileopen',
  PRIVATE: '/cmsapps/mycms/mobile',
  EAIJCT: '/eaijct/Public_Bank',
  E2EE: '/eaijct/Public_Bank/JunctionManager?URL=/cmsapps/mycms',
  PLPUrl: '/eaijct/Public_Bank/PLPServlet',
};

export const END_POINTS = {
  /* Authentication & Session */
  INIT_APP: `${PATHS.PUBLIC}/initApp/v2`,
  E2EE: `${PATHS.EAIJCT}/JunctionManager?URL=/pbone/pbone`,
  REQUEST_SESSION: `${PATHS.EAIJCT}/PBAuthenticate`,
  SESSION_LOGIN: `${PATHS.EAIJCT}/PBAuthenticate`,
  LOGIN: `${PATHS.PRIVATE}/login`,
  REQUEST_PAC: `${PATHS.PRIVATE}/requestPac`,
  REQUEST_BINDING: `${PATHS.PRIVATE}/binding`,
  INIT_USER: `${PATHS.PUBLIC}/initUser`,
  QUICK_LOGIN: `${PATHS.PUBLIC}/quickLogin`,
  LOG_OUT_PRIVATE: `${PATHS.PRIVATE}/logout`,
  LOG_OUT_PUBLIC: `${PATHS.PUBLIC}/logout`,
  CSRF: `${PATHS.PUBLIC}/csrf`,
  VALIDATE_PIN: `${PATHS.PUBLIC}/validatePin`,
  VALIDATE_IC: `${PATHS.PRIVATE}/validateIC`,
  CHANGE_PIN: `${PATHS.PUBLIC}/changePin`,
  FORGOT_PIN: `${PATHS.PUBLIC}/forgotPin`,
  REQUEST_EMAIL_PAC: `${PATHS.PRIVATE}/requestEmailPac`,
  VALIDATE_EMAIL_PAC: `${PATHS.PRIVATE}/validateEmailPac`,
  UNBIND_SINGLE: `${PATHS.PRIVATE}/unbindSingle`,
  /* Device Management */
  REGISTER_BIOMETRIC: `${PATHS.PUBLIC}/updateBiometric`,
  LINKED_DEVICES: `${PATHS.PUBLIC}/getDevice`,
  UNBIND_DEVICE: `${PATHS.PUBLIC}/unbind`,
  REG_UNBIND_DEVICE: `${PATHS.PRIVATE}/regunbind`,

  /* CASA */
  LOAD_CASA_PUBLIC: `${PATHS.PUBLIC}/casaSummary`,
  LOAD_CASA_HISTORY: `${PATHS.PUBLIC}/casaHistory`,
  LOAD_CASA_FOREIGN_CURRENCY: `${PATHS.PUBLIC}/mfCasaDetails`,
  LOAD_CASA_MONEY_MARKET: `${PATHS.PUBLIC}/mmdDetails`,
  CHANGE_ACCOUNT_NICKNAME: `${PATHS.PUBLIC}/changeAccountNickname`,

  /* Fixed Deposit */
  LOAD_DEPOSIT_PUBLIC: `${PATHS.PUBLIC}/fdSummary`,
  LOAD_DEPOSIT_DETAILS: `${PATHS.PUBLIC}/fdDetails`,
  LOAD_DEPOSIT_HISTORY: `${PATHS.PUBLIC}/fdHistory`,
  LOAD_DEPOSIT_FOREIGN_CURRENCY: `${PATHS.PUBLIC}/mfFdDetails`,

  /* SoftToken */
  INIT_SOFT_TOKEN_ACTIVATION: `${PATHS.PRIVATE}/softTokenActivationInitialization`,
  VALIDATE_ID_PBSS: `${PATHS.PRIVATE}/softTokenValidateId`,
  REGISTER_DS_APP: `${PATHS.PRIVATE}/softTokenActivationStep1`,
  GENERATE_TOKEN_LICENSE: `${PATHS.PRIVATE}/softTokenActivationStep2`,
  GENERATE_TOKEN_INSTANCE: `${PATHS.PRIVATE}/softTokenActivationStep3`,
  ACTIVATE_TOKEN_INSTANCE: `${PATHS.PRIVATE}/softTokenActivationStep4`,
  DEACTIVATE_SOFT_TOKEN: `${PATHS.PUBLIC}/deactivateSoftToken`,
  LOAD_SOFT_TOKEN_STATUS: `${PATHS.PUBLIC}/getSoftTokenStatus/v2`,
  INIT_TRANSACTION_PUBLIC: `${PATHS.PUBLIC}/softToken/generateTxnSCM`,
  INIT_TRANSACTION_PRIVATE: `${PATHS.PRIVATE}/softToken/generateTxnSCM`,
  VALIDATE_SIGNATURE_PUBLIC: `${PATHS.PUBLIC}/softToken/valSignature`,
  VALIDATE_SIGNATURE_PRIVATE: `${PATHS.PRIVATE}/softToken/valSignature`,
  CHECK_SECFA_PUBLIC: `${PATHS.PUBLIC}/getSecfa/v2`,
  CHECK_SECFA_PRIVATE: `${PATHS.PRIVATE}/getSecfa/v2`,
  PING_PUBLIC: `${PATHS.PUBLIC}/ping`,
  PING_PRIVATE: `${PATHS.PRIVATE}/ping`,
  VALIDATE_SECURE_PIN_PUBLIC: `${PATHS.PUBLIC}/softToken/getRPD`,
  VALIDATE_SECURE_PIN_PRIVATE: `${PATHS.PRIVATE}/softToken/getRPD`,
  REQUEST_PAC_PUBLIC: `${PATHS.PUBLIC}/requestPac`,
  REQUEST_PAC_PRIVATE: `${PATHS.PRIVATE}/requestPac`,
  REQUEST_CHALLENGE_CODE_PUBLIC: `${PATHS.PUBLIC}/requestChallengeCode`,
  REQUEST_CHALLENGE_CODE_PRIVATE: `${PATHS.PRIVATE}/requestChallengeCode`,
  GET_PENDING_TRANSACTION: `${PATHS.PUBLIC}/softToken/getPendingTrx`,
  CHECK_TRANSACTION_STATUS: `${PATHS.PUBLIC}/softToken/checkTrxStatus`,
  REJECT_TRANSACTION: `${PATHS.PUBLIC}/softToken/rejectTrx`,
  REJECT_TRANSACTION_V2: `${PATHS.PRIVATE}/softToken/rejectTrx/v2`,
  REJECT_TRANSACTION_PUBLIC_V2: `${PATHS.PUBLIC}/softToken/rejectTrx/v2`,

  /* Account Preferences */
  UPDATE_PREFERRED_ACC_PUBLIC: `${PATHS.PUBLIC}/updatePrefAccount`,
  UPDATE_PREFERRED_ACC_PRIVATE: `${PATHS.PRIVATE}/updatePrefAccount`,

  /* Mailbox */
  MAILBOX: `${PATHS.PUBLIC}/mailbox/getAll`,

  /* Credit Card */
  LOAD_CREDIT_CARD_SUMMARY: `${PATHS.PUBLIC}/ccSummary`,
  LOAD_CREDIT_CARD_BILL_STATUS: `${PATHS.PUBLIC}/ccBillAccStatus`,
  LOAD_CREDIT_CARD_DETAILS: `${PATHS.PUBLIC}/ccDetails`,
  LOAD_CREDIT_CARD_HISTORY: `${PATHS.PUBLIC}/ccHistory`,
  LOAD_CREDIT_CARD_HOLDER: `${PATHS.PUBLIC}/ccHistory`,
  LOAD_CREDIT_CARD_CARD_SUMMARY: `${PATHS.PUBLIC}/ccCardSummary`,

  /* Loan */
  LOAD_LOAN_SUMMARY: `${PATHS.PUBLIC}/loanSummary`,
  LOAD_LOAN_HISTORY: `${PATHS.PUBLIC}/loanHistory`,
  LOAD_LOAN_DETAILS: `${PATHS.PUBLIC}/loanDetails`,

  /* Gold Investment */
  LOAD_GOLD_INVESTMENT_SUMMARY: `${PATHS.PUBLIC}/giaSummary`,
  LOAD_GOLD_INVESTMENT_HISTORY: `${PATHS.PUBLIC}/giaHistory`,

  /* Analytics */
  ANALYTICS_LOGS: `${PATHS.PUBLIC}/analytics/logs`,

  /* Settings */
  UPDATE_DISPLAY_NAME: `${PATHS.PUBLIC}/updateDisplayName`,
  GET_DEVICE_HISTORY: `${PATHS.PUBLIC}/getDeviceHistory`,

  /* Biometric */
  GET_BIOMETRIC_IND: `${PATHS.PUBLIC}/getBiometricInd`,
  UPDATE_BIOMETRIC_PRIVATE: `${PATHS.PRIVATE}/updateBiometric`,
  UPDATE_BIOMETRIC_PUBLIC: `${PATHS.PUBLIC}/updateBiometric`,

  /* Mail */
  GET_MAIL: `${PATHS.PUBLIC}/getMail`,
  READ_MAIL: `${PATHS.PUBLIC}/readMail`,
  DELETE_MAIL: `${PATHS.PUBLIC}/deleteMail`,

  /* Notification */
  UPDATE_PUSH_NOTIFICATION: `${PATHS.PUBLIC}/updatePushNotification`,
  UPDATE_PUSH_INDICATOR: `${PATHS.PUBLIC}/updatePushIndicator`,
  GET_ALERT: `${PATHS.PUBLIC}/notification`,

  /* Security Posture */
  SUBMIT_SECURITY_POSTURE: `${PATHS.PUBLIC}/updateSecurityPosture`,
  SUBMIT_NO_THIRD_PARTY_APP: `${PATHS.PUBLIC}/updateNoThirdPartyApp`,
};
