import React from 'react';
import {Animated, View} from 'react-native';
import Reanimated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

import {HapticTouchableOpacity, Text} from '@/components/atoms';
import {colors} from '@/styles';
import {styles} from './styles';
import {GradientIcon} from '@/components/molecules';
import {QuickLinkItemProps} from './types';
import {isAndroid} from '@/utils/device';

export const QuickLinkItem: React.FC<QuickLinkItemProps> = ({
  icon,
  label,
  onPress,
  disabled,
  badge = false,
  style,
  scrollY = null,
  horizontal = false,
}) => {
  const pressScale = useSharedValue(1);
  const pressAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{scale: pressScale.value}],
  }));

  const handlePressIn = () => {
    pressScale.value = withTiming(0.93, {duration: 1});
  };
  const handlePressOut = () => {
    pressScale.value = withSpring(1, {duration: 1, dampingRatio: 0.6});
  };

  const minHeight = scrollY?.interpolate({
    inputRange: [0, 80],
    outputRange: [100, 0],
    extrapolate: 'clamp',
  });
  const maxHeight = scrollY?.interpolate({
    inputRange: [0, 80],
    outputRange: [100, 55],
    extrapolate: 'clamp',
  });
  const textOpacity = scrollY?.interpolate({
    inputRange: [0, 30],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });
  const paddingVertical = scrollY?.interpolate({
    inputRange: [0, 80],
    outputRange: [15, 10],
    extrapolate: 'clamp',
  });
  const minWidth = scrollY?.interpolate({
    inputRange: [0, 80],
    outputRange: [80, 0],
    extrapolate: 'clamp',
  });
  const maxWidth = scrollY?.interpolate({
    inputRange: [0, 80],
    outputRange: [80, 60],
    extrapolate: 'clamp',
  });
  return (
    <Reanimated.View style={pressAnimatedStyle}>
      <HapticTouchableOpacity
        activeOpacity={isAndroid ? 0.9 : 0.7}
        onPress={onPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
      >
        <Animated.View
          style={[
            styles.container,
            horizontal && styles.containerHorizontal,
            style,
            !!scrollY && {
              minHeight,
              maxHeight,
              paddingVertical,
              minWidth,
              maxWidth,
            },
          ]}
        >
          <GradientIcon
            source={icon}
            iconSize={16}
            imageStyle={{tintColor: disabled ? '#adadad' : colors.black}}
          />
          {label && (
            <Animated.Text
              as={Text.type.P4}
              numberOfLines={2}
              style={[
                styles.label,
                horizontal && styles.labelHorizontal,
                {...(disabled && {color: '#adadad'})},
                {opacity: textOpacity},
              ]}
              allowFontScaling={false}
            >
              {label}
            </Animated.Text>
          )}
          {badge && (
            <View
              style={[styles.badge, horizontal && styles.badgeHorizontal]}
            />
          )}
        </Animated.View>
      </HapticTouchableOpacity>
    </Reanimated.View>
  );
};
