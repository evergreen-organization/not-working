import React, {useState} from 'react';
import {useCasaModule} from '../hooks/useCasaModule';
import {SummaryDetailsTemplate} from '@/components/templates';
import {NotesPopUp} from '@/components/organisms';
import {
  MoneyMarketHeader,
  MoneyMarketList,
} from '../components/moneyMarketList';
import {CasaHistoryScreen} from '@/screens/AccountModule/CasaModule/CasaHistoryScreen';
import {AccountNavigatorProps} from '@/types/navigation';
import {routes} from '@/navigations';
import {gradientColors} from '@/styles';

export const CasaAccountDetails = ({
  route,
}: AccountNavigatorProps<routes.CASA_DETAILS>) => {
  const {account} = route.params;
  const [isMoneyMarketGrid, setIsMoneyMarketGrid] = useState(false);
  const {
    casaData,
    accountInfo,
    views,
    details,
    fcData,
    fcDataList,
    renderCurrency,
    isLoading,
    isSummaryLoading,
    moneyMarketVisible,
    onMoneyMarketClose,
    moneyMarket,
    mmLoading,
  } = useCasaModule({
    account,
  });

  const data =
    casaData?.data?.accounts?.find(
      (item: any) => item.accountNo === account.accountNo,
    ) || account;
  const isFCY = !!account?.currencies?.length;

  let accountData = {...data, ...fcData, accountDesc: account.accountDesc};

  return (
    <SummaryDetailsTemplate
      navBarTitle={'Accounts'}
      accountInfo={accountInfo(accountData)}
      details={details(accountData)}
      views={views(accountData)}
      account={accountData}
      list={fcDataList}
      isFCY={isFCY}
      isLoading={isLoading || isSummaryLoading}
      renderCurrency={renderCurrency}
      historyComp={
        <CasaHistoryScreen
          accountData={{
            accountNo: accountData.accountNo,
            currency: accountData.currency,
            accountName: accountData.accountName,
            currencies: accountData.currencies,
          }}
        />
      }
      topCardTitle={'Available Balance'}
      topCardValue={accountData.availableBalance}
      topCardCurrency={accountData.currency}
      active={accountData.accountStatus}
    >
      <NotesPopUp
        isVisible={moneyMarketVisible}
        onClose={onMoneyMarketClose}
        title="Placements"
        // subtitle="View your placement details and terms"
        titleInfo={`1. Upon maturity, the initial placement amount and the interest/profit earned will be credited back to the originating savings / -i or current / -i account. \n2. Please contact the placement branch for assistance.`}
        loading={mmLoading}
        headerStyle={{backgroundColor: gradientColors.primary[0]}}
        headerContent={
          <MoneyMarketHeader
            count={
              (moneyMarket?.active?.length ?? 0) +
              (moneyMarket?.mature?.length ?? 0)
            }
            isGrid={isMoneyMarketGrid}
            onToggleGrid={() => setIsMoneyMarketGrid(!isMoneyMarketGrid)}
          />
        }
      >
        <MoneyMarketList
          data={moneyMarket}
          currency={accountData.currency}
          isGrid={isMoneyMarketGrid}
        />
      </NotesPopUp>
    </SummaryDetailsTemplate>
  );
};
