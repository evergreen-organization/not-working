export interface CasaAccountTypeListProps {
  route: {
    params: {
      accountType: string;
    };
  };
}

export interface CasaAccountDetailsProps {
  account: {
    accountNo: string;
    accountDesc: string;
    accountName: string;
    currentBalance: string;
    currency: string;
    availableBalance?: string;
  };
  navigation: any;
}

export interface CasaAccountProps {
  accountNo: string;
  accountDesc: string;
  accountName: string;
  currentBalance: string;
  currency: string;
  availableBalance?: string;
  oneDayFloat?: string;
  onlineFloat?: string;
  odLimit?: string;
  accountStatus?: boolean;
  statusType?: string;
  accountType?: string;
  interestPaidYtd?: string;
  interestAccrual?: string;
  holdAmt?: string;
  errorMsg?: string;
  mmdExist?: boolean;
}
