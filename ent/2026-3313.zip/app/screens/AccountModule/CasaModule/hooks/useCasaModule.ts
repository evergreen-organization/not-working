import {useNavigation} from '@react-navigation/native';
import {useSession} from '@/hooks';
import {routes} from '@/navigations';
import {useAccount} from '@/navigations/providers/AccountProvider';
import {LOADING} from '@/api';

import AddIcon from '@/assets/images/icon/dashboardAdd.png';
import RemoveIcon from '@/assets/images/icon/dashboardRemove.png';
import RetryIcon from '@/assets/images/icon/retry.png';
import PlacementIcon from '@/assets/images/icon/percent.png';
import {usePrefAccount} from '@/navigations/providers/PrefAccountProvider';
import {CasaAccountProps} from '../type';
import {tagColors} from '@/styles';
import {useCallback, useEffect, useMemo, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {
  getCasaMoneyMarketByAccount,
  getCurrentUser,
  getSettings,
  requestCasaHistory,
  requestCasaMoneyMarket,
  requestForeignCurrency,
  resetCasaHistory,
  resetCasaMoneyMarket,
} from '@/store';
import {lastNMonthAbbrv, showFailure} from '@/utils';
import {TRANS_SORT, TRANS_TYPE} from '@/constants';

export const useCasaModule = ({account} = {}) => {
  useSession();
  const dispatch = useDispatch();
  const [isLoading, setLoading] = useState(false);
  const [fcData, setFcData] = useState({});
  const [moneyMarketVisible, setMoneyMarketVisible] = useState(false);
  const [mmLoading, setMmLoading] = useState(false);
  const [initialCurrencyValue, setInitialCurrencyValue] = useState(
    account?.currency === 'MYM' ? account?.currencies?.[0] : account?.currency,
  );
  const user = useSelector(getCurrentUser);
  const {deviceId} = useSelector(getSettings);

  const refreshHistory = ({
    currency,
    accountNo,
  }: {
    currency: string;
    accountNo: string;
  }) => {
    const months = lastNMonthAbbrv();
    const month = months[0].value;
    const tranType = TRANS_TYPE[0].value;
    const sortType = TRANS_SORT[3].value;
    dispatch(resetCasaHistory());
    dispatch(
      requestCasaHistory({
        accountNo,
        month: month,
        pageNo: '0',
        tranType,
        sortType,
        currency,
      }),
    );
  };

  const getForeignCurrencyData = useCallback(
    async request => {
      try {
        setLoading(true);
        const {payload} = await dispatch(requestForeignCurrency(request));
        setLoading(false);

        if (payload?.problem) {
          return showFailure(payload.problem);
        }

        setFcData(payload.accountDetails);
        if (isAddedtoPA(request.accountNo)) {
          addToPreferred(payload.accountDetails);
        }
      } catch (err) {
        setLoading(false);
        console.error('Fetch error:', err);
        showFailure('Unexpected error occurred');
      }
    },
    [dispatch],
  );

  const renderCurrency = useCallback(
    currency => {
      if (!account?.accountNo) return;

      setInitialCurrencyValue(currency);
      getForeignCurrencyData({
        currency,
        accountNo: account.accountNo,
      });
      refreshHistory({currency: currency, accountNo: account.accountNo});
    },
    [account, getForeignCurrencyData],
  );

  const FCY = useMemo(() => {
    if (!account?.currencies?.length) return {};
    return {
      data: account?.currencies.map(item => ({
        title: item,
        label: item,
        value: item,
      })),
      initialValue: initialCurrencyValue,
    };
  }, [account, initialCurrencyValue]);

  useEffect(() => {
    if (!account?.currencies?.length || !account.accountNo) return;
    getForeignCurrencyData({
      currency: initialCurrencyValue,
      accountNo: account.accountNo,
    });
  }, [account]);

  const navigation = useNavigation();
  const {data} = useAccount();
  const {isAddedToPreferred, addToPreferred, removeFromPreferred} =
    usePrefAccount();

  const accountList = data.find(item => item.id === 'accounts')?.data;

  const accountConfig = {
    title: 'Accounts',
    route: routes.CASA_DETAILS,
    requestSummary: () => data.find(item => item.id === 'accounts')?.onRetry(),
    getBalance: item => item.availableBalance || '',
    getIcon: () => 'S',
  };

  const navigateTo = (item: CasaAccountProps) =>
    navigation.navigate(routes.ACCOUNTS_MODULE, {
      screen: routes.CASA_DETAILS,
      params: {account: item},
    });

  const handleRefresh = () => {
    if (accountList?.accountsStatus === LOADING || !accountConfig) return;
    accountConfig.requestSummary?.();
  };

  const isAddedtoPA = (accountNo: string) => isAddedToPreferred(accountNo);

  const moneyMarket = useSelector(state =>
    getCasaMoneyMarketByAccount(state, account?.accountNo),
  );

  useEffect(() => {
    return () => {
      dispatch(resetCasaMoneyMarket());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onMoneyMarketPress = async (accountNo: string) => {
    setMmLoading(true);
    setMoneyMarketVisible(true);
    try {
      const {payload} = await dispatch(
        requestCasaMoneyMarket({
          accountNo,
          encryptedId: user?.encryptedId,
          deviceId,
        }),
      );
      if (payload.problem) {
        showFailure(payload.problem);
        return;
      }
    } finally {
      setMmLoading(false);
    }
  };

  const onMoneyMarketClose = () => {
    setMoneyMarketVisible(false);
  };

  const accountInfo = (account: CasaAccountProps) => ({
    title: account.accountDesc,
    subtitle: account.accountNo,
    description: account.accountName,
  });

  const details = (account: CasaAccountProps) =>
    isLoading
      ? [{title: 'Loading...', loading: true}]
      : [
          {title: 'Account Holder', value: account.accountName},
          {title: 'Account Name', value: account.accountDesc},
          {title: 'Account No.', value: account.accountNo},
          {
            title: 'Available Balance',
            value: account.availableBalance,
            currency: account.currency,
          },
          {
            title: 'Current Balance',
            value: account.currentBalance,
            currency: account.currency,
          },
          {
            title: 'Interest Paid YTD',
            value: account.interestPaidYtd || '',
            currency: account.currency,
          },
          {
            title: 'Interest Accrual',
            value: account.interestAccrual || '',
            currency: account.currency,
          },
          {
            title: 'Hold Amount',
            value: account.holdAmt || '',
            currency: account.currency,
          },
          {
            title: 'One Day Float',
            value: account.oneDayFloat || '',
            currency: account.currency,
          },
          {
            title: 'Online Float',
            value: account.onlineFloat || '',
            currency: account.currency,
          },
          {
            title: 'OD Limit',
            value: account.odLimit || '',
            currency: account.currency,
          },
          {
            title: 'Status',
            tagList: [
              {
                title: account.accountStatus
                  ? 'Active'
                  : account.statusType || 'Inactive',
                color: account.accountStatus ? tagColors.green : tagColors.red,
              },
            ],
          },
        ];

  const views = (account: CasaAccountProps) => {
    const retryView = {
      icon: RetryIcon,
      onPress: handleRefresh,
      disabled: accountList?.accountsStatus === LOADING,
    };
    const moneyMarketView = {
      icon: PlacementIcon,
      label: 'Money Market Deposit',
      onPress: () => onMoneyMarketPress(account.accountNo),
    };
    const dashboardView = isAddedtoPA(account.accountNo)
      ? {
          icon: RemoveIcon,
          label: 'Remove from Dashboard',
          onPress: () => removeFromPreferred(account.accountNo),
        }
      : {
          icon: AddIcon,
          label: 'Add to Dashboard',
          onPress: () => addToPreferred(account),
        };

    return account?.mmdExist
      ? [retryView, moneyMarketView, dashboardView]
      : [retryView, dashboardView];
  };

  const casaData = data.find(item => item.id === 'accounts');

  return {
    casaData,
    // Account list specific
    accountList,
    accountConfig,
    navigateTo,
    handleRefresh,
    fcData,
    fcDataList: FCY,
    renderCurrency,
    isLoading,
    isSummaryLoading: accountList?.accountsStatus === LOADING,
    // Account details specific
    isAddedtoPA,
    accountInfo,
    details,
    views,
    // Money Market Deposit specific
    moneyMarketVisible,
    onMoneyMarketClose,
    moneyMarket,
    mmLoading,
  };
};
