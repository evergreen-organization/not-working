import React, {useState} from 'react';
import {TouchableOpacity, View} from 'react-native';
import {Icon, Text} from '@/components/atoms';
import {NoteCard} from '@/components/molecules';
import {styles} from './styles';
import {colors} from '@/styles';
import ArrowUpIcon from '@/assets/images/icon/up-arrow.png';

export * from './header';

const PREVIEW_COUNT = 2;

const TERM_UNIT_LABELS: Record<string, string> = {
  D: 'Days',
  M: 'Months',
  Y: 'Years',
};

const formatTenure = (tenure?: number, termUnit?: string) => {
  if (tenure === null || tenure === undefined) return undefined;
  return `${tenure} ${
    TERM_UNIT_LABELS[termUnit ?? ''] ?? termUnit ?? ''
  }`.trim();
};

export interface MoneyMarketListProps {
  data?: {active?: any[]; mature?: any[]};
  currency?: string;
  isGrid?: boolean;
}

export const MoneyMarketList: React.FC<MoneyMarketListProps> = ({
  data,
  currency,
  isGrid = false,
}) => {
  const [activeExpanded, setActiveExpanded] = useState(false);
  const [maturedExpanded, setMaturedExpanded] = useState(false);

  const active = data?.active ?? [];
  const matured = data?.mature ?? [];

  const renderCards = (items: any[], isMatured: boolean) => (
    <View style={isGrid && styles.gridWrap}>
      {items.map(item => (
        <View key={item.refNo} style={isGrid && styles.gridItem}>
          <NoteCard
            refNo={item.refNo}
            rate={`${item.interestRate} % p.a.`}
            isMatured={isMatured}
            amount={item.initialPlacement}
            currency={currency}
            startDate={item.startDate}
            endDate={item.endDate}
            productName={item.title}
            branch={item.branch}
            tenure={formatTenure(item.tenure, item.termUnit)}
            grid={isGrid}
          />
        </View>
      ))}
    </View>
  );

  const renderSection = (
    items: any[],
    isMatured: boolean,
    isExpanded: boolean,
    onToggle: () => void,
  ) => {
    const visibleItems = isExpanded ? items : items.slice(0, PREVIEW_COUNT);
    const hiddenCount = items.length - PREVIEW_COUNT;

    return (
      <>
        {renderCards(visibleItems, isMatured)}
        {hiddenCount > 0 && (
          <TouchableOpacity style={styles.viewMoreButton} onPress={onToggle}>
            <Text as={Text.type.P4} style={styles.viewMoreText} params={{}}>
              {isExpanded ? 'View Less' : `View More (${hiddenCount})`}
            </Text>
            {isExpanded && (
              <Icon source={ArrowUpIcon} size={14} color={colors.primary} />
            )}
          </TouchableOpacity>
        )}
      </>
    );
  };

  return (
    <View style={styles.container}>
      {active.length > 0 && (
        <>
          <View style={styles.sectionHeader}>
            <View style={[styles.sectionDot, styles.activeDot]} />
            <Text
              as={Text.type.P4}
              style={[styles.sectionHeaderText, styles.activeText]}
              params={{}}
            >
              {`${active.length} Active`}
            </Text>
            <View style={styles.sectionDivider} />
          </View>
          {renderSection(active, false, activeExpanded, () =>
            setActiveExpanded(!activeExpanded),
          )}
        </>
      )}

      {matured.length > 0 && (
        <>
          <View style={[styles.sectionHeader, styles.sectionHeaderSpaced]}>
            <View style={[styles.sectionDot, styles.maturedDot]} />
            <Text
              as={Text.type.P4}
              style={[styles.sectionHeaderText, styles.maturedText]}
              params={{}}
            >
              {`${matured.length} Matured`}
            </Text>
            <View style={styles.sectionDivider} />
          </View>
          {renderSection(matured, true, maturedExpanded, () =>
            setMaturedExpanded(!maturedExpanded),
          )}
        </>
      )}

      {!active.length && !matured.length && (
        <Text as={Text.type.P4} style={styles.emptyText} params={{}}>
          No Placements Available
        </Text>
      )}
    </View>
  );
};
