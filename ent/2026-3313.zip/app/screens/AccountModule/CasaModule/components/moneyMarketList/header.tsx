import React, {useCallback, useState} from 'react';
import {Alert, Linking, TouchableOpacity, View} from 'react-native';
import {Icon, Tag, Text} from '@/components/atoms';
import {BottomPopUp} from '@/components/molecules';
import {URL_PIDM} from '@/constants';
import {styles} from './styles';
import {colors} from '@/styles';
import GridIcon from '@/assets/images/icon/dashboards.png';
import RowIcon from '@/assets/images/icon/row.png';

export interface MoneyMarketHeaderProps {
  count: number;
  enablePIDM?: boolean;
  isGrid: boolean;
  onToggleGrid: () => void;
}

export const MoneyMarketHeader: React.FC<MoneyMarketHeaderProps> = ({
  count,
  enablePIDM = false,
  isGrid,
  onToggleGrid,
}) => {
  const [pidmModalVisible, setPidmModalVisible] = useState(false);
  const [pidmNotModalVisible, setPidmNotModalVisible] = useState(false);

  const handlePIDMTagPress = useCallback(() => {
    setPidmModalVisible(true);
  }, []);

  const handleNotPIDMTagPress = useCallback(() => {
    setPidmNotModalVisible(true);
  }, []);

  const handlePIDMLinkPress = useCallback(() => {
    Alert.alert(
      'Redirect from PB enterprise',
      "You will be redirected to Public Bank's website on your browser.",
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'OK',
          onPress: () => {
            Linking.openURL(URL_PIDM.uri).catch(err =>
              console.error("Couldn't load page", err),
            );
          },
        },
      ],
    );
  }, []);

  const renderPIDMProtectedModal = () => {
    return (
      <BottomPopUp
        isVisible={pidmModalVisible}
        onClose={() => setPidmModalVisible(false)}
      >
        <View style={{padding: 20}}>
          <Text as={Text.type.P10}>PIDM</Text>
          <Text as={Text.type.P9} style={{paddingTop: 10}}>
            Protected by PIDM up to RM250,000 for each depositor.{'\n'}View the{' '}
            <Text
              style={{
                color: colors.primary,
                textDecorationLine: 'underline',
                fontWeight: '500',
              }}
              onPress={handlePIDMLinkPress}
            >
              List of Insured Deposits.
            </Text>{' '}
          </Text>
        </View>
      </BottomPopUp>
    );
  };

  const renderPIDMNotProtectedModal = () => {
    return (
      <BottomPopUp
        isVisible={pidmNotModalVisible}
        onClose={() => setPidmNotModalVisible(false)}
      >
        <View style={{padding: 20}}>
          <Text as={Text.type.P10}>PIDM</Text>
          <Text as={Text.type.P9} style={{paddingTop: 10}}>
            Not protected by PIDM
          </Text>
        </View>
      </BottomPopUp>
    );
  };

  return (
    <View style={styles.headerRow}>
      <View style={styles.listHeaderLeft}>
        <Text as={Text.type.P12} style={styles.headerRowTitle} params={{}}>
          {`${count} Money Market Deposit (s)`}
        </Text>
        {enablePIDM !== undefined && (
          <View style={{overflow: 'hidden', marginLeft: 10}}>
            <Tag
              title="PIDM"
              onPress={
                enablePIDM === true ? handlePIDMTagPress : handleNotPIDMTagPress
              }
              typography={Text.type.P15}
              colorScheme={
                enablePIDM === true
                  ? Tag.colorScheme.default
                  : Tag.colorScheme.info
              }
              style={{marginRight: 0}}
            />
            {enablePIDM === false && (
              <View
                style={{
                  position: 'absolute',
                  width: 45,
                  height: 1,
                  backgroundColor: Tag.colorScheme.info.primary,
                  top: 10,
                  transform: [{rotate: '22deg'}],
                }}
              />
            )}
          </View>
        )}
      </View>
      <TouchableOpacity onPress={onToggleGrid} style={styles.toggleButton}>
        <Icon
          source={isGrid ? GridIcon : RowIcon}
          size={20}
          color={colors.white}
        />
      </TouchableOpacity>

      {renderPIDMProtectedModal()}
      {renderPIDMNotProtectedModal()}
    </View>
  );
};
