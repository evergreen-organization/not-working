import {StyleSheet} from 'react-native';
import {colors, tagColors} from '@/styles';

export const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 0,
    backgroundColor: 'rgba(0,0,0,0.1)',
    paddingVertical: 10,
    paddingHorizontal: 24,
  },
  headerRowTitle: {
    color: colors.white,
    fontSize: 15,
    fontWeight: '700',
    flexShrink: 1,
  },
  listHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flexShrink: 1,
  },
  toggleButton: {
    width: 36,
    height: 36,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    marginTop: 2,
    paddingHorizontal: 4,
  },
  sectionHeaderSpaced: {
    marginTop: 14,
  },
  sectionDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  activeDot: {
    backgroundColor: tagColors.green.primary,
  },
  maturedDot: {
    backgroundColor: tagColors.orange.primary,
  },
  sectionDivider: {
    flex: 1,
    height: 1,
    backgroundColor: colors.ultraLightGrey,
    marginLeft: 4,
  },
  sectionHeaderText: {
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  activeText: {
    color: tagColors.green.primary,
  },
  maturedText: {
    color: tagColors.orange.primary,
  },
  gridWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  gridItem: {
    width: '48.5%',
  },
  viewMoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    marginTop: -2,
    marginBottom: 8,
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
  },
  viewMoreText: {
    color: colors.primary,
    fontWeight: '700',
    fontSize: 13,
  },
  emptyText: {
    textAlign: 'center',
    color: colors.darkGrey,
    marginTop: 24,
  },
});
