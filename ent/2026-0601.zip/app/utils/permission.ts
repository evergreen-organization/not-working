import messaging from '@react-native-firebase/messaging';
import {
  requestNotifications,
  RESULTS,
  PermissionStatus,
} from 'react-native-permissions';
import {Alert, Linking, PermissionsAndroid, Platform} from 'react-native';

export const PUSH_NOTIFICATION_PERMISSION_TITLE =
  'Notifications permission is required';
export const PUSH_NOTIFICATION_PERMISSION_MESSAGE =
  'Go to settings and turn on access';

const requestIOSNotification = async (): Promise<boolean> => {
  const authorizationStatus = await messaging().requestPermission();
  return (
    authorizationStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authorizationStatus === messaging.AuthorizationStatus.PROVISIONAL
  );
};

export const checkPushNotificationPermission = async (): Promise<boolean> => {
  try {
    if (Platform.OS === 'ios') {
      return requestIOSNotification();
    }

    // POST_NOTIFICATIONS is only required on Android 13+ (API 33);
    // on older versions notifications are granted by default.
    if (Number(Platform.Version) >= 33) {
      const hasPermission = await PermissionsAndroid.check(
        PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS,
      );
      if (hasPermission) {
        return true;
      }

      const result = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS,
      );
      return result === PermissionsAndroid.RESULTS.GRANTED;
    }

    return true;
  } catch (error) {
    console.warn('Error checking notification permission:', error);
    return false;
  }
};

export const requestPushNotificationPermission = async (): Promise<boolean> => {
  if (Platform.OS === 'ios') {
    const permission = await requestIOSNotification();
    if (!permission) {
      promptNotificationPermission();
    }
    return permission;
  }

  const {status} = await requestNotifications();
  if (checkResult(status)) {
    return true;
  }

  promptNotificationPermission();
  return false;
};

const promptNotificationPermission = (): void => {
  grantPermission(
    PUSH_NOTIFICATION_PERMISSION_TITLE,
    PUSH_NOTIFICATION_PERMISSION_MESSAGE,
  );
};

export const checkResult = (result: PermissionStatus): boolean => {
  switch (result) {
    case RESULTS.DENIED:
    case RESULTS.BLOCKED:
    case RESULTS.UNAVAILABLE:
      return false;
    case RESULTS.LIMITED:
    case RESULTS.GRANTED:
      return true;
  }
};

export const grantPermission = (title: string, desc: string): void => {
  Alert.alert(
    title,
    desc,
    [
      {
        text: "Don't allow",
      },
      {
        text: 'Go to settings',
        onPress: () => {
          Linking.openSettings().then();
        },
      },
    ],
    {cancelable: false},
  );
};
