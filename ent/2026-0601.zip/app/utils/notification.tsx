import {useNavigation} from '@react-navigation/native';
import {useEffect, useRef, useState} from 'react';
import Toast from 'react-native-toast-message';
import {useSelector} from 'react-redux';
import {useAppDispatch} from '@/store';
import {RenderHTML} from 'react-native-render-html';
import {
  APP_MESSAGE_ACTION,
  NOTIFICATION_ACTION,
  TOAST_SECURE_SIGN,
} from '@/constants';
import {useFireBaseListener} from '@/hooks/useFireBaseListener';
import {useHmsListener} from '@/hooks/useHmsListener';
import {routes} from '@/navigations';
import {
  getCurrentUser,
  getNotificationData,
  getSoftTokenPendingTransaction,
  isLoggedIn,
  logout,
  pushIndicatorStored,
  requestAlerts,
  getSettings,
} from '@/store';
import {
  clearIOSBadgeNotification,
  isFirebaseSupported,
} from './notificationUtils';

import {Button, Loading} from '@/components/atoms';
import {PopUpBox} from '@/components';

import moment from 'moment';
import {Linking, StyleSheet, useWindowDimensions, View} from 'react-native';

import {useAppState} from '@/hooks';
import {NavigationContainerRef} from '@react-navigation/native';
import {colors} from '@/styles';

interface User {
  userId: string;
}

interface NotificationData {
  id: string;
  action?: string;
  msgId?: string;
}

interface PendingTransaction {
  transactionId?: string;
}

interface NotificationAction {
  action: string;
  id: string;
  msgId?: string;
  notifRefNo?: string;
}
interface AlertNotification {
  subject: string;
  content: string;
  transtamp: string;
  notifrefno: string;
}
interface NotificationContainerProps {
  navigationRef: NavigationContainerRef<any>;
}

const isSameUser = (currentUser: User | null, userId: string): boolean =>
  currentUser?.userId === userId;

const isPendingTransactionAction = (action: string): boolean =>
  action === NOTIFICATION_ACTION.PENDING_TRX;

export const NotificationContainer = ({
  navigationRef,
}: NotificationContainerProps) => {
  const dispatch = useAppDispatch();
  const navigation = useNavigation();
  const store_currentUser = useSelector(getCurrentUser);
  const currentUser = useRef<User | null>(store_currentUser);
  const pendingTran = useSelector(
    getSoftTokenPendingTransaction,
  ) as PendingTransaction;
  const loggedIn = useSelector(isLoggedIn);
  const fireBaseListener = useFireBaseListener();
  const hmsListener = useHmsListener();
  const {deviceId} = useSelector(getSettings);
  const deviceIdRef = useRef(deviceId);
  const [showAlertPopup, setShowAlertPopup] = useState(false);
  const [popupData, setPopupData] = useState<AlertNotification | null>(null);
  const {width} = useWindowDimensions();
  const loggedInRef = useRef(loggedIn);
  const notificationData = useSelector(getNotificationData) as NotificationData;
  const [isLoading, setIsLoading] = useState(false);
  const isBackground = useAppState();
  const [initialRender, setInitialRender] = useState(true);

  const isSameRoute = (path: string): boolean =>
    navigationRef.getCurrentRoute()?.name === path;

  const checkShowToast = (): boolean => {
    const isDifferentUser = !isSameUser(
      currentUser.current,
      notificationData?.id,
    );
    if (isDifferentUser || isSameRoute(routes.SOFT_TOKEN_PENDING_TRANSACTION)) {
      return isDifferentUser;
    }
    return false;
  };

  const onClose = () => {
    setShowAlertPopup(false);
  };
  useEffect(() => {
    if (initialRender) {
      return;
    }
    if (isBackground) {
      return;
    }

    if (notificationData?.id && checkShowToast()) {
      secureSignToast(notificationData.id);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isBackground]);

  useEffect(() => {
    currentUser.current = store_currentUser;
  }, [store_currentUser]);
  useEffect(() => {
    loggedInRef.current = loggedIn;
  }, [loggedIn]);
  useEffect(() => {
    deviceIdRef.current = deviceId;
  }, [deviceId]);
  useEffect(() => {
    setInitialRender(false);
    (async () => {
      await createNotificationListener();
    })(); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const createNotificationListener = async (): Promise<void> => {
    const checkFirebase = await isFirebaseSupported();
    if (checkFirebase) {
      return fireBaseListener.createListener({
        checkAction,
        checkActionInitial,
        secureSignToast,
      });
    } else {
      return hmsListener.createListener({
        checkAction,
        checkActionInitial,
        secureSignToast,
      });
    }
  };

  useEffect(() => {
    if (pendingTran?.transactionId) {
      if (isSameRoute(routes.SOFT_TOKEN_PENDING_TRANSACTION)) {
        return;
      }
      secureSignToast(notificationData?.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingTran?.transactionId]);

  const goPendingTranModule = (id: string): void =>
    checkCurrentUser(routes.SOFT_TOKEN_LOADING_TRANSACTION, id);

  const goNotificationModule = (id: string, msgId?: string): void => {
    if (msgId) {
      checkCurrentUser(routes?.MAIL);
    }
  };
  const getNotificationDetails = async (
    notiRef: string,
  ): Promise<AlertNotification | null> => {
    try {
      setIsLoading(true);

      const {payload} = await dispatch(
        requestAlerts({
          encryptedId: currentUser.current?.encryptedId,
          deviceId: deviceIdRef.current,
        }),
      );

      const notification = payload?.notificationList?.find(
        item => item.notifrefno === notiRef,
      );

      return notification || null;
    } catch (error) {
      console.error('Failed to get notification details:', error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const goAlertNotificationModule = async (
    userId: string,
    notifRefNo: string,
  ) => {
    const isSame = isSameUser(currentUser.current, userId);

    if (!isSame) {
      return checkUserAlert(userId, notifRefNo);
    }

    if (!notifRefNo) {
      return;
    }

    const notification = await getNotificationDetails(notifRefNo);

    if (notification) {
      setPopupData(notification);
      setShowAlertPopup(true);
    } else {
      console.warn('Notification not found or failed to fetch');
      setShowAlertPopup(false);
    }
  };

  const secureSignToast = (id: string): void => {
    (async () => await clearIOSBadgeNotification())();
    Toast.show({
      type: TOAST_SECURE_SIGN,
      onPress: async (action: string) => {
        if (action === APP_MESSAGE_ACTION.VIEW) {
          dispatch(pushIndicatorStored({notificationLoading: true}));
          await checkCurrentUser(
            routes.SOFT_TOKEN_LOADING_TRANSACTION,
            id,
            true,
          );
          dispatch(pushIndicatorStored({notificationLoading: false}));
        }
        Toast.hide();
      },
    });
  };

  const checkAction = ({
    action,
    id,
    msgId,
    notifRefNo,
  }: NotificationAction): {
    showToast: boolean;
    toastType?: string;
    pressAction?: () => void;
    id?: string;
    notifRefNo?: string;
  } => {
    if (isPendingTransactionAction(action)) {
      return {
        /**
         Show toast:
         1. Alternate user receives push notification
         2. Screens other than PendingTransaction as it will reload upon receive push notification
         **/
        showToast:
          !currentUser.current?.userId ||
          !isSameUser(currentUser.current, id) ||
          !isSameRoute(routes.SOFT_TOKEN_PENDING_TRANSACTION),
        toastType: TOAST_SECURE_SIGN,
        pressAction: () => goPendingTranModule(id),
        id,
      };
    } else if (action === 'alert') {
      return {
        showToast: true,
        pressAction: () => goAlertNotificationModule(id, notifRefNo),
      };
    }
    return {
      showToast: true,
      pressAction: () => goNotificationModule(id, msgId),
    };
  };

  const checkActionInitial = (data: NotificationAction): void => {
    // Open app will call initUser, no need to call getPendingTransaction
    if (isPendingTransactionAction(data?.action)) {
      if (isSameUser(currentUser.current, data?.id)) {
        return;
      }
      return checkCurrentUser(routes.SOFT_TOKEN_LOADING_TRANSACTION, data?.id);
    } else if (data?.action === 'alert') {
      return goAlertNotificationModule(data.id, data.notifRefNo ?? '');
    }
    return goNotificationModule(data?.id, data?.msgId);
  };

  const checkCurrentUser = async (
    path: string,
    userId: string,
    wait = false,
  ): Promise<void> => {
    if (
      !currentUser.current?.userId ||
      !isSameUser(currentUser.current, userId)
    ) {
      wait ? await dispatch(logout()) : dispatch(logout());
      return navigation.navigate(routes.NOTIFICATION_ROUTING, {
        path: routes.LOGIN_PIN,
        params: {userId, path},
      });
    }

    if (isSameRoute(path) && loggedIn) {
      return;
    }

    navigation.navigate(routes.NOTIFICATION_ROUTING, {
      path: routes.HOME_LOADING,
      params: {path},
    });
  };

  const renderPopUpBox = (data: AlertNotification, isLoading: boolean) => {
    const formattedDate = data?.transtamp
      ? moment(data.transtamp).format('DD MMM YY').toUpperCase()
      : '';

    const content = isLoading ? (
      <View style={{minHeight: 100, justifyContent: 'center'}}>
        <Loading size="large" color={colors.lightMedium} />
      </View>
    ) : (
      <View style={{maxWidth: width - 60, paddingBottom: 20}}>
        <RenderHTML
          disableTopShadow
          bottomShadowPosition={100}
          baseStyle={{
            fontSize: 12,
            fontWeight: 'normal',
            fontFamily: 'Nunito-Regular',
          }}
          containerStyle={{padding: 24}}
          html={data?.content ?? ''}
          onLinkPress={href => {
            if (href) {
              Linking.openURL(href);
            }
          }}
        />
      </View>
    );

    return (
      <PopUpBox
        isVisible={showAlertPopup}
        onClose={onClose}
        contentStyle={styles.popContentStyle}
        descriptionStyle={styles.descriptionStyle}
        style={styles.popUpHeaderStyle}
        titleNumberOfLine={2}
        date={!isLoading ? formattedDate : undefined}
        title={!isLoading ? data?.subject : undefined}
        desc={!isLoading ? content : undefined}
      >
        <View style={styles.popButtonContainer}>
          <Button
            style={styles.popCloseButton}
            title="Close"
            onPress={onClose}
          />
        </View>
      </PopUpBox>
    );
  };

  const checkUserAlert = async (
    userId: string,
    notifRefNo: string,
  ): Promise<void> => {
    if (loggedInRef.current) {
      await dispatch(logout());
    }

    navigation.navigate(routes.NOTIFICATION_ROUTING, {
      path: routes.LOGIN_PIN,
      params: {userId, path: routes.MAIN_TAB, notifRefNo},
    });
  };
  return <>{showAlertPopup && renderPopUpBox(popupData, isLoading)}</>;
};
export const styles = StyleSheet.create({
  popContentStyle: {
    backgroundColor: colors.ultraLightGrey,
    padding: 16,
    borderRadius: 10,
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    paddingHorizontal: 36,
  },
  descriptionStyle: {textAlign: 'center'},
  popCloseButton: {
    flex: 1,
  },
  popButtonContainer: {flexDirection: 'row', padding: 20},
  popUpHeaderStyle: {paddingHorizontal: 0, paddingVertical: 0},
});
