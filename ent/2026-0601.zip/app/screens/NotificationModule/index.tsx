import React, {useEffect, useRef} from 'react';
import {Button, Screen, Space} from '@/components/atoms';
import {Navbar, PopUpBox} from '@/components';
import MailboxIcon from '@/assets/images/icon/mailbox2.png';
import ALertsIcon from 'assets/images/icon/alert.png';
import AnnouncementsIcon from '@/assets/images/icon/announcements.png';
import Animated, {SlideInLeft, SlideOutRight} from 'react-native-reanimated';
import {TabBar} from './components/tabBar';
import {styles} from './styles';
import {TabContent} from './components/tabContent';
import {Linking, useWindowDimensions, View} from 'react-native';
import {colors} from '@/styles';
import {URL_ANNOUNCEMENTS} from '@/constants';
import WebView from 'react-native-webview';
import {useAllNotification} from './hooks';
import {RenderHTML} from 'react-native-render-html';
import moment from 'moment';

export const NotificationScreen: React.FC = () => {
  const {width} = useWindowDimensions();
  const {
    allNotifications,
    alertPopupDetails,
    onCloseAlert,
    onSelectAlert,
    showAlertPopup,
    handleWebViewMessage,
    handleWebViewError,
    injectedJavaScript,
    onRefresh,
    onDelete,
    onSelect,
    onClose,
    showPopup,
    popupDetails,
    deleting,
    loadingMail,
    alertLoading,
    loadingAnnc,
    webViewKey,
    activeTab,
    onTabChange,
  } = useAllNotification();
  const hasFetchedAnnouncements = useRef(false);
  const popupCreatedDate = popupDetails?.createdDate;

  const formattedPopupDate =
    popupCreatedDate && /^\d{2}\s+[A-Za-z]{3}\s+\d{4}$/.test(popupCreatedDate)
      ? popupCreatedDate
          .toLowerCase()
          .replace(/\b\w/g, (character: string) => character.toUpperCase())
      : popupCreatedDate;

  useEffect(() => {
    hasFetchedAnnouncements.current = true;
  }, []);

  return (
    <>
      <Screen>
        <Navbar title="Notifications" back />
        <TabBar
          tabs={[
            {title: 'All', loading: loadingMail || alertLoading || loadingAnnc},
            {title: 'Alerts', icon: ALertsIcon, loading: alertLoading},
            {title: 'Mailbox', icon: MailboxIcon, loading: loadingMail},
            {
              title: 'Announcements',
              icon: AnnouncementsIcon,
              loading: loadingAnnc,
            },
          ]}
          activeTab={activeTab}
          onChange={onTabChange}
          style={styles.tabBar}
        />
        <Animated.View
          entering={SlideInLeft}
          exiting={SlideOutRight}
          style={styles.animatedView}
        >
          <TabContent
            activeTab={activeTab}
            allNotifications={allNotifications}
            loadingMail={loadingMail}
            alertLoading={alertLoading}
            loadingAnnc={loadingAnnc}
            onRefresh={onRefresh}
            onSelect={onSelect}
            onSelectAlert={onSelectAlert}
          />
        </Animated.View>
        <PopUpBox
          contentStyle={styles.popContentStyle}
          style={styles.popUpHeaderStyle}
          titleNumberOfLine={3}
          descriptionStyle={styles.descriptionStyle}
          isVisible={showPopup}
          date={formattedPopupDate}
          title={popupDetails?.subject}
          onClose={onClose}
        >
          <RenderHTML
            disableTopShadow
            bottomShadowPosition={100}
            baseStyle={{
              fontSize: 12,
              fontWeight: 'normal',
              fontFamily: 'Nunito-Regular',
            }}
            containerStyle={{padding: 24}}
            html={popupDetails?.message ?? ''}
            onLinkPress={href => {
              if (href) {
                Linking.openURL(href);
              }
            }}
          />
          <View style={styles.popupContainer}>
            <Button
              style={styles.button}
              loading={deleting}
              variant={Button.variants.text}
              color={colors.tertiary}
              title="Delete"
              onPress={() => onDelete(popupDetails)}
              labelStyle={undefined}
              iconStyle={undefined}
              children={undefined}
              typography={undefined}
              disabled={undefined}
              source={undefined}
              sourceRight={undefined}
            />
            <Space width={10} />
            <Button
              style={styles.button}
              title="Close"
              onPress={onClose}
              loading={null}
              variant={null}
              color={null}
              labelStyle={undefined}
              iconStyle={undefined}
              children={undefined}
              typography={undefined}
              disabled={undefined}
              source={undefined}
              sourceRight={undefined}
            />
          </View>
        </PopUpBox>
        <PopUpBox
          isVisible={showAlertPopup}
          contentStyle={styles.popContentStyle}
          style={styles.popUpHeaderStyle}
          titleNumberOfLine={2}
          date={moment(alertPopupDetails?.transtamp).format('DD MMM YYYY')}
          descriptionStyle={styles.descriptionStyle}
          title={alertPopupDetails?.title}
          desc={
            <View style={{maxWidth: width - 60, paddingBottom: 20}}>
              <RenderHTML
                disableTopShadow
                bottomShadowPosition={100}
                baseStyle={{
                  fontSize: 12,
                  fontWeight: 'normal',
                  fontFamily: 'Nunito-Regular',
                }}
                containerStyle={{padding: 24}}
                html={alertPopupDetails?.description ?? ''}
                onLinkPress={href => {
                  if (href) {
                    Linking.openURL(href);
                  }
                }}
              />
            </View>
          }
          onClose={onCloseAlert}
        >
          <View style={styles.popupContainer}>
            <Button
              style={styles.button}
              title="Close"
              onPress={onCloseAlert}
            />
          </View>
        </PopUpBox>
      </Screen>

      {loadingAnnc && (
        <View style={styles.hiddenWebView} pointerEvents="none">
          <WebView
            key={webViewKey}
            source={URL_ANNOUNCEMENTS}
            injectedJavaScript={injectedJavaScript}
            onMessage={handleWebViewMessage}
            cacheEnabled={false}
            cacheMode="LOAD_NO_CACHE"
            incognito={true}
            onError={handleWebViewError}
          />
        </View>
      )}
    </>
  );
};
