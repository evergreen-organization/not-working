import {useCallback, useMemo, useState} from 'react';
import dayjs from 'dayjs';
import {useMailNotification} from './useMailNotification';
import {useAnncNotification} from './useAnncNotification';
import {useAlertNotification} from './useAlertNotification';
import moment from 'moment';

const DATE_KEY_FORMAT = 'DD MMM YYYY';

// Formats the mail API and announcement scrape are known/likely to produce
const PARSE_FORMATS = [
  'DD MMM YYYY',
  'D MMM YYYY',
  'DD MMM YY',
  'YYYY-MM-DD',
  'DD/MM/YYYY',
];

// Parse once at merge time so sorting/grouping never re-parses date strings
const toDateKeys = (createdDate?: string) => {
  // dayjs month-name matching is case-sensitive; the mail API sends
  // uppercase months ("18 SEP 2025"), so normalize to "18 Sep 2025"
  const normalized = (createdDate ?? '')
    .trim()
    .replace(
      /[A-Za-z]+/g,
      word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase(),
    );
  const strict = dayjs(normalized, PARSE_FORMATS, true);
  if (strict.isValid()) {
    return {
      sortKey: strict.valueOf(),
      dateKey: strict.format(DATE_KEY_FORMAT),
    };
  }
  const loose = dayjs(normalized);
  if (loose.isValid()) {
    return {sortKey: loose.valueOf(), dateKey: loose.format(DATE_KEY_FORMAT)};
  }
  return {sortKey: 0, dateKey: createdDate ?? ''};
};

export const useAllNotification = () => {
  const [activeTab, setActiveTab] = useState<
    'All' | 'Mailbox' | 'Announcements' | 'Alerts'
  >('All');
  const {
    mail,
    loadingMail,
    onRefresh: onRefreshMail,
    onDelete,
    onSelect,
    onClose,
    showPopup,
    popupDetails,
    deleting,
  } = useMailNotification();
  const {
    announcements,
    loadingAnnc,
    webViewKey,
    handleWebViewMessage,
    handleWebViewError,
    injectedJavaScript,
    refreshAnnouncements,
  } = useAnncNotification();
  const {
    alert,
    alertLoading,
    alertPopupDetails,
    onCloseAlert,
    onSelectAlert,
    showAlertPopup,
    onRefresh: onRefreshAlert,
  } = useAlertNotification();

  const allNotifications = useMemo(() => {
    const mailArray = Array.isArray(mail) ? mail : [];
    const alertArray = Array.isArray(alert) ? alert : [];
    const announcementArray = Array.isArray(announcements) ? announcements : [];

    return [
      ...announcementArray.map(item => ({
        ...item,
        ...toDateKeys(item.createdDate),
      })),
      ...mailArray.map(item => ({
        ...item,
        title: item.subject,
        description: item.message,
        type: 'mail',
        ...toDateKeys(item.createdDate),
      })),
      ...alertArray.map(item => {
        const date = dayjs(item.transtamp);
        const valid = date.isValid();
        const dateKey = valid ? date.format(DATE_KEY_FORMAT) : item.transtamp;
        return {
          ...item,
          title: item.subject,
          description: item.content,
          createdDate: moment(item.transtamp).format('DD MMM YY HH:mm:ss A'),
          type: 'alert',
          sortKey: valid ? date.valueOf() : 0,
          dateKey,
        };
      }),
    ];
  }, [mail, announcements, alert]);

  const onRefresh = useCallback(() => {
    onRefreshMail();
    onRefreshAlert();
    refreshAnnouncements();
  }, [onRefreshMail, onRefreshAlert, refreshAnnouncements]);

  const onTabChange = (tab: string) => {
    setActiveTab(tab as 'All' | 'Mailbox' | 'Announcements' | 'Alerts');
  };

  return {
    allNotifications,
    loadingMail,
    alertLoading,
    loadingAnnc,
    alertPopupDetails,
    onCloseAlert,
    onSelectAlert,
    showAlertPopup,
    announcements,
    webViewKey,
    handleWebViewMessage,
    handleWebViewError,
    injectedJavaScript,
    onRefresh,
    onDelete,
    onSelect,
    onClose,
    showPopup,
    popupDetails,
    deleting,
    activeTab,
    onTabChange,
  };
};
