import notificationIcon from '@/assets/images/icon/notificationAlert.png';

export const contentLogin = {
  id: 'contentLogin',
  img: notificationIcon,
  description: 'Login Now to begin device binding.',
  buttonText: 'OK',
  showOnce: true,
};
export const contentIOSVersion = {
  id: 'contentIOSVersion',
  img: notificationIcon,
  description:
    'iOS 14 will not be supported by PB enterprise Mobile App from 17/03/2025 onwards. Please update your operating system version to iOS 15.0 or later to continue using the app.',
  buttonText: 'OK',
  showOnce: false,
};
export const contentPendingPBSS = {
  id: 'contentPendingPBSS',
  img: notificationIcon,
  description:
    'Tap on "PB SecureSign" to continue PB SecureSign Activation Process.',
  buttonText: 'Done',
  showOnce: false,
};

export const contentPendingPBSSApproval = {
  id: 'contentPendingPBSSApproval',
  img: notificationIcon,
  description:
    'Your PB SecureSign activation is pending approval by your authoriser.\n\nPlease request your authoriser to approve the activation via PB enterprise website to complete the PB SecureSign activation process.',
  buttonText: 'Done',
  highlightedText: '',
  showOnce: false,
};

export const contentPendingPBSSCoolingOff = (PBSSCoolingOffHour: string) => {
  const remainingHours = PBSSCoolingOffHour?.split?.(':')[0] ?? 12;
  return {
    id: 'contentPendingPBSSCoolingOff',
    img: notificationIcon,
    description: `Your PB SecureSign will be activated in ${remainingHours} hours.\n\nWe thank you for your patience as we work to secure your access.`,
    buttonText: 'Done',
    highlightedText: '',
    showOnce: false,
  };
};
