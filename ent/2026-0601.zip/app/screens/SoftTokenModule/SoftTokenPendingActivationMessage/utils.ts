import dayjs from 'dayjs';
import {displayCoolingOffHour} from '../utils';

export const getCoolingOffDateTime = (PBSSCoolingOffHour: any) => {
  if (!PBSSCoolingOffHour) {
    return {};
  }
  const [hour, minute] = PBSSCoolingOffHour.split(':');
  const dateTime = dayjs().add(hour, 'hours').add(minute, 'minutes');
  return {
    date: dateTime.format('DD MMM YYYY'),
    time: dateTime.format('HH:mm:ss A'),
  };
};

export const getPendingDescription = (
  description: any,
  PBSSCoolingOffHour: any,
) => {
  if (!description) {
    return '';
  }
  const {date, time} = getCoolingOffDateTime(PBSSCoolingOffHour);

  return description
    ?.replace(
      '${PBSSCoolingOffHour}',
      displayCoolingOffHour(PBSSCoolingOffHour),
    )
    ?.replace('${PBSSCoolingOffDate}', date)
    ?.replace('${PBSSCoolingOffTime}', time);
};
