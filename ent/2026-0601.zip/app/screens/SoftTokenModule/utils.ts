import dayjs from 'dayjs';

export const displayCoolingOffHour = (time: string) => {
  if (!time) {
    return '';
  }
  const [hour] = time.split(':');
  return `${Number(hour) + 1}`;
};

export const displayProcessedDateTime = (date: string) => {
  if (!date) {
    return '';
  }
  return dayjs(date, 'D-MMM-YYYY H:m:s').format('DD MMM YYYY HH:mm:ss A');
};
