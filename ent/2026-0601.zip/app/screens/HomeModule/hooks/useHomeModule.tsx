import {useCallback, useEffect, useState} from 'react';
import {Alert, Linking, Animated, Platform} from 'react-native';
import {useSelector} from 'react-redux';
import {
  getLoginPromptVersion,
  getPbssPrompter,
  getSettings,
  getSoftToken,
  getSoftTokenActivationStatus,
  loginPromptVersionSaved,
  requestAlerts,
  requestMail,
  requiresPBSS,
  updatePbssChecking,
  useAppDispatch,
} from '@/store';
import {getCurrentUser, isLoggedIn, isBound, getAllUser} from '@/store';
import {useAccessControl} from '@/hooks/useAccessControl';
import {addAnalyticCheckpoint, showFailure} from '@/utils';
import {URL_APPLY, USER_ANALYTICS} from '@/constants';
import {routes} from '@/navigations';
import {USER_DEACTIVATION_URL} from '@/config/config';
import PBSecureSignIcon from '@/assets/images/icon/pbss-icon.png';
import ApprovalsIcon from '@/assets/images/icon/approvals-icon.png';
import ApplyIcon from '@/assets/images/icon/tick.png';
import DeactivateIcon from '@/assets/images/icon/deactivate-icon.png';
import ForexIcon from '@/assets/images/icon/forex-icon.png';
import {useNavigation} from '@react-navigation/native';
import {usePrefAccount} from '@/navigations/providers/PrefAccountProvider';
import {
  getCollapsedSheetHeight,
  getNotInitHeight,
  useHomeSheet,
} from '@/navigations/providers/HomeSheetProvider';
import {
  PopupData,
  QuickLink,
  UseHomeModuleProps,
  UseHomeModuleReturn,
  User,
} from '../types';
import {getSystemVersion} from 'react-native-device-info';
import AsyncStorage from '@react-native-async-storage/async-storage';
import moment from 'moment';
import {
  checkPendingCoolingOff,
  checkSecureSignPendingAuthoriser,
} from '@/screens/SoftTokenModule/SoftTokenStatusCheck/utils';
import {
  contentIOSVersion,
  contentLogin,
  contentPendingPBSS,
  contentPendingPBSSApproval,
  contentPendingPBSSCoolingOff,
} from '@/screens/AccountModule/CasaModule/data';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

const QUICK_LINKS = (props: {
  onNavigateSecure: (path: string) => void;
  onApplyPress: () => void;
  onKillSwitchPress: () => void;
  navigation: any;
  scrollY: Animated.Value;
  disabled?: boolean;
}): QuickLink[] => [
  {
    icon: PBSecureSignIcon,
    label: 'PB SecureSign',
    onPress: () =>
      props.onNavigateSecure(routes.SOFT_TOKEN_LOADING_TRANSACTION),
    scrollY: props.scrollY,
  },
  {
    icon: ApprovalsIcon,
    label: 'Approvals',
    onPress: () => showFailure('Coming Soon!'),
    // onPress: () => {
    //   props.navigation.navigate(routes.APPROVALS);
    // },
    scrollY: props.scrollY,
    disabled: true,
  },
  {
    icon: ForexIcon,
    label: 'Forex',
    onPress: () => props.navigation.navigate(routes.FOREX),
    scrollY: props.scrollY,
  },
  {
    icon: ApplyIcon,
    label: 'Apply',
    onPress: props.onApplyPress,
    scrollY: props.scrollY,
  },
  {
    icon: DeactivateIcon,
    label: 'Kill Switch',
    onPress: props.onKillSwitchPress,
    scrollY: props.scrollY,
  },
];

export const useHomeModule = ({
  scrollY,
  notifRefNo,
  isFocused = true,
}: UseHomeModuleProps): UseHomeModuleReturn => {
  const {setSheetSize} = useHomeSheet();
  const currentUser = useSelector(getCurrentUser);
  const isDeviceBound = useSelector(isBound);
  const {userId} = currentUser;
  const navigation = useNavigation();
  const accessControl = useAccessControl();
  const dispatch = useAppDispatch();
  const insets = useSafeAreaInsets();
  const loggedIn = useSelector(isLoggedIn);
  const bound = useSelector(isBound);
  const user = useSelector(getCurrentUser) as User;
  const users = useSelector(getAllUser);
  const isInitialised = users?.length > 0;

  const [showPin, setShowPin] = useState(false);
  const [showAddAccountsModal, setShowAddAccountsModal] = useState(false);
  const [editEnabled, setEditEnabled] = useState(false);
  const [showAmount, setShowAmount] = useState(false);
  const [isLimitPopupVisible, setIsLimitPopupVisible] = useState(false);
  const osVersion = getSystemVersion();

  const [showPopUp, setShowPopUp] = useState(false);
  const [popUp, setPopUp] = useState<any>(null);
  const loginPromptVersion = useSelector(getLoginPromptVersion);
  const [popUpQueue, setPopUpQueue] = useState([]);
  const hasTriggeredPbssPrompter = useSelector(getPbssPrompter);
  const {
    isActivated: isPBSSActivated,
    isLicenseAvailable: isPBSSLicenseAvailable,
  } = useSelector(getSoftToken);
  const roleRequirePBSS = useSelector(requiresPBSS);
  const {prefAccountLoading, preferredAccountsList, setPreferredAccountsList} =
    usePrefAccount();
  const [showAlertPopup, setShowAlertPopup] = useState(false);
  const [popupData, setPopupData] = useState<PopupData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const notInitHeight = getNotInitHeight(insets.bottom);

  const {deviceId} = useSelector(getSettings);
  const getNotificationDetails = async (notiRef: string) => {
    try {
      setIsLoading(true);
      setShowAlertPopup(true);

      const {payload} = await dispatch(
        requestAlerts({encryptedId: user?.encryptedId, deviceId}),
      );

      if (payload?.notificationList) {
        const notificationContent = payload.notificationList.find(
          i => i.notifrefno === notiRef,
        );
        setPopupData(notificationContent);
      }
    } catch (error) {
      console.error('Failed to get notification details:', error);
      setShowAlertPopup(false);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    if (notifRefNo) {
      getNotificationDetails(notifRefNo);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notifRefNo]);

  const onClose = () => {
    setShowAlertPopup(false);
  };
  useEffect(() => {
    dispatch(requestMail({encryptedId: user?.encryptedId, deviceId}));
    if (Platform.OS == 'ios' && parseInt(osVersion) < 15) {
      checkLastPopupDate();
    }
    checkSoftTokenActivationStatus();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (!showPopUp && popUpQueue.length > 0) {
      const nextPopUp = popUpQueue[0];
      setPopUp(nextPopUp);
      setShowPopUp(true);
    }
  }, [popUpQueue, showPopUp]);

  const checkLastPopupDate = async () => {
    try {
      const lastShown = await AsyncStorage.getItem('lastPopupDate');

      const today = moment().format('DD-MM-YYYY'); // Format the current date as 'DD-MM-YYYY'
      if (lastShown !== today) {
        setPopUpQueue(prevQueue => [...prevQueue, contentIOSVersion]);
        await AsyncStorage.setItem('lastPopupDate', today); // Update the date.
      }
    } catch (error) {
      console.error('Error checking last pop-up date:', error);
    }
  };
  const checkSoftTokenActivationStatus = async () => {
    if (!isDeviceBound && loginPromptVersion < 1) {
      // Content for device not bound
      setPopUpQueue(prevQueue => [...prevQueue, contentLogin]);

      return;
    }

    const {payload} = await dispatch(getSoftTokenActivationStatus({userId}));
    if (payload.problem) {
      return;
    }

    if (!hasTriggeredPbssPrompter) {
      checkShowPBSSTutorial(payload);
    }
  };

  const checkShowPBSSTutorial = payload => {
    // pbss pending authoriser status get from payload
    const isPBSSPendingAuthoriser = checkSecureSignPendingAuthoriser({
      isSecureSignRegistered: payload.isSoftTokenRegistered,
      isSecureSignPending: payload.isSoftTokenPendingActivation,
    });

    // pbss cooling-off status get from payload
    const isPBSSCoolingOff = checkPendingCoolingOff({
      PBSSCoolingOffHour: payload.coolingOffHour,
    });

    //if role not require PBSS, no need PBSS prompter
    if (!roleRequirePBSS) {
      return;
    }

    //if PBSS not activated and no license, no need PBSS prompter
    if (!isPBSSActivated && !isPBSSLicenseAvailable) {
      return;
    }

    // content for pbss not activated
    if (!isPBSSActivated) {
      dispatch(updatePbssChecking(true));
      setPopUpQueue(prevQueue => [...prevQueue, contentPendingPBSS]);

      return;
    }

    // content for pbss not authorized or cooling-off
    if (isPBSSPendingAuthoriser) {
      dispatch(updatePbssChecking(true));
      setPopUpQueue(prevQueue => [...prevQueue, contentPendingPBSSApproval]);
      return;
    }

    if (isPBSSCoolingOff) {
      dispatch(updatePbssChecking(true));
      setPopUpQueue(prevQueue => [
        ...prevQueue,
        contentPendingPBSSCoolingOff(payload.coolingOffHour),
      ]);
    }
  };

  const handleClose = () => {
    setShowPopUp(false);
    setPopUpQueue(prevQueue => prevQueue.slice(1));
    handleShowPrompter();
  };

  const handleShowPrompter = () => {
    const isShowOnce = popUp.showOnce;
    if (isShowOnce) {
      //currently dispatch login prompter only
      dispatch(loginPromptVersionSaved(1));
    }
  };

  const onNavigateSecure = useCallback(
    (path: string) => {
      accessControl.navigate(path);
    },
    [accessControl],
  );

  const onKillSwitchPress = useCallback(() => {
    addAnalyticCheckpoint({
      dispatch,
      action: USER_ANALYTICS.PROFILE.KILL_SWITCH,
    }).catch(error => {
      console.error('Failed to add kill switch analytics:', error);
    });

    Alert.alert(
      'Redirect from PB enterprise',
      "You will be redirected to Public Bank's website on your browser.",
      [
        {text: 'Cancel'},
        {
          text: 'OK',
          onPress: () => {
            Linking.openURL(USER_DEACTIVATION_URL).catch(error => {
              console.error('Failed to open deactivation URL:', error);
            });
          },
        },
      ],
    );
  }, [dispatch]);

  const onApplyPress = useCallback(() => {
    addAnalyticCheckpoint({
      dispatch,
      action: USER_ANALYTICS.PROFILE.APPLY,
    }).catch(error => {
      console.error('Failed to add apply analytics:', error);
    });

    Alert.alert(
      'Redirect from PB enterprise',
      "You will be redirected to Public Bank's website on your browser.",
      [
        {text: 'Cancel'},
        {
          text: 'OK',
          onPress: () => {
            Linking.openURL(URL_APPLY.uri).catch(error => {
              console.error('Failed to open apply URL:', error);
            });
          },
        },
      ],
    );
  }, [dispatch]);

  const handleEdit = useCallback(() => {
    setEditEnabled(true);
  }, []);

  const handleDone = () => {
    setEditEnabled(false);
    setPreferredAccountsList();
  };

  const onBack = useCallback(() => {
    if (loggedIn === null) {
      if (isInitialised) {
        setSheetSize(getCollapsedSheetHeight(insets.bottom));
      } else {
        setSheetSize(notInitHeight + 20);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loggedIn, isInitialised, setSheetSize, notInitHeight]);

  // Logged-in and logged-out-initialised sizes are declared by the view
  // Session-scoped UI state must not leak into the next session; reset on
  // logout regardless of focus (logout can fire from a pushed screen or
  // the inactivity timer)
  useEffect(() => {
    if (loggedIn === null) {
      setEditEnabled(false);
    }
  }, [loggedIn]);

  // types themselves (SheetSizer in renderContent); only the not-initialised
  // fallback needs an explicit size here. Re-runs when the home route
  // regains focus, since pushed screens set the sheet to 94%.
  useEffect(() => {
    if (loggedIn === null && isFocused) {
      setShowPin(false);
      if (!isInitialised) {
        setSheetSize(getCollapsedSheetHeight(insets.bottom));
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loggedIn, isInitialised, notInitHeight, setShowPin, isFocused]);

  return {
    navigation,
    loggedIn,
    bound,
    user,
    preferredAccountsList,
    showPin,
    setShowPin,
    showAddAccountsModal,
    setShowAddAccountsModal,
    editEnabled,
    showAmount,
    setShowAmount,
    isLimitPopupVisible,
    setIsLimitPopupVisible,
    prefAccountLoading,
    onNavigateSecure,
    onKillSwitchPress,
    onApplyPress,
    handleEdit,
    handleDone,
    onBack,
    notInitHeight,
    showAlertPopup,
    popupData,
    isLoading,
    onClose,
    quickLinksData: QUICK_LINKS({
      onNavigateSecure,
      onApplyPress,
      onKillSwitchPress,
      navigation,
      scrollY,
    }),
    handlePopUpPrompt: popUp,
    handleClose,
    showPopUp,
  };
};
