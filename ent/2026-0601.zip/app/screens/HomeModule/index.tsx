import React, {useEffect, useRef} from 'react';
import {
  Animated,
  Platform,
  useWindowDimensions,
  View,
  ScrollView,
  Linking,
} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {routes} from '@/navigations';
import {Accounts} from '@/screens/AccountModule/AccountDashboard';
import {LoginPinScreen} from '@/screens/AuthModule/LoginPin';
import {
  DashboardHeader,
  HomeNavBar,
  LoginButton,
  QuickLinks,
  UserInfo,
} from './components';
import {Button, Loading, Space} from '@/components/atoms';
import {styles} from './styles';
import {useAccountModule} from '@/screens/AccountModule/hooks/useAccountModule';
import {
  getCollapsedSheetHeight,
  SheetSize,
  SheetSizeOptions,
  useHomeSheet,
  useSheetSize,
} from '@/navigations/providers/HomeSheetProvider';
import {useHomeModule} from './hooks/useHomeModule';
import {useHomeAnimation} from './hooks/useHomeAnimation';
import {useIsFocused, useNavigation, useRoute} from '@react-navigation/native';
import {AccessDeniedModal} from './components/accessDeniedModal';
import {PopUpAlert, PopUpBox} from '@/components/organisms';
import {PopupData, RouteParams} from './types';
import moment from 'moment';
import {colors} from '@/styles';
import {RenderHTML} from 'react-native-render-html';
import {usePrefAccount} from '@/navigations/providers/PrefAccountProvider';
import Sortable from 'react-native-sortables';

// Declares the sheet size for the view type it is rendered with; `enabled`
// re-fires the request when the home route regains focus (it stays mounted
// under pushed screens, so mount effects alone would not re-apply the size)
const SheetSizer = ({
  size,
  opts,
  enabled = true,
}: {
  size: SheetSize;
  opts?: SheetSizeOptions;
  enabled?: boolean;
}) => {
  useSheetSize(size, opts, enabled);
  return null;
};

// MAIN_TAB route: the home content rendered inside the app-wide bottom
// sheet (the white top area + sheet shell live in AppShell/navigator)
export const HomeScreen = () => {
  const scrollViewRef = useRef<ScrollView>(null);
  const navigation = useNavigation();
  const {width, height} = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const isFocused = useIsFocused();
  const route = useRoute();
  const {notifRefNo} = (route?.params as RouteParams) || {};
  const {
    scrollY,
    backgroundColor,
    dashboardBorderTopStyles,
    welcomeStyles,
    headerContainerStyle,
  } = useHomeAnimation();

  const {
    loggedIn,
    user,
    bound,
    showPin,
    setShowPin,
    editEnabled,
    showAmount,
    setShowAmount,
    handleEdit,
    handleDone,
    onBack,
    quickLinksData,
    preferredAccountsList = [],
    showPopUp,
    handlePopUpPrompt,
    handleClose,
    showAlertPopup,
    popupData,
    isLoading,
    onClose,
  } = useHomeModule({scrollY, notifRefNo, isFocused});

  const {setShowAddAccountsModal} = usePrefAccount();
  const {headerHeightSV, contentHeightSV} = useHomeSheet();
  const {viewer} = useAccountModule();

  useEffect(() => {
    // The logged-in header is absolutely positioned and compensated for by
    // the body's paddingTop, so it must not count toward content sizing
    if (loggedIn !== null) {
      headerHeightSV.value = 0;
    }
  }, [loggedIn, headerHeightSV]);

  useEffect(() => {
    if (!bound) {
      setTimeout(() => {
        navigation.navigate(routes.LOGIN);
      }, 100);
    }
  }, [bound]);

  const renderContent = () => {
    if (loggedIn !== null) {
      return (
        <>
          <SheetSizer size="94%" enabled={isFocused} />
          <Accounts
            editEnabled={editEnabled}
            setShowAddAccountsModal={setShowAddAccountsModal}
            showAmount={showAmount}
          />
        </>
      );
    }
    if (showPin) {
      return (
        <View style={{height: height * 0.72, paddingTop: 30}}>
          <SheetSizer size="85%" enabled={isFocused} />
          <LoginPinScreen enableHeader={false} />
        </View>
      );
    }
    return (
      <>
        <SheetSizer
          size={getCollapsedSheetHeight(insets.bottom)}
          enabled={isFocused}
        />
        <QuickLinks
          items={quickLinksData}
          containerStyle={{marginTop: 20, paddingHorizontal: 28}}
        />
        <Space height={10} />
        <LoginButton
          text="Tap To Login"
          activeOpacity={0.7}
          onPress={() => {
            if (!bound) {
              navigation.navigate(routes.LOGIN);
            } else {
              setShowPin(true);
            }
          }}
          style={{marginHorizontal: 24}}
        />
      </>
    );
  };
  const renderPopUpBox = (data: PopupData, isLoading: boolean) => {
    const formattedDate = data?.transtamp
      ? moment(data.transtamp).format('DD MMM YY').toUpperCase()
      : '';

    const content = isLoading ? (
      <View style={{minHeight: 140, justifyContent: 'center'}}>
        <Loading size="large" color={colors.lightMedium} />
      </View>
    ) : (
      <View style={{maxWidth: width - 60, paddingBottom: 20}}>
        <RenderHTML
          disableTopShadow
          bottomShadowPosition={100}
          baseStyle={{
            fontSize: 12,
            fontWeight: 'normal',
            fontFamily: 'Nunito-Regular',
          }}
          containerStyle={{padding: 24}}
          html={data?.content ?? ''}
          onLinkPress={href => {
            if (href) {
              Linking.openURL(href);
            }
          }}
        />
      </View>
    );

    return (
      <PopUpBox
        isVisible={showAlertPopup}
        contentStyle={styles.popContentStyle}
        descriptionStyle={styles.descriptionStyle}
        style={styles.popUpHeaderStyle}
        onClose={onClose}
        titleNumberOfLine={2}
        date={formattedDate}
        title={data?.subject}
        desc={content}
      >
        <View style={styles.popButtonContainer}>
          <Button
            style={styles.popCloseButton}
            title="Close"
            onPress={onClose}
          />
        </View>
      </PopUpBox>
    );
  };
  return (
    // PortalProvider teleports the actively dragged preferred-account card
    // into an overlay rendered above this subtree, so it isn't covered by
    // the absolutely positioned header (zIndex 99999) inside the container
    <Sortable.PortalProvider>
      <View style={styles.container}>
        <Animated.View
          style={headerContainerStyle}
          onLayout={event => {
            headerHeightSV.value =
              loggedIn !== null ? 0 : event.nativeEvent.layout.height;
          }}
        >
          <HomeNavBar
            showClose={showPin}
            handleClose={() => {
              onBack();
              setShowPin(false);
            }}
            welcomeStyles={welcomeStyles}
          />
          {loggedIn !== null && (
            <>
              <UserInfo user={user} scrollY={scrollY} width={width} />
              <QuickLinks
                items={quickLinksData}
                containerStyle={{paddingHorizontal: 28}}
              />
              <Animated.View
                style={[
                  {
                    backgroundColor: '#e5e5e5',
                    marginHorizontal: 24,
                    height: 0.5,
                    marginTop: 10,
                  },
                  dashboardBorderTopStyles,
                ]}
              />
              <DashboardHeader
                editEnabled={editEnabled}
                hasPreferredAccounts={preferredAccountsList?.length > 0}
                showDescription={preferredAccountsList?.length > 1}
                showAmount={showAmount}
                setShowAmount={setShowAmount}
                onEdit={handleEdit}
                onDone={handleDone}
              />
            </>
          )}
        </Animated.View>

        <View style={styles.scrollClip}>
          <Animated.ScrollView
            bounces={false}
            ref={scrollViewRef}
            onScroll={Animated.event(
              [{nativeEvent: {contentOffset: {y: scrollY}}}],
              {
                useNativeDriver: false,
              },
            )}
            onScrollEndDrag={event => {
              const offsetY = event.nativeEvent.contentOffset.y;
              if (offsetY > 5 && offsetY < 100) {
                scrollViewRef.current?.scrollTo({
                  y: offsetY < 50 ? 0 : 100,
                  animated: true,
                });
              }
            }}
            scrollEventThrottle={0.1}
            style={[styles.bottomModalContainer, {backgroundColor}]}
            showsVerticalScrollIndicator={false}
          >
            <View
              style={[
                {
                  paddingBottom:
                    loggedIn !== null ? (editEnabled ? 190 : 150) : 24,
                },
                loggedIn !== null && {
                  paddingTop: editEnabled
                    ? Platform.OS === 'ios'
                      ? 300
                      : 305
                    : Platform.OS === 'ios'
                    ? 295
                    : 300,
                },
              ]}
              onLayout={event => {
                contentHeightSV.value = event.nativeEvent.layout.height;
              }}
            >
              {renderContent()}
            </View>
          </Animated.ScrollView>
        </View>

        <AccessDeniedModal />
        <PopUpAlert
          visible={showPopUp}
          onClose={handleClose}
          onHandlePopUpPrompt={handlePopUpPrompt}
        />
        {showAlertPopup && renderPopUpBox(popupData, isLoading)}
        {/* Backdrop bar under the scroll view's rounded bottom corners;
          zIndex -1 keeps its top 20px tucked behind the scroll content */}
        {loggedIn !== null && preferredAccountsList?.length > 0 && (
          <View
            style={{
              backgroundColor: colors.darkRed,
              height: 90,
              marginTop: -20,
              zIndex: -1,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {viewer && preferredAccountsList?.length > 0 && (
              <Button
                variant={Button.variants.text}
                labelStyle={{color: colors.white}}
                style={{width: '90%', height: 30, padding: 0}}
                title="View All Accounts"
                onPress={() =>
                  navigation.navigate(routes.ACCOUNTS_MODULE, {
                    screen: routes.ACCOUNTS_ALL,
                  })
                }
              />
            )}
          </View>
        )}
      </View>
    </Sortable.PortalProvider>
  );
};
