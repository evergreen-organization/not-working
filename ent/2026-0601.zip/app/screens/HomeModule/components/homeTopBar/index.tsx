import {View, Image, StyleSheet, Platform} from 'react-native';
import React, {useState} from 'react';
import EnterpriseLogoImage from '@/assets/images/icon/PBEnterpriseLogo_Vertical.png';
import NotificationIcon from '@/assets/images/icon/bell3.png';
import LinearGradient from 'react-native-linear-gradient';
import Video from 'react-native-video';
import BGVideo from '@/assets/video/bg-video.mp4';
import BGImage from '@/assets/images/bg-video-image.png';
import {HapticTouchableOpacity, Icon, Text} from '@/components/atoms';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {colors} from '@/styles';
import GradientRoundedView from '@/components/molecules/gradientRoundedView';
import {useNavigation} from '@react-navigation/native';
import {routes} from '@/navigations';
import {useSelector} from 'react-redux';
import {getAllUser} from '@/store';
import {isFoldPhone, width} from '@/utils/device';

export const HomeTopBar = () => {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const users = useSelector(getAllUser);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);

  const bound = users.length > 0;

  let logoWidth = isFoldPhone ? width / 6 : width / 4;
  return (
    <View style={styles.container}>
      {bound && (
        <HapticTouchableOpacity
          activeOpacity={0.7}
          onPress={() => navigation.navigate(routes.NOTIFICATION)}
          style={{
            position: 'absolute',
            right: 20,
            top: Platform.OS === 'ios' ? insets.top + 10 : insets.top + 20,
            zIndex: 9999,
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <GradientRoundedView variant={'light'}>
            <Icon source={NotificationIcon} size={16} color={colors.black} />
          </GradientRoundedView>
          <Text style={{color: '#fff', fontSize: 8, fontWeight: 'bold'}}>
            Notifications
          </Text>
        </HapticTouchableOpacity>
      )}
      <Image
        source={EnterpriseLogoImage}
        resizeMode="contain"
        style={[
          styles.enterpriseLogo,
          {
            width: logoWidth * 0.8,
            height: logoWidth * 0.8,
            left: 32,
            top: 130,
          },
        ]}
      />
      <LinearGradient
        locations={[0, 0.6, 1]}
        colors={['#ffffff00', '#ffffff00', '#ffffff99']}
        style={styles.gradientBackground}
      />
      <View
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          zIndex: 8,
        }}
      >
        <Image
          source={BGImage}
          resizeMode="cover"
          style={styles.backgroundImage}
        />
      </View>
      {isVideoLoaded ? null : (
        <Video
          source={BGVideo}
          style={styles.backgroundVideo}
          repeat={false}
          paused={false}
          muted={true}
          disableFocus={true}
          resizeMode="cover"
          ignoreSilentSwitch="ignore"
          focusable={false}
          onEnd={() => {
            setIsVideoLoaded(true);
          }}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  enterpriseLogo: {
    position: 'absolute',
    zIndex: 11,
  },
  gradientBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    zIndex: 10,
  },
  backgroundImage: {width: '100%', height: '100%'},
  backgroundVideo: {width: '100%', height: '100%', zIndex: 9},
});
