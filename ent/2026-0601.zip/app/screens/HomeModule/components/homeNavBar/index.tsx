import React, {useEffect, useRef, useState} from 'react';
import {Animated, View} from 'react-native';
import {useSelector} from 'react-redux';
import {useNavigation} from '@react-navigation/native';
import {useAppDispatch} from '@/store';

import {colors} from '@/styles';
import {routes} from '@/navigations';
import {getCurrentUser, isBound, isLoggedIn} from '@/store';
import {
  addAnalyticCheckpoint,
  checkDemoFromUserId,
  showFailure,
  showSuccess,
} from '@/utils';
import {DEMO_ERROR_MSG, USER_ANALYTICS} from '@/constants';

import {Button, IconButton, Text} from '@/components/atoms';
import {SwitchUserModal} from '../switchUserModal';
import {HomeNavBarProps, User} from './types';

import LogoutIcon from '@/assets/images/icon/logout2.png';
import SwapIcon from '@/assets/images/icon/swap.png';
import CloseIcon from '@/assets/images/icon/close.png';
import ProfileIcon from '@/assets/images/icon/profile.png';
import NotificationIcon from '@/assets/images/icon/bell3.png';
import ForgotPasswordIcon from '@/assets/images/icon/forgot-password.png';
import {styles} from './styles';
import {logout} from '@/store';
import {useTranslation} from '@/hooks';
import {checkPendingCoolingOff} from '@/screens/SoftTokenModule/SoftTokenStatusCheck/utils';

export const HomeNavBar: React.FC<HomeNavBarProps> = ({
  showClose,
  handleClose,
  welcomeStyles,
}) => {
  const {t} = useTranslation();
  const navigation = useNavigation();
  const user = useSelector(getCurrentUser) as User;
  const bound = useSelector(isBound);
  const loggedIn = useSelector(isLoggedIn);
  const isNotLoggedIn = loggedIn === null;
  const isUserLoggedIn = loggedIn !== null;
  const hasMounted = useRef(false);
  const dispatch = useAppDispatch();
  const [showSwitch, setShowSwitch] = useState(false);
  const isDemo = checkDemoFromUserId(user?.userId);
  const handleSettings = () => navigation.navigate(routes.PROFILE);
  const handleNotifications = () => navigation.navigate(routes.NOTIFICATION);
  const handleCloseSwitch = () => setShowSwitch(false);
  const {PBSSCoolingOffHour, isPBSSRegistered} = user || '';
  const handleLogout = () => {
    showSuccess(t('Logout successfully'));
    dispatch(logout());
  };

  useEffect(() => {
    if (hasMounted.current) {
      if (loggedIn === null) {
        dispatch(logout());
      }
    } else {
      hasMounted.current = true;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loggedIn]);

  const handleSwitchUser = () => {
    setShowSwitch(true);
    addAnalyticCheckpoint({
      dispatch,
      action: USER_ANALYTICS.PROFILE.SWITCH_USER,
    }).then();
  };

  const onForgetPin = () => {
    if (isDemo) {
      return showFailure(DEMO_ERROR_MSG);
    }

    if (isPBSSRegistered && checkPendingCoolingOff({PBSSCoolingOffHour})) {
      return showFailure(
        t(
          `The Reset SecurePIN function is temporarily unavailable.\nYour PB SecureSign is currently pending cooling-off. Please try again after the cooling-off period has ended.`,
        ),
      );
    }
    navigation.navigate(routes.FORGOT_PIN_MESSAGE, {
      userId: user?.userId,
    });
  };

  if (!bound) {
    return (
      <View style={[styles.titleContainer, {gap: 10}]}>
        <View style={{flex: 1}}>
          <Text as={Text.type.H3}>Welcome to PB enterprise!</Text>
        </View>
      </View>
    );
  }

  const buttonProps = {
    variant: Button.variants.text,
    color: colors.darkGrey,
    style: styles.rightButton,
    minWidth: 45,
  };

  return (
    <View style={[styles.titleContainer, {gap: 10}]}>
      <View
        style={[
          {flex: 1, marginLeft: 4},
          isNotLoggedIn && {
            alignItems: 'flex-start',
          },
        ]}
      >
        <Animated.Text
          allowFontScaling={false}
          style={[
            styles.welcomeText,
            isUserLoggedIn && styles.loggedInWelcomeText,
            isUserLoggedIn && welcomeStyles,
          ]}
          numberOfLines={1}
        >
          {isUserLoggedIn && 'Welcome,'}
          {!isUserLoggedIn &&
            `${t('$username', {
              username:
                user?.username === '' || user?.username === null
                  ? ' '
                  : user?.username,
            })}`}
        </Animated.Text>
        {!isUserLoggedIn && (
          <Text
            as={Text.type.P1}
            style={styles.companyText}
            params={{companycode: user?.companyCode}}
          >
            $companycode
          </Text>
        )}
      </View>

      {loggedIn ? (
        <>
          <IconButton
            icon={ProfileIcon}
            onPress={handleSettings}
            label="Profile"
            {...buttonProps}
          />
          <IconButton
            icon={NotificationIcon}
            onPress={handleNotifications}
            label="Notifications"
            {...buttonProps}
          />
          <IconButton
            icon={LogoutIcon}
            onPress={handleLogout}
            label="Logout"
            {...buttonProps}
          />
        </>
      ) : showClose ? (
        <>
          <IconButton
            icon={ForgotPasswordIcon}
            onPress={onForgetPin}
            label="Forgot SecurePIN"
            {...buttonProps}
          />
          <IconButton
            icon={CloseIcon}
            onPress={handleClose}
            label="Close"
            {...buttonProps}
          />
        </>
      ) : (
        <>
          <IconButton
            icon={ProfileIcon}
            onPress={handleSettings}
            label="Profile"
            {...buttonProps}
          />
          <IconButton
            icon={SwapIcon}
            onPress={handleSwitchUser}
            label="Switch User"
            {...buttonProps}
          />
        </>
      )}
      <SwitchUserModal visible={showSwitch} onClose={handleCloseSwitch} />
    </View>
  );
};
