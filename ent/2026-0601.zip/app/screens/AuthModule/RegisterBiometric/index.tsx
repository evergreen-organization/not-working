import React from 'react';
import {MessageTemplate} from '@/components/templates';
import BiometricLottie from '@/assets/lottie/biometric-theme.json';
import {useRegisterBiometric} from './hooks/useRegisterBiometric';

export const RegisterBiometricScreen = () => {
  const {onYes, onSkip} = useRegisterBiometric();

  return (
    <MessageTemplate
      title={'Do you want to enable Biometric Login?'}
      lottie={BiometricLottie}
      leftButtonTitle={'Skip'}
      rightButtonTitle={'Yes'}
      onLeftPress={onSkip}
      onRightPress={onYes}
      rightButtonInfoText={'(Recommended)'}
    />
  );
};
