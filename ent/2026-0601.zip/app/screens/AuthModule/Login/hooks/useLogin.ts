import {useEffect, useState} from 'react';
import {useSelector} from 'react-redux';
import {routes} from '@/navigations';
import {FAILED, IDLE, LOADING} from '@/api';
import {
  DEMO_LOGIN_FAILED_MSG,
  DemoData,
  ERR_CLIENT_ERROR,
  ERR_CLIENT_ERROR_MESSAGE,
  ERR_USER_ID_BLOCKED,
  SECONDARY_DEMO_LOGIN_ERROR_MSG,
} from '@/constants';
import {
  encryption,
  formatUserId,
  checkDemoFromCompanyUser,
  SHA256Hash,
  showFailure,
} from '@/utils';
import {
  authReset,
  getAllUser,
  getAuth,
  getSettings,
  keyboardDismissed,
  keyboardReset,
  logout,
  requestCSRF,
  requestE2ee,
  requestLogin,
  requestSession,
  requestSessionLogin,
  requestValidateIC,
  updateAuthObject,
  useAppDispatch,
} from '@/store';
import {ERR_INVALID_LOGIN, ERR_TITLE, SUCCESS_STATUS} from '../utils';
import {storage} from '@/storage';
import {useTranslation} from '@/hooks';
import {LoginScreenProps, LoginStep, LoginSteps} from '../types.d';
import {useCustomKeyboard} from '@/../modules/react-native-custom-keyboard/src';
import ApplyIcon from '@/assets/images/icon/tick.png';
import DeactivateIcon from '@/assets/images/icon/deactivate-icon.png';
import ForexIcon from '@/assets/images/icon/forex-icon.png';
import {useHomeModule} from '@/screens/HomeModule/hooks/useHomeModule';
import {Animated} from 'react-native';

export const useLogin = ({navigation}: LoginScreenProps) => {
  const {t} = useTranslation();
  const dispatch = useAppDispatch();
  const users = useSelector(getAllUser);
  const auth = useSelector(getAuth);
  const {deviceId} = useSelector(getSettings);
  const bound = users.length > 0;
  const [pWord, setPWord] = useState<string>();
  const [username, setUsername] = useState('');
  const [step, setStep] = useState<LoginStep>(LoginSteps.step1);
  const [loading, setLoading] = useState(false);
  const [pPhrase, setPPhrase] = useState(false);
  const {hideCustomKeyboard} = useCustomKeyboard();
  const {onKillSwitchPress, onApplyPress} = useHomeModule({
    scrollY: new Animated.Value(0),
    bottomSheetRef: {current: null},
    notifRefNo: '',
  });

  useEffect(() => {
    dispatch(logout());
    dispatch(authReset());
    dispatch(requestCSRF());
    return () => {
      onReset();
      dispatch(keyboardReset());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onSubmitUsername = async ({
    company,
    userId,
  }: {
    company: string;
    userId: string;
  }) => {
    hideCustomKeyboard();
    dispatch(keyboardDismissed());
    setLoading(true);

    const exist = users.find(user => user.userId === userId.toUpperCase());
    if (exist) {
      showFailure('User ID already bound. Please enter SecurePIN to login.');
      setLoading(false);
      return navigation.navigate(routes.LOGIN_PIN, {userId});
    }

    const tempUsername = formatUserId(company, userId);
    setUsername(tempUsername);

    if (checkDemoFromCompanyUser(company, userId)) {
      setLoading(false);
      dispatch(updateAuthObject({userId, company}));
      dispatch(keyboardReset());
      return setStep(LoginSteps.step2);
    }

    const {payload: e2eeResponse} = await dispatch(requestE2ee());
    if (e2eeResponse?.problem === ERR_CLIENT_ERROR) {
      dispatch(updateAuthObject({status: FAILED}));
      setLoading(false);
      return showFailure(ERR_CLIENT_ERROR_MESSAGE);
    }

    const {payload} = await dispatch(
      requestSession({username: tempUsername, Next: 'Next'}),
    );
    setLoading(false);
    if (payload.problem) {
      return showFailure(payload.problem);
    }

    setPPhrase(true);

    dispatch(updateAuthObject({userId, company}));
    dispatch(keyboardReset());
    setStep(LoginSteps.step2);
  };

  const onConfirmPPhrase = () => setStep(LoginSteps.step3);

  const onSubmitPWord = async ({pWord}: {pWord: string}) => {
    setLoading(true);
    hideCustomKeyboard();
    dispatch(keyboardDismissed());

    if (!bound) {
      await storage.storeUserKey(username);
    }

    if (checkDemoFromCompanyUser(auth?.company, auth?.userId)) {
      return callDemoLogin(pWord);
    }

    const encryptMsg = encryption.encryptUserIdPWord({
      userId: username,
      pWord,
    });
    await callWebSealLogin({username, encryptMsg});
  };

  const callDemoLogin = async (demoPWord: string) => {
    const encryptedPWord = SHA256Hash(demoPWord);
    setLoading(false);
    if (encryptedPWord !== DemoData.User.secureKey) {
      return showFailure(DEMO_LOGIN_FAILED_MSG);
    }
    if (bound) {
      return showFailure(SECONDARY_DEMO_LOGIN_ERROR_MSG);
    }
    return callLogin();
  };

  const callWebSealLogin = async ({
    username: user,
    encryptMsg,
  }: {
    username: string;
    encryptMsg: string;
  }) => {
    const {payload} = await dispatch(
      requestSessionLogin({username: user, encryptMsg, Submit: 'Login'}),
    );
    setPWord('');
    if (payload?.replace(/\s/g, '') === SUCCESS_STATUS) {
      return callLogin();
    }
    setLoading(false);
    if (payload?.problem) {
      return showFailure(payload?.problem);
    }
    dispatch(updateAuthObject({status: IDLE}));
    if (payload?.includes(ERR_USER_ID_BLOCKED)) {
      return showFailure(t(ERR_TITLE), t(ERR_INVALID_LOGIN));
    }
    showFailure(t(ERR_TITLE), t(ERR_INVALID_LOGIN));
  };

  const callLogin = async () => {
    const {payload} = await dispatch(requestLogin());
    setLoading(false);
    if (!payload || payload?.problem) {
      dispatch(authReset());
      onReset();
      return showFailure(payload?.problem ?? 'error');
    }

    //Hack to pass name even thought not showing nickname form
    dispatch(updateAuthObject({name: auth.userId}));

    // validate IC if 2nd bind
    if (bound) {
      // flag to show the new user is added from add user button
      dispatch(updateAuthObject({isAddingNewUser: true}));

      const {payload: validateICPayload} = await dispatch(
        requestValidateIC({deviceId}),
      );
      if (!validateICPayload || validateICPayload?.problem) {
        dispatch(authReset());
        onReset();
        return showFailure(validateICPayload?.problem ?? 'error');
      }
    }

    if (payload.isRegistered) {
      return navigation.navigate(routes.LOGIN_CONFIRM);
    }
    navigation.navigate(routes.REGISTER_PIN);
  };

  const onReset = () => {
    setStep(LoginSteps.step1);
    setPWord('');
  };

  onKillSwitchPress;

  const QUICK_LINKS = [
    {
      icon: ForexIcon,
      label: 'Forex',
      onPress: () => navigation.navigate(routes.FOREX),
    },
    {
      icon: ApplyIcon,
      label: 'Apply',
      onPress: onApplyPress,
    },
    {
      icon: DeactivateIcon,
      label: 'Kill Switch',
      onPress: onKillSwitchPress,
    },
  ];

  return {
    pWord,
    step,
    loading: auth.loading === LOADING || loading,
    userId: auth?.userId,
    company: auth?.company,
    pPhrase,
    quickLinksData: QUICK_LINKS,
    onSubmitUsername,
    onConfirmPPhrase,
    onSubmitPWord,
    onReset,
  };
};
