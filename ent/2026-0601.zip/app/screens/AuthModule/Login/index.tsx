import React from 'react';
import {useLogin} from './hooks/useLogin';
import {LoginUsername} from '@/components/molecules';
import {LoginPWord} from '@/components/molecules';
import {LoginConfirmPPhrase, LoginPPhrase} from '@/components/molecules';
import {Navbar} from '@/components';
import {View} from 'react-native';
import {Screen, Text} from '@/components/atoms';
import {styles} from './styles';
import {LoginScreenProps, LoginSteps} from './types.d';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {QuickLinks} from '@/screens/HomeModule/components';

export const LoginScreen = (props: LoginScreenProps) => {
  const inset = useSafeAreaInsets();
  const {
    pWord,
    step,
    loading,
    userId,
    company,
    pPhrase,
    onSubmitUsername,
    onConfirmPPhrase,
    onSubmitPWord,
    onReset,
    quickLinksData,
  } = useLogin(props);

  const renderLogin = () => {
    // Step 2 - confirm pPhrase
    if (step === LoginSteps.step2) {
      return (
        <>
          <LoginPPhrase userId={userId} companyId={company} pPhrase={pPhrase} />
          <View style={{flex: 1}} />
          <LoginConfirmPPhrase onYes={onConfirmPPhrase} onNo={onReset} />
        </>
      );
    }

    // Step 3 - enter pword
    if (step === LoginSteps.step3) {
      return (
        <>
          <LoginPPhrase
            showCancel
            userId={userId}
            companyId={company}
            onReset={onReset}
            pPhrase={pPhrase}
          />
          <LoginPWord
            value={pWord}
            loading={loading}
            onSubmit={onSubmitPWord}
          />
        </>
      );
    }

    // Step 1 - enter username
    return (
      <>
        <LoginUsername loading={loading} onSubmit={onSubmitUsername} />
        <View style={styles.footer}>
          <QuickLinks
            items={quickLinksData}
            containerStyle={{marginTop: 20, paddingHorizontal: 28}}
          />
        </View>
      </>
    );
  };

  return (
    <Screen variant={Screen.variant.paddingTopOnly}>
      <Navbar back />
      <View style={[styles.container, {paddingBottom: inset.bottom}]}>
        <View style={styles.header}>
          <Text as={Text.type.H3} style={styles.welcomeText}>
            Welcome to PB enterprise!
          </Text>
          <View style={styles.spacer} />
          <Text as={Text.type.P1} style={styles.subtitle}>
            Enter your credentials to log in
          </Text>
        </View>
        <View style={styles.content}>{renderLogin()}</View>
      </View>
    </Screen>
  );
};
