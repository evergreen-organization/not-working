import {colors} from '@/styles';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom: 24,
  },
  header: {
    justifyContent: 'center',
    marginTop: 80,
    marginBottom: 20,
    paddingHorizontal: 30,
  },
  spacer: {
    height: 12,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
  },
  subtitle: {
    color: colors.medium,
    marginTop: -5,
  },
  welcomeText: {
    color: colors.primary,
    fontSize: 24,
    // fontWeight: 'bold',
  },
  footer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 100,
  },
});
