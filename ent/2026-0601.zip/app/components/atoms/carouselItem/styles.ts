import {StyleSheet} from 'react-native';
import {colors} from '@/styles';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 10,
  },
  image: {
    resizeMode: 'contain',
    flex: 0.5,
    justifyContent: 'center',
  },
  title: {
    marginBottom: 10,
    color: colors.black,
    textAlign: 'center',
  },
  description: {
    color: colors.medium,
    textAlign: 'center',
    fontSize: 14,
  },
  textContainer: {
    flex: 0.4,
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  hyperlink: {
    textAlign: 'center',
    color: colors.primary,
    marginTop: 30,
  },
});
