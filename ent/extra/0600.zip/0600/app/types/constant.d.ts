export type UatEnvironment = boolean;

export interface UrlConfig {
  uri: string;
}

export type RoleType =
  | 'ROLE_ADMINISTRATOR'
  | 'ROLE_ADMINAUTHOR'
  | 'ROLE_VIEWER'
  | 'ROLE_MAKER'
  | 'ROLE_AUTHORISER'
  | 'ROLE_VERIFIER';

export interface IUserRoles {
  ROLE_ADMINISTRATOR: RoleType;
  ROLE_ADMINAUTHOR: RoleType;
  ROLE_VIEWER: RoleType;
  ROLE_MAKER: RoleType;
  ROLE_AUTHORISER: RoleType;
  ROLE_VERIFIER: RoleType;
}

export type BiometricSensorType = 'Face/Touch ID' | 'Fingerprint';

export interface BiometricAccess {
  FACE_ID: string;
  TOUCH_ID: string;
  FINGERPRINT: string;
}

export type SoftTokenApprovalResult =
  | 'SUCCESS'
  | 'FAIL'
  | 'REJECTED'
  | 'CANCELLED'
  | 'APPROVAL_REJECTED';

export type SoftTokenApprovalItemType =
  | 'PBSS_PENDING_APPROVAL'
  | 'FUND_TRANSFER'
  | 'PROFILE_MAINTENANCE'
  | 'PAYMENT'
  | 'FILE_UPLOAD'
  | 'FILE_UPLOAD_FILESTATUS'
  | 'DuitNow'
  | 'DuitNow_FILESTATUS'
  | 'ADMIN_APPROVAL'
  | 'PENDING_APPROVAL'
  | 'DEACTIVATEUSER'
  | 'OTHERS'
  | 'ADDED_TRANSACTION'
  | 'FIRST_LOGIN'
  | 'CALL_AUTHENTICATION'
  | 'KILL_SWITCH';

export interface SoftTokenApprovalResultMap {
  SUCCESS: SoftTokenApprovalResult;
  FAIL: SoftTokenApprovalResult;
  REJECTED: SoftTokenApprovalResult;
  CANCELLED: SoftTokenApprovalResult;
  APPROVAL_REJECTED: SoftTokenApprovalResult;
}

export interface SoftTokenApprovalItemTypeMap {
  PBSS_PENDING_APPROVAL: SoftTokenApprovalItemType;
  TRANSFER: SoftTokenApprovalItemType;
  PROFILE: SoftTokenApprovalItemType;
  PAYMENT: SoftTokenApprovalItemType;
  FILE_UPLOAD: SoftTokenApprovalItemType;
  FILE_UPLOAD_FILE_STATUS: SoftTokenApprovalItemType;
  DUIT_NOW: SoftTokenApprovalItemType;
  DUIT_NOW_FILE_STATUS: SoftTokenApprovalItemType;
  ADMIN_APPROVAL: SoftTokenApprovalItemType;
  PENDING_APPROVAL: SoftTokenApprovalItemType;
  DEACTIVATE_USER: SoftTokenApprovalItemType;
  DEFAULT: SoftTokenApprovalItemType;
  ADDED_TRANSACTION: SoftTokenApprovalItemType;
  FIRST_LOGIN: SoftTokenApprovalItemType;
  CALL_AUTHENTICATION: SoftTokenApprovalItemType;
  KILL_SWITCH: SoftTokenApprovalItemType;
}

export type NotificationActionType = 'pendingTrx' | 'requestToken';

export interface NotificationAction {
  PENDING_TRX: NotificationActionType;
  REQUEST_TOKEN: NotificationActionType;
}
