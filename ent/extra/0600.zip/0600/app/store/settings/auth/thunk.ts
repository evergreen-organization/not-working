import {createAsyncThunk} from '@reduxjs/toolkit';
import {eaiClient, handleResponse, privateClient, publicClient} from '@/api';
import qs from 'qs';
import {
  checkDemoFromCompanyUser,
  checkDemoFromState,
  checkDemoFromUserId,
} from '@/utils';
import {DemoData} from '@/constants';
import {END_POINTS, PATHS} from '@/services/endpoints';

const eaiConfig = {
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
  },
};

export const requestSession = createAsyncThunk(
  'auth/eaijct/requestSession',
  async (request, {dispatch, getState, rejectWithValue}) => {
    const result = await eaiClient.post(
      END_POINTS.REQUEST_SESSION,
      qs.stringify(request),
      eaiConfig,
    );
    return handleResponse({
      result,
      state: getState(),
      dispatch,
      rejectWithValue,
    });
  },
);

export const requestE2ee = createAsyncThunk('auth/eaijct/e2ee', () => {
  return eaiClient.get(PATHS.E2EE);
});

export const requestSessionLogin = createAsyncThunk(
  'auth/eaijct/login',
  async (request, {dispatch, getState, rejectWithValue}) => {
    const result = await eaiClient.post(
      END_POINTS.SESSION_LOGIN,
      qs.stringify(request),
      eaiConfig,
    );
    return handleResponse({
      result,
      state: getState(),
      dispatch,
      rejectWithValue,
    });
  },
);

export const requestLogin = createAsyncThunk(
  'auth/login',
  async (_, {dispatch, getState, rejectWithValue}) => {
    const {company, userId} = getState().settingEntities.auth || {};
    if (checkDemoFromCompanyUser(company, userId)) {
      return handleResponse({
        result: DemoData.Auth.Login,
        state: getState(),
        dispatch,
        rejectWithValue,
      });
    }
    const result = await privateClient.get(END_POINTS.LOGIN);
    return handleResponse({
      result,
      state: getState(),
      dispatch,
      rejectWithValue,
    });
  },
);

export const requestValidateIC = createAsyncThunk(
  'auth/validateIC',
  async (request, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromState(getState())) {
      return handleResponse({
        result: DemoData.Auth.ValidateIC,
        state: getState(),
        dispatch,
        rejectWithValue,
      });
    }
    const result = await privateClient.post(END_POINTS.VALIDATE_IC, request);
    return handleResponse({
      result,
      state: getState(),
      dispatch,
      rejectWithValue,
    });
  },
);

export const requestLogout = createAsyncThunk(
  'auth/logout',
  async ({isPublic = true, accessToken}) => {
    let result;
    if (isPublic) {
      if (accessToken) {
        publicClient.setHeaders({'ACCESS-TOKEN': accessToken});
      }
      result = await publicClient.get(END_POINTS.LOG_OUT_PUBLIC);
    } else {
      result = await privateClient.get(END_POINTS.LOG_OUT_PRIVATE);
      eaiClient.get('/pkmslogout').then(); //to logout webseal
    }
    return result.data;
  },
);

export const requestCSRF = createAsyncThunk(
  'auth/csrf',
  async (_, {dispatch, getState, rejectWithValue}) => {
    let result = await publicClient.get(END_POINTS.CSRF);
    return handleResponse({
      result,
      state: getState(),
      dispatch,
      rejectWithValue,
    });
  },
);

export const requestQuickLogin = createAsyncThunk(
  'auth/quickLogin',
  async (request, {dispatch, getState, rejectWithValue}) => {
    const {deviceId, encryptedId, pin} = request;
    if (
      checkDemoFromState(getState()) ||
      checkDemoFromUserId(request?.userId)
    ) {
      if (request?.pin6d === DemoData.User.pin) {
        return handleResponse({
          result: DemoData.Auth.Quick_Login,
          state: getState(),
          dispatch,
          rejectWithValue,
        });
      }
      return handleResponse({
        result: DemoData.Auth.Quick_Login_Fail,
        state: getState(),
        dispatch,
        rejectWithValue,
      });
    }
    const result = await publicClient.post(END_POINTS.QUICK_LOGIN, {
      deviceId,
      encryptedId,
      pin,
    });
    return handleResponse({
      result,
      state: getState(),
      dispatch,
      rejectWithValue,
    });
  },
);

export const requestPac = createAsyncThunk(
  'auth/requestPac',
  async (
    {isPublic, tranType, deviceId, encryptedId, userId},
    {rejectWithValue, dispatch, getState},
  ) => {
    //During registration, user state is null there can't get user info.
    if (checkDemoFromUserId(userId)) {
      return handleResponse({
        result: DemoData.Auth.Pac,
        state: getState(),
        dispatch,
        rejectWithValue,
      });
    }
    let result = isPublic
      ? await publicClient.post(END_POINTS.REQUEST_PAC_PUBLIC, {
          tranType,
          deviceId,
          encryptedId,
        })
      : await privateClient.post(END_POINTS.REQUEST_PAC_PRIVATE, {
          tranType,
          deviceId,
          encryptedId,
        });

    return handleResponse({
      result,
      state: getState(),
      dispatch,
      rejectWithValue,
    });
  },
);

export const requestBind = createAsyncThunk(
  'auth/bind',
  async (request, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromUserId(request.userId)) {
      if (request.secfa === DemoData.User.pac) {
        return handleResponse({
          result: DemoData.Auth.Bind,
          state: getState(),
          dispatch,
          rejectWithValue,
        });
      }
      return handleResponse({
        result: DemoData.Auth.Bind_Fail,
        dispatch,
        rejectWithValue,
        state: getState(),
      });
    }
    let result = await privateClient.post(END_POINTS.REQUEST_BINDING, request);
    return handleResponse({
      result,
      dispatch,
      rejectWithValue,
      state: getState(),
    });
  },
);

export const requestUnbind = createAsyncThunk('auth/unbind', () => {
  return publicClient.get(END_POINTS.UNBIND_DEVICE);
});

export const requestRegistrationUnbind = createAsyncThunk(
  'auth/registrationUnbind',
  async (_, {dispatch, getState, rejectWithValue}) => {
    const result = await privateClient.get(END_POINTS.UNBIND_DEVICE);
    return handleResponse({
      result,
      state: getState(),
      dispatch,
      rejectWithValue,
    });
  },
);

export const requestChangePin = createAsyncThunk(
  'auth/changePin',
  async (request, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromUserId(request.userId)) {
      return handleResponse({
        result: DemoData.Auth.Pac,
        state: getState(),
        dispatch,
        rejectWithValue,
      });
    }
    const result = await publicClient.post(END_POINTS.CHANGE_PIN, request);
    return handleResponse({
      result,
      dispatch,
      rejectWithValue,
      state: getState(),
    });
  },
);

export const requestForgotPin = createAsyncThunk(
  'auth/forgotPin',
  async (request, {dispatch, getState, rejectWithValue}) => {
    const result = await publicClient.post(END_POINTS.FORGOT_PIN, request);
    return handleResponse({
      result,
      dispatch,
      rejectWithValue,
      state: getState(),
    });
  },
);

export const requestEmailPac = createAsyncThunk(
  'auth/requestEmailPac',
  async (_, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromState(getState())) {
      return handleResponse({
        result: DemoData.Auth.RequestEmailPac,
        state: getState(),
        dispatch,
        rejectWithValue,
      });
    }
    const result = await privateClient.get(END_POINTS.REQUEST_EMAIL_PAC);
    return handleResponse({
      result,
      dispatch,
      rejectWithValue,
      state: getState(),
    });
  },
);

export const validateEmailPac = createAsyncThunk(
  'auth/validateEmailPac',
  async ({emailPac}, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromState(getState())) {
      return handleResponse({
        result: DemoData.Auth.ValidateEmail,
        state: getState(),
        dispatch,
        rejectWithValue,
      });
    }
    const result = await privateClient.post(END_POINTS.VALIDATE_EMAIL_PAC, {
      emailPac,
    });
    return handleResponse({
      result,
      dispatch,
      rejectWithValue,
      state: getState(),
    });
  },
);

export const validatePin = createAsyncThunk(
  'auth/validatePin',
  async ({pin}, {dispatch, getState, rejectWithValue}) => {
    if (checkDemoFromState(getState())) {
      return handleResponse({
        result: DemoData.Auth.ValidatePin,
        state: getState(),
        dispatch,
        rejectWithValue,
      });
    }
    const result = await publicClient.post(END_POINTS.VALIDATE_PIN, {
      pin,
    });
    return handleResponse({
      result,
      dispatch,
      rejectWithValue,
      state: getState(),
    });
  },
);

export const requestUnbindSingle = createAsyncThunk(
  'auth/unbindSingle',
  async ({deviceId, encryptedId}, {dispatch, rejectWithValue, getState}) => {
    if (checkDemoFromState(getState())) {
      return handleResponse({
        result: DemoData.Auth.UnbindSingle,
        state: getState(),
        dispatch,
        rejectWithValue,
      });
    }
    const result = await privateClient.post(END_POINTS.UNBIND_SINGLE, {
      deviceId,
      encryptedId,
    });
    return handleResponse({
      result,
      dispatch,
      rejectWithValue,
      state: getState(),
    });
  },
);
