import React, {useState, useEffect} from 'react';
import {View, Text} from 'react-native';
import Svg, {Rect} from 'react-native-svg';
import dayjs from 'dayjs';

const parseDateString = (dateString: string): number => {
  try {
    const notificationTime = dayjs(
      dateString,
      'DD MMM YYYY hh:mm:ss A',
    ).valueOf();
    const currentTime = dayjs().valueOf();

    const totalTime = Math.max(
      0,
      Math.ceil((notificationTime - currentTime) / 1000),
    );
    if (isNaN(totalTime)) {
      throw new Error('Invalid date string');
    }
    return totalTime;
  } catch (error) {
    console.error('Error parsing date string:', error);
    return dayjs().valueOf();
  }
};

export const Timer = ({date, duration = 30, onExpire}: any) => {
  const dateTimestamp = typeof date === 'string' ? parseDateString(date) : date;

  const [timeLeft, setTimeLeft] = useState<number>(dateTimestamp);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => {
        setTimeLeft(prevTimeLeft => Math.max(0, prevTimeLeft - 1));
      }, 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && onExpire) {
      onExpire();
    }
  }, [timeLeft, onExpire]);

  return (
    <View style={{width: '100%'}}>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          width: '100%',
        }}
      >
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: 18,
            color:
              timeLeft > 10 ? '#10B981' : timeLeft > 5 ? '#F59E0B' : '#EF4444',
          }}
        >
          {timeLeft}s
        </Text>
        <Text
          style={{
            marginLeft: 4,
            color:
              timeLeft > 10 ? '#10B981' : timeLeft > 5 ? '#F59E0B' : '#EF4444',
          }}
        >
          remaining
        </Text>
      </View>
      <View style={{marginTop: 8, flex: 1}}>
        <Svg width="100%" height={20}>
          <Rect x={0} y={0} width="100%" height={20} rx={10} fill="#E5E7EB" />
          <Rect
            x={0}
            y={0}
            width={`${((duration - timeLeft) / duration) * 100}%`}
            height={20}
            rx={10}
            fill={
              timeLeft > 10 ? '#10B981' : timeLeft > 5 ? '#F59E0B' : '#EF4444'
            }
          />
        </Svg>
      </View>
    </View>
  );
};
