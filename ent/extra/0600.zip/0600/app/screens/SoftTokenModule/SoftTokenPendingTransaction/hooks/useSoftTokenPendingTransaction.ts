import {handleResponse} from '@/api';
import {
  ERR_MSG_PIN_LOCKED,
  NOTIFICATION_ACTION,
  rejectionReasonMaxCharacter,
  rejectionReasonRegex,
  SOFT_TOKEN_APPROVAL_RESULT,
  validationMsg,
} from '@/constants';
import {useAppState, useSession, useTranslation} from '@/hooks';
import {routes} from '@/navigations';
import {
  ERROR_AUTHENTICATION_EXPIRED,
  PBSecureSign,
  rejectPendingTransactionApi,
  rejectTransactionReasonApi,
  retrievePendingTransaction,
} from '@/softToken';
import {
  PBSS_CALLER_AUTH,
  PBSS_SECURE_PAC,
  PBSS_SECURE_PAC_INPUT,
} from '@/softToken/component/constant';
import {
  getCurrentUser,
  getNotificationData,
  getSoftTokenPendingTransaction,
  notificationDataReset,
  paymentAuthReset,
  softTokenPendingTranReset,
  useAppDispatch,
} from '@/store';
import {ApplicationNavigatorProps} from '@/types/navigation';
import {clearIOSBadgeNotification, showFailure} from '@/utils';
import {useEffect, useRef, useState} from 'react';
import {useSelector} from 'react-redux';
import * as Yup from 'yup';
import {isTransactionApproval} from '../utils';

export const useSoftTokenPendingTransaction = ({
  navigation,
}: ApplicationNavigatorProps<routes.SOFT_TOKEN_PENDING_TRANSACTION>) => {
  const {t} = useTranslation();
  const validationSchema = Yup.object().shape({
    reason: Yup.string()
      .required(t(validationMsg.rejectionRequired))
      .label(t('Reason'))
      .matches(rejectionReasonRegex, t(validationMsg.rejectionReason))
      .max(rejectionReasonMaxCharacter),
  });

  useSession();
  const dispatch = useAppDispatch();
  const state = useSelector((_state: any) => _state);
  const isBackground = useAppState();

  const [initialRender, setInitialRender] = useState(true);
  const [loading, setLoading] = useState(false);
  const [submissionLoading, setSubmissionLoading] = useState(false);
  const [rejectionModal, setRejectionModal] = useState(false);

  const notificationData = useSelector(getNotificationData) as any;
  const pendingTran = useSelector(getSoftTokenPendingTransaction) as any;
  const [transactions, setTransactions] = useState<any[]>([]);
  const {userId} = useSelector(getCurrentUser);

  const [activated, setActivated] = useState(false);
  const [initType, setInitType] = useState(PBSecureSign.type.pin);
  const [transactionObj, setTransactionObj] = useState({
    transactionId: pendingTran?.transactionId,
    pendingTransactionId: '',
    isPublic: true,
    softTokenType: pendingTran?.softTokenType,
  });
  const formRef = useRef<any>();
  const initialValues = {reason: ''};

  const isBackgroundRef = useRef(isBackground);

  useEffect(() => {
    setInitialRender(false);
    (async () => {
      await onInit();
      await clearIOSBadgeNotification();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingTran]);

  useEffect(() => {
    if (initialRender || isBackground) {
      return;
    }

    if (notificationData?.action === NOTIFICATION_ACTION.PENDING_TRX) {
      if (notificationData?.id === userId) {
        onRefresh();
      }
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notificationData]);

  useEffect(() => {
    if (initialRender || isBackground) {
      return;
    }

    if (isBackgroundRef.current && !isBackground) {
      onRefresh();
    }
    isBackgroundRef.current = isBackground;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isBackground]);

  const setSecfaType = (softTokenType: any) => {
    if (softTokenType === PBSS_SECURE_PAC) {
      return setInitType(PBSecureSign.type.pinPac);
    }
    if (softTokenType === PBSS_SECURE_PAC_INPUT) {
      return setInitType(PBSecureSign.type.pinPacInput);
    }
    if (softTokenType === PBSS_CALLER_AUTH) {
      return setInitType(PBSecureSign.type.pin);
    }
    return setInitType(PBSecureSign.type.pin);
  };

  const onInit = async () => {
    if (pendingTran?.transactionId) {
      setLoading(true);
      setSecfaType(pendingTran.softTokenType);
      setTransactionObj({
        ...transactionObj,
        softTokenType: pendingTran?.softTokenType,
        transactionId: pendingTran?.transactionId,
      });
      const {
        status,
        data: decodedTransaction,
        errorCode,
        errorMessage,
      } = await retrievePendingTransaction(pendingTran);

      if (status !== 'S') {
        setLoading(false);
        return showFailure(`${errorCode}: ${t(errorMessage || '')}`);
      }

      if (Array.isArray(decodedTransaction)) {
        setTransactions(decodedTransaction);
      }
      setLoading(false);
    }
    dispatch(softTokenPendingTranReset());
    dispatch(paymentAuthReset());
    if (notificationData?.id === userId) {
      dispatch(notificationDataReset());
    }
  };

  const onRefresh = () => {
    navigation.navigate(routes.SOFT_TOKEN_LOADING_TRANSACTION);
  };

  const onApprove = async () => {
    setSubmissionLoading(true);
    setActivated(true);
  };

  const handleReject = () => {
    //Approver Rejection
    if (
      isTransactionApproval(transactionObj?.softTokenType) &&
      transactionObj?.softTokenType !== PBSS_CALLER_AUTH
    ) {
      return showRejectionReason();
    }

    //Maker Rejection
    return callRejectionApi({
      api: rejectPendingTransactionApi,
      request: {transactionId: transactionObj.transactionId},
    });
  };

  //Call Rejection Api
  const callRejectionApi = async ({api, request}: any) => {
    setSubmissionLoading(true);
    const result = await api(request);
    const response = handleResponse({
      result,
      state,
      dispatch,
      rejectWithValue: null,
    } as any);
    setSubmissionLoading(false);

    const authenticationExpired =
      response.status === ERROR_AUTHENTICATION_EXPIRED;

    if (response?.problem && !authenticationExpired) {
      showFailure(response.problem);
      return onCancel({});
    }

    const rejectionProps = {
      authenticationExpired,
      refNo: response?.refNo,
      timeStamp: response?.refDateTime,
      isApproval: isTransactionApproval(transactionObj?.softTokenType),
    };

    return onRejectionComplete(rejectionProps);
  };

  const showRejectionReason = () => {
    setRejectionModal(true);
  };

  const onRejectionCancel = () => {
    setRejectionModal(false);
  };

  const onRejectionConfirm = () => formRef.current.handleSubmit();

  const onRejectionSubmit = async ({reason}: any) => {
    setRejectionModal(false);

    return callRejectionApi({
      api: rejectTransactionReasonApi,
      request: {
        transactionId: transactionObj.transactionId,
        rejectReason: reason,
      },
    });
  };

  const onRejectionComplete = ({
    authenticationExpired,
    refNo,
    timeStamp,
    isApproval,
  }: any) => {
    dispatch(softTokenPendingTranReset());
    dispatch(paymentAuthReset());

    const rejectionType = isApproval
      ? SOFT_TOKEN_APPROVAL_RESULT.APPROVAL_REJECTED
      : SOFT_TOKEN_APPROVAL_RESULT.REJECTED;
    const type = authenticationExpired
      ? SOFT_TOKEN_APPROVAL_RESULT.FAIL
      : rejectionType;
    navigation.navigate(routes.MAIN_TAB);
    navigation.navigate(routes.SOFT_TOKEN_APPROVAL_MESSAGE, {
      type,
      refNo,
      timeStamp,
    });
  };

  const onCancel = (result: any) => {
    setActivated(false);
    setLoading(false);
    setSubmissionLoading(false);

    if (result?.quit) {
      return navigation.navigate(routes.MAIN_TAB);
    }
  };

  const onComplete = (result: any) => {
    setActivated(false);
    setLoading(false);
    setSubmissionLoading(false);
    const {isSuccess, isPinLocked, response} = result || {};

    if (isPinLocked) {
      showFailure(t(ERR_MSG_PIN_LOCKED));
      navigation.navigate(routes.MAIN_TAB);
      return (navigation.navigate as any)(routes.FORGOT_PIN, {
        userId: userId || '',
      });
    }

    if (!isSuccess) {
      navigation.navigate(routes.MAIN_TAB);
      return navigation.navigate(routes.SOFT_TOKEN_APPROVAL_MESSAGE, {
        type: SOFT_TOKEN_APPROVAL_RESULT.FAIL,
        refNo: response?.refNo,
        timeStamp: response?.refDateTime,
      });
    }
    if (initType === PBSecureSign.type.pinPac) {
      return navigation.navigate(routes.MAIN_TAB);
    }

    dispatch(softTokenPendingTranReset());
    dispatch(paymentAuthReset());
    navigation.navigate(routes.MAIN_TAB);
    return navigation.navigate(routes.SOFT_TOKEN_APPROVAL_MESSAGE, {
      type: SOFT_TOKEN_APPROVAL_RESULT.SUCCESS,
      refNo: response?.refNo,
      timeStamp: response?.refDateTime,
    });
  };

  const onClose = () => navigation.navigate(routes.MAIN_TAB);

  return {
    onApprove,
    handleReject,
    onComplete,
    onCancel,
    onRefresh,
    onClose,
    onRejectionConfirm,
    onRejectionSubmit,
    onRejectionCancel,
    data: transactions,
    loading,
    submissionLoading,
    activated,
    transactionObj,
    initType,
    initialValues,
    rejectionModal,
    formRef,
    validationSchema,
  };
};
