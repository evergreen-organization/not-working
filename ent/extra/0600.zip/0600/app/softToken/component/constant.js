export const PBSS_PIN = 'SOFT_TOKEN_PN';
export const PBSS_CALLER_AUTH = 'SOFT_TOKEN_MA';
export const PBSS_SECURE_PAC = 'SECURE_PAC';
export const PBSS_SECURE_PAC_INPUT = 'SECURE_PAC_INPUT';
export const PBSS_NO_SECFA = 'NOT_REQUIRED';

export const PBSS_SECFA_DUPLICATE = 'PBSS_SECFA_DUPLICATE';
export const PBSS_SECFA_OPTIONS = 'PBSS_SECFA_OPTIONS';
export const PBSS_SECFA_WARNING = 'PBSS_SECFA_WARNING';

export const SECFA_OPTIONS = [
  {id: PBSS_PIN, title: 'Soft Token'},
  {id: PBSS_SECURE_PAC, title: 'Secure Pac'},
  {id: PBSS_SECURE_PAC_INPUT, title: 'Secure Pac Input'},
  {id: PBSS_CALLER_AUTH, title: 'Call Authentication'},
];

export const getSecfaOptionsData = () => {
  return SECFA_OPTIONS;
};
