import React, {useEffect, useState} from 'react';
import {PBSecureSignView} from './component';
import {
  PBSS_PIN,
  PBSS_SECURE_PAC,
  PBSS_SECURE_PAC_INPUT,
} from '../component/constant';
import {useSelector} from 'react-redux';
import {useAppDispatch} from '@/store';
import {validateTransactionSignature} from '../transAuthUtils';
import {showFailure} from '@/utils';

export const PBSecureSign = ({
  initType,
  transactionObj,
  onComplete,
  onCancel: onCancelAction,
  activated,
}) => {
  const dispatch = useAppDispatch();
  const state = useSelector(_state => _state);

  const {transactionId, isPublic} = transactionObj || {};

  const [data, setData] = useState({...transactionObj});
  const [step, setStep] = useState(0);
  const [type, setType] = useState(null);
  useEffect(() => {
    setData({...transactionObj});
  }, [transactionObj]);

  useEffect(() => {
    if (activated) {
      start();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activated]);

  const start = () => {
    if (initType) {
      setType(initType[step]);
    }
  };

  const resetState = () => {
    setStep(0);
    setType(null);
    setData(null);
  };

  const onCancel = result => {
    resetState();
    onCancelAction(result);
  };

  const onFailure = result => {
    resetState();
    onComplete({...result, isSuccess: false});
  };

  const onSuccess = async result => {
    const currentStep = step + 1;

    setType(initType[currentStep]);

    if (currentStep < initType.length) {
      setStep(currentStep);
      return setData({...data, ...result?.data});
    }

    /* Secure Pin only to validate signature
     Others to validate elsewhere
     Signature validation:
     Pac Display: to be validated with pac input on web
     Pac Input: to validate user input
     Pin Signature: to get signature to proceed with transaction submission api call
    */
    if (initType === PBSecureSign.type.pin) {
      const validationRequest = {
        isPublic,
        transactionId,
        signature: result?.data?.signature,
        state,
        dispatch,
      };

      const response = await validateTransactionSignature(validationRequest);
      const {authenticationExpired, problem, errorMsg} = response;

      if (errorMsg) {
        showFailure(errorMsg);
        return onCancel();
      }

      if (authenticationExpired || problem) {
        return onFailure({authenticationExpired, response});
      }

      return onComplete({isSuccess: true, response});
    }

    return onComplete({isSuccess: true, response: {...result?.data}});
  };

  const props = {
    onCancel,
    onSuccess,
    onFailure,
    type,
    data,
    state,
    dispatch,
    isPublic,
  };

  return <PBSecureSignView {...props} />;
};

PBSecureSign.type = {
  pin: [PBSS_PIN],
  pinPac: [PBSS_PIN, PBSS_SECURE_PAC],
  pinPacInput: [PBSS_PIN, PBSS_SECURE_PAC_INPUT],
  pinSignature: [PBSS_PIN],
  callerAuth: [PBSS_PIN],
};
